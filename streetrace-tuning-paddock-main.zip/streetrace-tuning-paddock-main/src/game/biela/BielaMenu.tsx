import { useMemo, useState } from "react";
import { brl, setPlayer, type Player } from "../store";
import { hasGasket, mountRod, scanRods } from "./smart-rod";

export function BielaMenu({ p, onExit }: { p: Player; onExit: () => void }) {
  const sc = useMemo(() => scanRods(p), [p]);
  const [msg, setMsg] = useState<string | null>(null);
  const mount = (id: string) => {
    const next = mountRod(p, id);
    if (!hasGasket(p)) return setMsg("Falta o kit de juntas do motor. Compre na Auto Peças › Motor.");
    if (next === p) return setMsg("Não deu pra montar: saldo ou pino não confere.");
    setPlayer(() => next); setMsg("Biela montada.");
  };
  return (
    <div className="absolute inset-0 z-40 flex flex-col overflow-y-auto bg-background/95 p-3">
      <h2 className="text-center font-display text-lg text-primary">Biela inteligente</h2>
      <div className="text-center text-xs text-muted-foreground">Saldo {brl(p.money)}</div>
      {!sc ? <p className="mt-6 text-center text-sm">Escolha uma moto na garagem.</p> : (
        <div className="mx-auto mt-3 w-full max-w-md space-y-2">
          <div className="rounded-xl bg-secondary/70 p-3 text-sm">
            <div>Pistão montado: <b>{sc.pistonName}</b></div>
            <div>Pino do pistão: <b>{sc.pistonPin ?? "sem ficha"} mm</b></div>
            <div>Corte do motor: <b>{sc.rpmLimit} rpm</b></div>
            <div>Kit de juntas do motor: <b className={hasGasket(p) ? "" : "text-destructive"}>{p.parts.filter((x) => x === `junta-motor-${p.activeBike}`).length} no estoque</b> · gasta 1 ao abrir</div>
            <div>Biela montada: <b>{sc.mounted?.factory ? "Original" : sc.mounted?.name ?? "Original"}</b></div>
          </div>
          {msg && <p className="text-center text-xs text-accent">{msg}</p>}
          {sc.options.map((o) => {
            const rec = o.part.id === sc.best;
            return (
              <div key={o.part.id} className={`rounded-xl border p-3 text-sm ${rec ? "border-primary bg-primary/15" : "border-border bg-secondary/50"} ${o.ok ? "" : "opacity-60"}`}>
                <div className="flex items-center justify-between gap-2"><b>{o.part.brand} · {o.part.name}</b>{rec && <span className="text-[10px] font-bold text-primary">RECOMENDADA</span>}</div>
                <div className="text-xs text-muted-foreground">{o.part.spec}</div>
                <div className="mt-1 text-xs">Pino {o.pin ?? "?"} mm · aguenta {o.part.rodRpm ?? "?"} rpm{o.margin != null && ` · ${o.margin >= 0 ? "folga" : "falta"} ${Math.abs(o.margin)} rpm`}</div>
                {o.why && <div className="text-xs text-destructive">Não serve: {o.why}</div>}
                {o.margin != null && o.margin < 0 && o.ok && <div className="text-xs text-destructive">Risco de quebra acima de {o.part.rodRpm} rpm</div>}
                <button disabled={!o.ok || o.mounted || (!o.owned && p.money < o.price)} onClick={() => mount(o.part.id)} className="mt-2 w-full rounded-lg bg-primary py-1.5 text-xs font-bold text-primary-foreground disabled:opacity-40">
                  {o.mounted ? "MONTADA" : !o.ok ? "INCOMPATÍVEL" : o.owned ? "MONTAR (no estoque)" : `COMPRAR E MONTAR · ${brl(o.price)}`}
                </button>
              </div>
            );
          })}
        </div>
      )}
      <button onClick={onExit} className="mx-auto mt-4 w-full max-w-md rounded-xl bg-secondary py-2 font-bold">Voltar</button>
    </div>
  );
}
