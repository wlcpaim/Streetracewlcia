// Menu Biela inteligente: identifica o pino do pistão montado e o giro do motor, e escolhe a biela que serve.
import { PARTS_CATALOG, partById, type Part } from "../parts";
import { bikeModel, engine } from "../physics";
import { partReleased } from "../startgame";
import { compatOf } from "../platform/compat";
import { pinDe } from "../pins/pins";
import { priceNow } from "../economy";
import type { Player } from "../store";

/** Folga de giro que a biela precisa ter acima do corte do motor (rpm). */
export const ROD_MARGIN_RPM = 500;

export interface RodOption { part: Part; pin: number | null; ok: boolean; why: string | null; owned: boolean; mounted: boolean; price: number; margin: number | null }
export interface RodScan { pistonPin: number | null; pistonName: string; rpmLimit: number; mounted: Part | undefined; options: RodOption[]; best: string | null }

export function scanRods(p: Player): RodScan | null {
  const bike = p.activeBike;
  if (!bike) return null;
  const s = p.setup, pis = s.slots.pistao, cur = s.slots.biela;
  const pistonPin = pinDe(pis, bike), rpmLimit = Math.round(engine(bikeModel(bike), s).rpmLimit);
  const options = PARTS_CATALOG.filter((x) => x.kind === "biela" && !x.factory && partReleased(x.id) && compatOf(x, bike).c !== "INCOMPATIVEL").map((x): RodOption => {
    const pin = pinDe(x.id, bike);
    const bad = pin != null && pistonPin != null && pin !== pistonPin;
    const margin = x.rodRpm ? x.rodRpm - rpmLimit : null;
    return { part: x, pin, ok: !bad, why: bad ? `olhal ${pin} mm, pino do pistão ${pistonPin} mm` : null, owned: p.parts.includes(x.id), mounted: cur === x.id, price: priceNow(x), margin };
  });
  const fit = options.filter((o) => o.ok && o.margin != null);
  const safe = fit.filter((o) => o.margin! >= ROD_MARGIN_RPM).sort((a, b) => (a.owned === b.owned ? a.price - b.price : a.owned ? -1 : 1));
  const best = (safe[0] ?? fit.sort((a, b) => b.margin! - a.margin!)[0])?.part.id ?? null;
  return { pistonPin, pistonName: partById(pis)?.name ?? "Original", rpmLimit, mounted: partById(cur), options, best };
}

/** Compra (se faltar) e monta a biela na hora; a biela retirada volta pro estoque. */
/** Kit de juntas do motor da moto ativa (gasto 1 por abertura do motor). */
export const gasketId = (bike: string | null | undefined) => (bike ? `junta-motor-${bike}` : "");
export const hasGasket = (p: Player) => p.parts.includes(gasketId(p.activeBike));

export function mountRod(p: Player, id: string): Player {
  const sc = scanRods(p), o = sc?.options.find((x) => x.part.id === id);
  if (!sc || !o || !o.ok || o.mounted) return p;
  if (!o.owned && p.money < o.price) return p;
  if (!hasGasket(p)) return p; // abrir o motor gasta 1 kit de juntas
  const parts = [...p.parts];
  parts.splice(parts.indexOf(gasketId(p.activeBike)), 1);
  if (o.owned) parts.splice(parts.indexOf(id), 1);
  const old = p.setup.slots.biela;
  if (old && !partById(old)?.factory) parts.push(old);
  return { ...p, money: o.owned ? p.money : Math.round((p.money - o.price) * 100) / 100, parts, setup: { ...p.setup, slots: { ...p.setup.slots, biela: id } } };
}
