// Garagem com várias motos: cada moto guarda o próprio acerto e tanque; venda à concessionária paga 80% da tabela.
import { BIKE_MODELS, factoryGear, stockSetupOf, type Setup } from "./physics";
import type { Player } from "./store";
import { partById } from "./parts";

export const MAX_BIKES = 5;
/** Concessionária recompra pagando esta fração do preço de tabela (perde 20%). */
export const RESALE_SHARE = 0.8;
export const tablePrice = (id: string) => BIKE_MODELS.find((b) => b.id === id)?.price ?? 0;
export const resaleValue = (id: string) => Math.round(tablePrice(id) * RESALE_SHARE);
export const garageFull = (p: Pick<Player, "bikes">) => p.bikes.length >= MAX_BIKES;

type Stored = { setup: Setup; fuelL: number };

/** Peça montada neste acerto (slot ou relação). */
export function mountedOn(s: Pick<Setup, "slots" | "front" | "rear">, id: string): boolean {
  const x = partById(id);
  if (!x) return false;
  return x.kind === "pinhao" ? s.front === x.front : x.kind === "coroa" ? s.rear === x.rear : x.kind === "kit" ? s.front === x.front && s.rear === x.rear : (s.slots as Record<string, string>)[x.kind] === id;
}
/** Cópias desta peça presas nas motos guardadas na garagem (não ativas): continuam nelas e não voltam ao estoque. */
export function mountedElsewhere(p: { garage?: Player["garage"] | undefined; activeBike: string | null; bikes: string[] }, id: string): number {
  return Object.entries(p.garage ?? {}).filter(([bike, v]) => bike !== p.activeBike && p.bikes.includes(bike) && v?.setup && mountedOn(v.setup, id)).length;
}
const stash = (p: Player): Record<string, Stored> => ({ ...(p.garage ?? {}), ...(p.activeBike ? { [p.activeBike]: { setup: p.setup, fuelL: p.fuelL } } : {}) });

/** Troca a moto ativa guardando o acerto da atual. */
export function switchBike(p: Player, id: string): Player {
  if (!p.bikes.includes(id) || id === p.activeBike) return p;
  const g = stash(p), t = g[id] ?? { setup: { ...stockSetupOf(id), psi: SHOP_PSI }, fuelL: 0 };
  delete g[id];
  return { ...p, garage: g, activeBike: id, setup: t.setup, fuelL: t.fuelL };
}

/** Compra: guarda a moto atual e entra a nova com acerto de fábrica e tanque vazio. */
/** Toda moto sai da loja com 40 psi. */
export const SHOP_PSI = 40;
export function addBike(p: Player, id: string): Player {
  if (p.bikes.includes(id) || garageFull(p) || p.money < tablePrice(id)) return p;
  return { ...p, garage: stash(p), money: p.money - tablePrice(id), bikes: [...p.bikes, id], parts: [...p.parts, ...[`pinhao-${factoryGear(id).front}`, `coroa-${factoryGear(id).rear}`].filter((g) => !p.parts.includes(g))], activeBike: id, setup: { ...stockSetupOf(id), psi: SHOP_PSI }, fuelL: 0 };
}

/** Venda à concessionária por 80% da tabela; a próxima moto da garagem vira a ativa. */
export function sellBike(p: Player, id: string): Player {
  if (!p.bikes.includes(id) || (id === p.activeBike && p.broken)) return p;
  const g = stash(p);
  delete g[id];
  const bikes = p.bikes.filter((b) => b !== id);
  const base = { ...p, money: p.money + resaleValue(id), bikes, garage: g };
  if (id !== p.activeBike) return base;
  const next = bikes[0];
  if (!next) return { ...base, activeBike: null, setup: stockSetupOf("titan160"), fuelL: 0 };
  const t = g[next] ?? { setup: stockSetupOf(next), fuelL: 0 };
  delete g[next];
  return { ...base, activeBike: next, setup: t.setup, fuelL: t.fuelL };
}
