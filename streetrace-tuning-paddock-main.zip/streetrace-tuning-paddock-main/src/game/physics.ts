import { fuelUsdMul } from "./economy";
import { tbiAirGain } from "./airflow";
import { CAM_FX, PARTS_CATALOG, clutchCapNm, STOCK_SLOTS, partById, slotPart, type Cam, type Slot } from "./parts";
import WORKSHOP from "./data/workshop_services.json";
import { exhaustAt, exhaustSpec } from "./exhaust";
import { escapePeakShiftRpm, matchVE } from "./sintonia";
import { DEFAULT_REC_PSI, crrAt, recPsiOf, tireState, tireGeometry } from "./tire";
import { MU_ASPHALT, TIRE, groundStep, newGround, slideMul, tempGrip, tractionLimit, wheelieForce, type Ground } from "./ground";
import { K } from "./physics-registry/constants";
import { dragForce, pitchGeometry, raceEffectiveMass, rearSpinMass, rollingForce } from "./vehicle-dynamics";

export interface Service {
  id: string;
  group: string;
  name: string;
  price: number;
  hpMul?: number;
  rpmPeak?: number;
  need?: number;
  stress?: number;
  relief?: number;
  exclusive?: string;
  needsCavas?: boolean;
  /** Opens valve pockets in the installed piston. */
  cavas?: boolean;
  clearOnRebuild?: boolean;
  /** Bench prep on a stock kit before mounting (kit stays in stock; blocked once mounted). */
  prepFor?: string;
  /** Stock parts the mechanic mounts with this job (equipped when done). */
  requires?: string[];
  /** Pure assembly job for this part id (sets the slot, not stored in services). */
  install?: string;
  /** Old measure kept only so saves, kits and rivals keep working; not offered in the menus. */
  legacy?: boolean;
}
export const SERVICE_GROUPS = WORKSHOP.groups;
export const SERVICES = WORKSHOP.services as Service[];

// Realistic-ish longitudinal physics for StreetRace.
// Power and weight come from the bike setup; weight changes acceleration, not engine power.

export type Fuel = "gasolina" | "etanol";
import { blendFx, type Blend } from "./fuelmix";
import { alcoolGain } from "./alcool";
import { ENGINE_CATALOG, strokeMmOf } from "./data/engine_catalog";
import { effectiveModulo, hasElectronicCut, ignitionRpmLimit, ignitionOf, sparkEnergy } from "./ignition";
import { platformOf } from "./platform/platforms";
export type Exhaust = "original" | "dore";
export type Tire = "original" | "fino";

export interface Setup {
  fuel: Fuel;
  exhaust: Exhaust;
  removed: { mirrors: boolean; rabeta: boolean; frontBrake: boolean };
  airFilter: AirFilter;
  /** Final drive: pinhão (front) x coroa (rear) teeth. */
  front: number;
  rear: number;
  slots: Record<Slot, string>;
  /** Tire pressure (psi). */
  psi: number;
  /** Tank blend fractions (Gasolina C, Podium, Etanol, Metanol); unset = pure base fuel. */
  blend?: Blend;
  /** Tread wear 0 (new) to 1 (dead), set from Player.tireKm before a run; worn tread loses grip. */
  tireWear?: number;
  /** Desgaste acumulado da embreagem 0 (nova) a 1 (gasta): discos gastos transmitem menos torque. */
  clutchWear?: number;
  /** Installed head compression ratio. */
  compression: number;
  cam: Cam;
  /** Odometer and km since last oil change. */
  km: number;
  /** Odometer reading when the engine was last rebuilt (break-in restarts there). */
  engineKm0?: number;
  oilKm: number;
  /** Programmable ECU map (used only with a programmable módulo). */
  ecu: Ecu;
  /** Oficina machining services done on this engine. */
  services: string[];
  /** Rider body mass (kg); defaults to RIDER_KG. */
  riderKg?: number;
  /** Free machining done by writing to the mechanic (mm); unset = untouched. See machining.ts. */
  mach?: { cavaMm?: number; rebaixoMm?: number; domeMm?: number; assentoMm?: number; cavaDiam?: { adm: number; esc: number } };
  /** Pino cursado gravado em cada virabrequim (id → serviço pino-N): fica na peça quando ela sai e volta com ela. */
  viraStroke?: Record<string, string>;
  /** Assinatura de preparação de cada peça solta (id → serviços): gravada quando a peça sai, restaurada quando volta. */
  partPrep?: Record<string, string[]>;
  /** Usinagem livre gravada no pistão solto (cava em mm). */
  partMach?: Record<string, { cavaMm?: number }>;
  /** Corte de giro escolhido no módulo com limitador configurável (rpm); unset = máximo do módulo. */
  revCut?: number | undefined;
  /** Conversão "Passar pro Álcool" montada na Oficina (motos carburadas); unset = sistema de gasolina. */
  alcool?: boolean | undefined;
  /** Giclês montados na conversão e os ideais calculados (número = Ø × 100); a mistura lê daqui. */
  gicles?: { alta: number; lenta: number; altaIdeal: number; lentaIdeal: number } | undefined;
  /** Carenagem/bolha montada (id de peça kind "carenagem"); unset = moto pelada de fábrica. */
  aero?: string | undefined;
}
export interface Ecu {
  rpm: number;
  /** Ignition advance vs base map (degrees). */
  timing: number;
  /** Fuel trim (%). */
  trim: number;
  /** Fuel trim per rpm band (%): baixa ~5,5k, média ~7,5k, alta ~9,5k+. */
  low: number;
  mid: number;
  high: number;
  /** Upshift rpm per gear change (1→2 .. 4→5); 0 = automático. */
  shift: number[];
  /** Ignition cut on upshift (ms). */
  qs: number;
  /** 2-Step launch rpm (0 = desligado). */
  launch: number;
  /** Over-rev fuel trim (%) above ~10,5k; undefined = segue a alta. */
  over?: number;
  /** Ignition offset (°) in the low (≤6k) and high (≥10k) bands. */
  tLow?: number;
  tHigh?: number;
  /** Malha fechada: sonda corrige a mistura até ±6% abaixo de 8k. */
  closed?: boolean;
  /** Proteção de mistura pobre: corta potência onde empobrece, poupa o pistão. */
  leanCut?: boolean;
  /** Corte suave (atraso de ponto) em vez de corte seco: alivia válvulas, perde um pouco no topo. */
  softCut?: boolean;
  /** Corte de troca por marcha (ms), 0 = usa o geral. */
  qsGear?: number[];
  /** Marcha lenta (rpm) — muda o ronco parado. */
  idle?: number;
}
/** Shift cut (ms) used when leaving `gear`. */
export const qsFor = (e: Ecu, gear: number) => (e.qsGear?.[gear - 1] || e.qs || 220);
export const STOCK_ECU: Ecu = { rpm: 9000, timing: 0, trim: 0, low: 0, mid: 0, high: 0, shift: [0, 0, 0, 0], qs: 220, launch: 0 };
export type AirFilter = "original" | "sem" | "caixa";
export const STOCK_FRONT = 15;
export const STOCK_REAR = 44;

export const LIGHT_REMOVED = { mirrors: true, rabeta: true, frontBrake: true };

/** Calibragem recomendada padrão (traseiro, piloto só); cada moto usa tire.recPsiOf() em stockSetupOf()/step(). */
export const FACTORY_PSI = 40; // sai de fábrica cheio (40 psi); murchar até a recomendada ganha largada e amarra em alta
export const STOCK_SETUP: Setup = {
  fuel: "gasolina",
  exhaust: "original",
  removed: { mirrors: true, rabeta: true, frontBrake: false }, // sai da loja sem retrovisores e sem rabeta
  airFilter: "original",
  front: STOCK_FRONT,
  rear: STOCK_REAR,
  slots: STOCK_SLOTS,
  psi: FACTORY_PSI,
  compression: 9.5,
  cam: "original",
  km: 0,
  oilKm: 0,
  ecu: STOCK_ECU,
  services: [],
};
/** Mesma referência da calibragem de fábrica (antes 28 contra 36 de fábrica: penalizava a moto original). */
export const STOCK_PSI = FACTORY_PSI;

/** Pinhão/coroa de fábrica da própria moto (relacaoFinal documentada no catálogo); sem documento, o padrão do jogo. */
export function factoryGear(bikeId: string | null | undefined): { front: number; rear: number } {
  const f = bikeId ? catalogFinal(bikeId) : null;
  return f?.front && f.rear ? { front: f.front, rear: f.rear } : { front: STOCK_FRONT, rear: STOCK_REAR };
}
/** Montagem 100% original de UMA moto: mesmo STOCK_SETUP, mas com a relação final de fábrica dela. */
export function stockSetupOf(bikeId: string | null | undefined): Setup {
  const g = factoryGear(bikeId), psi = FACTORY_PSI, compression = factoryCR(bikeId);
  return g.front === STOCK_SETUP.front && g.rear === STOCK_SETUP.rear && psi === STOCK_SETUP.psi && compression === STOCK_SETUP.compression ? STOCK_SETUP : { ...STOCK_SETUP, front: g.front, rear: g.rear, psi, compression };
}
/** Taxa de compressão homologada de fábrica da moto (catálogo); sem documento, a referência do jogo. */
export function factoryCR(bikeId: string | null | undefined): number {
  const v = bikeId ? ENGINE_CATALOG[bikeId]?.p["taxaCompressao"]?.valor : null;
  return typeof v === "number" ? v : STOCK_SETUP.compression;
}

/** Giclês da conversão vindos de save antigo: só aceita as quatro medidas positivas e plausíveis. */
const validGicles = (g: unknown): Setup["gicles"] => {
  if (!g || typeof g !== "object") return undefined;
  const o = g as Record<string, unknown>;
  const nums = [o["alta"], o["lenta"], o["altaIdeal"], o["lentaIdeal"]].map((v) => (typeof v === "number" && Number.isFinite(v) ? v : 0));
  if (nums.some((n) => n <= 0 || n > 300)) return undefined;
  return { alta: nums[0]!, lenta: nums[1]!, altaIdeal: nums[2]!, lentaIdeal: nums[3]! };
};

/** Fills old saves and sanitizes persisted values before they reach the physics engine. */
export function normalizeSetup(s: Partial<Setup> | undefined): Setup {
  const raw: Partial<Setup> = s && typeof s === "object" ? s : {};
  const finite = (value: unknown, fallback: number, min: number, max: number) =>
    typeof value === "number" && Number.isFinite(value) ? Math.min(max, Math.max(min, value)) : fallback;
  const inputSlots: Partial<Record<Slot, string>> = raw.slots && typeof raw.slots === "object" ? raw.slots : {};
  const slots = { ...STOCK_SLOTS, ...inputSlots } as Record<Slot, string>;
  // saves antigos: virabrequim montado no slot da biela migra para o slot próprio
  if (slots.biela === "vira-ww3") { slots.vira = "vira-ww3"; slots.biela = STOCK_SLOTS.biela; }
  if (slots.cilindro === "cilindro-4mm" && slots.vira === STOCK_SLOTS.vira) slots.vira = "vira-ww3";
  for (const slot of Object.keys(STOCK_SLOTS) as Slot[]) {
    const id = slots[slot];
    const part = typeof id === "string" ? slotPart(id, slot) : slotPart(STOCK_SLOTS[slot], slot);
    slots[slot] = part.kind === slot ? part.id : STOCK_SLOTS[slot];
  }
  const inputEcu: Partial<Ecu> = raw.ecu && typeof raw.ecu === "object" ? raw.ecu : {};
  const ecu: Ecu = {
    ...STOCK_ECU,
    ...inputEcu,
    rpm: finite(inputEcu.rpm, STOCK_ECU.rpm, 3000, 20000),
    timing: finite(inputEcu.timing, 0, -20, 30),
    trim: finite(inputEcu.trim, 0, -40, 40),
    low: finite(inputEcu.low, 0, -40, 40),
    mid: finite(inputEcu.mid, 0, -40, 40),
    high: finite(inputEcu.high, 0, -40, 40),
    shift: Array.isArray(inputEcu.shift) ? inputEcu.shift.slice(0, 4).map((v) => finite(v, 0, 0, 20000)) : [...STOCK_ECU.shift],
    qs: finite(inputEcu.qs, STOCK_ECU.qs, 0, 1000),
    launch: finite(inputEcu.launch, 0, 0, 15000),
    ...(inputEcu.over == null ? {} : { over: finite(inputEcu.over, 0, -40, 40) }),
    ...(inputEcu.tLow == null ? {} : { tLow: finite(inputEcu.tLow, 0, -20, 30) }),
    ...(inputEcu.tHigh == null ? {} : { tHigh: finite(inputEcu.tHigh, 0, -20, 30) }),
    ...(inputEcu.qsGear == null ? {} : { qsGear: Array.isArray(inputEcu.qsGear) ? inputEcu.qsGear.slice(0, 5).map((v) => finite(v, 0, 0, 1000)) : [] }),
  };
  const cam = typeof raw.cam === "string" && raw.cam in CAM_FX ? raw.cam as Cam : STOCK_SETUP.cam;
  return {
    ...STOCK_SETUP,
    ...raw,
    fuel: raw.fuel === "etanol" ? "etanol" : "gasolina",
    exhaust: raw.exhaust === "dore" ? "dore" : "original",
    airFilter: "original", // filtro sempre original (sem menu)
    front: finite(raw.front, STOCK_FRONT, 8, 30),
    rear: finite(raw.rear, STOCK_REAR, 20, 70),
    psi: finite(raw.psi, FACTORY_PSI, 10, 60),
    compression: finite(raw.compression, 9.5, 7, 16),
    km: finite(raw.km, 0, 0, 10000000),
    engineKm0: finite(raw.engineKm0, 0, 0, 10000000),
    oilKm: finite(raw.oilKm, 0, 0, 1000000),
    tireWear: finite(raw.tireWear, 0, 0, 1),
    clutchWear: finite(raw.clutchWear, 0, 0, 1),
    alcool: raw.alcool === true || undefined,
    gicles: validGicles(raw.gicles),
    aero: typeof raw.aero === "string" && partById(raw.aero)?.kind === "carenagem" ? raw.aero : undefined,
    riderKg: finite(raw.riderKg, RIDER_KG, 0, 300),
    cam,
    removed: { mirrors: true, rabeta: true, frontBrake: false }, // toda moto sai da loja sem retrovisores e sem rabeta
    slots,
    ecu,
    services: Array.isArray(raw.services) ? raw.services.filter((id): id is string => typeof id === "string" && !!serviceById(id)) : [],
  };
}

export interface BikeModel {
  id: string;
  /** Limite de tração da biela original (N), quando a ficha do jogador informa o giro que ela aguenta; padrão 9500 N. */
  rodLimitN?: number;
  name: string;
  year: number;
  price: number; // R$ (tabela FIPE de referência)
  flex: boolean;
  engine: string;
  cc: number;
  cooling: string;
  valves: string;
  gears: number;
  hpGas: number;
  hpEth: number;
  rpmPeak: number;
  torqueGas: number; // kgf.m
  torqueEth: number;
  rpmTorque: number;
  rpmLimit: number;
  dryWeight: number; // kg
  tank: number; // L
  topSpeed: number; // km/h (referência)
  /** Referência de VALIDAÇÃO: km/h no corte de fábrica por marcha. A corrida usa drivetrain() (relações do manual + pneu montado). */
  gearTop: number[];
  stockExhaustKg: number;
  tires: string;
  stock: boolean;
}

export const FUEL_DENSITY: Record<Fuel, number> = { gasolina: 0.74, etanol: 0.79 }; // kg/L
/** Wide-open-throttle brake specific fuel consumption (kg/kWh). Etanol needs ~45% more mass per kWh. */
export const BSFC: Record<Fuel, number> = { gasolina: 0.42, etanol: 0.61 };
/** Liters burned per second while the engine delivers `watts` at the crank. More power = more fuel. */
export function fuelFlow(f: Fuel, watts: number) {
  return (watts / 1000) * BSFC[f] / FUEL_DENSITY[f] / 3600;
}

export const TITAN_160: BikeModel = {
  id: "titan160",
  rodLimitN: 7360, // biela original aguenta 9.500 rpm: máx de mechlimits.physicsAt (carga plena) até esse giro
  name: "Honda CG 160 Titan",
  year: 2026,
  price: 18990,
  flex: true,
  engine: "Monocilíndrico 4T, OHC",
  cc: 162.7,
  cooling: "Ar",
  valves: "2 válvulas",
  gears: 5,
  hpGas: 14.4,
  hpEth: 14.7,
  rpmPeak: 8000,
  torqueGas: 1.41,
  torqueEth: 1.43,
  rpmTorque: 6750,
  rpmLimit: 9000,
  dryWeight: 120,
  tank: 14,
  topSpeed: 130,
  gearTop: [39.6, 65.2, 85.0, 103.6, 120.5], // relações Honda, corte de jogo autorizado de 9.000 rpm
  stockExhaustKg: 6.8,
  tires: "80/100-18 · 100/80-18",
  stock: true,
};

export const FACTOR_150: BikeModel = {
  id: "factor150",
  rodLimitN: 6660, // biela original aguenta 9.500 rpm: máx de mechlimits.physicsAt (carga plena) até esse giro
  name: "Yamaha Factor 150",
  year: 2026,
  price: 17690,
  flex: true,
  engine: "Monocilíndrico 4T, SOHC",
  cc: 149.3,
  cooling: "Ar",
  valves: "2 válvulas",
  gears: 5,
  hpGas: 11.8,
  hpEth: 12.4, // ficha Yamaha Factor 150 UBS: 12,4 cv a 7.500 rpm, 1,3 kgf·m a 5.500 rpm
  rpmPeak: 7500,
  torqueGas: 1.3,
  torqueEth: 1.3,
  rpmTorque: 5500,
  rpmLimit: 9000,
  dryWeight: 133,
  tank: 15.4,
  topSpeed: 112,
  gearTop: [39.4, 59.8, 81.2, 102.3, 122.2], // relações Yamaha, corte de jogo autorizado de 9.000 rpm
  stockExhaustKg: 6.5,
  tires: "80/100-18 · 100/80-18",
  stock: true,
};

export const TITAN_150: BikeModel = {
  id: "titan150",
  rodLimitN: 6650, // biela original aguenta 9.500 rpm: máx de mechlimits.physicsAt (carga plena) até esse giro
  name: "Honda CG 150 Titan ESD",
  year: 2006,
  price: 9900,
  flex: false,
  engine: "Monocilíndrico 4T, OHC · carburador 22 mm",
  cc: 149.2,
  cooling: "Ar",
  valves: "2 válvulas",
  gears: 5,
  hpGas: 14.2,
  hpEth: 14.2,
  rpmPeak: 8000,
  torqueGas: 1.35,
  torqueEth: 1.35,
  rpmTorque: 6500,
  rpmLimit: 9000,
  dryWeight: 112,
  tank: 15.4,
  topSpeed: 130,
  gearTop: [40.7, 63.3, 83.8, 103.9, 120.8], // relações 2004–2008, corte de jogo autorizado de 9.000 rpm
  stockExhaustKg: 6.6,
  tires: "2.75-18 · 90/90-18",
  stock: true,
};

export const CG_125: BikeModel = {
  id: "cg125",
  rodLimitN: 12500, // biela original: 12.500 N de tração, aguenta 13.500 rpm inclusive com pistão 4MM (12.366 N)
  name: "Honda CG 125 Bolinha",
  year: 1979,
  price: 7500,
  flex: false,
  engine: "Monocilíndrico 4T, OHV · carburador Keihin 20 mm",
  cc: 124,
  cooling: "Ar",
  valves: "2 válvulas",
  gears: 4,
  hpGas: 11,
  hpEth: 11,
  rpmPeak: 9000,
  torqueGas: 0.94,
  torqueEth: 0.94,
  rpmTorque: 7500,
  rpmLimit: 9800,
  dryWeight: 94,
  tank: 12,
  topSpeed: 105,
  gearTop: [38.0, 61.1, 82.7, 105.2], // relações OEM 4 marchas: primária 4,055 × marcha × 38/15 × raio dinâmico no limite do platinado
  stockExhaustKg: 5.8,
  tires: "2.50-18 · 2.75-18",
  stock: true,
};

/** Every bike model in the catalog (COMPLEGAME). Release in the official game is startgame.ts. */
export const BIKE_MODELS: BikeModel[] = [TITAN_160, FACTOR_150, TITAN_150, CG_125];

export const RIDER_KG = 90;
export const PARTS = {
  mirrors: 0.9,
  rabeta: 1.8,
  frontBrake: 2.4,
};
export const AIR_FILTER = { hp: 0.4, kg: 0.35 };
/** Airbox removed: TBI breathes straight from open air (filter goes with it). Leans the mixture. */
export const AIRBOX = { hp: 0.8, kg: 1.3, need: 0.04 };
export const DORE_KG = 1.8;
/** Dore primary pipe sizing (classic tuned-length formulas). */
export function doreCalc(b: BikeModel) {
  const ed = 220; // exhaust duration + 180°
  const lenIn = (850 * ed) / b.rpmPeak - 3;
  const diaIn = Math.sqrt(b.cc / ((lenIn + 3) * 25)) * 2.1;
  return { lengthMm: Math.round(lenIn * 25.4), diameterMm: Math.round(diaIn * 25.4 * 10) / 10 };
}

const SERVICE_MAP = new Map((WORKSHOP.services as Service[]).map((x) => [x.id, x]));
export const serviceById = (id: string) => SERVICE_MAP.get(id);
const svc = (s: Setup) => s.services.map(serviceById).filter((x): x is Service => !!x);

// Setups are immutable values (always rebuilt with spread), so derived numbers are cached per object:
// the race sim calls these thousands of times per second and must stay cheap on phones.
function memoS<R>(f: (s: Setup) => R) {
  const m = new WeakMap<Setup, R>();
  return (s: Setup) => {
    if (!m.has(s)) m.set(s, f(s));
    return m.get(s)!;
  };
}
function memoBS<R>(f: (b: BikeModel, s: Setup) => R) {
  const m = new WeakMap<Setup, Map<BikeModel, R>>();
  return (b: BikeModel, s: Setup) => {
    let x = m.get(s);
    if (!x) m.set(s, (x = new Map()));
    if (!x.has(b)) x.set(b, f(b, s));
    return x.get(b)!;
  };
}

/** Fuel demand vs injector supply: >0 lean, <0 rich. */
const mixture = memoS(mixtureCalc);
/** Blend fuel demand; flex only matters for the base, so the Titan reference is used here. */
const blendNeed = (s: Setup) => blendFx(s, true).need;
function mixtureCalc(s: Setup) {
  const cyl = slotPart(s.slots.cilindro, "cilindro");
  const need = blendNeed(s) * (1 + (cyl.need ?? 0) + (slotPart(s.slots.tbi, "tbi").need ?? 0) + svc(s).reduce((n, x) => n + (x.need ?? 0), 0) + (s.airFilter === "caixa" ? AIRBOX.need : 0));
  const mod = slotPart(s.slots.modulo, "modulo");
  const line = (slotPart(s.slots.bico, "bico").flow ?? 1) * (slotPart(s.slots.bomba, "bomba").flow ?? 1);
  let supply = mod.id === SERVITEC_ID ? line * servitecPulse(servitecMap().rpmPeak) : line * (1 + (mod.prog ? s.ecu.trim : 0) / 100);
  // conversão pro álcool: a vazão do sistema escala com a área do giclê montado vs o ideal (orifício);
  // o acerto fino da oficina (parafuso de ar/boia) zera desvios de até 5% de área; fora disso, menor dá falta (magra), maior dá excesso (gorda)
  // sem conversão (giclê trocado na gasolina): o ideal é o giclê de fábrica, só a razão de área muda a vazão
  if (s.gicles && s.gicles.altaIdeal > 0) {
    const jr = (s.gicles.alta / s.gicles.altaIdeal) ** 2, f = Math.abs(jr - 1) <= 0.05 ? 1 : jr;
    supply *= s.alcool ? blendNeed(s) * f : f;
  }
  return { need, supply, lean: need - supply };
}
/** Servitec — ECU Remapeada: mapa fixo gravado para o kit que a traz no bundle. */
export const SERVITEC_ID = "modulo-remap";
let SV: { kitId: string; need: number; flow: number; rpmPeak: number; compression: number } | null = null;
/**
 * Calibração do mapa Servitec, derivada só do catálogo do kit que a traz (cilindro + serviços + bico + comando):
 * need_kit = 1 + Σneed; flow_kit = vazão do bico do kit × bomba original; pico = pico da Titan + comando + serviços.
 * Taxa de projeto = taxa de fábrica (o kit não muda a taxa). Nada se adapta ao motor onde ela for instalada.
 */
export function servitecMap() {
  if (SV) return SV;
  const kits = PARTS_CATALOG.filter((p) => p.bundle?.modulo === SERVITEC_ID);
  const kit = kits.find((p) => p.bundle!.services?.length) ?? kits[0];
  if (!kit) return (SV = { kitId: "", need: 1, flow: 1, rpmPeak: TITAN_160.rpmPeak, compression: STOCK_SETUP.compression });
  const list = (kit.bundle!.services ?? []).map(serviceById).filter((x): x is Service => !!x);
  const need = 1 + (kit.need ?? 0) + list.reduce((n, x) => n + (x.need ?? 0), 0);
  const flow = (partById(kit.bundle!.bico)?.flow ?? 1) * (partById(STOCK_SLOTS.bomba)?.flow ?? 1);
  const rpmPeak = TITAN_160.rpmPeak + (CAM_FX[kit.bundle!.cam] ?? CAM_FX.original).rpm + list.reduce((n, x) => n + (x.rpmPeak ?? 0), 0);
  return (SV = { kitId: kit.id, need, flow, rpmPeak, compression: STOCK_SETUP.compression });
}
/** Pulso fixo do mapa (fração do pulso de fábrica) num rpm: entrega exatamente o need do kit com o bico do kit. */
export function servitecPulse(rpm: number) {
  const m = servitecMap();
  return (m.need * (1 + (m.need - 1) * 0.6 * (rpm / m.rpmPeak - 1))) / m.flow;
}
/** Ponto fixo do mapa: o ótimo do kit na taxa de projeto, por combustível (flex mantido). */
export const servitecTiming = (eth: boolean) => timingOpt({ compression: servitecMap().compression } as Setup, eth);
/** Ponto que a central aplica de fato (null = central de fábrica sem ponto ajustável). */
export function mapTiming(b: BikeModel, s: Setup) {
  const mod = slotPart(s.slots.modulo, "modulo");
  if (mod.id === SERVITEC_ID) return servitecTiming(s.fuel === "etanol" && b.flex);
  return mod.prog || mod.ponto ? s.ecu.timing : null;
}
const isProg = memoS((s: Setup) => !!slotPart(s.slots.modulo, "modulo").prog);
/** Band trim at rpm (linear blend between band centres). */
export function bandTrim(e: Ecu, rpm: number) {
  const lo = e.low ?? 0, mid = e.mid ?? 0, hi = e.high ?? 0;
  if (rpm <= 5500) return lo;
  if (rpm >= 10500 && e.over != null) return hi + (e.over - hi) * Math.min(1, (rpm - 10500) / 1000);
  if (rpm >= 9500) return hi;
  if (rpm < 7500) return lo + (mid - lo) * ((rpm - 5500) / 2000);
  return mid + (hi - mid) * ((rpm - 7500) / 2000);
}
/** Mixture at a given rpm: prepared engines (need > 1) pull more fuel as revs climb. */
export function mixtureAt(s: Setup, rpm: number, rpmPeak: number) {
  const m = mixture(s);
  const need = m.need * (1 + (m.need - 1) * 0.6 * (rpm / rpmPeak - 1));
  let supply = m.supply + (slotPart(s.slots.bico, "bico")?.flow ?? 1) * ((isProg(s) ? bandTrim(s.ecu, rpm) : 0) / 100);
  if (s.slots.modulo === SERVITEC_ID) supply = (m.supply * servitecPulse(rpm)) / servitecPulse(servitecMap().rpmPeak);
  // closed loop: the O2 sensor pulls the mixture back toward target at part load / low revs
  if (isProg(s) && s.ecu.closed && rpm <= 8000) {
    const err = need - supply;
    supply += Math.max(-0.06, Math.min(0.06, err));
  }
  return { need, supply, lean: need - supply };
}
/** Falta de combustível extra de uma moto não flex com álcool: volume pedido (estequiometria do tanque) − vazão do sistema de gasolina. 0 = gasolina ou flex. */
export function ethShortage(b: BikeModel, s: Setup) {
  if (b.flex) return 0;
  if (s.alcool) return 0; // convertida: a vazão vem dos giclês montados (mixtureCalc), não do sistema de gasolina
  const need = blendFx(s, false).need;
  return Math.max(0, need - 1);
}
/** Mixture power factor. Lean: the burned fuel caps the energy (supply/need), never below what was injected. Rich: excess fuel cools and dilutes. */
function mixMul(lean: number, need = 1) {
  if (lean <= 0) return Math.max(0.3, 1 + lean * 0.4);
  return Math.max(Math.max(0, need - lean) / Math.max(1e-6, need), 1 - lean * 0.6);
}
/** Power factor at rpm from band mixture vs the global mixture already inside engine().hp. */
export function mixFactor(s: Setup, rpm: number, rpmPeak: number) {
  const mAt = mixtureAt(s, rpm, rpmPeak), m0 = mixture(s);
  const lean = mAt.lean;
  let f = mixMul(lean, mAt.need) / mixMul(m0.lean, m0.need);
  if (isProg(s)) {
    f *= timingBandFactor(s.ecu, rpm);
    if (s.ecu.leanCut && lean > 0.04) f *= 0.85;
    if (s.ecu.softCut && rpm >= s.ecu.rpm - 250) f *= 0.97;
  }
  return Math.max(0.2, f);
}
/** Low revs want a little less advance, high revs a little more; 1 when the band offsets are zero. */
const bandW = (rpm: number) => ({ lo: rpm <= 6000 ? 1 : rpm < 8000 ? (8000 - rpm) / 2000 : 0, hi: rpm >= 10000 ? 1 : rpm > 8000 ? (rpm - 8000) / 2000 : 0 });
export function timingBandFactor(e: Ecu, rpm: number) {
  const w = bandW(rpm);
  const g = (d: number, o: number) => 1 - 0.01 * ((d - o) ** 2 - o * o);
  return g(e.tLow ?? 0, -1) ** w.lo * g(e.tHigh ?? 0, 1.5) ** w.hi;
}
/** AFR_stoich por combustível de bomba brasileiro: gasolina C (E27) 13,2 · etanol hidratado 8,4. */
export const AFR_STOICH = { gasolina: K("fuel.afr.gasolina_c_e27"), etanol: K("fuel.afr.etanol_hidratado") } as const;
/** lambda_mix pedido pelo mapa de fábrica em plena carga (ESTIMADO, sem sonda medida). */
export const LAMBDA_TARGET = 0.88;
/**
 * Única fonte de verdade da mistura. A massa entregue é proporcional a `supply`, a pedida a `need`:
 * lambda_mix = LAMBDA_TARGET × need / supply; AFR_actual = AFR_stoich × lambda_mix.
 * Combustão, injeção, dino, relatório e auditoria leem esta função; nenhum módulo recalcula a mistura.
 */
export function mixState(b: BikeModel, s: Setup, rpm: number, rpmPeak: number) {
  const m = mixtureAt(s, rpm, rpmPeak);
  const AFR_stoich = s.fuel === "etanol" && b.flex ? AFR_STOICH.etanol : AFR_STOICH.gasolina;
  const lambda_mix = (LAMBDA_TARGET * m.need) / Math.max(1e-6, m.supply);
  return { need: m.need, supply: m.supply, lean: m.lean, AFR_stoich, lambda_target: LAMBDA_TARGET, AFR_requested: AFR_stoich * LAMBDA_TARGET, lambda_mix, AFR_actual: AFR_stoich * lambda_mix, deliveredFrac: m.supply / m.need };
}
/** AFR_actual em rpm (mesma origem de mixState). */
export function afrAt(b: BikeModel, s: Setup, rpm: number, rpmPeak: number) {
  return mixState(b, s, rpm, rpmPeak).AFR_actual;
}
export const timingOptimum = (b: BikeModel, s: Setup) => timingOpt(s, s.fuel === "etanol" && b.flex);
const timingOpt = (s: Setup, eth: boolean) => (eth ? 4 : 2) - Math.max(0, s.compression - 9.5) * 1.2;

/** Power shape vs rpm (1 at the power peak). */
/** Installed pipe id (legacy Setup.exhaust "dore" counts as the Dore). */
export const exhaustId = (s: Setup) => (s.exhaust === "dore" && (s.slots.escape ?? "escape-original") === "escape-original" ? "escape-dore" : s.slots.escape);
/** Cilindrada of the build (cc), read from the cylinder kit name. */
export function ccOf(b: BikeModel, s: Setup) {
  const c = slotPart(s.slots.cilindro, "cilindro");
  const pis = slotPart(s.slots.pistao, "pistao"), Sp = strokeMmOf(b.id);
  // pistão sob medida (Ø próprio) só serve na moto declarada: Vd = π/4·D²·(curso + pino cursado)
  if (pis.boreMm && Sp != null && (!pis.bikes || pis.bikes.includes(b.id))) return Math.round((Math.PI / 4) * pis.boreMm ** 2 * (Sp + pinOffsetMm(s)) / 100) / 10;
  if (c.factory) return b.cc;
  // geometria montada: Ø do cilindro (nome/especificação) × curso real (ficha + pino cursado) — Vd = π/4·D²·S
  const bore = /(\d{2}[,.]\d)\s*mm/.exec(`${c.name} ${c.spec}`), S = strokeMmOf(b.id);
  if (bore && S != null) { const D = Number(bore[1]!.replace(",", ".")); return Math.round((Math.PI / 4) * D * D * (S + pinOffsetMm(s)) / 100) / 10; }
  if (c.cc) return c.cc;
  const m = /(\d{3})\s*cc/.exec(c.name);
  return m ? Number(m[1]) : b.cc;
}
/** Curso extra do pino cursado (serviço de usinagem do virabrequim), mm. */
export const pinOffsetMm = (s: Setup) => s.services.reduce((max, id) => {
  const m = /^pino-(\d+)$/.exec(id);
  if (!m) return max;
  const d = m[1]!;
  // id com dois dígitos guarda décimos: pino-05 = 0,5 mm · pino-15 = 1,5 mm; um dígito = mm inteiro
  const mm = d.length > 1 ? Number(d) / 10 : Number(d);
  return Math.max(max, mm);
}, 0);
/** Relações de fábrica (primária × marchas) da ficha do fabricante; null se ausentes. */
export function catalogRatios(bikeId: string): { prim: number; gears: number[] } | null {
  const p = ENGINE_CATALOG[bikeId]?.p;
  const pr = /^(\d+[,.]\d+)/.exec(String(p?.["relacaoPrimaria"]?.valor ?? ""));
  const gears = [...String(p?.["relacoesCambio"]?.valor ?? "").matchAll(/ª\s*(\d+[,.]\d+)/g)].map((m) => Number(m[1]!.replace(",", ".")));
  return pr && gears.length ? { prim: Number(pr[1]!.replace(",", ".")), gears } : null;
}
/** Relação final documentada (coroa/pinhão de fábrica), ou null sem documento. */
export function catalogFinal(bikeId: string): { ratio: number; rear: number | null; front: number | null } | null {
  const v = String(ENGINE_CATALOG[bikeId]?.p["relacaoFinal"]?.valor ?? "");
  const r = /^(\d+[,.]\d+)/.exec(v), t = /\((\d+)\/(\d+)\)/.exec(v);
  return r ? { ratio: Number(r[1]!.replace(",", ".")), rear: t ? Number(t[1]) : null, front: t ? Number(t[2]) : null } : null;
}
/**
 * Velocidade no corte por marcha da moto ORIGINAL (km/h, pinhão/coroa de fábrica), derivada das relações documentadas.
 * Só referência de validação: a corrida usa drivetrain() com a relação montada.
 */
export function oemGearTop(b: BikeModel): number[] {
  return drivetrain(b, stockSetupOf(b.id)).vCutKmh.map((v) => Math.round(v * 10) / 10);
}
/** Raio geométrico do pneu traseiro (última medida "L/P-aro"), m. */
export function rearTireRadiusM(spec: string) {
  const all = [...spec.matchAll(/(\d{2,3})\/(\d{2,3})-(\d{2})/g)], m = all[all.length - 1];
  if (m) return (Number(m[3]) * 25.4 / 2 + (Number(m[1]) * Number(m[2])) / 100) / 1000;
  // medida em polegadas (pneu diagonal "2.75-18"): altura do flanco ≈ largura (série ~100, ESTIMADO)
  const inch = [...spec.matchAll(/(\d[.,]\d{2})-(\d{2})/g)].at(-1);
  return inch ? (Number(inch[2]) * 25.4 / 2 + Number(inch[1]!.replace(",", ".")) * 25.4) / 1000 : null;
}
/** Gas-flow multiplier of the pipe at an rpm (stock pipe on stock engine = 1). */
export const exhaustMul = (b: BikeModel, s: Setup, rpm: number) => exhaustAt(exhaustId(s), ccOf(b, s), b.cc, rpm);
/** Exhaust curve normalized to the power peak: shapes torque across the rpm range. */
/** Exhaust flow vs the factory pipe on this same engine at the power peak: the real pipe gain (or choke) enters the
 * curve and therefore the total power; the stock pipe on any engine stays 1 at the peak. No per-part cv is displayed. */
export const exhaustShape = (b: BikeModel, s: Setup, rpm: number, rpmPeak: number) => exhaustMul(b, s, rpm) / exhaustMul(b, s, rpmPeak);
/** Pipe flow vs the factory pipe at the power peak on this same engine: enters engine().hp, so the displayed cv rises. */
export const exhaustPeakGain = (b: BikeModel, s: Setup, rpmPeak: number) => exhaustMul(b, s, rpmPeak) / exhaustAt("escape-original", ccOf(b, s), b.cc, rpmPeak);
export const exhaustKg = (s: Setup) => exhaustSpec(exhaustId(s)).kg;

/**
 * Curva de torque de fábrica abaixo do pico de potência, normalizada pelo torque no pico de potência (T/T₁).
 * rT = rpm de torque máximo / rpm de potência máxima; R = T_max / T₁, ambos da ficha da moto
 * (R = T_ficha·ω_pico / P_pico). Abaixo de rT o torque cresce de 0 (rpm 0) até R; entre rT e o pico de
 * potência é a cúbica de Hermite com T(rT)=R, T'(rT)=0, T(1)=1 e T'(1)=−1 — esta última é exatamente
 * dP/dω = 0 no pico (P = T·ω). Sem piso artificial: rotação zero ⇒ torque zero ⇒ potência zero.
 */
export function torqueShape(r: number, rT: number, R: number) {
  if (r <= 0) return 0;
  if (r <= rT) return R * (1 - ((rT - r) / rT) ** 2);
  const h = 1 - rT, u = Math.min(1, (r - rT) / h);
  return R * (2 * u ** 3 - 3 * u ** 2 + 1) + (-2 * u ** 3 + 3 * u ** 2) - h * (u ** 3 - u ** 2);
}
/** rT e R da ficha de cada moto (torque e potência declarados no mesmo combustível). */
export function torqueCurveOf(b?: BikeModel, s?: Setup) {
  if (!b) return { rT: 0.8, R: 1.1 }; // genérico (ESTIMADO) só para chamadas sem moto
  const eth = s?.fuel === "etanol" && b.flex;
  const hp = eth ? b.hpEth : b.hpGas, tKgfm = eth ? b.torqueEth : b.torqueGas;
  const T1 = (hp * K("unit.cv_w")) / ((b.rpmPeak * 2 * Math.PI) / 60);
  const rT = b.rpmTorque > 0 && b.rpmTorque < b.rpmPeak ? b.rpmTorque / b.rpmPeak : 0.8;
  return { rT, R: Math.max(1, (tKgfm * K("phys.g")) / T1) };
}
export function powerShape(rpm: number, rpmPeak: number, b?: BikeModel, s?: Setup) {
  const r = rpm / rpmPeak;
  // até o pico: P/P_pico = r·T(r)/T₁ (P = T·ω), curva de torque da ficha de cada motor
  const ve = s ? matchVE(s, rpm) / matchVE(s, rpmPeak) : 1;
  if (r <= 1) { const c = torqueCurveOf(b, s); return Math.max(0, r * torqueShape(r, c.rT, c.R)) * ve; }
  const ohv = b && platformOf(b.id)?.motor.arquitetura === "OHV";
  if (ohv) {
    const springGain = s ? valveFloatRpm(s) - K("overrev.ohc.float_rpm") : 0;
    const width = Math.max(K("overrev.ohv.decay_width"), K("overrev.ohv.decay_width") + springGain);
    const flow = Math.exp(-(((rpm - rpmPeak) / width) ** 2));
    const arch = ignitionOf(b.id), peakSpark = sparkEnergy(arch, rpmPeak), spark = sparkEnergy(arch, rpm);
    const burn = Number.isFinite(peakSpark) ? Math.min(1, spark / peakSpark) : 1;
    return flow * burn * ve;
  }
  const floatAt = s ? valveFloatRpm(s) : K("overrev.ohc.float_rpm");
  const floatLoss = Math.exp(-(Math.max(0, rpm / floatAt - 1) ** 2));
  return Math.max(0, 1 - Math.pow(r - 1, 2) * 3.2) * floatLoss * ve;
}

/** Effective engine for a setup: power, power peak, rev limit and fuel use. */
export const engine = memoBS(engineCalc);
function engineCalc(b: BikeModel, s: Setup) {
  const eth = s.fuel === "etanol" && b.flex;
  const bfx = blendFx(s, b.flex);
  // flex: central adaptativa entrega a potência de ficha proporcional ao etanol no tanque
  let hp = bfx.flexEth != null ? b.hpGas + (b.hpEth - b.hpGas) * bfx.flexEth : eth ? b.hpEth : b.hpGas;
  if (s.airFilter === "sem") hp += AIR_FILTER.hp;
  if (s.airFilter === "caixa") hp += AIRBOX.hp;
  hp += (slotPart(s.slots.vela, "vela").hp ?? 0) + (slotPart(s.slots.cabo, "cabo").hp ?? 0);
  let mul = 1 + (s.compression - factoryCR(b.id)) * 0.025; // potência de ficha na taxa homologada da própria moto
  if (!eth && s.compression > 11) mul -= (s.compression - 11) * 0.04; // detonação: ponto atrasa na gasolina
  let rpmPeak = b.rpmPeak;
  const cam = CAM_FX[s.cam] ?? CAM_FX.original;
  rpmPeak += cam.rpm;
  rpmPeak += escapePeakShiftRpm(s); // tubo longo antecipa, curto atrasa o pico
  mul *= cam.mul;
  mul *= breakInHpMul(s); // amaciamento
  // moto a gasolina (não flex) com álcool: sem ganho de potência e giclê/bico de gasolina não dão vazão (falta de combustível)
  mul *= b.flex ? bfx.hpMul : Math.min(1, bfx.hpMul);
  if (!b.flex) { const x = ethShortage(b, s); if (x > 0) mul *= mixMul(x, 1 + x); }
  // conversão "Passar pro Álcool": ganho por moto (alcool.ts); giclê errado cobra pela mistura (mixtureCalc)
  if (!b.flex && s.fuel === "etanol" && s.alcool) hp += alcoolGain(b.id);
  const oil = slotPart(s.slots.oleo, "oleo");
  mul *= oil.hpMul ?? 1;
  mul *= slotPart(s.slots.cilindro, "cilindro").hpMul ?? 1;
  mul *= slotPart(s.slots.pistao, "pistao").hpMul ?? 1;
  // pistão sob medida (KMP 4MM): potência proporcional ao volume deslocado real Vd montado / Vd de fábrica
  { const pk = slotPart(s.slots.pistao, "pistao"); if (pk.boreMm && (!pk.bikes || pk.bikes.includes(b.id))) mul *= ccOf(b, s) / b.cc; }
  for (const k of ["molas", "biela"] as Slot[]) mul *= slotPart(s.slots[k], k).hpMul ?? 1;
  mul *= 1 - Math.min(0.05, Math.max(0, s.oilKm / (oil.oilLife ?? 1000) - 1) * 0.02);
  for (const x of svc(s)) {
    if (x.group !== "alim" || x.exclusive !== "tbi") mul *= x.hpMul ?? 1; // brocar borboleta entra pelo fluxo de ar
    rpmPeak += x.rpmPeak ?? 0;
  }
  // módulo incompatível com a arquitetura da moto não funciona: vale o de fábrica (ignition.ts)
  const mod = effectiveModulo(b, s);
  mul *= mod.hpMul ?? 1;
  if (mod.prog || mod.ponto || mod.id === SERVITEC_ID) {
    // Servitec: ponto fixo do mapa do kit (não acompanha taxa diferente da de projeto).
    const t = mod.id === SERVITEC_ID ? servitecTiming(eth) : s.ecu.timing;
    const o = timingOpt(s, eth);
    mul *= 1 + 0.01 * t - 0.0025 * (t - o) ** 2 + 0.0025 * o * o;
  }
  const mx = mixture(s);
  mul *= mixMul(mx.lean, mx.need);
  // platinado/CDI: teto físico da centelha e das molas; ECU: corte do mapa ou do limitador
  const rpmLimit = ignitionRpmLimit(b, mod, valveFloatRpm(s)) ?? (mod.prog ? s.ecu.rpm : revCutRange(b, mod).clamp(s.revCut));
  // ganho físico do escape vs escape original no pico entra na potência exibida (curva fora do pico via exhaustShape)
  mul *= exhaustPeakGain(b, s, rpmPeak);
  // assentamento: válvula afundada na sede perde vazão pela parede da câmara (blindagem), ~2%/mm
  mul *= 1 - 0.02 * (s.mach?.assentoMm ?? 0);
  mul *= matchVE(s, rpmPeak); // casamento comando × escape no pico
  // corpo de borboleta: densidade do coletor no pico pela vazão compressível (airflow.ts); fábrica = 1
  mul *= tbiAirGain(s, ccOf(b, s), rpmPeak);
  return { hp: hp * mul, rpmPeak, rpmLimit, eth, fuelMul: Math.max(1, mx.supply) * bfx.burn };
}

/** Margem de força da mola dimensionada sobre a exigida na rotação de projeto. */
export const SPRING_MARGIN = 1.1;
/** Rotação em que a mola instalada deixa a válvula flutuar (comando, serviços de levante e reparos de mola). */
export function valveFloatRpm(s: Setup) {
  const mol = slotPart(s.slots.molas, "molas");
  // molas dimensionadas: força calculada para segurar o comando montado na rotação de projeto (margem SPRING_MARGIN);
  // trem mais leve (kit de válvulas) pede menos força, a mesma mola segura até rpm·√(1/massa)
  if (mol.springRpm) return Math.round(mol.springRpm * Math.sqrt(SPRING_MARGIN / (mol.valveMassMul ?? 1)));
  const cam = CAM_FX[s.cam] ?? CAM_FX.original;
  const liftSvc = s.services.map((id) => SERVICES.find((v) => v.id === id)).filter((x) => x?.needsCavas).length;
  return 10300 - cam.risk * 40 - liftSvc * 150 + ((slotPart(s.slots.molas, "molas").fix ?? {})["Válvula atropelada"] ?? 0) * 40;
}

/** Faixa do limitador: módulo configurável vai de REV_CUT_MIN até o corte de fábrica + rpm do módulo (o hardware não passa disso). */
export const REV_CUT_MIN = 6000;
/** Ajuste de fábrica do Servitec ao comprar: corte original + 1000 rpm. */
export const SERVITEC_DEFAULT_RPM = 1000;
export function revCutRange(b: BikeModel, mod: { rpm?: number; revCfg?: boolean }) {
  const max = b.rpmLimit + (mod.rpm ?? 0), min = Math.min(REV_CUT_MIN, b.rpmLimit);
  // módulo configurável sai da caixa ajustado em +SERVITEC_DEFAULT_RPM; o jogador sobe até o máximo do módulo
  const def = Math.min(max, b.rpmLimit + SERVITEC_DEFAULT_RPM);
  const clamp = (v?: number) => (!mod.revCfg ? max : v == null || !Number.isFinite(v) ? def : Math.round(Math.min(max, Math.max(min, v)) / 50) * 50);
  return { min, max, factory: b.rpmLimit, def, clamp };
}

/** Km rodados desde o último motor novo/retificado. */
export const breakKm = (s: Setup) => Math.max(0, s.km - (s.engineKm0 ?? 0));
/** Amaciamento 0 (motor cru) → 1 (totalmente assentado aos 3000 km), curva que desacelera. */
export const breakIn = (s: Setup) => Math.min(1, Math.sqrt(breakKm(s) / 3000));
/** Amaciamento não dá potência: a moto original entrega a ficha e nunca passa dela (o assentamento entra só no
 * desgaste/risco). O antigo +3% amaciado era potência sem fonte física. */
export const BREAKIN_MAX_GAIN = 0.03;
/** Pedido do jogador (13/11): anéis assentados vedam melhor e o atrito interno cai, então o motor ganha
 * até +3% (1% → 2% → 3% conforme amacia). Refazer o motor zera engineKm0 e volta a 0%. Vale igual para
 * as duas motos, então original × original com a mesma km continua empatando. */
export const breakInHpMul = (s: Setup) => 1 + BREAKIN_MAX_GAIN * breakIn(s);
export function breakInLabel(s: Setup) {
  const v = breakIn(s);
  return v < 1 / 3 ? "Motor novo" : v < 1 ? "Amaciando" : "Amaciado";
}

/** Mechanical load of the build (0 = factory). Drives break risk; each cause carries the failure it produces. */
export function stress(b: BikeModel, s: Setup) {
  const causes: [string, number, string][] = [];
  const add = (label: string, v: number, src = "") => v > 0 && causes.push([label, v, src]);
  const cyl = slotPart(s.slots.cilindro, "cilindro");
  const pis = slotPart(s.slots.pistao, "pistao");
  const list = svc(s);
  const has = (id: string) => s.services.includes(id);
  add("Pistão travou no cilindro", cyl.stress ?? 0, `Kit de cilindro maior (${cyl.name}) esquenta e dilata mais`);
  // anéis RIK: 1º anel de aço nitretado resiste mais à quebra por calor/assentamento ruim (metade do risco), ainda precisa brunir
  if (cyl.stress && !has("brunimento")) add("Anéis quebrados", pis.rings === "RIK" ? 7.5 : 15, pis.rings === "RIK" ? "Cilindro sem brunimento: anéis RIK aguentam mais, mas não assentam por completo" : "Cilindro novo montado sem brunimento: o anel não assenta");
  if (cyl.id === "cilindro-220" && !has("parede-grossa")) add("Cilindro trincado", 25, "Cilindro 220cc sem parede grossa: camisa fina demais");
  add("Pistão furado", pis.stress ?? 0, `Pistão ${pis.name} sobe a pressão na câmara`);
  add("Cabeçote empenado", slotPart(s.slots.tbi, "tbi").stress ?? 0, "TBI maior: mais ar, mais calor no cabeçote");
  for (const x of list) add(x.id.startsWith("pino") ? "Biela quebrada" : "Cabeçote empenado", x.stress ?? 0, `Serviço: ${x.name}`);
  const cavas = !!pis.cavas || list.some((x) => x.cavas);
  if (list.some((x) => x.needsCavas) && !cavas) add("Válvula atropelada", 20, "Válvula/levante maior sem cavas no pistão: pouca folga");
  if (!cavas) add("Válvula atropelada", (CAM_FX[s.cam] ?? CAM_FX.original).risk, "Comando bravo sem cavas no pistão");
  const eth = s.fuel === "etanol" && b.flex;
  add("Pistão furado", eth ? (s.compression - 12) * 8 : (s.compression - 11) * 12, `Taxa ${s.compression}:1 alta pro combustível ${s.fuel}: detona`);
  const e = engine(b, s);
  const over = ignitionOf(b.id) === "platinado" ? 0 : (e.rpmLimit - 10000) / 100;
  add("Válvula atropelada", over * (has("molas-duplas") ? 1.5 : 3) * (isProg(s) && s.ecu.softCut ? 0.7 : 1), `Corte em ${e.rpmLimit} rpm: a mola não fecha a válvula a tempo${has("molas-duplas") ? " (molas duplas ajudam)" : ""}`);
  const mt = mapTiming(b, s);
  if (mt != null) add("Pistão furado", (mt - timingOpt(s, eth)) * 8, `Ponto ${Math.round(mt * 10) / 10}° adiantado demais pra taxa ${s.compression}:1: detona`);
  const mx = mixture(s);
  let worst = mx.lean;
  for (let r = 5500; r <= e.rpmLimit; r += 250) worst = Math.max(worst, mixtureAt(s, r, e.rpmPeak).lean);
  add("Pistão derretido · mistura pobre", worst * 250 * (isProg(s) && s.ecu.leanCut ? 0.4 : 1), "Falta combustível em alto giro: mistura pobre esquenta o pistão");
  if (isProg(s)) {
    add("Pistão furado", ((s.ecu.tHigh ?? 0) - 1.5) * 6, "Avanço extra no giro alto do mapa");
    add("Pistão furado", ((s.ecu.tLow ?? 0) - 0.5) * 8, "Avanço extra no giro baixo do mapa");
    add("Câmbio espanado", (120 - Math.min(s.ecu.qs ?? 220, ...(s.ecu.qsGear ?? []).filter((x) => x > 0))) * 0.25, "Corte do quickshifter curto: a marcha entra com tranco");
    if (s.ecu.launch) add("Embreagem queimada", ((s.ecu.launch - 8000) / 100) * 2, `2-step em ${s.ecu.launch} rpm frita a embreagem parada`);
  }
  // parts that reinforce a specific failure point absorb its load
  const fixes: Record<string, number> = {};
  for (const k of ["embreagem", "molas", "biela"] as Slot[]) for (const [c, v] of Object.entries(slotPart(s.slots[k], k).fix ?? {})) fixes[c] = (fixes[c] ?? 0) + v;
  for (const c of causes) {
    const f = Math.min(c[1], fixes[c[0]] ?? 0);
    c[1] -= f;
    fixes[c[0]] = (fixes[c[0]] ?? 0) - f;
  }
  const raw = causes.reduce((n, c) => n + c[1], 0);
  const relief = (pis.relief ?? 0) + list.reduce((n, x) => n + (x.relief ?? 0), 0);
  const value = Math.max(0, raw - relief);
  causes.sort((x, y) => y[1] - x[1]);
  // amaciado e bem regulado (sem mistura pobre) quebra menos a longo prazo; motor cru quebra mais
  const tuned = worst < 0.05 ? 1 : 0.4;
  const bi = breakIn(s);
  const wear = (bi < 0.15 ? 1.15 : 1) * (1 - 0.3 * bi * tuned);
  return { value, causes: causes.filter((c) => c[1] > 0).map(([c, v, src]) => ({ cause: c, load: Math.round(v * 10) / 10, src })), relief, worstLean: worst, breakIn: bi, cause: causes[0]?.[0] ?? "Motor fundiu", risk: Math.min(0.85, Math.max(0, value - 10) * 0.012 * wear) };
}

export const tireOf = memoS(tireCalc);
function tireCalc(s: Setup) {
  const t = slotPart(s.slots.pneu, "pneu");
  // referência estática (v = 0, calibragem padrão); a corrida usa recPsiOf(moto) e Crr(v) em step()
  const ts = tireState(s.psi, DEFAULT_REC_PSI);
  return { crr: crrAt(s.psi, DEFAULT_REC_PSI, 0, (t.crr ?? 1) * tireGeometry(t).rollingMul), grip: (t.grip ?? 1) * ts.muPsi * (1 - 0.18 * (s.tireWear ?? 0)), deflM: ts.deflM, muPsi: ts.muPsi };
}

/** Bike mass without fuel (kg, unrounded). */
const dryKg = memoBS((b: BikeModel, s: Setup) => {
  let kg = b.dryWeight;
  if (s.removed.mirrors) kg -= PARTS.mirrors;
  if (s.removed.rabeta) kg -= PARTS.rabeta;
  if (s.removed.frontBrake) kg -= PARTS.frontBrake;
  if (s.exhaust === "dore") kg += DORE_KG - b.stockExhaustKg;
  if (s.airFilter === "sem") kg -= AIR_FILTER.kg;
  if (s.airFilter === "caixa") kg -= AIRBOX.kg;
  for (const k of ["bateria", "susp", "pneu", "escape", "embreagem", "roda"] as Slot[]) kg += slotPart(s.slots[k], k).kg ?? 0;
  return kg;
});
export function stats(b: BikeModel, s: Setup, fuelL = 0) {
  const e = engine(b, s);
  const kg = dryKg(b, s) + fuelL * FUEL_DENSITY[s.fuel];
  const torque = (e.eth ? b.torqueEth : b.torqueGas) * (e.hp / (e.eth ? b.hpEth : b.hpGas));
  return { hp: Math.round(e.hp * 10) / 10, kg: Math.round(kg * 10) / 10, torque: Math.round(torque * 100) / 100, rpmLimit: e.rpmLimit };
}

export const RHO = 1.5;
/** Fator de Cd·A da carenagem montada (1 = sem carenagem). */
export const aeroMul = (s: { aero?: string | undefined }) => (s.aero ? partById(s.aero)?.cdaMul ?? 1 : 1);
export const CDA = 0.32; // piloto sentado (Cd·A de street 150–160 cc); deitado = CDA × TUCK_DRAG
/** Eficiência mecânica motor → roda (registry drivetrain.eta_total): P_roda = P_embreagem × ETA, T_roda = T_motor × i_total × ETA. */
export const ETA = K("drivetrain.eta_total");
const G = K("phys.g");
const SHIFT_TIME = 0.22;

export interface SimState {
  t: number;
  x: number;
  v: number; // m/s
  gear: number;
  rpm: number;
  shiftT: number;
  /** Fim da trava após redução inteligente (s). */
  downLockT?: number;
  /** Maior giro alcançado na marcha atual desde que ela acoplou (referência da queda de giro). */
  gearRpmMax?: number;
  /** Marcha de onde a redução inteligente saiu e a velocidade naquele instante (histerese para voltar). */
  downFrom?: number;
  downV?: number;
  top: number;
  t60: number | null;
  t100: number | null;
  finishT: number | null;
  fuel: number; // L left in the tank
  dry: boolean; // ran out of fuel
  gearMax: number[]; // km/h reached in each gear
  /** Telemetria: instante (s) em que cada marcha entrou (índice 0 = 1ª). Não afeta a física. */
  gearT?: number[];
  t100m: number | null;
  t500m: number | null;
  /** Clutch slip fraction (0..1). */
  slip: number;
  /** Rider lay down after catching the draft; stays tucked until the finish. */
  tucked?: boolean;
  /** Transição sentado (0) → deitado (1). */
  tuckK?: number;
  /** Velocidade da banda do pneu traseiro (m/s); > v quando patina. */
  wv?: number;
  /** Rear tire spinning (force over traction). */
  spin?: boolean;
  /** Front axle A off the asphalt (pitch > 0). */
  wheelie?: boolean;
  /** Ground dynamics: pitch, throttle, tire temperature (ground.ts). */
  gr?: Ground;
  /** Launch rpm override used only by idealLaunch() to test candidates. */
  launchAt?: number;
  /** Crank rpm while the clutch is slipping on launch; undefined once locked (rpm follows the wheel). */
  crankRpm?: number | undefined;
  /** Embreagem já acoplou na 1ª: o giro segue o câmbio daqui em diante (sem voltar a patinar por estado perdido). */
  locked?: boolean;
  /** Energia dissipada nos discos nesta corrida (J). */
  clutchJ?: number;
  /** Telemetria do último passo (StressCheck): potência no virabrequim depois do acelerador (W), entregue pela embreagem (W),
   * força no asfalto, limite de tração μ·N_B, resistências (N), massa total (kg), aceleração (m/s²), acelerador efetivo e limitador. */
  pEngW?: number;
  pW?: number;
  fW?: number;
  tracN?: number;
  /** Atrito de deslizamento ÷ μ estático usado no último passo (cai com a velocidade de escorregamento). */
  slideK?: number;
  /** Crr(v,P) do passo, deflexão do pneu traseiro (m), μ efetivo no asfalto */
  crr?: number; deflM?: number; tireMu?: number;
  dragN?: number;
  rollN?: number;
  massKg?: number;
  /** Massa equivalente de aceleração do passo (m + inércias refletidas), kg. */
  mEffKg?: number;
  acc?: number;
  thr?: number;
  limiter?: boolean;
}

export function newSim(fuelL = 0): SimState {
  return { t: 0, x: 0, v: 0, gear: 1, rpm: 6000, shiftT: 0, top: 0, t60: null, t100: null, finishT: null, fuel: fuelL, dry: false, gearMax: [], t100m: null, t500m: null, slip: 0 };
}

// ===================== TRANSMISSÃO (cadeia cinemática única) =====================
// Relação total i_k = primária × marcha_k × (coroa / pinhão). Roda: n_roda = rpm / i_k; v = ω_roda × r_din.
// Torque na roda = T_motor × i_k × η. Corrida, garagem, dinamômetro, scanner, NEXUS e RealGear leem daqui.
const rDynCache = new Map<string, number>();
/** Raio dinâmico do pneu traseiro MONTADO (m): medida da peça (a da ficha quando é o original) × fator de rolagem. */
export function rearTireDynM(b: BikeModel, s: Setup) {
  const tp = slotPart(s.slots.pneu, "pneu"), key = b.id + "|" + tp.id;
  let r = rDynCache.get(key);
  if (r == null) {
    r = (rearTireRadiusM(tp.factory ? b.tires : tp.name) ?? rearTireRadiusM(b.tires) ?? 0.3) * K("tire.rolling_factor");
    rDynCache.set(key, r);
  }
  return r;
}
export interface Drivetrain {
  /** MANUAL: primária e marchas do manual do fabricante; PENDENTE: sem relações internas, relação total equivalente da tabela de referência. */
  origem: "MANUAL" | "PENDENTE";
  fonte: string;
  primary: number | null;
  /** Relação interna de cada marcha (conduzida/motora); null quando não documentada. */
  gears: (number | null)[];
  front: number; rear: number; final: number;
  rDynM: number;
  /** Relação total por marcha (rpm do motor / rpm da roda). */
  totals: number[];
  rpmLimit: number;
  /** Velocidade TEÓRICA no corte por marcha (km/h), sem patinagem. Não é a velocidade alcançada. */
  vCutKmh: number[];
  eta: number;
}
export const drivetrain = memoBS(drivetrainCalc);
function drivetrainCalc(b: BikeModel, s: Setup): Drivetrain {
  const cat = catalogRatios(b.id), rpm = engine(b, s).rpmLimit, r = rearTireDynM(b, s), fin = s.rear / s.front;
  const w = (rpm * 2 * Math.PI) / 60, cut = (i: number) => ((w * r) / i) * 3.6;
  if (cat && cat.gears.length === b.gears) {
    const totals = cat.gears.map((ig) => cat.prim * ig * fin);
    return { origem: "MANUAL", fonte: `engine_catalog ${b.id}: relacaoPrimaria × relacoesCambio`, primary: cat.prim, gears: cat.gears, front: s.front, rear: s.rear, final: fin, rDynM: r, totals, rpmLimit: rpm, vCutKmh: totals.map(cut), eta: ETA };
  }
  // sem relações internas documentadas: relação total equivalente da tabela de referência no final de fábrica, escalada pela final montada
  const g0 = factoryGear(b.id), fin0 = g0.rear / g0.front, w0 = (b.rpmLimit * 2 * Math.PI) / 60;
  const totals = b.gearTop.map((kmh) => ((w0 * r) / (kmh / 3.6)) * (fin / fin0));
  return { origem: "PENDENTE", fonte: "relações internas não documentadas: BikeModel.gearTop como referência", primary: null, gears: b.gearTop.map(() => null), front: s.front, rear: s.rear, final: fin, rDynM: r, totals, rpmLimit: rpm, vCutKmh: totals.map(cut), eta: ETA };
}
/** Relação total da marcha (1 = primeira). */
export const gearRatioTotal = (b: BikeModel, s: Setup, gear: number) => drivetrain(b, s).totals[gear - 1] ?? NaN;
/** Velocidade (m/s) sem patinagem para um rpm do motor numa marcha. */
export function speedAtRpm(b: BikeModel, s: Setup, gear: number, rpm: number) {
  const d = drivetrain(b, s), i = d.totals[gear - 1];
  return i ? ((rpm * 2 * Math.PI) / 60) * d.rDynM / i : 0;
}
/** Rpm do motor que a marcha impõe a uma velocidade (m/s). */
export function rpmAtSpeed(b: BikeModel, s: Setup, gear: number, vMs: number) {
  const d = drivetrain(b, s), i = d.totals[gear - 1];
  return i ? ((vMs / d.rDynM) * i * 60) / (2 * Math.PI) : 0;
}
/** Torque na roda (N·m) = T_motor × i_total × η. */
export const wheelTorqueNm = (b: BikeModel, s: Setup, gear: number, engineNm: number) => engineNm * gearRatioTotal(b, s, gear) * ETA;
/** Força trativa (N) = torque na roda / r_din. */
export const wheelForceN = (b: BikeModel, s: Setup, gear: number, engineNm: number) => wheelTorqueNm(b, s, gear, engineNm) / drivetrain(b, s).rDynM;
/** Rpm logo após a troca, à mesma velocidade: rpm × i_nova / i_anterior. */
export const shiftRpm = (b: BikeModel, s: Setup, from: number, to: number, rpm: number) => (rpm * gearRatioTotal(b, s, to)) / gearRatioTotal(b, s, from);

/** Velocidade teórica no corte por marcha (km/h) para a relação montada — a mesma que a corrida usa. */
export const gearSpeeds = (b: BikeModel, s: Setup) => drivetrain(b, s).vCutKmh;

const clutchNm = memoS((s: Setup) => clutchCapNm(s));

/** Rider lies down from this gear on, cutting aero drag by TUCK_DRAG. */
/** Redução inteligente: rpm máximo após reduzir (fração do corte), queda de giro que dispara a redução
 *  (fração do maior giro alcançado na marcha) e tempo segurando a marcha reduzida. */
export const DOWNSHIFT_MAX = 0.95;
export const DOWNSHIFT_DROP = 0.1;
export const DOWNSHIFT_HOLD_S = 1.5;
export const TUCK_GEAR = 2;
export const TUCK_DRAG = 0.75; // deitado total na velocidade plena corta 25% do Cd·A
/** Piloto começa a deitar TUCK_DELAY_S depois de engatar a 2ª e leva TUCK_TRANS_S para deitar por completo. */
export const TUCK_DELAY_S = 2;
export const TUCK_TRANS_S = 1.2;
export const TUCK_MAX_CUT = 1 - TUCK_DRAG;
/** Velocidade a partir da qual o corte de vento do piloto deitado é pleno (abaixo, cresce com v). */
export const TUCK_FULL_KMH = 150;
/** Progresso 0..1 da transição sentado → deitado (só depois de 2 s na 2ª). */
export function tuckProgress(st: { t: number; gear: number; gearT?: number[] }) {
  const t2 = st.gearT?.[1];
  if (t2 === undefined || st.gear < 2) return 0;
  return Math.max(0, Math.min(1, (st.t - t2 - TUCK_DELAY_S) / TUCK_TRANS_S));
}
/** Fração do arrasto cortada: postura × velocidade (mais vento, mais corte), máx TUCK_MAX_CUT. */
export const tuckCut = (k: number, v: number) => TUCK_MAX_CUT * k * Math.min(1, (v * 3.6) / TUCK_FULL_KMH);
/** Solo, the rider also lies on the tank once past this speed (real riders tuck on the straight). */
export const TUCK_KMH = 80;
/** Without a 2-step the rider launches holding the throttle near the cut. */
export const LAUNCH_RPM_MUL = 0.98;
/** ...but never far past the power peak: a rider without 2-step feels where the engine pulls. */
export const LAUNCH_PEAK_MUL = 1.12;
/** Teto do giro de largada sem 2-step (protege biela, cilindro e válvulas no tranco da embreagem). */
export const LAUNCH_MAX_RPM = 9500;
/** Faixa do 2-step programável. */
export const LAUNCH_2STEP_MIN = 6000;
export const LAUNCH_2STEP_MAX = 12000;
/** Spinning tire keeps this share of the static grip. */
export const SPIN_GRIP = 0.85;
/** Rpm held before the drop (2-step, or near the cut capped by the power peak) — same value the sim launches at. */
export function launchRpm(b: BikeModel, s: Setup) {
  const { rpmLimit } = engine(b, s);
  // sem 2-step o piloto larga no giro ideal desta configuração (pneu, calibragem, peso, relação, torque)
  // largada: o piloto segura 2 s no corte e solta a embreagem de uma vez no giro máximo do motor
  // (ou no 2-step programado no módulo). Mesma regra para todas as motos: original x original empata.
  // só o 2-step passa do teto de largada (6.000–12.000 rpm); sem ele o piloto solta no máximo a LAUNCH_MAX_RPM
  if (isProg(s) && s.ecu.launch) return Math.min(Math.max(s.ecu.launch, LAUNCH_2STEP_MIN), LAUNCH_2STEP_MAX, rpmLimit);
  // sem corte eletrônico (platinado): não há limitador para segurar; o piloto segura no punho no pico de potência
  if (!hasElectronicCut(b, effectiveModulo(b, s))) return Math.min(engine(b, s).rpmPeak, rpmLimit, LAUNCH_MAX_RPM);
  return Math.min(rpmLimit, LAUNCH_MAX_RPM);
}
/**
 * Giro ideal de largada desta configuração. Cada giro candidato (passo 500 rpm, refinado em 150 rpm) é
 * largado na própria step(): curva de potência, mistura, escape, relação, embreagem, peso, pneu
 * (composto, calibragem, desgaste, temperatura), transferência de carga, empinada e patinagem.
 * O ideal é o giro com menor tempo até LAUNCH_EVAL_M; empate fica com o menor giro.
 * Também informa o limite físico estático min(tração μ·N_B, força que levanta o eixo A).
 */
export const LAUNCH_EVAL_M = 60;
const launchCache = new Map<string, { rpm: number; t60m: number; limit: number; mu: number; kg: number }>();
export const idealLaunch = memoBS((b: BikeModel, s: Setup) => {
  const key = b.id + JSON.stringify(s);
  const hit = launchCache.get(key);
  if (hit) return hit;
  const { rpmPeak, rpmLimit } = engine(b, s);
  const m = dryKg(b, s) + (s.riderKg ?? RIDER_KG);
  const mu = MU_ASPHALT * tireOf(s).grip * tempGrip(slotPart(s.slots.pneu, "pneu"), TIRE.ambC);
  const geo = pitchGeometry(b.id, dryKg(b, s) + b.tank * FUEL_DENSITY[s.fuel], s.riderKg ?? RIDER_KG);
  const limit = Math.min(tractionLimit(mu, m, geo), wheelieForce(m, geo));
  const run = (rpm: number) => {
    const st = newSim(b.tank);
    st.launchAt = rpm;
    while (st.x < LAUNCH_EVAL_M && st.t < 20 && !st.dry) step(st, b, s, DT, 1e9);
    return st.t;
  };
  const lo = Math.max(2500, Math.round((0.45 * rpmPeak) / 50) * 50), hi = Math.floor((LAUNCH_RPM_MUL * rpmLimit) / 50) * 50;
  let best = hi, bestT = run(hi);
  for (let r = lo; r < hi; r += 500) { const t = run(r); if (t < bestT - 1e-9) { bestT = t; best = r; } }
  for (let r = Math.max(lo, best - 450); r <= Math.min(hi, best + 450); r += 150) { const t = run(r); if (t < bestT - 1e-9) { bestT = t; best = r; } }
  const out = { rpm: best, t60m: bestT, limit, mu, kg: m };
  if (launchCache.size > 500) launchCache.clear();
  launchCache.set(key, out);
  return out;
});
/** Idle rpm with the natural single-cylinder hunt (±~45 rpm), deterministic in t. */
export function idleRpm(s: Setup, t: number) {
  const base = s.ecu.idle ?? 1300;
  return base + Math.sin(t * 5.1) * 28 + Math.sin(t * 13.7) * 12 + Math.sin(t * 1.3) * 6;
}
/** Rpm while bouncing on the limiter/2-step: drops ~250 rpm each cut, ~14 cuts/s. */
/** Sem limitador: o piloto segura o punho e o giro ondula entre target−100 e target−50, sem corte. */
export function heldRpm(target: number, t: number) {
  return target - 75 + 17.5 * Math.sin(t * 3.1) + 7.5 * Math.sin(t * 7.3);
}
export function cutRpm(target: number, t: number) {
  const ph = (t * 14) % 1;
  return target - 250 * (1 - ph);
}
const draftMulArg = (m: number) => m < 1;
export function step(st: SimState, b: BikeModel, s: Setup, dt: number, distance: number, wind = 0, dragMul = 1) {
  if (st.finishT !== null) return;
  const kg = Math.round((dryKg(b, s) + st.fuel * FUEL_DENSITY[s.fuel]) * 10) / 10;
  const { hp, rpmPeak, rpmLimit, fuelMul } = engine(b, s);
  const m = kg + (s.riderKg ?? RIDER_KG);
  const tire = tireOf(s);
  const gTop = (gearSpeeds(b, s)[st.gear - 1] ?? b.topSpeed) / 3.6;
  const prog = isProg(s);
  // largada: piloto segura no corte (ou no 2-step) e solta a embreagem de uma vez com giro alto.
  // Enquanto o virabrequim gira acima do câmbio a embreagem PATINA: transmite o torque de capacidade
  // (T_cap × relação total da 1ª ÷ raio do pneu) e o volante desacelera até acoplar. Depois de acoplada,
  // o giro segue a roda e sobe com a velocidade até o corte da 1ª.
  const cutFree = !hasElectronicCut(b, effectiveModulo(b, s));
  const l0 = st.launchAt ?? launchRpm(b, s);
  // rpm que o câmbio pede pela velocidade da RODA traseira (patinando, a roda gira mais rápido que a moto anda)
  const coupled = (Math.max(st.v, st.wv ?? 0) / gTop) * rpmLimit;
  // causa raiz do "teleporte": antes, ao acoplar, crankRpm virava undefined e o piso artificial devolvia o giro
  // ao rpm de largada no passo seguinte (patina/acopla alternando). Agora o acoplamento é um estado: uma vez
  // acoplada, o giro é o do câmbio (contínuo, ω = v·i/r) e só o volante integra o giro enquanto patina.
  const slipping = st.gear === 1 && !st.locked && (st.crankRpm ?? l0) > coupled + 50;
  if (slipping) st.rpm = Math.min(st.crankRpm ?? l0, rpmLimit);
  else {
    if (st.gear === 1) st.locked = true;
    const idle = s.ecu.idle ?? 1300;
    st.rpm = Math.max(idle, cutFree ? coupled : Math.min(coupled, rpmLimit));
    st.crankRpm = undefined;
  }
  const shape = powerShape(st.rpm, rpmPeak, b, s) * mixFactor(s, st.rpm, rpmPeak) * exhaustShape(b, s, st.rpm, rpmPeak);
  // limitador atua pela ROTAÇÃO do motor (nunca por km/h) e só em ignição com corte eletrônico
  const limiter = !cutFree && !slipping && coupled >= rpmLimit;
  const on = !st.dry && st.shiftT <= 0 && !limiter;
  let P = on ? hp * 735.5 * shape : 0;
  const pFull = P;
  // clutch slips when crank torque exceeds its capacity: P = T·ω, so the excess never reaches the wheel
  const omega = (st.rpm * 2 * Math.PI) / 60;
  const cNm = clutchNm(s) * (1 - 0.35 * (s.clutchWear ?? 0)); // discos gastos: menos atrito
  const cap = cNm * omega;
  let F: number;
  if (slipping) {
    // força na roda = T_cap × N_total ÷ r = T_cap × ω_corte ÷ v_topo(1ª): a relação da 1ª multiplica o torque
    const omegaL = (rpmLimit * 2 * Math.PI) / 60;
    F = (cNm * omegaL * ETA) / Math.max(gTop, 1);
    st.slip = 1 - coupled / Math.max(st.rpm, 1);
    // volante do motor: I·dω = (T_motor·acelerador − T_cap)·dt (acelerador do piloto do passo anterior)
    const tEng = (P * (st.gr?.thr ?? 1)) / Math.max(omega, 1);
    st.crankRpm = Math.max(coupled, st.rpm + ((tEng - cNm) / K("drivetrain.flywheel_i")) * (60 / (2 * Math.PI)) * dt);
    st.clutchJ = (st.clutchJ ?? 0) + cNm * Math.max(0, omega - (coupled * 2 * Math.PI) / 60) * dt;
  } else {
    st.slip = P > cap ? 1 - cap / P : 0;
    P = Math.min(P, cap);
    // wheel force through the gearbox: clutch slip keeps rpm up, so short gearing multiplies torque at launch
    F = (P * ETA) / Math.max(st.v, (st.rpm / rpmLimit) * gTop, 1);
  }
  // tração: peso sobre o pneu × aderência (calibragem, composto, desgaste). Passou do limite, o pneu
  // patina e o atrito dinâmico entrega menos que o estático: giro demais na largada perde tempo
  // dinâmica de solo (ground.ts): transferência de carga, empinada até 30°, patinagem com alívio do
  // piloto e temperatura do pneu mudando o atrito com o asfalto
  st.gr ??= newGround();
  // pneu físico: pressão → rigidez/deflexão → μ de contato, relaxação da carcaça e Crr(v) com histerese
  const tp = slotPart(s.slots.pneu, "pneu"), rec = recPsiOf(b.id);
  const ts = tireState(s.psi, rec, st.gr.nRear || m * G * 0.6);
  const tireGeo = tireGeometry(tp);
  const crr = crrAt(s.psi, rec, st.v, (tp.crr ?? 1) * tireGeo.rollingMul);
  const roll = rollingForce(crr, m * G);
  const pHyst = roll * st.v * (st.gr.nRear ? st.gr.nRear / (m * G) : 0.6); // parcela do traseiro vira calor nele
  const grip = (tp.grip ?? 1) * ts.muPsi * (1 - 0.18 * (s.tireWear ?? 0));
  // CG e inércia de arfagem desta moto com este piloto e o combustível que sobrou (vehicle-dynamics)
  const geo = pitchGeometry(b.id, kg, s.riderKg ?? RIDER_KG);
  const fReqFull = F;
  const gr = groundStep(st.gr, m, F, Math.max(st.v, (st.rpm / rpmLimit) * gTop, 1), st.v, MU_ASPHALT * grip, tp, dt, ts.sigma, pHyst, geo);
  P *= st.gr.thr;
  // banda mais rápida que o asfalto = ainda escorregando: atrito dinâmico até a roda voltar à velocidade da moto
  const sliding = gr.spin || (st.wv ?? 0) > st.v + 0.05;
  st.spin = sliding;
  st.wheelie = st.gr.wheelie;
  st.slideK = gr.spin ? gr.slide : slideMul((st.wv ?? 0) - st.v);
  F = gr.spin || !sliding ? gr.Fx : gr.trac * st.slideK;
  const vAir = st.v + wind;
  // rider lies on the tank only after catching the draft, and stays down: half the aero drag
  // sentado na largada e na 1ª; 2 s depois da 2ª deita gradualmente; corte de vento cresce com a postura e a velocidade
  void draftMulArg;
  st.tuckK = tuckProgress(st);
  st.tucked = st.tuckK >= 1;
  const tuck = 1 - tuckCut(st.tuckK, st.v);
  const drag = Math.sign(vAir) * dragForce(RHO, CDA * tuck * (tp.aero ?? 1) * aeroMul(s), 1, vAir) * dragMul; // ½·ρ·Cd·A·v²; pneus largos expõem mais área ao vento
  void tire;
  // massa equivalente: rodas sempre; virabrequim/volante refletido por (i_total/r)² só com a embreagem acoplada
  const iOverR = ((rpmLimit * 2 * Math.PI) / 60) / Math.max(gTop, 1);
  const engCoupled = !slipping && st.shiftT <= 0;
  // patinando, o virabrequim acelera junto com a roda (lado da roda), não com a moto
  const mEff = raceEffectiveMass(m, rearTireDynM(b, s), iOverR, engCoupled && !sliding);
  const a = (F - drag - roll) / mEff;
  st.crr = crr; st.deflM = ts.deflM; st.tireMu = gr.mu;
  st.pEngW = pFull * st.gr.thr; st.pW = P; st.fW = F; st.tracN = gr.trac; st.dragN = drag; st.rollN = roll; st.massKg = m; st.mEffKg = mEff; st.acc = a;
  st.thr = on ? st.gr.thr : 0; st.limiter = limiter;
  st.v = Math.max(0, st.v + a * dt);
  // roda traseira: o excesso de força sobre o atrito do asfalto acelera a massa girante (roda + motor acoplado);
  // com aderência a roda volta a rolar sem escorregar (velocidade da banda = velocidade da moto)
  if (sliding) st.wv = Math.max(st.v, Math.max(st.v, st.wv ?? 0) + ((fReqFull * st.gr.thr - F) / rearSpinMass(iOverR, engCoupled)) * dt);
  else st.wv = st.v;
  st.x += st.v * dt;
  st.t += dt;
  if (!st.dry) {
    st.fuel -= fuelFlow(s.fuel, Math.max(P, hp * 735.5 * 0.08)) * fuelMul * dt; // idle/shift still burns
    if (st.fuel <= 0) {
      st.fuel = 0;
      st.dry = true;
    }
  }
  if (st.shiftT > 0) st.shiftT -= dt;
  const kmh = st.v * 3.6;
  st.gearMax[st.gear - 1] = Math.max(st.gearMax[st.gear - 1] ?? 0, kmh);
  // upshift at rev limit, or earlier when the next gear already pulls harder at the wheel
  const curve = (rr: number) => powerShape(rr, rpmPeak, b, s);
  const nTop = (gearSpeeds(b, s)[st.gear] ?? gTop * 3.6) / 3.6;
  const nRpm = Math.min(rpmLimit, (st.v / nTop) * rpmLimit);
  const set = prog ? (s.ecu.shift?.[st.gear - 1] ?? 0) : 0;
  // força na roda ∝ P(rpm)/v: à MESMA velocidade, compara só a potência de cada marcha (sem dividir de novo pelo topo).
  // Passou do pico e a marcha atual parou de acelerar (vento venceu) → sobe: a próxima pode seguir puxando.
  const better = set > 0 ? st.rpm >= Math.min(set, rpmLimit) : st.gear < b.gears && st.rpm > rpmPeak && (curve(nRpm) >= curve(st.rpm) || (a < 0.15 && nRpm > rpmPeak * 0.8));
  // redução inteligente: trocou de marcha e o giro começou a cair. Só reduz quando o giro já caiu DOWNSHIFT_DROP
  // (10%) do maior giro alcançado nesta marcha, ainda desacelerando, e a marcha de baixo, à MESMA velocidade,
  // cai dentro da faixa segura (≤ 95% do corte) e entrega mais potência na roda.
  if (st.shiftT <= 0) st.gearRpmMax = Math.max(st.gearRpmMax ?? 0, st.rpm);
  const lost = st.rpm <= (st.gearRpmMax ?? st.rpm) * (1 - DOWNSHIFT_DROP);
  if (st.gear > 1 && st.shiftT <= 0 && a < 0 && lost && st.t >= (st.downLockT ?? 0)) {
    const pTop = (gearSpeeds(b, s)[st.gear - 2] ?? gTop * 3.6) / 3.6;
    const dRpm = (st.v / Math.max(pTop, 0.1)) * rpmLimit;
    if (dRpm <= rpmLimit * DOWNSHIFT_MAX && curve(dRpm) > curve(st.rpm) * 1.02) {
      st.shiftT = SHIFT_TIME;
      st.downFrom = st.gear;
      st.downV = st.v;
      st.gear--;
      st.gearRpmMax = 0;
      st.downLockT = st.t + DOWNSHIFT_HOLD_S; // segura a marcha: sem caçar troca
    }
  }
  // histerese: só volta para a marcha que perdeu giro quando já anda DOWNSHIFT_DROP mais rápido do que quando saiu dela
  // e ela de fato puxa mais (ou a de baixo bateu no corte) — sem isso a troca e a redução se alternam
  const backUp = st.downFrom !== st.gear + 1 || (st.v >= (st.downV ?? 0) * (1 + DOWNSHIFT_DROP) && (st.v >= gTop * 0.985 || curve(nRpm) >= curve(st.rpm)));
  if ((st.v >= gTop * 0.985 || (better && st.t >= (st.downLockT ?? 0))) && backUp && st.gear < b.gears && st.shiftT <= 0) {
    st.shiftT = prog ? qsFor(s.ecu, st.gear) / 1000 : SHIFT_TIME;
    st.gear++;
    st.gearRpmMax = 0;
    (st.gearT ??= [0])[st.gear - 1] = st.t;
  }
  st.top = Math.max(st.top, kmh);
  if (st.t60 === null && kmh >= 60) st.t60 = st.t;
  if (st.t100 === null && kmh >= 100) st.t100 = st.t;
  if (st.t100m === null && st.x >= 100) st.t100m = st.t;
  if (st.t500m === null && st.x >= 500) st.t500m = st.t;
  if (st.x >= distance) st.finishT = st.t;
}

/** Stopped on track: tank dry and the bike rolled to a halt. */
export const stalled = (st: SimState) => st.dry && st.v < 0.3 && st.finishT === null;

export const DT = 1 / 240;

export function simulate(b: BikeModel, s: Setup, distance: number, fuelL = b.tank) {
  const st = newSim(fuelL);
  while (st.finishT === null && !stalled(st) && st.t < 900) step(st, b, s, DT, distance);
  return st;
}

/** Pump price (R$/L) drifting through the day like a real market; deterministic per minute. */
export function fuelPrice(f: Fuel, now = Date.now()) {
  const m = now / 60000;
  const base = f === "gasolina" ? 6.29 : 4.39;
  const swing = Math.sin(m / 37) * 0.18 + Math.sin(m / 9.3) * 0.06 + Math.sin(m / 2.1) * 0.02;
  const k = Math.max(-0.15, Math.min(0.15, swing * (f === "gasolina" ? 1 : 1.2)));
  return Math.round(base * (1 + k) * fuelUsdMul() * 100) / 100;
}

/** Seeded PRNG (mulberry32): same seed and build give the same outcome. */
export function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
/** Stable 32-bit hash for seeding. */
export function seedOf(str: string) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) h = Math.imul(h ^ str.charCodeAt(i), 16777619);
  return h >>> 0;
}

/** Model of the player's active bike (Titan by default). */
export const bikeModel = (id: string | null | undefined): BikeModel => BIKE_MODELS.find((b) => b.id === id) ?? TITAN_160;

/** Slipstream uses the gap from the follower's front axle to the leader's rear axle,
 * with no overlap; returns the drag multiplier inside the configured window. */
export const DRAFT_MIN_GAP = 0;
export const DRAFT_MAX_GAP = 35;
export const DRAFT_MAX_CUT = 0.5; // vácuo ×0,5 · deitado ×0,5 → juntos ×0,25 do vento
/** Sprite length in meters and axle offsets from x (central axle C): B rear −3.3 m, A front +3.1 m. */
export const AXLE_B_M = -3.3;
export const AXLE_A_M = 3.1;
/** Draft opens when the follower's front axle (A) is within this many meters of the leader's rear axle (B). */
export const DRAFT_GAP = 2;
export function draftGap(self: SimState, leader: SimState) {
  return leader.x + AXLE_B_M - (self.x + AXLE_A_M);
}
export function draftMul(self: SimState, leader: SimState) {
  if (self.finishT !== null || self.t <= 0 || leader.x <= self.x) return 1;
  const g = draftGap(self, leader);
  // A must be fully behind B (no overlap / side by side) and within DRAFT_GAP
  return g >= 0 && g <= DRAFT_GAP + 1e-9 ? 1 - DRAFT_MAX_CUT : 1;
}
