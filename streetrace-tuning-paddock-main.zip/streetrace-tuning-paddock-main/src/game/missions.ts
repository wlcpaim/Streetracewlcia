// Missions panel (map + garage); a mission is done when its check passes and pays once when claimed.
import type { Player } from "./store";
import type { Scene } from "./Game";
import { factoryGear } from "./physics";

export interface Mission { id: string; title: string; desc: string; cash: number; xp: number; go?: { label: string; scene: Scene; work?: string }; spot?: string; done: (p: Player) => boolean }

export const MISSIONS: Mission[] = [
  { id: "conhecer", title: "Chegada na quebrada", desc: "O mapa é teu menu: toca nas fachadas. Streetrace Motos vende moto, Garagem guarda e abastece, AutoStreet vende peças, Oficina monta kits e tem dinamômetro, as lojas de comida e o Moto Táxi pagam corres, Corridas é o racha. Resgata pra começar.", cash: 100, xp: 5, done: () => true },
  { id: "primeira-moto", title: "Primeira nave", desc: "Sem moto não tem corre. Toca em LOJA, escolhe uma moto na Streetrace Motos e confirma a compra. Depois da compra você vai direto pra Garagem.", cash: 500, xp: 10, go: { label: "LOJA", scene: "store" }, spot: "Streetrace Motos", done: (p) => p.bikes.length > 0 },
  { id: "abastecer", title: "Tanque cheio", desc: "Moto nova vem quase seca. Na Garagem toca no galão, escolhe Gasolina ou Álcool e enche o tanque. Misturou combustível no tanque, vira mistura. Secou no meio da reta, ficou a pé.", cash: 250, xp: 8, go: { label: "GARAGEM", scene: "garage" }, spot: "Casa", done: (p) => !!p.fueled },
  { id: "primeiro-corre", title: "Primeiro corre", desc: "Entrega paga as contas. No Açaí toca em FAZER ENTREGAS, aceita o pedido que chegar e espera a entrega terminar. No tutorial, novos chamados só voltam no nível 4.", cash: 400, xp: 10, go: { label: "AÇAÍ", scene: "mapa", work: "acai" }, spot: "Açaí", done: (p) => (p.jobsDone ?? 0) > 0 },
  { id: "dino", title: "Teste de bancada", desc: "O dinamômetro mede a força da moto. Na Oficina toca no dinamômetro, depois em PUXAR, e lê a dica do mecânico. Toque 2× na tela pra voltar.", cash: 400, xp: 8, go: { label: "OFICINA", scene: "oficina" }, spot: "Oficina", done: (p) => (p.dinoUntil ?? 0) > 0 },
  { id: "primeiro-racha", title: "Primeiro pega", desc: "Hora do racha. Na Garagem toca em CORRER, Pega de rua, escolhe Fácil e a primeira pista. Na contagem de 5 s o motor fica na lenta e enche nos 2 últimos. No tutorial até perdendo você ganha XP.", cash: 800, xp: 15, go: { label: "CORRER", scene: "garage" }, spot: "Corridas", done: (p) => (p.wins ?? 0) > 0 || p.reports.length > 0 },
  { id: "primeira-peca", title: "Primeiro veneno", desc: "Prêmio no bolso, hora de preparar. Na AutoStreet abre Transmissão e compra um kit relação mais curto (mais leve) pra arrancar na 1/4 (400 m) e 1/2 milha (800 m). Ele abre no Fuçar como pinhão e coroa soltos.", cash: 600, xp: 12, go: { label: "PEÇAS", scene: "pecas" }, spot: "AutoStreet Auto Peças", done: (p) => { const g = factoryGear(p.activeBike ?? ""); return p.parts.some((id) => /^kit-/.test(id) || (/^(pinhao|coroa)-/.test(id) && id !== `pinhao-${g.front}` && id !== `coroa-${g.rear}`)); } },
  { id: "equipar-peca", title: "Mão na graxa", desc: "Na Garagem abre FUÇAR, vai em Transmissão e monta o kit relação que você comprou. A relação original volta pro Estoque da Garagem.", cash: 350, xp: 10, go: { label: "GARAGEM", scene: "garage" }, spot: "Casa", done: (p) => { const g = factoryGear(p.activeBike ?? ""); return p.setup.front !== g.front || p.setup.rear !== g.rear; } },
  { id: "level-3", title: "Nome na quebrada", desc: "Tutorial concluído: você já está no nível 5. Agora joga normal: faz pegas e corres pra ganhar XP e alcançar o nível 6. No nível 6 liberam as corridas Online, a Competição e as missões que ensinam o resto do jogo.", cash: 1000, xp: 20, done: (p) => p.level >= ONLINE_LEVEL },
];

/** Level that unlocks Online, Competição and Categorias. */
export const ONLINE_LEVEL = 6;
/** Level granted when the guided tutorial ends. */
export const TUTORIAL_END_LEVEL = 5;

export const MISSION_SCENES: Scene[] = ["mapa", "garage"];
export const claimed = (p: Player, id: string) => (p.missions ?? []).includes(id);
/** Done but not yet claimed (badge count). */
export const missionsReady = (p: Player): number => { const c = currentMission(p); return c ? (c.done(p) ? 1 : 0) : extrasReady(p); };
/** Missions unlock one by one: the current one is the first not yet claimed. */
export const currentMission = (p: Player) => MISSIONS.find((m) => !claimed(p, m.id));
export const unlocked = (p: Player, m: Mission) => claimed(p, m.id) || currentMission(p)?.id === m.id;
export const missionsLeft = (p: Player) => MISSIONS.filter((m) => !claimed(p, m.id)).length;

/** Map facade the current mission points to (soft pulse on the map). */
export const missionSpot = (p: Player) => { const c = currentMission(p); return c && !c.done(p) ? c.spot : undefined; };
/** Workplace modal to open when the map mounts (mission shortcut). */
let pendingWork: string | null = null;
export const requestWork = (id: string) => { pendingWork = id; window.dispatchEvent(new Event("open-work")); };
export const takeWork = () => { const w = pendingWork; pendingWork = null; return w; };

/** Skip tutorial: claims every campaign mission (cash + XP), lands at least on level 3. Cash/XP applied by caller via earn()/gainXp(). */
export const skipTotals = (p: Player) => {
  const left = MISSIONS.filter((m) => !claimed(p, m.id));
  return { cash: left.reduce((n, m) => n + m.cash, 0), xp: left.reduce((n, m) => n + m.xp, 0) };
};
/** Campaign finished: the list is cleared and daily + milestone missions take over. */
export const campaignDone = (p: Player) => !currentMission(p);

/** Local calendar day (UTC would reset Brazilian dailies at 21:00). */
export const today = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
export interface Daily { day: string; jobs: number; races: number; wins: number; claimed: string[] }
export const newDaily = (p: Player): Daily => ({ day: today(), jobs: p.jobsDone ?? 0, races: p.reports.length, wins: p.wins ?? 0, claimed: [] });

export interface Extra { id: string; title: string; desc: string; cash: number; xp: number; go?: { label: string; scene: Scene }; done: (p: Player) => boolean }
const d = (p: Player) => p.daily ?? newDaily(p);
export const DAILY: Extra[] = [
  { id: "d-corres", title: "Corre do dia", desc: "Faz 3 corres hoje.", cash: 120, xp: 2, done: (p) => (p.jobsDone ?? 0) - d(p).jobs >= 3 },
  { id: "d-pegas", title: "Aquece o motor", desc: "Corre 2 pegas de rua hoje.", cash: 100, xp: 2, done: (p) => p.reports.length - d(p).races >= 2 },
  { id: "d-vitoria", title: "Dono da rua", desc: "Vence 1 pega hoje.", cash: 180, xp: 3, done: (p) => (p.wins ?? 0) - d(p).wins >= 1 },
];
/** Missões principais pós-tutorial: seguem o conteúdo do jogo (garagem, oficina, pistas, trampo). */
export const MAIN: Extra[] = [
  { id: "m-relacao-14", title: "Relação de arrancada", desc: "Monta uma relação mais curta que a de fábrica e corre a 1/4 de milha.", cash: 600, xp: 8, go: RACE0(), done: (p) => runs(p, 402.33).length > 0 && (() => { const g = factoryGear(p.activeBike ?? ""); return p.setup.rear / p.setup.front > g.rear / g.front; })() },
  { id: "m-meia-milha", title: "Meia milha", desc: "Completa uma corrida de 1/2 milha (800 m).", cash: 500, xp: 6, go: RACE0(), done: (p) => runs(p, 804.67).length > 0 },
  { id: "m-escape", title: "Ronco novo", desc: "Monta um escapamento esportivo e confere no dinamômetro.", cash: 700, xp: 8, go: { label: "GARAGEM", scene: "garage" }, done: (p) => p.setup.slots.escape !== "escape-original" && (p.dinoUntil ?? 0) > 0 },
  { id: "m-modulo", title: "Mais giro", desc: "Monta um módulo de ignição de preparação.", cash: 800, xp: 8, go: { label: "GARAGEM", scene: "garage" }, done: (p) => p.setup.slots.modulo !== "modulo-original" },
  { id: "m-calibrar", title: "Calibrar pneu", desc: "Muda a calibragem do pneu e vence um pega.", cash: 400, xp: 5, go: RACE0(), done: (p) => (p.wins ?? 0) > 0 && p.setup.psi !== 29 && p.setup.psi !== 28 },
  { id: "m-trampo-10", title: "Corre firme", desc: "Completa 10 corres de entrega.", cash: 600, xp: 6, done: (p) => (p.jobsDone ?? 0) >= 10 },
  { id: "m-segunda-moto", title: "Garagem dupla", desc: "Tenha 2 motos na garagem.", cash: 1500, xp: 12, go: { label: "LOJA", scene: "store" }, done: (p) => p.bikes.length >= 2 },
  { id: "m-oleo", title: "Óleo em dia", desc: "Na Garagem abre FUÇAR e troca o óleo do motor. Óleo velho rouba força e aumenta o risco de quebra.", cash: 400, xp: 5, go: { label: "GARAGEM", scene: "garage" }, done: (p) => (p.missions ?? []).includes("level-3") && p.setup.oilKm < 1 && p.setup.km > 0 },
  { id: "m-online", title: "Primeiro online", desc: "Na Garagem toca em CORRER e entra no Online: enfrenta um piloto de verdade.", cash: 800, xp: 8, go: RACE0(), done: (p) => p.level >= ONLINE_LEVEL && (p.missions ?? []).includes("level-3") && p.reports.length > 0 },
  { id: "m-bololo", title: "Bololo", desc: "Corre o Bololo: 4 motos.", cash: 1200, xp: 12, go: RACE0(), done: (p) => p.reports.some((r) => r.distance > 6000) },
];
export const GOALS: Extra[] = [
  { id: "g-wins-5", title: "Casca grossa", desc: "Vence 5 pegas.", cash: 300, xp: 4, done: (p) => (p.wins ?? 0) >= 5 },
  { id: "g-wins-25", title: "Rei do racha", desc: "Vence 25 pegas.", cash: 1200, xp: 10, done: (p) => (p.wins ?? 0) >= 25 },
  { id: "g-jobs-20", title: "Trabalhador", desc: "Completa 20 corres.", cash: 400, xp: 5, done: (p) => (p.jobsDone ?? 0) >= 20 },
  { id: "g-parts-5", title: "Garagem cheia", desc: "Tenha 5 peças compradas.", cash: 500, xp: 5, done: (p) => p.parts.length >= 5 },
  { id: "g-km-100", title: "Rodado", desc: "Roda 100 km com a moto.", cash: 350, xp: 4, done: (p) => p.setup.km >= 100 },
  { id: "g-level-5", title: "Piloto respeitado", desc: "Chega no nível 5.", cash: 800, xp: 0, done: (p) => p.level >= 5 },
  { id: "g-level-10", title: "Lenda da quebrada", desc: "Chega no nível 10.", cash: 2500, xp: 0, done: (p) => p.level >= 10 },
];
function RACE0() { return { label: "CORRER", scene: "garage" as Scene }; }
const runs = (p: Player, m?: number) => p.reports.filter((r) => !r.dnf && !r.broke && (m === undefined || Math.abs(r.distance - m) < 0.5));
const best = (p: Player, m: number) => Math.min(Infinity, ...runs(p, m).map((r) => r.time));
const RACE = { label: "CORRER", scene: "garage" as Scene };
const DINO = { label: "OFICINA", scene: "oficina" as Scene };
/** Hardcore record challenges (after the tutorial, level 5+): claimed once, each with a redirect button, no tap hints. */
export const CHALLENGES: Extra[] = [
  { id: "c-18-95", title: "Bala de 1/8", desc: "Fecha a 1/8 de milha abaixo de 9,5 s.", cash: 1500, xp: 15, go: RACE, done: (p) => best(p, 201.16) < 9.5 },
  { id: "c-14-15", title: "Quarto de milha cravado", desc: "Fecha a 1/4 de milha abaixo de 15 s.", cash: 3000, xp: 25, go: RACE, done: (p) => best(p, 402.33) < 15 },
  { id: "c-top-130", title: "Ponteiro no fim", desc: "Passa de 130 km/h numa corrida.", cash: 2500, xp: 20, go: RACE, done: (p) => runs(p).some((r) => r.top >= 130) },
  { id: "c-0100-7", title: "Arranque monstro", desc: "Faz 0–100 km/h abaixo de 7 s.", cash: 3500, xp: 25, go: RACE, done: (p) => runs(p).some((r) => r.t100 != null && r.t100 < 7) },
  { id: "c-hp-25", title: "25 cavalos", desc: "Bate 25 cv numa corrida com a moto preparada.", cash: 4000, xp: 30, go: DINO, done: (p) => runs(p).some((r) => r.hp >= 25) },
  { id: "c-streak-5", title: "Invicto", desc: "Vence 5 pegas seguidos sem perder.", cash: 2000, xp: 20, go: RACE, done: (p) => (p.bestStreak ?? 0) >= 5 },
  { id: "c-dificil", title: "Sem medo do Difícil", desc: "Vence o computador no Difícil na 1/4 de milha.", cash: 3000, xp: 25, go: RACE, done: (p) => runs(p, 402.33).some((r) => r.result === "vitória" && r.diff === "Difícil") },
];
export const dailyClaimed = (p: Player, id: string) => !!p.daily && p.daily.day === today() && p.daily.claimed.includes(id);
/** Done-but-unclaimed count in the post-campaign lists (badge + tap hint). */
export const extrasReady = (p: Player) =>
  DAILY.filter((m) => !dailyClaimed(p, m.id) && m.done(p)).length + [...MAIN, ...GOALS, ...CHALLENGES].filter((m) => !claimed(p, m.id) && m.done(p)).length;

/** Open the missions panel on the next mount (e.g. right after buying a bike). */
let pendingMissions = false;
export const requestMissions = () => { pendingMissions = true; };
export const takeMissions = () => { const v = pendingMissions; pendingMissions = false; return v; };

/** Guided tutorial (every campaign step before the level goal): only the current mission's action is allowed and the engine never breaks. */
export const inTutorial = (p: Player) => { const c = currentMission(p); return !!c && c.id !== "level-3"; };
export const TUTORIAL_LOCK = "Termine o tutorial primeiro: siga a missão atual.";
/** Engine can't break only during the guided tutorial; afterwards physics breaks it at any level. */
export const engineSafe = (p: Player) => inTutorial(p);
