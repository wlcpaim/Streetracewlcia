import { onSound, soundMul } from "./settings";
import { ARCHIVED_BIKE_ART, ARCHIVED_BIKE_IMG, type BikeSpriteSet } from "./complegame/bike-sprites";
export { preloadImages } from "./image-preload";
import bgRegister from "@/assets/bg_register.jpg.asset.json";
import mapa1 from "@/assets/mapa1_night_v2.png.asset.json";
import bgGarage from "@/assets/bg_garage.jpg.asset.json";
import bgStore from "@/assets/bg_store.jpg.asset.json";
import bgRace from "@/assets/bg_race.jpg.asset.json";
import titan from "@/assets/titan160.png.asset.json";
import { POSE_ASSETS } from "./sprite-calibration";
import titan160SoloV3 from "@/assets/titan160_solo_v3.png.asset.json";
import titan160LightV3 from "@/assets/titan160_light_v3.png.asset.json";
import titan150SoloV3 from "@/assets/titan150_solo_v3.png.asset.json";
import titan150LightV3 from "@/assets/titan150_light_v3.png.asset.json";
import factor150SoloV3 from "@/assets/factor150_solo_v3.png.asset.json";
import factor150LightV3 from "@/assets/factor150_light_v3.png.asset.json";
import cg125SoloV3 from "@/assets/cg125_solo_v3.png.asset.json";
import riderIdle from "@/assets/rider_idle.png.asset.json";
import riderCrouch from "@/assets/rider_crouch.png.asset.json";
import track1 from "@/assets/track1.mp3.asset.json";
import track2 from "@/assets/track2.mp3.asset.json";
import track3 from "@/assets/track3.mp3.asset.json";
import track4 from "@/assets/track4.mp3.asset.json";
import titanStock from "@/assets/titan_stock.png.asset.json";
import titanLight from "@/assets/titan_light.png.asset.json";
import titanDore from "@/assets/titan_dore.png.asset.json";
import titanDoreGarage from "@/assets/titan_dore_garage.png.asset.json";
import fuelCan from "@/assets/fuel_can_garage.png.asset.json";
import fuelBadge from "@/assets/fuel_badge_icon.png.asset.json";
import tapHand from "@/assets/tap_hand.png.asset.json";
import riderDoreCrouch from "@/assets/rider_dore_crouch.png.asset.json";
import factorStock from "@/assets/factor_stock.png.asset.json";
import factorRed2026 from "@/assets/factor150_red_2026.png.asset.json";
import titan2026 from "@/assets/titan160_2026.png.asset.json";
import factorFoot from "@/assets/factor_rider_foot.png.asset.json";
import factorG1 from "@/assets/factor_rider_g1.png.asset.json";
import factorTuck from "@/assets/factor_rider_tuck.png.asset.json";
import titanFoot from "@/assets/titan_rider_foot.png.asset.json";
import titanG1 from "@/assets/titan_rider_g1.png.asset.json";
import titanTuck from "@/assets/titan_rider_tuck.png.asset.json";
import t26Foot from "@/assets/titan26_foot.png.asset.json";
import t26G1 from "@/assets/titan26_g1.png.asset.json";
import t26Crouch from "@/assets/titan26_crouch.png.asset.json";
import t26Tuck from "@/assets/titan26_tuck.png.asset.json";
import tRFoot from "@/assets/titan_race_foot.png.asset.json";
import tRG1 from "@/assets/titan_race_g1.png.asset.json";
import tRCrouch from "@/assets/titan_race_crouch.png.asset.json";
import tRTuck from "@/assets/titan_race_tuck.png.asset.json";
import tRSolo from "@/assets/titan_race_solo.png.asset.json";
import fRFoot from "@/assets/factor_race_foot.png.asset.json";
import fRG1 from "@/assets/factor_race_g1.png.asset.json";
import fRCrouch from "@/assets/factor_race_crouch.png.asset.json";
import fRTuck from "@/assets/factor_race_tuck.png.asset.json";
import fRSolo from "@/assets/factor_race_solo.png.asset.json";
import t15Foot from "@/assets/titan150_race_foot.png.asset.json";
import t15G1 from "@/assets/titan150_race_g1.png.asset.json";
import t15Crouch from "@/assets/titan150_race_crouch.png.asset.json";
import t15Tuck from "@/assets/titan150_race_tuck.png.asset.json";
import t15Solo from "@/assets/titan150_race_solo.png.asset.json";
import c125Foot from "@/assets/cg125_race_foot.png.asset.json";
import c125G1 from "@/assets/cg125_race_g1.png.asset.json";
import c125Crouch from "@/assets/cg125_race_crouch.png.asset.json";
import c125Tuck from "@/assets/cg125_race_tuck.png.asset.json";
import c125Solo from "@/assets/cg125_race_solo.png.asset.json";
import t26Solo from "@/assets/titan26_solo.png.asset.json";
import bossCg from "@/assets/boss_cg_twister.png.asset.json";
import factorRiderIdle from "@/assets/factor_rider_idle.png.asset.json";
import factorRiderCrouch from "@/assets/factor_rider_crouch.png.asset.json";
import bgOficina from "@/assets/bg_oficina.png.asset.json";
import bgMotoPecas from "@/assets/bg_autopecas_fixo.png.asset.json";
import btnDino from "@/assets/btn_dinamometro.png.asset.json";
import btnPrep from "@/assets/btn_preparacao.png.asset.json";
import btnDiag from "@/assets/btn_diagnostico.png.asset.json";
import btnMont from "@/assets/btn_montagem.png.asset.json";
import btnGaragem from "@/assets/btn_garagem.png.asset.json";
import bgDino from "@/assets/bg_dinamometro.png.asset.json";
import bgFactor from "@/assets/bg_factor150.png.asset.json";
import riderStockIdle from "@/assets/rider_stock_idle.png.asset.json";
import riderStockCrouch from "@/assets/rider_stock_crouch.png.asset.json";
import bgEntrega from "@/assets/bg_entrega.png.asset.json";
import bgTaxi from "@/assets/bg_mototaxi.png.asset.json";
import playerIcon from "@/assets/player_profile_icon.png.asset.json";
import walletIcon from "@/assets/wallet_icon.png.asset.json";
import trophyRecords from "@/assets/trophy_records.png.asset.json";
import tarefas from "@/assets/tarefas.png.asset.json";
import btnCorrer from "@/assets/btn_correr.png.asset.json";
import btnGaragemRound from "@/assets/back_to_map.png.asset.json";
import raceStart from "@/assets/race_start.jpg.asset.json";
import raceLoop from "@/assets/race_loop.jpg.asset.json";
import raceFavela from "@/assets/race_favela.png.asset.json";
import racePalm from "@/assets/race_palm.jpg.asset.json";
import raceCity from "@/assets/race_city.jpg.asset.json";

export const IMG_ALL = {
  register: bgRegister.url,
  mapa: mapa1.url,
  garage: bgGarage.url,
  store: bgStore.url,
  race: bgRace.url,
  titan: tRSolo.url,
  titanStockOld: titanStock.url,
  titanOld: titan.url,
  titanLight: titanLight.url,
  titanDore: titanDore.url,
  titanDoreGarage: titanDoreGarage.url,
  fuelCan: fuelCan.url,
  fuelBadge: fuelBadge.url,
  tapHand: tapHand.url,
  riderDoreCrouch: riderDoreCrouch.url,
  factorStock: fRSolo.url,
  factorStockOld: factorStock.url,
  factorRiderIdle: factorRiderIdle.url,
  factorFoot: fRFoot.url,
  factorG1: fRG1.url, factorCrouch: fRCrouch.url,
  factorTuck: fRTuck.url,
  titanFoot: tRFoot.url,
  titanG1: tRG1.url, titanCrouch: tRCrouch.url,
  titanTuck: tRTuck.url,
  bossCg: bossCg.url,
  titan150: t15Solo.url, titan150Foot: t15Foot.url, titan150G1: t15G1.url, titan150Crouch: t15Crouch.url, titan150Tuck: t15Tuck.url,
  cg125: c125Solo.url, cg125Foot: c125Foot.url, cg125G1: c125G1.url, cg125Crouch: c125Crouch.url, cg125Tuck: c125Tuck.url,
  factorRiderCrouch: factorRiderCrouch.url,
  oficina: bgOficina.url,
  dino: bgDino.url,
  btnDino: btnDino.url,
  btnPrep: btnPrep.url,
  btnDiag: btnDiag.url,
  btnMont: btnMont.url,
  btnGaragem: btnGaragem.url,
  factor: bgFactor.url,
  motoPecas: bgMotoPecas.url,
  riderIdle: riderIdle.url,
  riderCrouch: riderCrouch.url,
  riderStockIdle: riderStockIdle.url,
  riderStockCrouch: riderStockCrouch.url,
  entrega: bgEntrega.url,
  taxi: bgTaxi.url,
  playerIcon: playerIcon.url,
  wallet: walletIcon.url,
  trophy: trophyRecords.url,
  tarefas: tarefas.url,
  btnCorrer: btnCorrer.url,
  btnGaragemRound: btnGaragemRound.url,
  raceStart: raceStart.url,
  raceLoop: raceLoop.url,
  raceFavela: raceFavela.url,
  racePalm: racePalm.url,
  raceCity: raceCity.url,
};

/** Imagem vazia (transparente) no lugar dos sprites de moto arquivados. */
export const BLANK_SPRITE = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";
const BIKE_SPRITE_KEYS = ['titan', 'titanStockOld', 'titanOld', 'titanLight', 'titanDore', 'titanDoreGarage', 'riderDoreCrouch', 'factorStock', 'factorStockOld', 'factorRiderIdle', 'factorFoot', 'factorG1', 'factorCrouch', 'factorTuck', 'titanFoot', 'titanG1', 'titanCrouch', 'titanTuck', 'titan150', 'titan150Foot', 'titan150G1', 'titan150Crouch', 'titan150Tuck', 'cg125', 'cg125Foot', 'cg125G1', 'cg125Crouch', 'cg125Tuck', 'factorRiderCrouch', 'riderIdle', 'riderCrouch', 'riderStockIdle', 'riderStockCrouch'] as const;
for (const k of BIKE_SPRITE_KEYS) ARCHIVED_BIKE_IMG[k] = IMG_ALL[k];
/** STARTGAME: sprites de piloto em moto e moto sozinha removidos (arquivados no COMPLEGAME). */
export const IMG = { ...IMG_ALL, ...Object.fromEntries(BIKE_SPRITE_KEYS.map((k) => [k, BLANK_SPRITE])) } as typeof IMG_ALL;

export const TRACKS = [
  { title: "Os Menor Em Ação 2", artist: "MC Joãozinho VT, Leozinho ZS, Kadu & V7", url: track1.url },
  { title: "Set Djay W 3", artist: "MC Vitão do Savoy, Davi, Ryan SP & PP da VS", url: track2.url },
  { title: "Imbatível", artist: "MC Lele JP", url: track3.url },
  { title: "Espancando Recalque", artist: "MC Hariel · DJ Pedro", url: track4.url },
];

// ---- Radio ----
let audio: HTMLAudioElement | null = null;
let idx = 0;
let muted = false;
/** True while the player has left the tab/app; blocks auto-advance from starting playback. */
let away = false;
let retry: ReturnType<typeof setTimeout> | undefined;
const audioSubs = new Set<() => void>();
export const radio = {
  get index() {
    return idx;
  },
  get paused() {
    return muted;
  },
  toggle() {
    muted = !muted;
    if (muted) audio?.pause();
    else this.el().play().catch(() => {});
    audioSubs.forEach((f) => f());
  },
  subscribe(f: () => void) {
    audioSubs.add(f);
    return () => audioSubs.delete(f);
  },
  /** One reusable element: the browser keeps the play permission granted by the first tap, so the playlist auto-advances. */
  el() {
    if (!audio) {
      audio = new Audio();
      audio.preload = "auto";
      audio.volume = Math.min(1, 0.004 * soundMul("music"));
      onSound(() => { if (audio) audio.volume = Math.min(1, 0.004 * soundMul("music")); });
      audio.onended = () => this.next();
      audio.onerror = () => {
        clearTimeout(retry);
        retry = setTimeout(() => this.next(), 1500);
      };
      audio.src = TRACKS[idx]!.url;
    }
    return audio;
  },
  async start() {
    away = false;
    if (muted) return;
    this.el().play().catch(() => {});
  },
  async next() {
    idx = (idx + 1) % TRACKS.length;
    audioSubs.forEach((f) => f());
    const a = this.el();
    a.src = TRACKS[idx]!.url;
    if (!muted && !away) a.play().catch(() => {});
  },
  pause() {
    away = true;
    clearTimeout(retry);
    audio?.pause();
  },
  resume() {
    away = false;
    if (!muted) audio?.play().catch(() => {});
  },
};

/** Garage image and the 4 race poses per bike model (same axles/ground in every image). */
const blankSet = (brand: string) => ({ solo: BLANK_SPRITE, brand, foot: BLANK_SPRITE, g1: BLANK_SPRITE, crouch: BLANK_SPRITE, tuck: BLANK_SPRITE });
Object.assign(ARCHIVED_BIKE_ART, {
  titan160: { solo: IMG_ALL.titan, brand: "Honda", foot: IMG_ALL.titanFoot, g1: IMG_ALL.titanG1, crouch: IMG_ALL.titanCrouch, tuck: IMG_ALL.titanTuck },
  factor150: { solo: IMG_ALL.factorStock, brand: "Yamaha", foot: IMG_ALL.factorFoot, g1: IMG_ALL.factorG1, crouch: IMG_ALL.factorCrouch, tuck: IMG_ALL.factorTuck },
  titan150: { solo: IMG_ALL.titan150, brand: "Honda", foot: IMG_ALL.titan150Foot, g1: IMG_ALL.titan150G1, crouch: IMG_ALL.titan150Crouch, tuck: IMG_ALL.titan150Tuck },
  cg125: { solo: IMG_ALL.cg125, brand: "Honda", foot: IMG_ALL.cg125Foot, g1: IMG_ALL.cg125G1, crouch: IMG_ALL.cg125Crouch, tuck: IMG_ALL.cg125Tuck },
});
/** Fotos antigas com retrovisores e rabeta: backup do COMPLEGAME (as motos agora saem da loja sem eles). */
Object.assign(ARCHIVED_BIKE_IMG, { titan160Mirrors: titan160SoloV3.url, titan150Mirrors: titan150SoloV3.url, factor150Mirrors: factor150SoloV3.url });
/** Garage image and the 4 race poses per bike model (loja/garagem: moto sem retrovisores e sem rabeta). */
export const BIKE_ART: Record<string, BikeSpriteSet> = {
  titan160: { ...blankSet("Honda"), ...POSE_ASSETS.titan160, solo: titan160LightV3.url },
  factor150: { ...blankSet("Yamaha"), ...POSE_ASSETS.factor150, solo: factor150LightV3.url },
  titan150: { ...blankSet("Honda"), ...POSE_ASSETS.titan150, solo: titan150LightV3.url },
  cg125: { ...blankSet("Honda"), ...POSE_ASSETS.cg125, solo: cg125SoloV3.url },
};
/** Escala de exibição por modelo (vazio = todas no tamanho medido); faixa e posição nunca mudam o tamanho. */
export const BIKE_SCALE: Record<string, number> = {};
export const bikeScale = (id: string | null | undefined) => BIKE_SCALE[id ?? ""] ?? 1;
export const bikeArt = (id: string | null | undefined) => BIKE_ART[id ?? ""] ?? BIKE_ART["titan160"]!;
/** Imagem da moto parada (todas saem da loja sem retrovisores e sem rabeta). */
export const bikeSolo = (id: string | null | undefined, _removed?: { mirrors: boolean; rabeta: boolean }) => bikeArt(id).solo;
