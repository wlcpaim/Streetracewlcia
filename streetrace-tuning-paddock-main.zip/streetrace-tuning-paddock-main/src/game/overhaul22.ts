/**
 * STREETRACE PHYSICS OVERHAUL 2.2 — camada física multiescala e auditoria unificada.
 *
 * Funções puras, SI. Cada número sai com unidade, fórmula, origem (calculado/estimado/ficha/medido),
 * margem e status. Não usa probabilidade. Nesta etapa NÃO altera o passo da corrida (physics.step):
 * recalcula cada grandeza de forma independente e aponta onde o passo atual contradiz a física.
 */
import { clutchCapNm, slotPart } from "./parts";
import { exhaustSpec, exhaustInfo } from "./exhaust";
import { RIDER_KG, STOCK_SETUP, ccOf, drivetrain, engine, exhaustId, gearSpeeds, mixtureAt, stats, tireOf, type BikeModel, type Setup } from "./physics";
import { EST, FUEL, crankW, crownGrowthMm, cylVol, geoOf, injectionAt, omegaOf, pistonAcc, rodStretchMm, torqueCurve, veAt, type Geo } from "./enginephys";
import { buildOf, physicsAt } from "./mechlimits";

export type Status = "PASS" | "WARNING" | "OVERLOAD" | "FAILURE" | "INSUFFICIENT_DATA" | "NOT_VALIDATED";
export type Src = "calculado" | "estimado" | "ficha" | "medido" | "faltante";
export type Row = { mod: string; item: string; value: number | null; unit: string; formula: string; params: string; src: Src; limit?: number | null; marginPct?: number | null; status: Status; why: string };

const DEG = Math.PI / 180;
const P_ATM = 101325;
const R = 287.05;
const r3 = (n: number) => Math.round(n * 1000) / 1000;
const r1 = (n: number) => Math.round(n * 10) / 10;

/** Parâmetros novos desta etapa: nenhum é medido. */
export const EST22 = {
  gammaU: 1.35, gammaB: 1.27, // não queimado / queimado
  tWallK: 450, // parede média da câmara
  hWall: 1200, // W/(m²·K) coeficiente médio (ordem de Woschni; sem calibração)
  pExhPa: 1.1 * P_ATM,
  tResK: 1000, // gás residual
  rodUtsMPa: null as number | null, // ruptura: sem ficha → INSUFFICIENT_DATA
  rodFatigueMPa: null as number | null, // limite de fadiga: sem ficha
  rodSafety: 1.5, // fator de projeto para carga admissível (escolha de projeto, não física)
  valveMassKg: 0.06, valveLiftM: 0.0075, camDurDeg: 240, springPreN: 230, springKNmm: 45, // calibrado só para a original não flutuar abaixo do corte de fábrica
  pistonCapJK: 0.25 * 900, ringToLinerWK: 9, headCapJK: 2.6 * 900, headToAirWK: 14, oilCapJK: 0.9 * 1900, oilToAirWK: 6,
  egtK: 1123,
};

// ===================== SOLVER MULTIESCALA =====================
/** Quantos graus de virabrequim um passo externo pula. 10.500 rpm a 1/240 s = 262,5°. */
export const degPerStep = (rpm: number, dt = 1 / 240) => rpm * 6 * dt;
/** Subpassos angulares necessários para resolver o motor dentro de um passo externo. */
export function substeps(rpm: number, dt = 1 / 240, baseDeg = 1) {
  if (!(baseDeg >= 0.5 && baseDeg <= 1)) throw new RangeError("baseDeg deve ficar entre 0,5° e 1°");
  return Math.max(1, Math.ceil(degPerStep(rpm, dt) / baseDeg));
}

export interface Cycle22 { pMaxBar: number; thPeakDeg: number; imepBar: number; workJ: number; qFuelJ: number; qRelJ: number; qWallJ: number; energyErrPct: number; airMg: number; fuelMg: number; lambda: number; residualFrac: number; tMaxK: number; steps: number; meanTorqueNm: number; pAt: (thDeg: number) => number; torqueAt: (thDeg: number) => number }

/**
 * Ciclo fechado com passo angular adaptativo: base 0,5–1°, refinado ×8 perto do PMS, da centelha,
 * durante a queima e onde a pressão varia rápido. Integração de Heun (RK2) da 1ª lei:
 * dP = [−γ·P·dV + (γ−1)·(dQ_comb − dQ_parede)] / V.
 */
export function cycle22(b: BikeModel, s: Setup, rpm: number, load = 1, opts: { baseDeg?: number; lambda?: number; sparkDeg?: number } = {}): Cycle22 {
  const base = opts.baseDeg ?? 1;
  const g = geoOf(b, s);
  const e = engine(b, s);
  const fuel = FUEL[e.eth ? "etanol" : "gasolina"];
  const omega = omegaOf(rpm);
  const ve = veAt(b, s, rpm) * Math.max(0.12, load);
  const pIvc = P_ATM * ve;
  const vIvc = cylVol(g, -Math.PI);
  // gás residual: o que sobra no volume da câmara a pressão de escape
  const mRes = (EST22.pExhPa * g.vcM3) / (R * EST22.tResK);
  const mTot = (pIvc * vIvc) / (R * EST.tIntakeK);
  const airKg = Math.max(1e-7, mTot - mRes);
  const lambda = opts.lambda ?? EST.lambdaWot * (1 + Math.max(-0.5, mixtureAt(s, rpm, e.rpmPeak).lean));
  const fuelKg = airKg / (fuel.afr * lambda);
  const qFuel = fuelKg * fuel.lhv;
  const qRel = qFuel * Math.min(1, 1 / lambda) * EST.combEff;
  const soc = -(opts.sparkDeg ?? EST.sparkBtdc) * DEG;
  const dur = EST.burnDeg * DEG;
  const xb = (th: number) => (th < soc ? 0 : 1 - Math.exp(-EST.wiebeA * Math.min(1, (th - soc) / dur) ** (EST.wiebeM + 1)));
  const area = (th: number) => 2 * (Math.PI * g.boreMm ** 2 / 4) * 1e-6 + Math.PI * (g.boreMm / 1000) * (cylVol(g, th) - g.vcM3) / g.areaM2;
  const gam = (th: number) => EST22.gammaU + (EST22.gammaB - EST22.gammaU) * xb(th);
  const mass = mTot + fuelKg;
  const dPdth = (th: number, P: number, dth: number) => {
    const V = cylVol(g, th), dV = (cylVol(g, th + dth) - V) / dth;
    const T = (P * V) / (mass * R);
    const dQw = (EST22.hWall * area(th) * (T - EST22.tWallK)) / omega; // J/rad
    const dQc = (qRel * (xb(th + dth) - xb(th))) / dth;
    const y = gam(th);
    return { d: (-y * P * dV + (y - 1) * (dQc - dQw)) / V, dQw, dV };
  };
  const pts: { th: number; P: number }[] = [{ th: -Math.PI, P: pIvc }];
  let th = -Math.PI, P = pIvc, w = 0, qW = 0, dUs = 0, pMax = P, thPk = 0, tMax = 0, steps = 0;
  while (th < Math.PI - 1e-12) {
    const near = Math.abs(th) < 15 * DEG || (th > soc - 5 * DEG && th < soc + dur + 5 * DEG);
    let dth = Math.min((near ? base / 8 : base) * DEG, Math.PI - th);
    const k1 = dPdth(th, P, dth);
    if (Math.abs(k1.d * dth) > 0.05 * P) dth /= 4; // pressão variando rápido: refina de novo
    const a = dPdth(th, P, dth);
    const pe = P + a.d * dth;
    const c = dPdth(th + dth, pe, dth);
    const P2 = P + 0.5 * (a.d + c.d) * dth;
    const dV = cylVol(g, th + dth) - cylVol(g, th);
    w += 0.5 * (P + P2) * dV;
    qW += 0.5 * (a.dQw + c.dQw) * dth;
    dUs += (P2 * cylVol(g, th + dth) - P * cylVol(g, th)) / (gam(th) - 1);
    th += dth; P = P2; steps++;
    pts.push({ th, P });
    if (P > pMax) { pMax = P; thPk = th; }
    tMax = Math.max(tMax, (P * cylVol(g, th)) / (mass * R));
  }
  // fechamento da 1ª lei: Q_comb − Q_parede = W + ΔU  (U = PV/(γ−1))
  const dU = dUs; // Σ d(PV)/(γ−1) com o γ de cada passo
  const energyErrPct = (100 * Math.abs(qRel * xb(Math.PI) - qW - w - dU)) / qRel;
  const pAt = (deg: number) => {
    const t = deg * DEG;
    let lo = 0, hi = pts.length - 1;
    if (t <= pts[0]!.th) return pts[0]!.P;
    if (t >= pts[hi]!.th) return pts[hi]!.P;
    while (hi - lo > 1) { const m = (lo + hi) >> 1; if (pts[m]!.th <= t) lo = m; else hi = m; }
    const A = pts[lo]!, B = pts[hi]!; return A.P + ((B.P - A.P) * (t - A.th)) / (B.th - A.th);
  };
  const recKg = buildOf(b, s).recKg;
  const torqueAt = (deg: number) => instTorque(g, deg, rpm, recKg, cyclePressure(pAt, deg));
  let tq = 0; for (let d = 0; d < 720; d += 0.5) tq += torqueAt(d) * 0.5; tq /= 720;
  return { pMaxBar: pMax / 1e5, thPeakDeg: thPk / DEG, imepBar: w / g.vdM3 / 1e5, workJ: w, qFuelJ: qFuel, qRelJ: qRel, qWallJ: qW, energyErrPct, airMg: airKg * 1e6, fuelMg: fuelKg * 1e6, lambda, residualFrac: mRes / mTot, tMaxK: tMax, steps, meanTorqueNm: tq, pAt, torqueAt };
}
/** Pressão nos 720°: 0° = PMS de combustão; fora do ciclo fechado, escape/admissão. */
export function cyclePressure(pAt: (d: number) => number, d: number) {
  if (d < 180) return pAt(d);
  if (d >= 540) return pAt(d - 720);
  return d < 360 ? EST22.pExhPa : 0.9 * P_ATM;
}
/** Torque instantâneo: T = F_pistão · r · (sinθ + k·sin2θ / (2√(1−k²sin²θ))). */
export function instTorque(g: Geo, deg: number, rpm: number, recKg: number, pPa: number) {
  const th = deg * DEG, k = g.rM / g.lM;
  const f = (pPa - P_ATM) * g.areaM2 - recKg * pistonAcc(g, omegaOf(rpm), th);
  return f * g.rM * (Math.sin(th) + (k * Math.sin(2 * th)) / (2 * Math.sqrt(1 - k * k * Math.sin(th) ** 2)));
}

// ===================== BIELA: LIMITES SEPARADOS =====================
export function rod22(b: BikeModel, s: Setup, rpm: number) {
  const g = geoOf(b, s), k0 = buildOf(b, s), c = cycle22(b, s, rpm, 1, { baseDeg: 0.5 });
  const kk = g.rM / g.lM, w = omegaOf(rpm);
  let tens = 0, tDeg = 0, comp = 0, cDeg = 0;
  for (let d = 0; d < 720; d += 0.5) {
    const th = d * DEG;
    const fp = (cyclePressure(c.pAt, d) - P_ATM) * g.areaM2 - k0.recKg * pistonAcc(g, w, th);
    const fr = fp / Math.cos(Math.asin(kk * Math.sin(th)));
    if (fr > comp) { comp = fr; cDeg = d; }
    if (-fr > tens) { tens = -fr; tDeg = d; }
  }
  const A = EST.rodAreaMm2, sT = tens / A, sC = comp / A; // N/mm² = MPa
  const sMean = (sC - sT) / 2, sAmp = (sC + sT) / 2;
  const buck = (Math.PI ** 2 * EST.rodE_GPa * 1e3 * EST.rodI_mm4) / g.rodMm ** 2;
  const allow = EST.rodYieldMPa / EST22.rodSafety;
  const sMax = Math.max(sT, sC);
  return { rpm, tensN: tens, tDeg, compN: comp, cDeg, sT, sC, sMean, sAmp, sMax, buckN: buck, allowMPa: allow, yieldMPa: EST.rodYieldMPa, legacyN: k0.rodLimitN, strainMm: rodStretchMm(tens),
    mech: sMax > EST.rodYieldMPa ? "escoamento" : comp > buck ? "flambagem" : null as string | null };
}

// ===================== ALIMENTAÇÃO: FONTE ÚNICA =====================
/** AR → COMBUSTÍVEL NECESSÁRIO → BICO → BOMBA → ENTREGUE → LAMBDA REAL. */
export function fuel22(b: BikeModel, s: Setup, rpm: number) {
  const e = engine(b, s);
  const f = FUEL[e.eth ? "etanol" : "gasolina"];
  const rho = s.fuel === "etanol" ? 0.789 : 0.745; // kg/L
  const c = cycle22(b, s, rpm, 1);
  const airGs = (c.airMg / 1000) * (rpm / 120);
  const target = EST.lambdaWot;
  // o mapa (speed-density) foi calibrado para o motor original com o bico original: abre o mesmo
  // tempo; bico maior entrega proporcionalmente mais; cilindro maior puxa mais ar que o mapa prevê
  const cs = cycle22(b, { ...STOCK_SETUP, fuel: s.fuel }, rpm, 1);
  const mapAirGs = (cs.airMg / 1000) * (rpm / 120);
  const bicoMul = slotPart(s.slots.bico, "bico").flow ?? 1;
  const trim = 1; // trims do Athlon ainda não entram nesta cadeia (pendente)
  const needGs = (mapAirGs / (f.afr * target)) * bicoMul * trim;
  const pumpGs = ((EST.pumpLh * (slotPart(s.slots.bomba, "bomba").flow ?? 1)) * rho * 1000) / 3600;
  const rail = needGs > pumpGs ? EST.railBar * (pumpGs / needGs) ** 2 : EST.railBar;
  const cycleMs = 120000 / rpm;
  const openFrac = Math.max(0, (cycleMs - EST.injDeadMs) / cycleMs);
  const injGs = ((EST.injFlowCcMin * (slotPart(s.slots.bico, "bico").flow ?? 1) * Math.sqrt(rail / EST.railBar)) / 60) * rho * openFrac;
  const deliv = Math.min(needGs, injGs, pumpGs);
  const lambdaReal = airGs / (f.afr * deliv);
  const pulseMs = (needGs / (injGs / openFrac)) * cycleMs + EST.injDeadMs;
  const old = injectionAt(b, s, rpm);
  return { rpm, airGs, needGs, injGs, pumpGs, delivGs: deliv, railBar: rail, pulseMs, duty: (pulseMs / cycleMs) * 100, lambdaTarget: target, mapAirGs, bicoMul, lambdaReal, lambdaMix: c.lambda, lambdaOld: old.lambda, short: deliv < needGs * 0.999, limitedBy: deliv >= needGs * 0.999 ? "nada" : injGs <= pumpGs ? "bico" : "bomba" };
}

// ===================== EMBREAGEM =====================
export function clutch22(b: BikeModel, s: Setup) {
  const cap = clutchCapNm(s);
  const tc = torqueCurve(b, s);
  const over = tc.rows.filter((r) => r.Nm > cap);
  return { capNm: cap, maxNm: tc.peakTorque.Nm, atRpm: tc.peakTorque.rpm, slipFrom: over[0]?.rpm ?? null, slipTo: over.at(-1)?.rpm ?? null, excessNm: Math.max(0, tc.peakTorque.Nm - cap) };
}

// ===================== TREM DE VÁLVULAS DINÂMICO =====================
/** Perfil cicloidal no tempo do came; contato perdido quando m·|a| > F_mola(x) na desaceleração. */
export function valve22(s: Setup, rpm: number) {
  const springMul = s.slots.molas === "molas-duplas" ? 1.35 : s.slots.molas === "molas-pratos" ? 1.35 : 1;
  const mass = EST22.valveMassKg * (s.slots.molas === "molas-pratos" ? 0.85 : 1);
  const L = EST22.valveLiftM, D = EST22.camDurDeg * DEG; // em graus de virabrequim
  const w = omegaOf(rpm);
  let worst = Infinity, at = 0, lossDeg: number | null = null;
  for (let d = 0; d <= EST22.camDurDeg; d += 0.5) {
    const ph = d * DEG / D;
    const x = (L / 2) * (1 - Math.cos(2 * Math.PI * ph));
    const a = (L / 2) * (2 * Math.PI / D) ** 2 * Math.cos(2 * Math.PI * ph) * w * w;
    if (a < 0) {
      const spring = (EST22.springPreN + EST22.springKNmm * x * 1000) * springMul;
      const m = spring / (mass * -a);
      if (m < worst) { worst = m; at = d; }
      if (m < 1 && lossDeg === null) lossDeg = d;
    }
  }
  return { rpm, margin: worst, atDeg: at, lossDeg, floats: worst < 1 };
}
export function floatRpm22(s: Setup) {
  let lo = 3000, hi = 25000;
  for (let i = 0; i < 40; i++) { const m = (lo + hi) / 2; if (valve22(s, m).floats) hi = m; else lo = m; }
  return Math.round(lo);
}

// ===================== ESCAPE: RESSONÂNCIA EMERGENTE =====================
/** A onda refletida volta em t = 2L/a; chega útil se volta dentro do cruzamento (~ 180° após a abertura). */
export function exhaust22(b: BikeModel, s: Setup) {
  const x = exhaustSpec(exhaustId(s));
  const a = Math.sqrt(1.35 * R * EST22.egtK);
  const tRet = (2 * x.L / 1000) / a;
  const returnDeg = 180; // EVO ~ 50° APMI → cruzamento ~ PMS: ESTIMADO sem ficha do comando
  const tuned = returnDeg / (6 * tRet);
  return { soundMs: a, tRetMs: tRet * 1000, tunedRpm: tuned, tableRpm: exhaustInfo(exhaustId(s), ccOf(b, s), 8000).tunedRpm, d: x.d, L: x.L, bandBonus: Math.abs(x.low) + Math.abs(x.mid) + Math.abs(x.high) };
}

// ===================== TÉRMICO ACOPLADO =====================
/** Temperaturas dos três nós (K): pistão, cabeçote/cilindro, óleo. */
export interface Nodes3 { tp: number; th: number; to: number }
/** Ar ambiente do modelo térmico (K). */
export const AIR_K = 303;
/**
 * Um passo do modelo de três nós: C·dT/dt = Q_entra − Q_sai. Calor de parede qW (W) dividido 35% pistão / 65% cabeçote;
 * anel→camisa e pistão→óleo por condução, cabeçote e óleo para o ar com convecção forçada (1 + v/10).
 */
export function thermal3Step(n: Nodes3, qW: number, vMs: number, dt: number) {
  const hAir = 1 + vMs / 10;
  const pRing = EST22.ringToLinerWK * (n.tp - n.th);
  const pOil = 4 * (n.tp - n.to);
  n.tp += ((qW * 0.35 - pRing - pOil) / EST22.pistonCapJK) * dt;
  n.th += ((qW * 0.65 + pRing - EST22.headToAirWK * hAir * (n.th - AIR_K)) / EST22.headCapJK) * dt;
  n.to += ((pOil - EST22.oilToAirWK * hAir * (n.to - AIR_K)) / EST22.oilCapJK) * dt;
  return n;
}
/** Três nós (pistão, cabeçote/cilindro, óleo) integrados no tempo a partir do calor de parede do ciclo. */
export function thermal22(b: BikeModel, s: Setup, rpm: number, seconds = 60, vMs = 25) {
  const c = cycle22(b, s, rpm, 1);
  const qW = Math.max(0, c.qWallJ) * (rpm / 120); // W para as paredes
  const n: Nodes3 = { tp: 363, th: 363, to: 363 }; const dt = 0.05;
  for (let t = 0; t < seconds; t += dt) thermal3Step(n, qW, vMs, dt);
  const { tp, th, to } = n;
  const k = buildOf(b, s);
  const legacy = physicsAt(b, s, k, rpm, 1, 200).eqC;
  return { rpm, seconds, wallW: qW, pistonC: tp - 273.15, headC: th - 273.15, oilC: to - 273.15, crownGrowthMm: crownGrowthMm(tp - 273.15), legacyEqC: legacy, pistonLimC: k.pistonLimC };
}

// ===================== DINÂMICA DO VEÍCULO =====================
export function vehicle22(b: BikeModel, s: Setup, driveN: number) {
  const m = stats(b, s).kg + (s.riderKg ?? RIDER_KG);
  const tire = tireOf(s);
  const muN = EST.mu * tire.grip;
  // tração limitada por N_traseiro = m·g·(share + h/L·a/g), com a = μN/m → resolvendo:
  const share = EST.rearStaticShare, hL = EST.cgHeightM / EST.wheelbaseM;
  const slipN = 1 - muN * hL > 0 ? (muN * m * 9.81 * share) / (1 - muN * hL) : Infinity;
  const wheelieN = (m * 9.81 * (1 - share)) / hL; // dianteira descarrega: N_frente = 0
  const fMax = Math.min(slipN, wheelieN);
  const raceTraction = 0.62 * m * 9.81 * 1.05 * tire.grip;
  return { m, fMaxN: fMax, slipN, wheelieN, raceTractionN: raceTraction, driveN, wheelie: wheelieN < slipN, diffPct: (100 * (raceTraction - fMax)) / fMax };
}

// ===================== AUDITORIA =====================
const margin = (v: number, lim: number) => (100 * (lim - v)) / lim;
export function audit22(b: BikeModel, s: Setup): Row[] {
  const out: Row[] = [];
  const add = (r: Row) => out.push(r);
  const e = engine(b, s);
  const top = e.rpmLimit;
  // solver
  add({ mod: "Solver", item: `Graus por passo a ${top} rpm`, value: degPerStep(top), unit: "°", formula: "Δθ = 6·rpm·Δt", params: "Δt = 1/240 s", src: "calculado", status: degPerStep(top) > 1 ? "WARNING" : "PASS", why: "O passo da corrida pula esse ângulo; o motor 2.2 resolve em subpassos angulares." });
  add({ mod: "Solver", item: "Subpassos angulares por passo", value: substeps(top), unit: "passos", formula: "ceil(Δθ / 1°)", params: "base 1°, refino ×8 no PMS e queima", src: "calculado", status: "PASS", why: "Nenhum evento crítico fica entre dois pontos." });
  const cA = cycle22(b, s, top, 1, { baseDeg: 1 }), cB = cycle22(b, s, top, 1, { baseDeg: 0.5 });
  const conv = (100 * Math.abs(cA.pMaxBar - cB.pMaxBar)) / cB.pMaxBar;
  add({ mod: "Solver", item: "Convergência P_max (1° vs 0,5°)", value: conv, unit: "%", formula: "|P1 − P0,5| / P0,5", params: `${r1(cA.pMaxBar)} vs ${r1(cB.pMaxBar)} bar`, src: "calculado", status: conv < 0.5 ? "PASS" : "WARNING", why: "Erro numérico do passo angular." });
  add({ mod: "Solver", item: "Fechamento da 1ª lei", value: cB.energyErrPct, unit: "%", formula: "Q_comb − Q_parede − W − ΔU", params: `${cB.steps} passos`, src: "calculado", status: cB.energyErrPct < 1 ? "PASS" : "WARNING", why: "Conservação de energia do integrador." });
  // combustão e torque
  for (const rpm of [...new Set([3000, 6000, e.rpmPeak, top])]) {
    const c = cycle22(b, s, rpm, 1, { baseDeg: 0.5 });
    const curveNm = crankW(b, s, rpm) / omegaOf(rpm);
    const d = (100 * (c.meanTorqueNm - curveNm)) / curveNm;
    add({ mod: "Combustão", item: `${rpm} rpm · P_max`, value: c.pMaxBar, unit: "bar", formula: "1ª lei + Wiebe + parede (Woschni simplificado)", params: `ar ${r1(c.airMg)} mg · comb ${r3(c.fuelMg)} mg · λ ${r3(c.lambda)} · residual ${r1(c.residualFrac * 100)}% · pico ${r1(c.thPeakDeg)}° APMS · T_max ${Math.round(c.tMaxK)} K`, src: "calculado", status: "NOT_VALIDATED", why: "Sem curva de pressão medida." });
    add({ mod: "Combustão", item: `${rpm} rpm · torque médio do ciclo vs curva da corrida`, value: d, unit: "%", formula: "T̄ = (1/720)∮F·r·(sinθ + k·sin2θ/2√…)dθ vs P/ω", params: `${r3(c.meanTorqueNm)} vs ${r3(curveNm)} N·m (ciclo sem atrito/bombeamento)`, src: "calculado", status: Math.abs(d) < 10 ? "NOT_VALIDATED" : "WARNING", why: Math.abs(d) < 10 ? "Ordem de grandeza coerente." : "CONTRADICTORY: a potência da corrida ainda vem de hp × forma, não do ciclo." });
  }
  // biela
  for (const rpm of [...new Set([e.rpmPeak, top])]) {
    const r = rod22(b, s, rpm);
    add({ mod: "Biela", item: `${rpm} rpm · tensão máx`, value: r.sMax, unit: "MPa", formula: "σ = F/A, F = (P·A_p − m·a)/cosβ", params: `tração ${Math.round(r.tensN)} N a ${r.tDeg}° · compressão ${Math.round(r.compN)} N a ${r.cDeg}° · A ${EST.rodAreaMm2} mm²`, src: "estimado", limit: r.yieldMPa, marginPct: margin(r.sMax, r.yieldMPa), status: r.mech === "escoamento" ? "FAILURE" : r.sMax > r.allowMPa ? "OVERLOAD" : "PASS", why: `Escoamento ${r.yieldMPa} MPa ESTIMADO; admissível ${r1(r.allowMPa)} MPa (FS ${EST22.rodSafety}).` });
    add({ mod: "Biela", item: `${rpm} rpm · flambagem`, value: r.compN, unit: "N", formula: "P_cr = π²EI/L²", params: `I ${EST.rodI_mm4} mm⁴ · L ${EST.rodMm} mm`, src: "estimado", limit: r.buckN, marginPct: margin(r.compN, r.buckN), status: r.compN > r.buckN ? "FAILURE" : "PASS", why: "Momento de inércia da seção não medido." });
    add({ mod: "Biela", item: `${rpm} rpm · fadiga`, value: r.sAmp, unit: "MPa (amplitude)", formula: "Goodman: σa/Se + σm/Su ≤ 1", params: `σm ${r1(r.sMean)} MPa`, src: "faltante", status: "INSUFFICIENT_DATA", why: "Falta limite de fadiga (Se) e ruptura (Su) da biela: pedir ficha técnica." });
  }
  const leg = buildOf(b, s).rodLimitN;
  add({ mod: "Biela", item: "Limite legado de tração", value: leg, unit: "N", formula: "9500 + reforço", params: "constante antiga", src: "estimado", status: "NOT_VALIDATED", why: `Sem origem física; equivale a ${r1(leg / EST.rodAreaMm2)} MPa na seção estimada. Não decide falha no 2.2.` });
  // alimentação
  for (const rpm of [...new Set([7800, e.rpmPeak, top])]) {
    const f = fuel22(b, s, rpm);
    const contra = Math.abs(f.lambdaReal - f.lambdaMix) / f.lambdaMix;
    add({ mod: "Alimentação", item: `${rpm} rpm · λ real`, value: f.lambdaReal, unit: "λ", formula: "λ = ṁ_ar / (AFR_est · ṁ_entregue)", params: `ar ${r3(f.airGs)} g/s (mapa prevê ${r3(f.mapAirGs)}) · bico ×${f.bicoMul} · comandado ${r3(f.needGs)} · bico ${r3(f.injGs)} · bomba ${r3(f.pumpGs)} · entregue ${r3(f.delivGs)} g/s · linha ${r3(f.railBar)} bar · duty ${r1(f.duty)}% · limita: ${f.limitedBy}`, src: "estimado", status: f.short ? (f.lambdaReal > 1.1 ? "FAILURE" : "OVERLOAD") : f.lambdaReal > 1.0 || f.lambdaReal < 0.8 ? "WARNING" : "PASS", why: f.short ? `Falta combustível pelo ${f.limitedBy}.` : f.lambdaReal > 1.0 ? "Mistura pobre em plena carga: o mapa não acompanha o ar do conjunto." : f.lambdaReal < 0.8 ? "Mistura rica: bico maior que o mapa espera." : "Entrega cobre o pedido." });
    add({ mod: "Alimentação", item: `${rpm} rpm · λ usado na potência`, value: f.lambdaMix, unit: "λ", formula: "mixtureAt() da corrida", params: `cadeia física dá ${r3(f.lambdaReal)}; injectionAt antigo dá ${r3(f.lambdaOld)}`, src: "calculado", status: contra > 0.02 ? "WARNING" : "PASS", why: contra > 0.02 ? `CONTRADICTORY: diferença ${r1(contra * 100)}% entre a mistura da potência e a entrega física.` : "Mistura da potência coincide com a entrega." });
  }
  // embreagem
  const cl = clutch22(b, s);
  add({ mod: "Embreagem", item: "Torque máx vs capacidade", value: cl.maxNm, unit: "N·m", formula: "patina se T_motor > T_cap", params: `cap ${cl.capNm} N·m (ficha do jogo) · pico a ${cl.atRpm} rpm`, src: "ficha", limit: cl.capNm, marginPct: margin(cl.maxNm, cl.capNm), status: cl.excessNm > 0 ? "OVERLOAD" : "PASS", why: cl.excessNm > 0 ? `Patina de ${cl.slipFrom} a ${cl.slipTo} rpm (excesso ${r3(cl.excessNm)} N·m).` : "Capacidade cobre o torque." });
  add({ mod: "Embreagem", item: "Fórmula da corrida", value: null, unit: "", formula: "P > T_cap·ω  ⇔  T > T_cap", params: "physics.step", src: "calculado", status: "PASS", why: "CORRECT: T_cap·ω é potência (W) comparada com potência; dimensionalmente certo, não é o erro relatado." });
  add({ mod: "Embreagem", item: "Posição da embreagem", value: null, unit: "", formula: "T_emb = T_motor × primária", params: `primária ${drivetrain(b, s).primary != null ? r3(drivetrain(b, s).primary!) : "não documentada"} (manual)`, src: drivetrain(b, s).primary != null ? "ficha" : "faltante", status: drivetrain(b, s).primary != null ? "PASS" : "INSUFFICIENT_DATA", why: "Embreagem multidisco na cesta da primária: vê o torque do motor × relação primária." });
  // válvulas
  const fr = floatRpm22(s), leg2 = buildOf(b, s).floatRpm, vt = valve22(s, top);
  add({ mod: "Válvulas", item: "Rotação de perda de contato", value: fr, unit: "rpm", formula: "m·|a(θ)| > F0 + k·x(θ)", params: `m ${EST22.valveMassKg} kg · F0 ${EST22.springPreN} N · k ${EST22.springKNmm} N/mm · ${EST22.camDurDeg}° · ${EST22.valveLiftM * 1000} mm`, src: "estimado", status: fr < top ? "OVERLOAD" : "NOT_VALIDATED", why: `No corte: margem ×${r3(vt.margin)} a ${vt.atDeg}° do came. Legado usa ${leg2} rpm fixo (${r1((100 * (leg2 - fr)) / fr)}%).` });
  // escape
  const ex = exhaust22(b, s);
  add({ mod: "Escape", item: "Ressonância emergente", value: ex.tunedRpm, unit: "rpm", formula: "rpm = θ_retorno / (6 · 2L/a), a = √(γRT)", params: `Ø ${ex.d} mm · L ${ex.L} mm · a ${r1(ex.soundMs)} m/s · retorno ${r3(ex.tRetMs)} ms`, src: "estimado", status: "NOT_VALIDATED", why: `Tabela do jogo diz ${Math.round(ex.tableRpm)} rpm (${r1((100 * (ex.tableRpm - ex.tunedRpm)) / ex.tunedRpm)}%). EGT e fase de válvula ESTIMADAS.` });
  if (ex.bandBonus > 0) add({ mod: "Escape", item: "Modificadores por faixa", value: ex.bandBonus, unit: "fração", formula: "low+mid+high", params: exhaustId(s), src: "estimado", status: "WARNING", why: "Multiplicador artificial ainda presente nesta peça." });
  // térmico
  const t = thermal22(b, s, top);
  add({ mod: "Térmico", item: `Pistão após ${t.seconds} s a ${top} rpm`, value: t.pistonC, unit: "°C", formula: "C·dT/dt = Q_parede·0,35 − G_anel·ΔT − G_óleo·ΔT", params: `parede ${Math.round(t.wallW)} W · cabeçote ${r1(t.headC)} °C · óleo ${r1(t.oilC)} °C · dilatação ${r3(t.crownGrowthMm)} mm`, src: "estimado", limit: t.pistonLimC, marginPct: margin(t.pistonC, t.pistonLimC), status: t.pistonC > t.pistonLimC ? "FAILURE" : "NOT_VALIDATED", why: `Legado (fórmula de equilíbrio) dá ${r1(t.legacyEqC)} °C. Capacidades e condutâncias ESTIMADAS.` });
  // transmissão
  const gs = gearSpeeds(b, s);
  const dt22 = drivetrain(b, s);
  add({ mod: "Transmissão", item: "Fonte da velocidade por marcha", value: gs[0] ?? null, unit: "km/h (1ª)", formula: "v = (rpm·2π/60)·r_din / (primária × marcha × coroa/pinhão)", params: gs.map((v) => r1(v)).join(" / "), src: dt22.origem === "MANUAL" ? "ficha" : "faltante", status: dt22.origem === "MANUAL" ? "PASS" : "INSUFFICIENT_DATA", why: dt22.origem === "MANUAL" ? "Relações internas do manual do fabricante; a corrida usa a mesma cadeia." : "Relações internas não documentadas para esta moto: relação total equivalente da tabela de referência." });
  // veículo
  const vd = vehicle22(b, s, 0);
  add({ mod: "Veículo", item: "Tração máxima com transferência de carga", value: vd.fMaxN, unit: "N", formula: "F = min(μ·m·g·s/(1 − μ·h/L), m·g·(1−s)·L/h)", params: `m ${r1(vd.m)} kg · μ ${EST.mu} · h ${EST.cgHeightM} m · L ${EST.wheelbaseM} m`, src: "estimado", status: Math.abs(vd.diffPct) > 10 ? "WARNING" : "NOT_VALIDATED", why: `A corrida usa 0,62·m·g·1,05 = ${Math.round(vd.raceTractionN)} N (${r1(vd.diffPct)}%).${vd.wheelie ? " Empinaria antes de patinar." : ""}` });
  return out;
}

export function audit22Txt(b: BikeModel, s: Setup, title = "") {
  const rows = audit22(b, s);
  const L = ["================ STREETRACE PHYSICS OVERHAUL 2.2 · AUDITORIA ================", title, `Moto: ${b.name} · ${r1(ccOf(b, s))} cc · combustível ${s.fuel} · taxa ${s.compression}`, "Status: PASS · WARNING · OVERLOAD · FAILURE · INSUFFICIENT_DATA · NOT_VALIDATED. Nada aqui foi validado com medição.", ""];
  for (const r of rows) L.push(`[${r.status}] ${r.mod} · ${r.item}: ${r.value === null ? "—" : r3(r.value)} ${r.unit} | ${r.formula} | ${r.params} | origem ${r.src}${r.limit != null ? ` | limite ${r3(r.limit)}` : ""}${r.marginPct != null ? ` | margem ${r1(r.marginPct)}%` : ""} | ${r.why}`);
  const n = (k: Status) => rows.filter((r) => r.status === k).length;
  L.push("", `Resumo: PASS ${n("PASS")} · WARNING ${n("WARNING")} · OVERLOAD ${n("OVERLOAD")} · FAILURE ${n("FAILURE")} · INSUFFICIENT_DATA ${n("INSUFFICIENT_DATA")} · NOT_VALIDATED ${n("NOT_VALIDATED")}`);
  L.push("Simulação NÃO declarada fisicamente validada: faltam dados experimentais (pressão de cilindro, dinamômetro, fichas de biela/bico/bomba/molas/relações).");
  return L.join("\n");
}
