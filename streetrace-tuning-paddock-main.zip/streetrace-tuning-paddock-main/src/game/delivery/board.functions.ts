// Mural de entregas no servidor: um chamado por lugar a cada BOARD_SLOT_S; o primeiro jogador a aceitar leva.
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { BOARD_SLOT_S, BOARD_WORKPLACES } from "./board-core";

const Shifts = z.object({ shifts: z.array(z.enum(BOARD_WORKPLACES)).max(4) });

export const deliveryBoard = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Shifts.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    const { rollJob } = await import("../trampo");
    const { workplace } = await import("../jobrun");
    const now = Date.now();
    const slot = Math.floor(now / 1000 / BOARD_SLOT_S);
    if (data.shifts.length) {
      const rows = data.shifts.map((id) => {
        const w = workplace(id);
        const j = rollJob(w.kind, 1, Math.random, id, 1);
        return { workplace: id, slot, job: { ...j, place: w.place || j.place }, expires_at: new Date((slot + 1) * BOARD_SLOT_S * 1000).toISOString() };
      });
      // ON CONFLICT: o primeiro pedido do intervalo cria o chamado, todos os outros veem o mesmo
      await db.from("delivery_board").upsert(rows as never, { onConflict: "workplace,slot", ignoreDuplicates: true });
    }
    const { data: open } = data.shifts.length
      ? await db.from("delivery_board").select("id,workplace,job,expires_at").in("workplace", data.shifts).is("claimed_by", null).gt("expires_at", new Date(now).toISOString())
      : { data: [] };
    return { serverNow: now, offers: (open ?? []).map((r) => ({ boardId: r.id, from: r.workplace, job: JSON.stringify(r.job), expires: Date.parse(r.expires_at) })) };
  });

export const claimDelivery = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ boardId: z.string().uuid(), playerId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: pl } = await context.supabase.from("players").select("id,name").eq("id", data.playerId).eq("user_id", context.userId).maybeSingle();
    if (!pl) throw new Error("jogador não pertence a esta conta");
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    // atômico: só atualiza se ainda ninguém pegou
    const { data: won } = await db.from("delivery_board").update({ claimed_by: pl.id, claimed_name: pl.name, claimed_at: new Date().toISOString() })
      .eq("id", data.boardId).is("claimed_by", null).gt("expires_at", new Date().toISOString()).select("job").maybeSingle();
    if (won) return { ok: true as const };
    const { data: row } = await db.from("delivery_board").select("claimed_name").eq("id", data.boardId).maybeSingle();
    return { ok: false as const, by: row?.claimed_name ?? null };
  });
