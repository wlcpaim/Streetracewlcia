/** Um novo chamado por lugar aberto a cada 15 s, igual para todos os jogadores. */
export const BOARD_SLOT_S = 30;
export const BOARD_WORKPLACES = ["pizzaria", "lanchonete", "acai", "taxi"] as const;
/** Mensagem quando outro jogador aceitou antes. */
export const takenMsg = (by: string | null) => (by ? `Jogador ${by} aceitou essa corrida` : "Outro jogador já aceitou essa corrida");
