// Sistema Físico dos Três Eixos 1.0 (AES 3.2) — A dianteiro, B traseiro, C motor/transmissão. Só leitura.
// Reaproveita kinematics.ts (cadeia C) e funnel.FICHA (geometria); não altera physics.ts nem a corrida.
// Tudo que não tem fonte fica PENDENTE; nenhum estado aqui chega a HOMOLOGADO (exige testes integrados + autorização humana).
import { TITAN_160, FACTOR_150, RIDER_KG, type BikeModel } from "../physics";
import { tireRadius } from "../intel/powertrain";
import { FICHA } from "./funnel";
import { chain, wikiRecalc, factorySpec, rpmToRad, type Dado, type KinSpec, type KOrigem } from "./kinematics";

export const AXLES_VERSION = "realgear.axles/1.0.0";
export const G0 = 9.80665; // m/s² (gravidade padrão, CGPM 1901)

export type Geometria = "ANEL_FINO" | "ANEL_ESPESSO" | "DISCO_SOLIDO" | "CILINDRO_MACICO" | "NAO_ROTATIVO";
export type Validacao = "VALIDADO" | "NAO_VALIDADO" | "PENDENTE";
export type Componente = {
  id: string; tipo: string; eixo: "A" | "B" | "C"; posicao: string;
  massa: Dado; material: { valor: string | null; origem: KOrigem; fonte: string };
  geometria: Geometria; dims: { r?: Dado; rInt?: Dado; rExt?: Dado }; // raios em m
  propriedades?: Record<string, Dado>; validacao: Validacao;
};
export type EstadoEixo = "NÃO IMPLEMENTADO" | "DADOS PENDENTES" | "IMPLEMENTADO" | "TESTADO" | "APROVADO" | "REPROVADO" | "HOMOLOGADO";

export type Veiculo = {
  massaMoto: Dado; massaPiloto: Dado; entreEixos: Dado; alturaCG: Dado; cgAteEixoTraseiro: Dado;
  cdA: Dado; rhoAr: Dado; crr: Dado; mu: Dado;
};
export type Manivela = { diametro: Dado; curso: Dado; biela: Dado; massaAlternativa: Dado; inerciaGirante: Dado };
export type MotoSpec = {
  bikeId: string; nome: string; versaoIdentificada: boolean; fonteVersao: string; referencia: boolean;
  veiculo: Veiculo; manivela: Manivela; kin: KinSpec;
  rodaA: { raioGeometrico: Dado; raioDinamico: Dado; raioEfetivoFreio: Dado; componentes: Componente[] };
  rodaB: { raioGeometrico: Dado; raioDinamico: Dado; raioEfetivoFreio: Dado; componentes: Componente[] };
  corrente: { passo: Dado; elos: Dado; massaPorMetro: Dado; cargaRupturaN: Dado; alongamento: Dado };
};

const P = (unidade: string, fonte = "sem fonte documental cadastrada"): Dado => ({ valor: null, unidade, origem: "PENDENTE", fonte });
const D = (valor: number, unidade: string, origem: KOrigem, fonte: string): Dado => ({ valor, unidade, origem, fonte });
const ok = (d: Dado | undefined) => !!d && d.valor !== null && Number.isFinite(d.valor);
const v = (d: Dado) => d.valor as number;
const MAT_P = { valor: null, origem: "PENDENTE" as KOrigem, fonte: "material não documentado" };

const comp = (eixo: "A" | "B" | "C", id: string, tipo: string, geometria: Geometria, raios: string[] = []): Componente => ({
  id: `${eixo}-${id}`, tipo, eixo, posicao: eixo === "A" ? "eixo dianteiro" : eixo === "B" ? "eixo traseiro" : "conjunto motor/transmissão",
  massa: P("kg"), material: MAT_P, geometria, dims: Object.fromEntries(raios.map((r) => [r, P("m")])), validacao: "PENDENTE",
});

function rodaA(): Componente[] {
  return [comp("A", "eixo", "Eixo físico da roda", "CILINDRO_MACICO", ["r"]), comp("A", "cubo", "Cubo", "ANEL_ESPESSO", ["rInt", "rExt"]),
    comp("A", "rolamentos", "Rolamentos", "NAO_ROTATIVO"), comp("A", "espacadores", "Espaçadores", "NAO_ROTATIVO"),
    comp("A", "raios", "Raios", "NAO_ROTATIVO"), comp("A", "aro", "Aro", "ANEL_FINO", ["r"]), comp("A", "pneu", "Pneu", "ANEL_ESPESSO", ["rInt", "rExt"]),
    comp("A", "disco", "Disco de freio", "ANEL_ESPESSO", ["rInt", "rExt"]), comp("A", "pinca", "Pinça de freio", "NAO_ROTATIVO"),
    comp("A", "pastilhas", "Pastilhas", "NAO_ROTATIVO"), comp("A", "fixacoes", "Elementos de fixação", "NAO_ROTATIVO"), comp("A", "garfo", "Garfo/suspensão", "NAO_ROTATIVO")];
}
function rodaB(): Componente[] {
  return [comp("B", "eixo", "Eixo traseiro", "CILINDRO_MACICO", ["r"]), comp("B", "cubo", "Cubo", "ANEL_ESPESSO", ["rInt", "rExt"]),
    comp("B", "rolamentos", "Rolamentos", "NAO_ROTATIVO"), comp("B", "espacadores", "Espaçadores", "NAO_ROTATIVO"),
    comp("B", "portacoroa", "Porta-coroa", "ANEL_ESPESSO", ["rInt", "rExt"]), comp("B", "coxins", "Coxins de transmissão", "NAO_ROTATIVO"),
    comp("B", "coroa", "Coroa", "ANEL_ESPESSO", ["rInt", "rExt"]), comp("B", "parafusos", "Parafusos e fixações", "NAO_ROTATIVO"),
    comp("B", "aro", "Aro", "ANEL_FINO", ["r"]), comp("B", "pneu", "Pneu", "ANEL_ESPESSO", ["rInt", "rExt"]), comp("B", "valvula", "Válvula", "NAO_ROTATIVO"),
    comp("B", "disco", "Disco de freio", "ANEL_ESPESSO", ["rInt", "rExt"]), comp("B", "pinca", "Pinça", "NAO_ROTATIVO"),
    comp("B", "pastilhas", "Pastilhas", "NAO_ROTATIVO"), comp("B", "balanca", "Interface com a balança", "NAO_ROTATIVO")];
}

/** Ficha de cada moto original. Versão/ano exato não identificado → a ficha não pode ser aprovada, só testada. */
export function motoSpec(b: BikeModel): MotoSpec {
  const fic = FICHA[b.id];
  const [fr, rr] = b.tires.split("·").map((t) => t.trim());
  const rA = fr ? tireRadius(fr) : null, rB = rr ? tireRadius(rr) : null;
  return {
    bikeId: b.id, nome: b.name, versaoIdentificada: false, referencia: false,
    fonteVersao: `ano/versão exatos não identificados (o jogo declara ${b.year}); dados de manual de oficina não anexados`,
    veiculo: {
      massaMoto: D(b.dryWeight, "kg", "JOGO", "BikeModel.dryWeight (peso seco declarado no jogo)"),
      massaPiloto: D(RIDER_KG, "kg", "JOGO", "physics.RIDER_KG"),
      entreEixos: P("m"), alturaCG: P("m"), cgAteEixoTraseiro: P("m"),
      cdA: P("m²", "physics.CDA = 0,27 é calibrado para velocidade final, não medido em túnel — não aceito como dado"),
      rhoAr: D(1.225, "kg/m³", "FICHA", "ISA ao nível do mar, 15 °C"), crr: P("1"), mu: P("1"),
    },
    manivela: {
      diametro: fic ? D(fic.boreMm / 1000, "m", "FICHA", "funnel.FICHA") : P("m"),
      curso: fic ? D(fic.strokeMm / 1000, "m", "FICHA", "funnel.FICHA") : P("m"),
      biela: P("m"), massaAlternativa: P("kg"), inerciaGirante: P("kg·m²"),
    },
    kin: factorySpec(b),
    rodaA: { raioGeometrico: rA ? D(rA, "m", "CALCULADO", `medida ${fr}`) : P("m"), raioDinamico: P("m", "raio sob carga não medido"), raioEfetivoFreio: P("m"), componentes: rodaA() },
    rodaB: { raioGeometrico: rB ? D(rB, "m", "CALCULADO", `medida ${rr}`) : P("m"), raioDinamico: P("m", "raio sob carga não medido"), raioEfetivoFreio: P("m"), componentes: rodaB() },
    corrente: { passo: D(0.0127, "m", "JOGO", "corrente 428 (1/2\")"), elos: P("elos"), massaPorMetro: P("kg/m"), cargaRupturaN: P("N", "catálogo do fabricante da corrente não anexado"), alongamento: P("1") },
  };
}
export const MOTO_SPECS = [motoSpec(TITAN_160), motoSpec(FACTOR_150)];

// ---------- Equações (SI) ----------
export const omega = rpmToRad;
/** Diâmetro primitivo de roda dentada: d = p / sin(π/Z). */
export const pitchDiameter = (p: number, Z: number) => p / Math.sin(Math.PI / Z);
/** Inércia polar pela geometria correta (não massa pontual). */
export function inertia(c: Componente): number | null {
  if (!ok(c.massa) || c.geometria === "NAO_ROTATIVO") return c.geometria === "NAO_ROTATIVO" ? 0 : null;
  const m = v(c.massa), d = c.dims;
  if (c.geometria === "ANEL_FINO") return ok(d["r"]) ? m * v(d["r"]!) ** 2 : null; // I = m r²
  if (c.geometria === "DISCO_SOLIDO" || c.geometria === "CILINDRO_MACICO") return ok(d["r"]) ? 0.5 * m * v(d["r"]!) ** 2 : null; // I = ½ m r²
  return ok(d["rInt"]) && ok(d["rExt"]) ? 0.5 * m * (v(d["rInt"]!) ** 2 + v(d["rExt"]!) ** 2) : null; // I = ½ m (r1² + r2²)
}
/** Rota independente (Wikipedia): ∫ r² dm por integração numérica de cascas finas, de densidade uniforme. */
export function inertiaNumeric(c: Componente, n = 4000): number | null {
  if (!ok(c.massa)) return null;
  const m = v(c.massa), d = c.dims;
  if (c.geometria === "ANEL_FINO") return ok(d["r"]) ? m * v(d["r"]!) ** 2 : null;
  const [r1, r2] = c.geometria === "ANEL_ESPESSO" ? [d["rInt"], d["rExt"]] : [{ valor: 0 } as Dado, d["r"]];
  if (!ok(r1) || !ok(r2)) return null;
  const a = v(r1!), b = v(r2!), h = (b - a) / n, area = Math.PI * (b * b - a * a);
  let I = 0; for (let i = 0; i < n; i++) { const r = a + (i + 0.5) * h; I += r * r * (m * 2 * Math.PI * r * h / area); }
  return I;
}
export const sumInertia = (cs: Componente[]) => { const xs = cs.map(inertia); return xs.some((x) => x === null) ? null : (xs as number[]).reduce((s, x) => s + x, 0); };

/** Biela-manivela exata: x(θ) do PMS; v e a por derivação analítica com ω constante. */
export function crankSlider(r: number, L: number, theta: number, w: number) {
  const s = Math.sin(theta), c = Math.cos(theta), q = Math.sqrt(L * L - r * r * s * s);
  const x = r + L - (r * c + q);
  const vel = r * w * (s + (r * s * c) / q);
  const acc = r * w * w * (c + (r * (c * c - s * s)) / q + (r ** 3 * s * s * c * c) / q ** 3);
  return { x, v: vel, a: acc };
}
export const dragForce = (rho: number, cdA: number, vRel: number) => 0.5 * rho * cdA * vRel * Math.abs(vRel);
export const rollingForce = (crr: number, Fz: number) => crr * Fz;
/** Escorregamento longitudinal: κ = (ω r − v)/max(|ω r|, |v|). Positivo em tração, negativo em frenagem. */
export const slipRatio = (w: number, r: number, vx: number) => { const den = Math.max(Math.abs(w * r), Math.abs(vx)); return den < 1e-9 ? 0 : (w * r - vx) / den; };
/** Cargas verticais com transferência longitudinal: ΔFz = m·a·h/L. */
export function axleLoads(m: number, a: number, h: number, L: number, bRear: number) {
  const aFront = L - bRear; // distância CG → eixo dianteiro
  const FzA = (m * G0 * bRear - m * a * h) / L, FzB = (m * G0 * aFront + m * a * h) / L;
  return { FzA, FzB };
}
export const brakeTorque = (Ft: number, rEff: number) => Ft * rEff;

// ---------- Baterias ----------
export type TStatus = "APROVADO" | "REPROVADO" | "INDETERMINADO";
export type AxTest = { n: number; bateria: "C" | "A" | "B"; nome: string; equacao: string; esperado: string; observado: string; unidade: string; estado: TStatus; pendentes: string[] };
export type AxReport = { versao: string; bikeId: string; nome: string; referencia: boolean; testes: AxTest[]; eixos: Record<"A" | "B" | "C", EstadoEixo>; homologacao: EstadoEixo; pendentes: string[] };
export type Cond = { marcha: number; rpm: number; torque: number; slipEmbreagem?: number; vVeiculo?: number; acel?: number; FtFreioA?: number; FtFreioB?: number };

const rel = (a: number, b: number) => Math.abs(a - b) / Math.max(Math.abs(b), 1e-12);
export const TOL_AX = 1e-9;

export function runBatteries(s: MotoSpec, c: Cond = { marcha: 2, rpm: 6000, torque: 12 }): AxReport {
  const T: AxTest[] = [];
  const add = (n: number, bateria: AxTest["bateria"], nome: string, equacao: string, unidade: string, deps: [string, Dado | undefined][], f: () => [number | string, number | string, boolean]) => {
    const pend = deps.filter(([, d]) => !ok(d)).map(([k]) => k);
    if (pend.length) { T.push({ n, bateria, nome, equacao, esperado: "—", observado: "—", unidade, estado: "INDETERMINADO", pendentes: pend }); return; }
    const [e, o, pass] = f();
    const fmt = (x: number | string) => (typeof x === "number" ? (Math.abs(x) > 1e-3 || x === 0 ? x.toFixed(6) : x.toExponential(6)) : x);
    T.push({ n, bateria, nome, equacao, esperado: fmt(e), observado: fmt(o), unidade, estado: pass ? "APROVADO" : "REPROVADO", pendentes: [] });
  };
  const k = s.kin, g = k.marchas[c.marcha - 1]!;
  const prim: [string, Dado][] = [["primária motora", k.primaria.motora], ["primária conduzida", k.primaria.conduzida]];
  const marchaD: [string, Dado][] = [[`${c.marcha}ª motora`, g.motora], [`${c.marcha}ª conduzida`, g.conduzida]];
  const todas: [string, Dado][] = k.marchas.flatMap((x, i): [string, Dado][] => [[`${i + 1}ª motora`, x.motora], [`${i + 1}ª conduzida`, x.conduzida]]);
  const etas: [string, Dado][] = [["η primária", k.eta.primaria], ["η câmbio", k.eta.cambio], ["η corrente", k.eta.corrente]];
  const fd: [string, Dado][] = [["pinhão", k.pinhao], ["coroa", k.coroa]];
  const rB = s.rodaB.raioDinamico, rA = s.rodaA.raioDinamico;
  const all = [...prim, ...marchaD, ...fd, ...etas, ["raio dinâmico B", rB] as [string, Dado]];
  const ch = () => chain({ ...k, raioPneu: rB }, c.marcha, c.rpm, c.torque, c.slipEmbreagem ?? 0);
  const st = (o: ReturnType<typeof chain>, el: string) => o.estagios.find((e) => e.elemento.startsWith(el))!;
  const iP = () => v(k.primaria.conduzida) / v(k.primaria.motora);
  const iG = () => v(g.conduzida) / v(g.motora);
  const iF = () => v(k.coroa) / v(k.pinhao);
  const veh = s.veiculo, m = () => v(veh.massaMoto) + v(veh.massaPiloto);

  // Bateria 1 — Eixo C
  add(1, "C", "Rotação do virabrequim", "ω = 2π·n/60", "rad/s", [], () => [(c.rpm * 2 * Math.PI) / 60, omega(c.rpm), rel(omega(c.rpm), (c.rpm * Math.PI) / 30) < TOL_AX]);
  add(2, "C", "Relação primária", "i_p = Z_conduzida/Z_motora (> 1)", "1", prim, () => [`> 1`, iP(), iP() > 1]);
  add(3, "C", "RPM do eixo primário", "n_1 = n_motor/i_p·(1−s_emb)", "rpm", [...prim, ...etas], () => { const o = ch(); const e = (c.rpm / iP()) * (1 - (c.slipEmbreagem ?? 0)); return [e, st(o, "Eixo primário").rpm, rel(st(o, "Eixo primário").rpm, e) < TOL_AX]; });
  add(4, "C", "RPM do eixo secundário", "n_2 = n_1/i_g", "rpm", [...prim, ...marchaD, ...etas], () => { const o = ch(); const e = (c.rpm * (1 - (c.slipEmbreagem ?? 0))) / (iP() * iG()); return [e, st(o, "Eixo secundário").rpm, rel(st(o, "Eixo secundário").rpm, e) < TOL_AX]; });
  add(5, "C", "Relação da 1ª marcha", "i_1 = Z_cond/Z_mot (> 1)", "1", [["1ª motora", k.marchas[0]!.motora], ["1ª conduzida", k.marchas[0]!.conduzida]], () => { const r = v(k.marchas[0]!.conduzida) / v(k.marchas[0]!.motora); return ["> 1", r, r > 1]; });
  add(6, "C", "Relações das marchas seguintes", "i_1 > i_2 > … > i_n", "1", todas, () => { const r = k.marchas.map((x) => v(x.conduzida) / v(x.motora)); return ["estritamente decrescente", r.map((x) => x.toFixed(3)).join(" > "), r.every((x, i) => i === 0 || x < r[i - 1]!)]; });
  add(7, "C", "RPM do pinhão", "n_pinhão = n_2", "rpm", [...prim, ...marchaD, ...etas], () => { const o = ch(); return [st(o, "Eixo secundário").rpm, st(o, "Pinhão").rpm, st(o, "Pinhão").rpm === st(o, "Eixo secundário").rpm]; });
  add(8, "C", "Velocidade linear da corrente", "v̄ = Z·p·n/60; v_max = ω·d_p/2 = v̄·(π/Z)/sin(π/Z)", "m/s", [...prim, ...marchaD, ...fd, ...etas, ["passo", s.corrente.passo]], () => {
    const o = ch(), n2 = st(o, "Pinhão").rpm, Z = v(k.pinhao), p = v(s.corrente.passo);
    const vMed = (Z * p * n2) / 60, vMax = omega(n2) * pitchDiameter(p, Z) / 2;
    return [`v_max/v̄ = ${((Math.PI / Z) / Math.sin(Math.PI / Z)).toFixed(6)} (efeito poligonal)`, `${vMed.toFixed(4)} / ${vMax.toFixed(4)}`, rel(vMax / vMed, (Math.PI / Z) / Math.sin(Math.PI / Z)) < 1e-9 && rel(o.vCorrente, vMed) < TOL_AX];
  });
  add(9, "C", "RPM da coroa", "Z_p·n_p = Z_c·n_c (mesma corrente)", "rpm", [...prim, ...marchaD, ...fd, ...etas], () => { const o = ch(); const nc = st(o, "Coroa").rpm, np = st(o, "Pinhão").rpm; return [v(k.pinhao) * np, v(k.coroa) * nc, rel(v(k.coroa) * nc, v(k.pinhao) * np) < TOL_AX]; });
  add(10, "C", "RPM da roda traseira", "n_roda = n_motor/(i_p·i_g·i_f)", "rpm", all, () => { const o = ch(), w = wikiRecalc({ ...k, raioPneu: rB }, c.marcha, c.rpm, c.torque, c.slipEmbreagem ?? 0); return [w.nRoda, st(o, "Pneu").rpm, rel(st(o, "Pneu").rpm, w.nRoda) < TOL_AX]; });
  add(11, "C", "Torque transmitido", "T_roda = T·i_total·η_total", "N·m", all, () => { const o = ch(), e = c.torque * iP() * iG() * iF() * v(k.eta.primaria) * v(k.eta.cambio) * v(k.eta.corrente); return [e, st(o, "Pneu").torque, rel(st(o, "Pneu").torque, e) < TOL_AX]; });
  add(12, "C", "Potência de entrada e saída", "P_ent = P_saída + P_perdas; P_saída ≤ P_ent", "W", all, () => { const o = ch(), pin = c.torque * omega(c.rpm), pout = st(o, "Pneu").potencia; return [pin, pout + o.perdas, rel(pout + o.perdas, pin) < TOL_AX && pout <= pin + 1e-9]; });
  add(13, "C", "Velocidade periférica da roda", "v = ω_roda·r_din", "m/s", all, () => { const o = ch(); const e = omega(st(o, "Pneu").rpm) * v(rB); return [e, o.vPeriferica, rel(o.vPeriferica, e) < TOL_AX]; });
  add(14, "C", "Comparação com a velocidade do veículo", "κ = (ω r − v)/max; v_veículo medido, não imposto", "1", [...all, ["velocidade do veículo (medida)", c.vVeiculo !== undefined ? D(c.vVeiculo, "m/s", "MEDIDO", "condição de teste") : undefined]], () => { const o = ch(), kap = slipRatio(omega(st(o, "Pneu").rpm), v(rB), c.vVeiculo!); return ["|κ| ≤ 1", kap, Math.abs(kap) <= 1]; });
  add(15, "C", "Verificação de perdas mecânicas", "P_perdas = P_ent·(1 − Πη) — uma vez por estágio", "W", all, () => { const o = ch(), pin = c.torque * omega(c.rpm) * (1 - (c.slipEmbreagem ?? 0)), e = pin * (1 - v(k.eta.primaria) * v(k.eta.cambio) * v(k.eta.corrente)) + c.torque * omega(c.rpm) * (c.slipEmbreagem ?? 0); return [e, o.perdas, rel(o.perdas, e) < 1e-9 && o.perdas >= 0]; });
  add(16, "C", "Verificação de escorregamento da embreagem", "T_emb = T·i_p·η_p ≤ T_capacidade", "N·m", [...prim, ["η primária", k.eta.primaria], ["capacidade da embreagem", k.embreagemNm]], () => { const Tc = c.torque * iP() * v(k.eta.primaria); return [`≤ ${v(k.embreagemNm)}`, Tc, Tc <= v(k.embreagemNm)]; });
  add(17, "C", "Comparação independente Wikipedia × RealGear", "i_total = ΠZ_cond/ΠZ_mot (rota Wikipedia)", "1", all, () => { const o = ch(), w = wikiRecalc({ ...k, raioPneu: rB }, c.marcha, c.rpm, c.torque); return [w.iTotal, o.iTotal, rel(o.iTotal, w.iTotal) < TOL_AX]; });
  add(18, "C", "Regressão: cinemática 1.0 inalterada", "chain(raio do jogo) = chain(raio dinâmico) quando raios iguais", "rpm", all, () => { const a = chain({ ...k, raioPneu: rB }, c.marcha, c.rpm, c.torque), b = chain({ ...k, raioPneu: { ...rB } }, c.marcha, c.rpm, c.torque); return [a.estagios.at(-1)!.rpm, b.estagios.at(-1)!.rpm, a.estagios.at(-1)!.rpm === b.estagios.at(-1)!.rpm]; });

  // Bateria 2 — Eixo A
  const vx = c.vVeiculo !== undefined ? D(c.vVeiculo, "m/s", "MEDIDO", "condição de teste") : undefined;
  const IA = sumInertia(s.rodaA.componentes), IB = sumInertia(s.rodaB.componentes);
  const IAd = IA === null ? undefined : D(IA, "kg·m²", "CALCULADO", "Σ I por geometria"), IBd = IB === null ? undefined : D(IB, "kg·m²", "CALCULADO", "Σ I por geometria");
  const cg: [string, Dado][] = [["massa moto", veh.massaMoto], ["massa piloto", veh.massaPiloto], ["altura CG", veh.alturaCG], ["entre-eixos", veh.entreEixos], ["CG→eixo traseiro", veh.cgAteEixoTraseiro]];
  const loads = (a: number) => axleLoads(m(), a, v(veh.alturaCG), v(veh.entreEixos), v(veh.cgAteEixoTraseiro));
  add(19, "A", "RPM da roda dianteira (rolando livre)", "n_A = 60·v/(2π·r_din,A)", "rpm", [["v veículo", vx], ["raio dinâmico A", rA]], () => { const n = (60 * c.vVeiculo!) / (2 * Math.PI * v(rA)); return [c.vVeiculo!, omega(n) * v(rA), rel(omega(n) * v(rA), c.vVeiculo!) < TOL_AX]; });
  add(20, "A", "Momento de inércia do conjunto A", "I = Σ I_geom; confere com ∫r²dm", "kg·m²", [["massas/raios dos componentes A", IAd]], () => { const num = s.rodaA.componentes.map((x) => inertiaNumeric(x) ?? 0).reduce((a, b) => a + b, 0); return [num, IA!, rel(IA!, num) < 1e-6]; });
  add(21, "A", "Velocidade periférica dianteira", "v = ω·r_din (não r geométrico)", "m/s", [["v veículo", vx], ["raio dinâmico A", rA], ["raio geométrico A", s.rodaA.raioGeometrico]], () => ["r_din ≤ r_geom", `${v(rA)} ≤ ${v(s.rodaA.raioGeometrico)}`, v(rA) <= v(s.rodaA.raioGeometrico)]);
  add(22, "A", "Torque de frenagem dianteiro", "T_brake = F_t·r_efetivo", "N·m", [["força tangencial na pastilha", c.FtFreioA !== undefined ? D(c.FtFreioA, "N", "MEDIDO", "condição") : undefined], ["raio efetivo do freio A", s.rodaA.raioEfetivoFreio]], () => { const Tb = brakeTorque(c.FtFreioA!, v(s.rodaA.raioEfetivoFreio)); return [c.FtFreioA! * v(s.rodaA.raioEfetivoFreio), Tb, Tb >= 0]; });
  add(23, "A", "Força longitudinal dianteira", "F_x,A = −T_brake/r_din − F_rr,A", "N", [["força tangencial", c.FtFreioA !== undefined ? D(c.FtFreioA, "N", "MEDIDO", "condição") : undefined], ["raio efetivo freio A", s.rodaA.raioEfetivoFreio], ["raio dinâmico A", rA], ["Crr", veh.crr], ...cg], () => { const { FzA } = loads(c.acel ?? 0), Fx = -brakeTorque(c.FtFreioA!, v(s.rodaA.raioEfetivoFreio)) / v(rA) - rollingForce(v(veh.crr), FzA); return ["≤ 0 (A não recebe tração da corrente)", Fx, Fx <= 0]; });
  add(24, "A", "Aderência dianteira", "|F_x,A| ≤ μ·F_z,A", "N", [["μ", veh.mu], ["força tangencial", c.FtFreioA !== undefined ? D(c.FtFreioA, "N", "MEDIDO", "condição") : undefined], ["raio efetivo freio A", s.rodaA.raioEfetivoFreio], ["raio dinâmico A", rA], ...cg], () => { const { FzA } = loads(c.acel ?? 0), Fx = brakeTorque(c.FtFreioA!, v(s.rodaA.raioEfetivoFreio)) / v(rA); return [`≤ ${(v(veh.mu) * FzA).toFixed(2)}`, Fx, Fx <= v(veh.mu) * FzA]; });
  add(25, "A", "Resistência ao rolamento dianteira", "F_rr = Crr·F_z,A", "N", [["Crr", veh.crr], ...cg], () => { const { FzA, FzB } = loads(0); return [m() * G0, FzA + FzB, rel(FzA + FzB, m() * G0) < TOL_AX && FzA > 0]; });
  add(26, "A", "Roda dianteira vs veículo", "κ_A = (ω_A r − v)/max ≈ 0 rolando livre", "1", [["v veículo", vx], ["raio dinâmico A", rA]], () => { const w = c.vVeiculo! / v(rA); return [0, slipRatio(w, v(rA), c.vVeiculo!), Math.abs(slipRatio(w, v(rA), c.vVeiculo!)) < 1e-12]; });

  // Bateria 3 — Eixo B
  add(27, "B", "RPM do eixo traseiro", "n_B = n_coroa", "rpm", all, () => { const o = ch(); return [st(o, "Coroa").rpm, st(o, "Cubo").rpm, st(o, "Coroa").rpm === st(o, "Cubo").rpm]; });
  // Torque médio por raio efetivo r̄ = Z·p/(2π) (média por volta). O raio primitivo p/(2·sin(π/Z)) dá só o valor instantâneo máximo: a razão d_c/d_p ≠ Z_c/Z_p (efeito poligonal).
  add(28, "B", "Torque no cubo", "T̄_cubo = (T_p/r̄_p)·r̄_c·η, r̄ = Z·p/(2π)", "N·m", [...all, ["passo", s.corrente.passo]], () => { const o = ch(), T2 = st(o, "Pinhão").torque, p = v(s.corrente.passo); const rm = (Z: number) => (Z * p) / (2 * Math.PI); const Tc = (T2 / rm(v(k.pinhao))) * rm(v(k.coroa)) * v(k.eta.corrente); return [st(o, "Cubo").torque, Tc, rel(Tc, st(o, "Cubo").torque) < 1e-9]; });
  add(29, "B", "Força de contato traseira", "F_x,B = T_roda/r_din,B ≤ μ·F_z,B", "N", [...all, ["μ", veh.mu], ...cg], () => { const o = ch(), Fx = st(o, "Pneu").torque / v(rB), { FzB } = loads(c.acel ?? 0); return [`≤ ${(v(veh.mu) * FzB).toFixed(2)}`, Fx, Fx <= v(veh.mu) * FzB]; });
  add(30, "B", "Momento de inércia do conjunto B", "I = Σ I_geom; confere com ∫r²dm", "kg·m²", [["massas/raios dos componentes B", IBd]], () => { const num = s.rodaB.componentes.map((x) => inertiaNumeric(x) ?? 0).reduce((a, b) => a + b, 0); return [num, IB!, rel(IB!, num) < 1e-6]; });
  add(31, "B", "Frenagem traseira", "T_brake,B = F_t·r_ef ≤ μ·F_z,B·r_din", "N·m", [["força tangencial B", c.FtFreioB !== undefined ? D(c.FtFreioB, "N", "MEDIDO", "condição") : undefined], ["raio efetivo freio B", s.rodaB.raioEfetivoFreio], ["raio dinâmico B", rB], ["μ", veh.mu], ...cg], () => { const Tb = brakeTorque(c.FtFreioB!, v(s.rodaB.raioEfetivoFreio)), { FzB } = loads(c.acel ?? 0); return [`≤ ${(v(veh.mu) * FzB * v(rB)).toFixed(2)}`, Tb, Tb <= v(veh.mu) * FzB * v(rB)]; });
  add(32, "B", "Escorregamento do pneu traseiro", "κ_B = (ω_B r − v)/max", "1", [...all, ["v veículo", vx]], () => { const o = ch(), kap = slipRatio(omega(st(o, "Pneu").rpm), v(rB), c.vVeiculo!); return ["−1 ≤ κ ≤ 1", kap, Math.abs(kap) <= 1]; });
  add(33, "B", "Transferência de carga", "ΔF_z = m·a·h/L; F_zA + F_zB = m·g", "N", [...cg, ["aceleração", c.acel !== undefined ? D(c.acel, "m/s²", "MEDIDO", "condição") : undefined]], () => { const a = loads(c.acel!), z = loads(0); const d = a.FzB - z.FzB, e = (m() * c.acel! * v(veh.alturaCG)) / v(veh.entreEixos); return [e, d, rel(d, e) < 1e-9 && rel(a.FzA + a.FzB, m() * G0) < 1e-12]; });
  add(34, "B", "Compatibilidade corrente × coroa × pinhão", "mesmo passo; carga no ramo tenso ≤ ruptura", "N", [...fd, ...prim, ...marchaD, ...etas, ["passo", s.corrente.passo], ["carga de ruptura", s.corrente.cargaRupturaN]], () => { const o = ch(), F = st(o, "Pinhão").torque / (pitchDiameter(v(s.corrente.passo), v(k.pinhao)) / 2); return [`≤ ${v(s.corrente.cargaRupturaN)}`, F, F <= v(s.corrente.cargaRupturaN) && v(s.corrente.passo) > 0.005 && v(s.corrente.passo) < 0.03]; });

  const estadoDe = (b: AxTest["bateria"]): EstadoEixo => {
    const ts = T.filter((t) => t.bateria === b);
    if (ts.some((t) => t.estado === "REPROVADO")) return "REPROVADO";
    if (ts.some((t) => t.estado === "INDETERMINADO")) return "DADOS PENDENTES";
    // Aprovação exige dados de fonte real (não referência sintética) e versão identificada.
    return s.referencia || !s.versaoIdentificada ? "TESTADO" : "APROVADO";
  };
  const eixos = { A: estadoDe("A"), B: estadoDe("B"), C: estadoDe("C") };
  const vals = Object.values(eixos);
  const homologacao: EstadoEixo = vals.includes("REPROVADO") ? "REPROVADO" : vals.includes("DADOS PENDENTES") ? "DADOS PENDENTES" : vals.every((x) => x === "APROVADO") ? "APROVADO" : "TESTADO";
  const pendentes = [...new Set(T.flatMap((t) => t.pendentes))];
  return { versao: AXLES_VERSION, bikeId: s.bikeId, nome: s.nome, referencia: s.referencia, testes: T, eixos, homologacao, pendentes };
}

/** Referência sintética para exercitar a matemática. Valores redondos inventados para TESTE — não representam nenhuma moto. */
export function referenceSpec(): MotoSpec {
  const base = motoSpec(TITAN_160);
  const R = (x: number, u: string) => D(x, u, "MEDIDO", "REFERÊNCIA DE TESTE (valor redondo, não é moto real)");
  const fill = (cs: Componente[], r: number) => cs.map((c): Componente => c.geometria === "NAO_ROTATIVO" ? { ...c, massa: R(0.5, "kg") } : {
    ...c, massa: R(c.tipo === "Pneu" ? 4 : c.tipo === "Aro" ? 2 : 1, "kg"),
    dims: c.geometria === "ANEL_ESPESSO" ? { rInt: R(c.tipo === "Pneu" ? r * 0.75 : 0.05, "m"), rExt: R(c.tipo === "Pneu" ? r : 0.1, "m") } : { r: R(c.geometria === "ANEL_FINO" ? r * 0.75 : 0.008, "m") },
  });
  const kin: KinSpec = { ...base.kin, bikeId: "referencia", nome: "Referência de teste",
    primaria: { motora: R(20, "dentes"), conduzida: R(70, "dentes") },
    marchas: [[12, 36], [16, 32], [20, 30], [22, 26], [24, 24]].map(([a, b]) => ({ motora: R(a!, "dentes"), conduzida: R(b!, "dentes") })),
    pinhao: R(15, "dentes"), coroa: R(45, "dentes"), passoCorrente: R(0.0127, "m"), raioPneu: R(0.29, "m"),
    eta: { primaria: R(0.98, "1"), cambio: R(0.97, "1"), corrente: R(0.95, "1") }, embreagemNm: R(60, "N·m") };
  return { ...base, bikeId: "referencia", nome: "Referência de teste (sintética)", referencia: true, versaoIdentificada: false, fonteVersao: "fixture de teste",
    veiculo: { massaMoto: R(120, "kg"), massaPiloto: R(80, "kg"), entreEixos: R(1.3, "m"), alturaCG: R(0.6, "m"), cgAteEixoTraseiro: R(0.6, "m"), cdA: R(0.3, "m²"), rhoAr: R(1.225, "kg/m³"), crr: R(0.015, "1"), mu: R(1.0, "1") },
    manivela: { diametro: R(0.06, "m"), curso: R(0.06, "m"), biela: R(0.1, "m"), massaAlternativa: R(0.2, "kg"), inerciaGirante: R(0.002, "kg·m²") },
    kin,
    rodaA: { raioGeometrico: R(0.3, "m"), raioDinamico: R(0.29, "m"), raioEfetivoFreio: R(0.11, "m"), componentes: fill(base.rodaA.componentes, 0.3) },
    rodaB: { raioGeometrico: R(0.3, "m"), raioDinamico: R(0.29, "m"), raioEfetivoFreio: R(0.08, "m"), componentes: fill(base.rodaB.componentes, 0.3) },
    corrente: { passo: R(0.0127, "m"), elos: R(120, "elos"), massaPorMetro: R(0.6, "kg/m"), cargaRupturaN: R(18000, "N"), alongamento: R(0, "1") } };
}

/** Passo integrado (Euler explícito, dt explícito): m_eq·a = F_x,B − F_drag − F_rr,A − F_rr,B. Só com todos os dados. */
export function integratedStep(s: MotoSpec, c: Cond & { vVeiculo: number }, dt = 0.01) {
  const k = { ...s.kin, raioPneu: s.rodaB.raioDinamico }, o = chain(k, c.marcha, c.rpm, c.torque);
  const rB = v(s.rodaB.raioDinamico), rA = v(s.rodaA.raioDinamico), veh = s.veiculo, m = v(veh.massaMoto) + v(veh.massaPiloto);
  const IA = sumInertia(s.rodaA.componentes)!, IB = sumInertia(s.rodaB.componentes)!;
  const { FzA, FzB } = axleLoads(m, c.acel ?? 0, v(veh.alturaCG), v(veh.entreEixos), v(veh.cgAteEixoTraseiro));
  const FxB = Math.min(o.estagios.at(-1)!.torque / rB, v(veh.mu) * FzB);
  const Fd = dragForce(v(veh.rhoAr), v(veh.cdA), c.vVeiculo), Frr = rollingForce(v(veh.crr), FzA + FzB);
  const mEq = m + IA / rA ** 2 + IB / rB ** 2; // inércia do motor refletida exige I do virabrequim medido → não somada
  const a = (FxB - Fd - Frr) / mEq;
  return { a, vNovo: c.vVeiculo + a * dt, FxB, Fd, Frr, FzA, FzB, mEq, pRoda: FxB * omega(o.estagios.at(-1)!.rpm) * rB, pEscorregamento: FxB * (omega(o.estagios.at(-1)!.rpm) * rB - c.vVeiculo), pTracao: FxB * c.vVeiculo, pResist: (Fd + Frr) * c.vVeiculo };
}
