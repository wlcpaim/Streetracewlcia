// Contrato JSON versionado entre a Wikipedia StreetRace (TypeScript) e a Engrenagem Real (Python).
// Mesmas regras em python/realgear/contract.py: SI, unidade obrigatória por grandeza, origem por dado,
// dado ausente = null + DESCONHECIDO, hash canônico idêntico nas duas linguagens.
export const SCHEMA_VERSION = "realgear.bridge/1.0.0";
export const RESPONSE_SCHEMA = "realgear.response/1.0.0";
export const HASH_ALG = "fnv1a32-canon-v1";

export type Origem = "MEDIDO" | "FICHA" | "JOGO" | "CALCULADO" | "ESTIMADO" | "DESCONHECIDO";
export const ORIGENS: Origem[] = ["MEDIDO", "FICHA", "JOGO", "CALCULADO", "ESTIMADO", "DESCONHECIDO"];
/** Grandeza física: valor em SI, unidade explícita, origem e de onde veio. */
export type Q = { value: number | null; unit: string; origin: Origem; source: string };
export type Txt = { value: string | null; origin: Origem; source: string };

/** Unidade SI exigida para cada caminho de grandeza (validador rejeita qualquer outra). */
export const UNITS: Record<string, string> = {
  "geometry.bore": "m", "geometry.stroke": "m", "geometry.rod_length": "m", "geometry.displacement": "m^3",
  "geometry.compression_ratio": "1", "geometry.cylinders": "1",
  "fuel.lower_heating_value": "J/kg", "fuel.density": "kg/m^3", "fuel.tank_volume": "m^3", "fuel.stoich_afr": "1",
  "ignition.advance_offset": "rad", "ignition.base_advance": "rad",
  "feeding.injector_flow_multiplier": "1", "feeding.fuel_pressure": "Pa", "feeding.fuel_trim": "1",
  "lubrication.oil_distance": "m", "lubrication.oil_viscosity": "Pa*s",
  "cooling.head_temperature": "K",
  "transmission.gears": "1", "transmission.front_teeth": "1", "transmission.rear_teeth": "1", "transmission.final_ratio": "1",
  "transmission.efficiency": "1", "transmission.clutch_capacity": "N*m",
  "limits.rev_limit": "rad/s", "limits.power_peak_speed": "rad/s", "limits.peak_power": "W", "limits.engine_distance": "m",
};
export const CONFIG_GROUPS = ["geometry", "components", "fuel", "ignition", "feeding", "lubrication", "cooling", "transmission", "limits", "mechanic_mods"] as const;

export type AuditRecord = {
  layer_id: string; audit_id: string; execution_id: string;
  test_status: "PASS" | "WARNING" | "FAILURE" | "INSUFFICIENT_DATA" | "NOT_RUN";
  inputs: Record<string, Q>; expected_results: Record<string, Q>; actual_results: Record<string, Q>;
  evidence: string[]; findings: string[];
};
export type ProjectPackage = {
  schema_version: string;
  identification: { project_id: string; bike_id: string; engine_id: string; project_version: number; created_at: string; source_system: string; approval_status: "MECANICO_APROVADO" };
  configuration: Record<(typeof CONFIG_GROUPS)[number], Record<string, unknown>>;
  missing_data: string[];
  audit: AuditRecord[];
  integrity: { algorithm: string; hash: string };
};
export const RESPONSE_STATUS = ["RECEBIDO", "DUPLICADO", "REJEITADO", "INCONCLUSIVO", "APROVADO", "REPROVADO"] as const;
export type ResponseStatus = (typeof RESPONSE_STATUS)[number];
export type EngineeringResponse = {
  schema_version: string; project_id: string; project_version: number; project_hash: string;
  audit_id: string; execution_id: string; layer_id: string; status: ResponseStatus;
  calculations: { name: string; equation: string; result: Q }[]; findings: string[]; missing_data: string[];
  evidence: string[]; report: string; next_action: string; created_at: string;
};

// ---------- hash canônico (idêntico em Python) ----------
function canonNum(n: number): string {
  if (Number.isInteger(n)) return String(n);
  const [m, e] = n.toExponential(11).split("e");
  return `${m}e${Number(e)}`;
}
export function canonical(x: unknown): string {
  if (x === null || x === undefined) return "null";
  if (typeof x === "number") { if (!Number.isFinite(x)) throw new Error("número não finito"); return canonNum(x); }
  if (typeof x === "boolean") return x ? "true" : "false";
  if (typeof x === "string") return JSON.stringify(x);
  if (Array.isArray(x)) return `[${x.map(canonical).join(",")}]`;
  const o = x as Obj;
  return `{${Object.keys(o).filter((k) => o[k] !== undefined).sort().map((k) => `${JSON.stringify(k)}:${canonical(o[k])}`).join(",")}}`;
}
export function fnv1a32(s: string): string {
  const bytes = new TextEncoder().encode(s); let h = 0x811c9dc5;
  for (const b of bytes) { h ^= b; h = Math.imul(h, 0x01000193); }
  return (h >>> 0).toString(16).padStart(8, "0");
}
/** O hash cobre identificação + configuração + dados ausentes + auditoria (tudo menos o próprio campo integrity). */
export const packageHash = (p: Omit<ProjectPackage, "integrity">) => fnv1a32(canonical({ schema_version: p.schema_version, identification: p.identification, configuration: p.configuration, missing_data: p.missing_data, audit: p.audit }));

// ---------- validação ----------
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Obj = any;
const isObj = (x: unknown): x is Obj => !!x && typeof x === "object" && !Array.isArray(x);
const isStr = (x: unknown) => typeof x === "string" && x.length > 0;
function checkQ(path: string, q: unknown, errs: string[]): void {
  if (!isObj(q)) { errs.push(`${path}: grandeza deve ser objeto {value, unit, origin, source}`); return; }
  if (!ORIGENS.includes(q.origin as Origem)) errs.push(`${path}: origem inválida '${String(q.origin)}'`);
  if (!isStr(q.source)) errs.push(`${path}: source obrigatório`);
  if (typeof q.unit !== "string") errs.push(`${path}: unidade obrigatória`);
  if (q.value === null) { if (q.origin !== "DESCONHECIDO") errs.push(`${path}: valor nulo exige origem DESCONHECIDO`); }
  else if (typeof q.value !== "number" || !Number.isFinite(q.value)) errs.push(`${path}: valor deve ser número finito ou null`);
  else if (q.origin === "DESCONHECIDO") errs.push(`${path}: DESCONHECIDO não pode ter valor`);
  const want = UNITS[path];
  if (want && q.unit !== want) errs.push(`${path}: unidade incompatível '${String(q.unit)}' (esperado ${want})`);
}
export function validatePackage(x: unknown): string[] {
  const errs: string[] = [];
  if (!isObj(x)) return ["pacote não é objeto JSON"];
  if (x.schema_version !== SCHEMA_VERSION) errs.push(`schema_version '${String(x.schema_version)}' não suportado (esperado ${SCHEMA_VERSION})`);
  const id = x.identification;
  if (!isObj(id)) errs.push("identification ausente");
  else {
    for (const k of ["project_id", "bike_id", "engine_id", "created_at", "source_system"]) if (!isStr(id[k])) errs.push(`identification.${k} obrigatório`);
    if (!Number.isInteger(id.project_version) || (id.project_version as number) < 1) errs.push("identification.project_version deve ser inteiro ≥ 1");
    if (id.approval_status !== "MECANICO_APROVADO") errs.push("identification.approval_status deve ser MECANICO_APROVADO");
    if (isStr(id.created_at) && Number.isNaN(Date.parse(id.created_at as string))) errs.push("identification.created_at não é data ISO");
  }
  const cfg = x.configuration;
  if (!isObj(cfg)) errs.push("configuration ausente");
  else {
    for (const g of CONFIG_GROUPS) if (!isObj(cfg[g])) errs.push(`configuration.${g} obrigatório`);
    for (const [path] of Object.entries(UNITS)) {
      const [g, k] = path.split(".") as [string, string];
      const grp = cfg[g];
      if (isObj(grp)) { if (!(k in grp)) errs.push(`configuration.${path} obrigatório`); else checkQ(path, grp[k], errs); }
    }
  }
  if (!Array.isArray(x.missing_data) || x.missing_data.some((m: unknown) => typeof m !== "string")) errs.push("missing_data deve ser lista de textos");
  if (!Array.isArray(x.audit)) errs.push("audit deve ser lista");
  else x.audit.forEach((a: unknown, i: number): void => {
    if (!isObj(a)) { errs.push(`audit[${i}] não é objeto`); return; }
    for (const k of ["layer_id", "audit_id", "execution_id", "test_status"]) if (!isStr(a[k])) errs.push(`audit[${i}].${k} obrigatório`);
    for (const k of ["inputs", "expected_results", "actual_results"]) if (!isObj(a[k])) errs.push(`audit[${i}].${k} obrigatório`);
    for (const k of ["evidence", "findings"]) if (!Array.isArray(a[k])) errs.push(`audit[${i}].${k} deve ser lista`);
  });
  const ig = x.integrity;
  if (!isObj(ig) || ig.algorithm !== HASH_ALG || !isStr(ig.hash)) errs.push("integrity {algorithm, hash} obrigatório");
  else if (!errs.length && packageHash(x as unknown as ProjectPackage) !== ig.hash) errs.push("integrity.hash não confere: conteúdo alterado");
  return errs;
}
const FORBIDDEN = ["setup", "slots", "patch", "apply", "configuration", "physics"];
export function validateResponse(x: unknown): string[] {
  const errs: string[] = [];
  if (!isObj(x)) return ["resposta não é objeto JSON"];
  if (x.schema_version !== RESPONSE_SCHEMA) errs.push(`schema_version '${String(x.schema_version)}' não suportado`);
  for (const k of ["project_id", "project_hash", "audit_id", "execution_id", "layer_id", "report", "next_action", "created_at"]) if (!isStr(x[k])) errs.push(`${k} obrigatório`);
  if (!Number.isInteger(x.project_version)) errs.push("project_version deve ser inteiro");
  if (!RESPONSE_STATUS.includes(x.status as ResponseStatus)) errs.push(`status inválido '${String(x.status)}'`);
  for (const k of ["calculations", "findings", "missing_data", "evidence"]) if (!Array.isArray(x[k])) errs.push(`${k} deve ser lista`);
  if (Array.isArray(x.calculations)) x.calculations.forEach((c: Obj, i: number) => { if (!isObj(c) || !isStr(c.name) || !isStr(c.equation)) errs.push(`calculations[${i}] incompleto`); else checkQ(`calculations[${i}]`, c.result, errs); });
  const bad = FORBIDDEN.filter((k) => k in x);
  if (bad.length) errs.push(`resposta externa não pode carregar alterações de motor/física (${bad.join(", ")})`);
  if ((x.status === "APROVADO" || x.status === "REPROVADO") && (!Array.isArray(x.evidence) || !x.evidence.length || !Array.isArray(x.calculations) || !x.calculations.length)) errs.push(`${String(x.status)} sem evidência e cálculos não é aceito`);
  return errs;
}
/** Lê texto JSON com erro legível em vez de exceção. */
export function parseJson(txt: string): { ok: true; value: unknown } | { ok: false; error: string } {
  try { return { ok: true, value: JSON.parse(txt) }; } catch (e) { return { ok: false, error: `JSON malformado: ${(e as Error).message}` }; }
}
