import { useEffect, useState } from "react";
import type { Projeto } from "../funnel";
import { download, jsonBlob } from "../logs";
import { exportProject } from "./exporter";
import { acceptResponse, localStore, recordExport, type LedgerEvent } from "./ledger";
import type { ProjectPackage } from "./contract";

export function BridgeTab({ projeto }: { projeto: Projeto | undefined }) {
  const [pkg, setPkg] = useState<ProjectPackage | null>(null);
  const [errs, setErrs] = useState<string[]>([]);
  const [msg, setMsg] = useState<string>("");
  const [events, setEvents] = useState<LedgerEvent[]>([]);
  useEffect(() => setEvents(localStore().read()), []);
  const doExport = () => {
    if (!projeto) return;
    const r = exportProject(projeto);
    if (!r.ok) { setErrs(r.errors); setPkg(null); return; }
    setErrs([]); setPkg(r.pkg); const st = localStore(); recordExport(st, r.pkg); setEvents(st.read());
    download(jsonBlob(r.pkg), `${r.pkg.identification.project_id}.v${r.pkg.identification.project_version}.json`);
  };
  const onFile = async (f: File | undefined) => {
    if (!f || !pkg) return;
    const st = localStore(); const a = acceptResponse(st, pkg, await f.text()); setEvents(st.read());
    setMsg(a.accepted ? `Resposta aceita: ${a.response!.status} · ${a.response!.execution_id}. Nada no motor foi alterado.` : `Resposta recusada: ${a.errors.join(" · ")}`);
  };
  return (
    <section className="space-y-3">
      <p className="text-sm text-muted-foreground">Exporta o projeto selecionado em JSON (SI) para o Python da Engrenagem Real e recebe a resposta. Receber não é aprovar; nenhuma resposta altera a moto ou a corrida.</p>
      <div className="flex flex-wrap gap-2">
        <button disabled={!projeto} onClick={doExport} className="h-10 rounded-xl bg-primary px-4 font-display text-primary-foreground disabled:opacity-60">EXPORTAR JSON</button>
        <label className={`flex h-10 cursor-pointer items-center rounded-xl bg-secondary px-4 text-sm ${pkg ? "" : "pointer-events-none opacity-60"}`}>
          Carregar resposta do Python
          <input type="file" accept="application/json,.json" className="hidden" onChange={(e) => onFile(e.target.files?.[0])} />
        </label>
      </div>
      {errs.length > 0 && <ul className="list-disc rounded-xl border border-destructive p-3 pl-6 text-sm">{errs.map((e) => <li key={e}>{e}</li>)}</ul>}
      {pkg && <p className="text-xs">Exportado {pkg.identification.project_id} v{pkg.identification.project_version} · hash {pkg.integrity.hash} · {pkg.missing_data.length} dados ausentes</p>}
      {msg && <p className="rounded-xl border border-border p-2 text-sm">{msg}</p>}
      <div className="rounded-xl border border-border p-2">
        <div className="mb-1 font-display text-sm">Histórico da ponte ({events.length})</div>
        <ul className="max-h-72 space-y-1 overflow-auto font-mono text-[11px]">
          {[...events].reverse().map((e, i) => <li key={i}>{e.at} · {e.kind}{"project_id" in e ? ` · ${e.project_id} v${e.project_version}` : ""}{"status" in e ? ` · ${e.status}` : ""}{"accepted" in e ? (e.accepted ? " · aceita" : " · recusada") : ""}{"errors" in e && e.errors.length ? ` · ${e.errors.join("; ")}` : ""}</li>)}
        </ul>
      </div>
    </section>
  );
}
