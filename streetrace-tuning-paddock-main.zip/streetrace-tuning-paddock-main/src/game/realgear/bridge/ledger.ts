// Ponte: histórico append-only de exportações, recebimentos e respostas. Nada aqui altera Setup/save/física.
import { cloudStore } from "@/game/cloud/cloud-store";
import { parseJson, validatePackage, validateResponse, type EngineeringResponse, type ProjectPackage } from "./contract";

export type LedgerEvent =
  | { kind: "EXPORT"; at: string; project_id: string; project_version: number; hash: string }
  | { kind: "RECEIPT"; at: string; project_id: string; project_version: number; hash: string; status: "RECEBIDO" | "DUPLICADO" | "REJEITADO"; errors: string[] }
  | { kind: "RESPONSE"; at: string; project_id: string; project_version: number; execution_id: string; status: string; accepted: boolean; errors: string[]; response?: EngineeringResponse }
  | { kind: "ERROR"; at: string; where: string; errors: string[] };
export interface Store { read(): LedgerEvent[]; append(e: LedgerEvent): void }
export const KEY = "streetrace-realgear-bridge-v1";
export function localStore(): Store {
  return {
    read: () => { try { return JSON.parse(cloudStore.getItem(KEY) ?? "[]"); } catch { return []; } },
    append: (e) => { const all = [...localStore().read(), e]; try { cloudStore.setItem(KEY, JSON.stringify(all)); } catch { /* cheio */ } },
  };
}
export function memoryStore(init: LedgerEvent[] = []): Store & { events: LedgerEvent[] } {
  const events = [...init];
  return { events, read: () => [...events], append: (e) => { events.push(e); } };
}
const now = () => new Date().toISOString();

export function recordExport(st: Store, pkg: ProjectPackage) {
  st.append({ kind: "EXPORT", at: now(), project_id: pkg.identification.project_id, project_version: pkg.identification.project_version, hash: pkg.integrity.hash });
}

export type Receipt = { status: "RECEBIDO" | "DUPLICADO" | "REJEITADO"; project_id: string | null; project_version: number | null; hash: string | null; errors: string[]; note: string };
/** Importador (espelho do lado Python): valida, checa integridade, duplicidade e versão; registra tudo. Recebimento ≠ aprovação. */
export function receivePackage(st: Store, input: string | unknown): Receipt {
  const parsed = typeof input === "string" ? parseJson(input) : { ok: true as const, value: input };
  if (!parsed.ok) { st.append({ kind: "ERROR", at: now(), where: "receivePackage", errors: [parsed.error] }); return { status: "REJEITADO", project_id: null, project_version: null, hash: null, errors: [parsed.error], note: "nada registrado como recebido" }; }
  const errs = validatePackage(parsed.value);
  const p = parsed.value as ProjectPackage;
  const id = p?.identification?.project_id ?? null, ver = p?.identification?.project_version ?? null, hash = p?.integrity?.hash ?? null;
  if (!errs.length) {
    const prev = st.read().filter((e): e is Extract<LedgerEvent, { kind: "RECEIPT" }> => e.kind === "RECEIPT" && e.status === "RECEBIDO" && e.project_id === id);
    const same = prev.find((e) => e.project_version === ver);
    if (same && same.hash === hash) { const r: Receipt = { status: "DUPLICADO", project_id: id, project_version: ver, hash, errors: [], note: "já recebido: execução não repetida" }; st.append({ kind: "RECEIPT", at: now(), project_id: id!, project_version: ver!, hash: hash!, status: r.status, errors: [] }); return r; }
    if (same) errs.push(`versão ${ver} já recebida com outro conteúdo (hash ${same.hash}): crie nova versão`);
    const top = Math.max(0, ...prev.map((e) => e.project_version));
    if (ver != null && ver < top) errs.push(`versão ${ver} é mais antiga que a última recebida (${top})`);
  }
  const status = errs.length ? "REJEITADO" : "RECEBIDO";
  st.append({ kind: "RECEIPT", at: now(), project_id: id ?? "?", project_version: ver ?? -1, hash: hash ?? "?", status, errors: errs });
  return { status, project_id: id, project_version: ver, hash, errors: errs, note: status === "RECEBIDO" ? "estrutura válida; recebimento não significa aprovação física" : "rejeitado" };
}

export type Acceptance = { accepted: boolean; errors: string[]; response: EngineeringResponse | null };
/** Aceita a resposta da Engrenagem Real só se for do mesmo projeto, versão e hash atuais. Nunca toca na física: só registra. */
export function acceptResponse(st: Store, current: ProjectPackage, input: string | unknown): Acceptance {
  const parsed = typeof input === "string" ? parseJson(input) : { ok: true as const, value: input };
  if (!parsed.ok) { st.append({ kind: "ERROR", at: now(), where: "acceptResponse", errors: [parsed.error] }); return { accepted: false, errors: [parsed.error], response: null }; }
  const errs = validateResponse(parsed.value);
  const r = parsed.value as EngineeringResponse;
  const id = current.identification;
  if (!errs.length) {
    if (r.project_id !== id.project_id) errs.push(`resposta é do projeto ${r.project_id}, atual é ${id.project_id}`);
    else if (r.project_version < id.project_version) errs.push(`resposta da versão antiga ${r.project_version} não pode ser aplicada à versão ${id.project_version}`);
    else if (r.project_version !== id.project_version) errs.push(`resposta da versão ${r.project_version} não existe localmente (atual ${id.project_version})`);
    else if (r.project_hash !== current.integrity.hash) errs.push("hash da resposta não confere com o projeto atual");
    if (st.read().some((e) => e.kind === "RESPONSE" && e.accepted && e.execution_id === r.execution_id)) errs.push(`execução ${r.execution_id} já registrada (duplicada)`);
  }
  const accepted = !errs.length;
  st.append({ kind: "RESPONSE", at: now(), project_id: r?.project_id ?? "?", project_version: r?.project_version ?? -1, execution_id: r?.execution_id ?? "?", status: r?.status ?? "?", accepted, errors: errs, ...(accepted ? { response: r } : {}) });
  return { accepted, errors: errs, response: accepted ? r : null };
}
