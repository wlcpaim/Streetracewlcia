// Exportador da Wikipedia StreetRace: projeto aprovado pelo mecânico → pacote JSON de engenharia (SI).
// Função pura: lê a física do jogo, não altera o motor, o setup nem o save do jogador.
import { ETA, FUEL_DENSITY, ccOf, drivetrain, engine, type Setup } from "../../physics";
import { CAM_LABEL, SLOTS, partById } from "../../parts";
import { physicsReview } from "../../intel/changelog";
import { FICHA, LHV, STOICH, type Projeto } from "../funnel";
import { HASH_ALG, SCHEMA_VERSION, packageHash, validatePackage, type AuditRecord, type Origem, type ProjectPackage, type Q } from "./contract";

// Conversões explícitas para SI (cada uma nomeada no source do dado).
export const MM_TO_M = 1e-3, CC_TO_M3 = 1e-6, L_TO_M3 = 1e-3, KG_L_TO_KG_M3 = 1e3, DEG_TO_RAD = Math.PI / 180, RPM_TO_RAD_S = (2 * Math.PI) / 60, CV_TO_W = 735.49875, KM_TO_M = 1e3, PCT_TO_1 = 1e-2;

const q = (value: number | null, unit: string, origin: Origem, source: string): Q => (value === null || !Number.isFinite(value) ? { value: null, unit, origin: "DESCONHECIDO", source } : { value, unit, origin, source });
const unk = (unit: string, why: string): Q => ({ value: null, unit, origin: "DESCONHECIDO", source: why });

export type ExportResult = { ok: true; pkg: ProjectPackage } | { ok: false; errors: string[] };

export function exportProject(p: Projeto, createdAt = new Date().toISOString()): ExportResult {
  const errors: string[] = [];
  if (!p.aprovadoMecanico) errors.push("projeto sem aprovação do mecânico: exportação bloqueada");
  if (!/^\d+$/.test(p.versao) || Number(p.versao) < 1) errors.push(`versão '${p.versao}' não é inteiro ≥ 1`);
  if (errors.length) return { ok: false, errors };
  const b = p.bike, s: Setup = structuredClone(p.setup);
  const e = engine(b, s), cc = ccOf(b, s), fic = FICHA[b.id], dtr = drivetrain(b, s);
  const comp = Object.fromEntries(SLOTS.map((k) => { const part = partById(s.slots[k]); return [k, { id: s.slots[k], name: part ? `${part.brand} ${part.name}`.trim() : null, factory: !!part?.factory, origin: part ? "JOGO" : "DESCONHECIDO", source: "parts.ts PARTS_CATALOG" }]; }));
  const bico = partById(s.slots.bico), emb = partById(s.slots.embreagem);
  const configuration: ProjectPackage["configuration"] = {
    geometry: {
      bore: q(fic ? fic.boreMm * MM_TO_M : null, "m", "FICHA", "funnel.ts FICHA boreMm × 1e-3"),
      stroke: q(fic ? fic.strokeMm * MM_TO_M : null, "m", "FICHA", "funnel.ts FICHA strokeMm × 1e-3"),
      rod_length: q(fic?.rodMm != null ? fic.rodMm * MM_TO_M : null, "m", "FICHA", "comprimento de biela não cadastrado na ficha"),
      displacement: q(cc * CC_TO_M3, "m^3", "JOGO", "physics.ccOf() cc × 1e-6"),
      compression_ratio: q(s.compression, "1", "JOGO", "Setup.compression"),
      cylinders: q(/Monocil/i.test(b.engine) ? 1 : null, "1", "FICHA", `BikeModel.engine '${b.engine}'`),
    },
    components: { ...comp, cam: { id: s.cam, name: CAM_LABEL[s.cam] ?? null, origin: "JOGO", source: "Setup.cam" } },
    fuel: {
      type: { value: s.fuel, origin: "JOGO", source: "Setup.fuel" },
      blend: s.blend ? { ...s.blend, origin: "JOGO", source: "Setup.blend (frações)" } : { value: null, origin: "JOGO", source: "sem mistura: combustível base puro" },
      lower_heating_value: q(LHV[s.fuel] ?? null, "J/kg", "ESTIMADO", "funnel.ts LHV (referência, não medido)"),
      density: q(FUEL_DENSITY[s.fuel] * KG_L_TO_KG_M3, "kg/m^3", "JOGO", "physics.FUEL_DENSITY kg/L × 1e3"),
      tank_volume: q(b.tank * L_TO_M3, "m^3", "FICHA", "BikeModel.tank L × 1e-3"),
      stoich_afr: q(STOICH[s.fuel] ?? null, "1", "ESTIMADO", "funnel.ts STOICH (referência)"),
    },
    ignition: {
      advance_offset: q(s.ecu.timing * DEG_TO_RAD, "rad", "JOGO", "Setup.ecu.timing (° sobre o mapa base) × π/180"),
      base_advance: unk("rad", "mapa de ignição base de fábrica não existe no jogo"),
      programmable: { value: !!partById(s.slots.modulo)?.prog, origin: "JOGO", source: "parts.ts modulo.prog" },
    },
    feeding: {
      injector_flow_multiplier: q(bico?.flow ?? 1, "1", "JOGO", "parts.ts bico.flow (× fábrica; vazão absoluta não cadastrada)"),
      fuel_pressure: unk("Pa", "pressão de linha não modelada"),
      fuel_trim: q(s.ecu.trim * PCT_TO_1, "1", "JOGO", "Setup.ecu.trim % × 1e-2"),
      air_filter: { value: s.airFilter, origin: "JOGO", source: "Setup.airFilter" },
    },
    lubrication: {
      oil_distance: q(s.oilKm * KM_TO_M, "m", "JOGO", "Setup.oilKm × 1e3"),
      oil_viscosity: unk("Pa*s", "viscosidade do óleo não cadastrada"),
    },
    cooling: {
      type: { value: b.cooling, origin: "FICHA", source: "BikeModel.cooling" },
      head_temperature: unk("K", "sem medição de temperatura de cabeçote"),
    },
    transmission: {
      gears: q(b.gears, "1", "FICHA", "BikeModel.gears"),
      front_teeth: q(s.front, "1", "JOGO", "Setup.front"),
      rear_teeth: q(s.rear, "1", "JOGO", "Setup.rear"),
      final_ratio: q(s.rear / s.front, "1", "CALCULADO", "rear / front"),
      efficiency: q(ETA, "1", "ESTIMADO", "physics.ETA = registry drivetrain.eta_total (total motor→roda, não medido por estágio)"),
      clutch_capacity: q(emb?.clutchNm ?? null, "N*m", "JOGO", "parts.ts embreagem.clutchNm"),
      primary_ratio: q(dtr.primary, "1", "FICHA", dtr.fonte),
      gear_ratios: dtr.origem === "MANUAL"
        ? { value: dtr.gears.map((g, i) => ({ gear: i + 1, internal: g, total: dtr.totals[i]!, cut_speed: dtr.vCutKmh[i]! / 3.6 })), unit: "1 (cut_speed m/s)", origin: "FICHA", source: `${dtr.fonte}; total = primária × marcha × coroa/pinhão; cut_speed = ω_corte·r_din/total` }
        : { value: null, origin: "DESCONHECIDO", source: dtr.fonte },
      dynamic_tire_radius: q(dtr.rDynM, "m", "ESTIMADO", "physics.rearTireDynM: raio estático do pneu montado × tire.rolling_factor"),
    },
    limits: {
      rev_limit: q(e.rpmLimit * RPM_TO_RAD_S, "rad/s", "CALCULADO", `physics.engine().rpmLimit ${e.rpmLimit} rpm × 2π/60`),
      power_peak_speed: q(e.rpmPeak * RPM_TO_RAD_S, "rad/s", "CALCULADO", `physics.engine().rpmPeak ${e.rpmPeak} rpm × 2π/60`),
      peak_power: q(e.hp * CV_TO_W, "W", "CALCULADO", `physics.engine().hp ${e.hp.toFixed(3)} cv × 735,49875`),
      engine_distance: q(s.km * KM_TO_M, "m", "JOGO", "Setup.km × 1e3"),
    },
    mechanic_mods: {
      services: { value: [...s.services], origin: "JOGO", source: "Setup.services" },
      machining: { value: s.mach ? { cava: s.mach.cavaMm != null ? s.mach.cavaMm * MM_TO_M : null, rebaixo: s.mach.rebaixoMm != null ? s.mach.rebaixoMm * MM_TO_M : null, unit: "m" } : null, origin: "JOGO", source: "Setup.mach mm × 1e-3" },
      ecu: { value: { ...s.ecu }, origin: "JOGO", source: "Setup.ecu (unidades do jogo: rpm, °, %, ms)" },
      removed: { value: { ...s.removed }, origin: "JOGO", source: "Setup.removed" },
    },
  };
  const missing: string[] = [];
  const walk = (o: unknown, path: string) => { if (o && typeof o === "object") { const r = o as { [k: string]: unknown; origin?: unknown; source?: unknown }; if (r.origin === "DESCONHECIDO") missing.push(`${path}: ${String(r.source)}`); else for (const [k, v] of Object.entries(r)) walk(v, path ? `${path}.${k}` : k); } };
  walk(configuration, "");
  const execId = `wiki-review-${p.id}-v${p.versao}`;
  const audit: AuditRecord[] = physicsReview(s, b.id).map((c) => ({
    layer_id: "WIKI-PHYSICS-REVIEW", audit_id: c.id, execution_id: execId,
    test_status: c.status,
    inputs: {}, expected_results: { [c.id]: q(c.ref, c.unit, "CALCULADO", c.formula) }, actual_results: { [c.id]: q(c.calc, c.unit, "CALCULADO", c.formula) },
    evidence: [`${c.law}: ${c.formula}`, `erro ${c.errPct.toFixed(4)}%`], findings: [c.note],
  }));
  const body: Omit<ProjectPackage, "integrity"> = {
    schema_version: SCHEMA_VERSION,
    identification: { project_id: p.id, bike_id: b.id, engine_id: `${b.id}:${b.engine}`, project_version: Number(p.versao), created_at: createdAt, source_system: "Wikipedia StreetRace", approval_status: "MECANICO_APROVADO" },
    configuration, missing_data: missing, audit,
  };
  const pkg: ProjectPackage = { ...body, integrity: { algorithm: HASH_ALG, hash: packageHash(body) } };
  const v = validatePackage(JSON.parse(JSON.stringify(pkg)));
  return v.length ? { ok: false, errors: v } : { ok: true, pkg };
}
