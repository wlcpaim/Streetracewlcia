import { useMemo, useState } from "react";
import { MOTO_SPECS, referenceSpec, runBatteries, inertia, type AxReport, type MotoSpec, type Componente } from "./axles";

const SPECS: MotoSpec[] = [...MOTO_SPECS, referenceSpec()];
const TONE: Record<string, string> = { APROVADO: "bg-primary text-primary-foreground", TESTADO: "bg-accent text-accent-foreground", REPROVADO: "bg-destructive text-destructive-foreground", INDETERMINADO: "bg-muted text-muted-foreground", "DADOS PENDENTES": "bg-muted text-muted-foreground" };
const NOME = { A: "Eixo A — dianteiro", B: "Eixo B — traseiro", C: "Eixo C — motor e transmissão" } as const;
const COND = { marcha: 2, rpm: 6000, torque: 12, vVeiculo: 15, acel: 2, FtFreioA: 1500, FtFreioB: 800 };

function download(name: string, data: unknown) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
  a.download = name; a.click(); URL.revokeObjectURL(a.href);
}
const fmt = (d: { valor: number | null; unidade: string }) => (d.valor === null ? "PENDENTE" : `${d.valor} ${d.unidade}`);

function Comps({ cs }: { cs: Componente[] }) {
  return (
    <table className="w-full text-xs"><thead><tr className="text-left text-muted-foreground"><th>Componente</th><th>Massa</th><th>Geometria</th><th>I (kg·m²)</th><th>Origem</th></tr></thead>
      <tbody>{cs.map((c) => { const I = inertia(c); return (
        <tr key={c.id} className="border-t border-border"><td>{c.tipo}</td><td>{fmt(c.massa)}</td><td>{c.geometria}</td><td>{I === null ? "PENDENTE" : I.toFixed(5)}</td><td>{c.massa.origem}</td></tr>); })}</tbody></table>
  );
}

export function AxlesTab() {
  const [i, setI] = useState(0);
  const [hist, setHist] = useState<AxReport[]>([]);
  const s = SPECS[i]!;
  const r = useMemo(() => runBatteries(s, COND), [s]);
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        {SPECS.map((x, k) => <button key={x.bikeId} onClick={() => setI(k)} className={`rounded-lg px-3 py-1.5 text-sm ${k === i ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>{x.nome}</button>)}
        <button onClick={() => setHist((h) => [runBatteries(s, COND), ...h].slice(0, 20))} className="rounded-lg bg-secondary px-3 py-1.5 text-sm">Executar baterias</button>
        <button onClick={() => download(`tres-eixos-${s.bikeId}.json`, { spec: s, relatorio: r, condicao: COND })} className="rounded-lg bg-secondary px-3 py-1.5 text-sm">Exportar relatório JSON</button>
      </div>
      <div className="rounded-xl bg-secondary p-3 text-sm">
        <p><b>Versão da moto:</b> {s.fonteVersao}</p>
        {s.referencia && <p className="text-destructive">Referência sintética de teste: valores redondos inventados só para conferir a matemática. Não é uma moto real.</p>}
        <p><b>Homologação:</b> <span className={`rounded px-2 ${TONE[r.homologacao] ?? "bg-muted"}`}>{r.homologacao}</span> — nunca automática; exige testes integrados e autorização humana.</p>
        <p className="text-xs text-muted-foreground">Condição: {COND.marcha}ª marcha, {COND.rpm} rpm, {COND.torque} N·m, v = {COND.vVeiculo} m/s, a = {COND.acel} m/s². Corridas não usam este módulo.</p>
      </div>
      <div className="grid gap-3 md:grid-cols-3">
        {(["C", "B", "A"] as const).map((e) => { const ts = r.testes.filter((t) => t.bateria === e); return (
          <div key={e} className="rounded-xl bg-secondary p-3 text-sm">
            <p className="font-semibold">{NOME[e]}</p>
            <span className={`rounded px-2 text-xs ${TONE[r.eixos[e]] ?? "bg-muted"}`}>{r.eixos[e]}</span>
            <p className="text-xs">{ts.filter((t) => t.estado === "APROVADO").length} aprovados · {ts.filter((t) => t.estado === "REPROVADO").length} reprovados · {ts.filter((t) => t.estado === "INDETERMINADO").length} indeterminados</p>
          </div>); })}
      </div>
      <div className="overflow-x-auto rounded-xl bg-secondary p-3">
        <table className="w-full text-xs"><thead><tr className="text-left text-muted-foreground"><th>#</th><th>Eixo</th><th>Teste</th><th>Equação</th><th>Esperado</th><th>Calculado</th><th>Estado</th></tr></thead>
          <tbody>{r.testes.map((t) => (
            <tr key={t.n} className="border-t border-border align-top"><td>{t.n}</td><td>{t.bateria}</td><td>{t.nome}</td><td className="font-mono">{t.equacao}</td><td>{t.esperado}</td><td>{t.observado} {t.unidade}</td>
              <td><span className={`rounded px-1 ${TONE[t.estado]}`}>{t.estado}</span>{t.pendentes.length > 0 && <div className="text-muted-foreground">falta: {t.pendentes.join(", ")}</div>}</td></tr>))}</tbody></table>
      </div>
      <details className="rounded-xl bg-secondary p-3 text-sm"><summary>Dados do veículo e do motor</summary>
        <ul className="text-xs">{Object.entries({ ...s.veiculo, ...s.manivela }).map(([k, d]) => <li key={k}><b>{k}</b>: {fmt(d)} · {d.origem} · {d.fonte}</li>)}</ul></details>
      <details className="rounded-xl bg-secondary p-3 text-sm"><summary>Componentes do eixo A</summary><Comps cs={s.rodaA.componentes} /></details>
      <details className="rounded-xl bg-secondary p-3 text-sm"><summary>Componentes do eixo B</summary><Comps cs={s.rodaB.componentes} /></details>
      <div className="rounded-xl bg-secondary p-3 text-sm"><p className="font-semibold">Dados pendentes ({r.pendentes.length})</p><p className="text-xs">{r.pendentes.join(" · ") || "nenhum"}</p></div>
      {hist.length > 0 && <div className="rounded-xl bg-secondary p-3 text-xs"><p className="font-semibold">Histórico desta sessão</p>{hist.map((h, k) => <p key={k}>{h.nome}: C {h.eixos.C} · B {h.eixos.B} · A {h.eixos.A} → {h.homologacao}</p>)}</div>}
    </div>
  );
}
