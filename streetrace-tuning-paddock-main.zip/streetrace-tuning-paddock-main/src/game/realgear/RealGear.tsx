import { cloudStore } from "@/game/cloud/cloud-store";
import { useEffect, useMemo, useState } from "react";
import { bikeModel, normalizeSetup } from "../physics";
import { BIKES } from "../admin-lab";
import { reportTxt, runFunnel, stockProject, type Camada, type Execucao, type Projeto } from "./funnel";
import { appendHistory, readHistory, type Tentativa } from "./history";
import { RG_UPDATES } from "./updates";
import { appendLayerLogs, readLayerLogs, type LayerLog } from "./logs";
import { LogsTab, OpenSourceTab } from "./Extras";
import { BridgeTab } from "./bridge/BridgeTab";
import { FixCenterTab } from "./fix/FixCenterTab";
import { AxlesTab } from "./AxlesTab";
import { RealGearContentTab } from "./content-reader/RealGearContentTab";
import { CloudTab } from "../cloud/CloudTab";
import { captureFailures, processFailure, readFix, saveFix } from "./fix/pipeline";
import { emptyFix, type FixState } from "./fix/contracts";
import { INTAKE_EVENT, INTAKE_KEY, readIntake, type Intake } from "./live-intake";

type Tab = "aovivo" | "nuvem" | "eixos" | "fix" | "projetos" | "funil" | "historico" | "logs" | "ponte" | "opensource" | "atualizacoes" | "conteudo";
const TONE: Record<string, string> = { APROVADA: "bg-primary text-primary-foreground", REPROVADA: "bg-destructive text-destructive-foreground", INCONCLUSIVA: "bg-accent text-accent-foreground", BLOQUEADA: "bg-muted text-muted-foreground" };

function playerProject(): Projeto | null {
  try {
    const p = JSON.parse(cloudStore.getItem("streetrace-save-v1") ?? "null");
    if (!p?.setup) return null;
    const b = bikeModel(p.activeBike ?? "titan160");
    return { id: `player-${b.id}`, versao: String(p.setup.km ?? 0), nome: `Moto do piloto ${p.name ?? ""}`.trim(), bike: b, setup: normalizeSetup(p.setup), aprovadoMecanico: true, origem: "Wikipedia StreetRace · save do jogo" };
  } catch { return null; }
}

export function RealGear() {
  const [tab, setTab] = useState<Tab>("projetos");
  const [projetos, setProjetos] = useState<Projeto[]>([]);
  const [sel, setSel] = useState(0);
  const [exec, setExec] = useState<Execucao | null>(null);
  const [open, setOpen] = useState<number | null>(null);
  const [hist, setHist] = useState<Tentativa[]>([]);
  const [busy, setBusy] = useState(false);
  const [logs, setLogs] = useState<LayerLog[]>([]);
  const [fix, setFix] = useState<FixState>(emptyFix);
  const nomes = useMemo(() => { try { return runFunnel(stockProject(BIKES[0]!), "1970-01-01T00:00:00Z").camadas.map((c) => ({ n: c.n, nome: c.nome })); } catch { return []; } }, []);
  const [intake, setIntake] = useState<Intake[]>([]);
  useEffect(() => { const pp = playerProject(); setProjetos([...(pp ? [pp] : []), ...BIKES.map(stockProject)]); setHist(readHistory()); setLogs(readLayerLogs()); setFix(readFix()); setIntake(readIntake()); if (location.hash === "#fix") setTab("fix"); if (location.hash === "#aovivo") setTab("aovivo"); }, []);
  useEffect(() => {
    const load = () => { setIntake(readIntake()); setHist(readHistory()); setLogs(readLayerLogs()); setFix(readFix()); };
    const onStore = (e: StorageEvent) => e.key === INTAKE_KEY && load();
    window.addEventListener(INTAKE_EVENT, load); window.addEventListener("storage", onStore);
    return () => { window.removeEventListener(INTAKE_EVENT, load); window.removeEventListener("storage", onStore); };
  }, []);
  const openIntake = (it: Intake) => {
    const list = projetos.some((x) => x.id === it.projeto.id) ? projetos : [it.projeto, ...projetos];
    setProjetos(list); setSel(list.findIndex((x) => x.id === it.projeto.id));
    const x = runFunnel(it.projeto, it.at); setExec(x); setOpen(x.atual); setTab("funil");
  };
  const p = projetos[sel];
  const run = () => { if (!p) return; setBusy(true); setTimeout(() => { const x = runFunnel(p); setExec(x); setHist(appendHistory(x)); setLogs(appendLayerLogs(p, x)); const c = captureFailures(readFix(), p, x); setFix(saveFix(c.novos.reduce((st, f) => processFailure(st, f.failureId, x.at), c.st))); setOpen(x.atual); setTab("funil"); setBusy(false); }, 20); };
  const grupos = useMemo(() => (exec ? (["A", "B", "C", "D"] as const).map((g) => ({ g, cs: exec.camadas.filter((c) => c.grupo === g) })) : []), [exec]);
  const menu: { g: string; items: [Tab, string][] }[] = [
    { g: "1 · Projeto e cálculo", items: [["aovivo", `Recebidos ao vivo (${intake.length})`], ["projetos", "Projetos"], ["funil", "Funil 24 camadas"], ["eixos", "3 Eixos"]] },
    { g: "2 · Auditoria e correção", items: [["fix", `Fix Center (${fix.failures.length})`], ["historico", "Histórico"], ["logs", "Logs por camada"]] },
    { g: "3 · Integração", items: [["nuvem", "Nuvem central"], ["ponte", "Ponte Python"]] },
    { g: "4 · Referência", items: [["conteudo", "Conteúdo técnico"], ["opensource", "Open Source"], ["atualizacoes", "Atualizações"]] },
  ];
  const pick = (k: Tab) => { setTab(k); document.getElementById("rg-conteudo")?.scrollIntoView({ behavior: "smooth", block: "start" }); };

  return (
    <div className="mx-auto max-w-5xl space-y-4 bg-background p-4 pb-24 text-foreground">
      <header className="space-y-1">
        <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Integração Wikipedia StreetRace</p>
        <h1 className="font-display text-3xl">Engrenagem Real</h1>
        <p className="text-sm text-muted-foreground">A matemática calcula · a física modela · o jogo executa · a auditoria verifica · as evidências aprovam.</p>
      </header>
      <nav aria-label="Motores" className="flex flex-wrap gap-1 rounded-xl bg-secondary p-1">
        {projetos.map((x, i) => <button key={x.id} onClick={() => { setSel(i); setExec(null); }} className={`rounded-lg px-3 py-1.5 font-display text-sm ${i === sel ? "bg-primary text-primary-foreground" : "bg-background"}`}>{x.bike.name}{x.id.startsWith("player-") ? " · piloto" : ""}</button>)}
      </nav>
      <nav aria-label="Menu técnico" className="sticky top-[52px] z-20 grid gap-2 rounded-xl border border-border bg-background/95 p-2 backdrop-blur sm:grid-cols-2 lg:grid-cols-4">
        {menu.map((m) => (
          <div key={m.g} className="space-y-1">
            <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{m.g}</p>
            <div className="flex flex-wrap gap-1">
              {m.items.map(([k, l]) => <button key={k} onClick={() => pick(k)} className={`rounded-lg px-2.5 py-1 text-xs ${tab === k ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>{l}</button>)}
            </div>
          </div>
        ))}
      </nav>
      <div id="rg-conteudo" className="scroll-mt-48" />

      {tab === "aovivo" && (
        <section className="space-y-2">
          <p className="rounded-xl bg-secondary p-3 text-sm">Cada relatório ao vivo que a Wikipedia recebe (corrida ou dinamômetro) entra aqui sozinho e passa pelas 24 camadas com a moto e o acerto daquele momento. Toque para abrir no funil.</p>
          {!intake.length && <p className="rounded-xl border border-border p-4 text-sm">Nenhum relatório recebido ainda. Corra ou faça uma puxada no dinamômetro.</p>}
          {intake.map((it) => (
            <button key={it.reportId} onClick={() => openIntake(it)} className="block w-full rounded-xl border border-border p-3 text-left">
              <div className="flex flex-wrap items-center justify-between gap-2"><span className="font-display">{it.projeto.nome}</span><span className={`rounded px-2 py-0.5 text-xs ${TONE[it.estado === "REALGEAR VERIFIED" ? "APROVADA" : "BLOQUEADA"]}`}>{it.estado}</span></div>
              <div className="text-xs text-muted-foreground">{new Date(it.at).toLocaleString("pt-BR")} · {it.kind === "dinamometro" ? "dinamômetro" : "corrida"} · {it.estado !== "REALGEAR VERIFIED" ? `parado na camada ${it.atual}: ${it.motivo}` : it.motivo} · falhas novas no Fix Center: {it.novasFalhas}</div>
            </button>
          ))}
        </section>
      )}
      {tab === "nuvem" && <CloudTab />}
      {tab === "eixos" && <AxlesTab />}
      {tab === "fix" && <FixCenterTab fix={fix} setFix={setFix} />}

      {tab === "projetos" && (
        <section className="space-y-2">
          {projetos.map((x, i) => (
            <button key={x.id} onClick={() => setSel(i)} className={`block w-full rounded-xl border p-3 text-left ${i === sel ? "border-primary" : "border-border"}`}>
              <div className="font-display">{x.nome}</div>
              <div className="text-xs text-muted-foreground">{x.bike.name} · {x.setup.fuel} · CR {x.setup.compression}:1 · versão {x.versao} · {x.origem}</div>
            </button>
          ))}
          <button disabled={busy || !p} onClick={run} className="h-10 rounded-xl bg-primary px-4 font-display text-primary-foreground disabled:opacity-60">{busy ? "CALCULANDO…" : "ENVIAR AO FUNIL"}</button>
        </section>
      )}

      {tab === "funil" && (!exec || !p ? <p className="rounded-xl bg-secondary p-4 text-sm">Escolha um projeto e envie ao funil.</p> : (
        <section className="space-y-3">
          <div className="rounded-xl bg-secondary p-3 text-sm">
            <div className="font-display text-lg">{exec.estado}</div>
            <div className="font-mono text-xs">{exec.runId} · {p.nome}</div>
            {exec.estado !== "REALGEAR VERIFIED" && <div className="mt-1">Parado na camada <b>{exec.atual}</b>: {exec.camadas[exec.atual - 1]?.motivo}</div>}
          </div>
          {grupos.map(({ g, cs }) => (
            <div key={g} className="space-y-1">
              <h2 className="font-display text-sm text-muted-foreground">GRUPO {g}</h2>
              {cs.map((c) => <LayerRow key={c.n} c={c} open={open === c.n} toggle={() => setOpen(open === c.n ? null : c.n)} txt={() => reportTxt(p, exec, c)} />)}
            </div>
          ))}
        </section>
      ))}

      {tab === "historico" && (
        <section className="space-y-1">
          {!hist.length && <p className="rounded-xl bg-secondary p-4 text-sm">Nenhuma tentativa registrada.</p>}
          {[...hist].reverse().map((h) => (
            <div key={h.runId + h.at} className="rounded-lg bg-secondary p-2 font-mono text-xs">{new Date(h.at).toLocaleString("pt-BR")} · {h.projetoId} v{h.versao} · {h.estado} · camada {h.atual} · hash {h.hash}</div>
          ))}
        </section>
      )}

      {tab === "logs" && <LogsTab logs={logs} nomes={nomes} />}
      {tab === "ponte" && <BridgeTab projeto={p} />}
      {tab === "opensource" && <OpenSourceTab />}

      {tab === "conteudo" && <RealGearContentTab />}
      {tab === "atualizacoes" && (
        <section className="space-y-3">
          {[...RG_UPDATES].reverse().map((u) => (
            <article key={u.n} className="rounded-xl border border-border p-3">
              <div className="font-display">Atualização {u.n} — {u.titulo}</div>
              <div className="text-xs text-muted-foreground">{u.data}</div>
              <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">{u.itens.map((i) => <li key={i}>{i}</li>)}</ul>
            </article>
          ))}
        </section>
      )}
    </div>
  );
}

function LayerRow({ c, open, toggle, txt }: { c: Camada; open: boolean; toggle: () => void; txt: () => string }) {
  return (
    <div className="rounded-xl border border-border">
      <button onClick={toggle} className="flex w-full items-center gap-2 p-2 text-left text-sm">
        <span className="w-6 font-mono text-xs">{c.n}</span>
        <span className="flex-1">{c.nome}</span>
        <span className={`rounded px-2 py-0.5 text-[10px] font-bold ${TONE[c.conclusao]}`}>{c.conclusao}</span>
      </button>
      {open && (
        <div className="space-y-2 border-t border-border p-2">
          <p className="text-xs">{c.motivo} · Próxima ação: <b>{c.proxima}</b></p>
          <button onClick={() => navigator.clipboard.writeText(txt())} className="rounded-lg bg-secondary px-2 py-1 text-xs">Copiar relatório</button>
          <pre className="max-h-[60dvh] overflow-auto whitespace-pre-wrap rounded-lg bg-secondary p-2 font-mono text-[11px] leading-snug">{txt()}</pre>
        </div>
      )}
    </div>
  );
}
