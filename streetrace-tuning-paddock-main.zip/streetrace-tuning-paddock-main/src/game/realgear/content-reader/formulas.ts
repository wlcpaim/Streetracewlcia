// Regras de DETECÇÃO de fórmulas. Cada regra só vira "implementada" quando a expressão
// é encontrada no código-fonte (arquivo + linha). Regras sem ocorrência ficam como MODELO_TEORICO.
export interface Var { s: string; sig: string; un: string }
export interface FormulaRule {
  id: string; nome: string; latex: string; vars: Var[]; re: RegExp;
  hipoteses: string; limites: string; resultado: string;
}

export const FORMULA_RULES: FormulaRule[] = [
  { id: "f.omega", nome: "Velocidade angular", latex: "\\omega = \\frac{2\\pi n}{60}", re: /2\s*\*\s*Math\.PI[^;\n]*\/\s*60\b|Math\.PI\s*\/\s*30\b|Math\.PI\s*\*[^;\n]*\/\s*30\b/,
    vars: [{ s: "ω", sig: "velocidade angular", un: "rad/s" }, { s: "n", sig: "rotação", un: "rpm" }], hipoteses: "rotação uniforme no passo", limites: "não modela flutuação cíclica", resultado: "ω usado em potência/torque e inércia" },
  { id: "f.potencia", nome: "Potência mecânica / torque", latex: "P = T\\,\\omega \\;\\Leftrightarrow\\; T = P/\\omega", re: /\b\w*(torque|tq|Nm)\w*\s*\*\s*(omega|w)\b|\/\s*(omega|w)\b|\bT\s*=\s*P\s*\//i,
    vars: [{ s: "P", sig: "potência", un: "W" }, { s: "T", sig: "torque", un: "N·m" }, { s: "ω", sig: "velocidade angular", un: "rad/s" }], hipoteses: "regime quase estático", limites: "perdas internas tratadas por fatores do jogo", resultado: "torque/potência no virabrequim" },
  { id: "f.newton", nome: "Segunda lei de Newton", latex: "a = \\frac{F}{m}", re: /\b(acc|accel|a)\s*=\s*\(?[^;\n]*\)?\s*\/\s*\(?\s*(mass|m|kg|massa|totalKg|mTot)\w*\b/i,
    vars: [{ s: "a", sig: "aceleração", un: "m/s²" }, { s: "F", sig: "força resultante", un: "N" }, { s: "m", sig: "massa", un: "kg" }], hipoteses: "corpo rígido, movimento retilíneo", limites: "sem inércia rotativa explícita salvo onde indicado", resultado: "aceleração longitudinal da moto" },
  { id: "f.cinetica", nome: "Energia cinética", latex: "E_c = \\tfrac12 m v^2", re: /0\.5\s*\*\s*\w*(m|mass|kg)\w*\s*\*\s*\w*v\w*\s*(\*\*\s*2|\*\s*\w*v\w*)/i,
    vars: [{ s: "E_c", sig: "energia cinética", un: "J" }, { s: "m", sig: "massa", un: "kg" }, { s: "v", sig: "velocidade", un: "m/s" }], hipoteses: "translação pura", limites: "sem energia rotacional", resultado: "energia do conjunto" },
  { id: "f.arrasto", nome: "Arrasto aerodinâmico", latex: "F_d = \\tfrac12 \\rho C_d A v^2", re: /0\.5\s*\*\s*\w*(rho|RHO|AIR|air)\w*[^;\n]*(cd|Cd|CdA|CDA|drag)/,
    vars: [{ s: "F_d", sig: "força de arrasto", un: "N" }, { s: "ρ", sig: "densidade do ar", un: "kg/m³" }, { s: "C_dA", sig: "área de arrasto", un: "m²" }, { s: "v", sig: "velocidade relativa ao ar", un: "m/s" }], hipoteses: "escoamento turbulento, Cd constante", limites: "CdA do jogo, sem túnel de vento", resultado: "resistência ao avanço; vácuo multiplica o arrasto" },
  { id: "f.rolamento", nome: "Resistência ao rolamento", latex: "F_r = C_{rr}\\, m\\, g", re: /crr\w*\s*\*[^;\n]*(9\.8|\bG\b|\bg\b|K\("phys\.g"\))|\*\s*\w*crr\w*/i,
    vars: [{ s: "C_rr", sig: "coeficiente de rolamento", un: "—" }, { s: "m", sig: "massa", un: "kg" }, { s: "g", sig: "gravidade", un: "m/s²" }], hipoteses: "pista plana", limites: "Crr do catálogo de pneus, não medido", resultado: "força resistiva do pneu" },
  { id: "f.area_pistao", nome: "Área do pistão / cilindrada", latex: "A = \\frac{\\pi D^2}{4},\\quad V_d = A\\,S", re: /Math\.PI\s*\/\s*4|Math\.PI\s*\*[^;\n]*\*\*\s*2\s*\/\s*4|Math\.PI\s*\*\s*\(?\w+\s*\/\s*2\)?\s*\*\*\s*2/,
    vars: [{ s: "D", sig: "diâmetro", un: "m" }, { s: "S", sig: "curso", un: "m" }, { s: "A", sig: "área", un: "m²" }, { s: "V_d", sig: "cilindrada", un: "m³" }], hipoteses: "cilindro perfeito", limites: "sem folgas", resultado: "área para força de gás e cilindrada" },
  { id: "f.pressao_tensao", nome: "Pressão / tensão normal", latex: "p = \\frac{F}{A},\\quad \\sigma = \\frac{F}{A}", re: /\/\s*\(?\s*(area|A|areaM2|aM2|Apist|areaPist|ap)\w*\s*\)?\s*[;,)\n]/,
    vars: [{ s: "F", sig: "força", un: "N" }, { s: "A", sig: "área", un: "m²" }, { s: "σ, p", sig: "tensão / pressão", un: "Pa" }], hipoteses: "distribuição uniforme", limites: "sem concentração de tensões", resultado: "tensão na biela / pressão no cilindro" },
  { id: "f.inercia_alternativa", nome: "Força inercial alternativa", latex: "F_i = m\\, r\\, \\omega^2 (\\cos\\theta + \\lambda \\cos 2\\theta)", re: /\*\s*(omega|w)\s*\*\*\s*2|\*\s*(omega|w)\s*\*\s*(omega|w)\b/,
    vars: [{ s: "m", sig: "massa alternativa", un: "kg" }, { s: "r", sig: "raio da manivela", un: "m" }, { s: "ω", sig: "velocidade angular", un: "rad/s" }, { s: "λ", sig: "r/L biela", un: "—" }], hipoteses: "biela rígida", limites: "massas alternativas estimadas", resultado: "tração/compressão na biela" },
  { id: "f.velocidade_pistao", nome: "Velocidade média do pistão", latex: "\\bar v_p = \\frac{2 S n}{60}", re: /2\s*\*\s*\w*(stroke|curso|S)\w*\s*\*\s*\w*rpm\w*\s*\/\s*60/i,
    vars: [{ s: "S", sig: "curso", un: "m" }, { s: "n", sig: "rotação", un: "rpm" }], hipoteses: "média por ciclo", limites: "—", resultado: "indicador de carga do conjunto alternativo" },
  { id: "f.calor", nome: "Energia térmica sensível", latex: "Q = m c \\Delta T", re: /\*\s*\w*(cp|Cp|specHeat|cal)\w*\s*\*\s*\(?\s*\w*(dT|deltaT|ΔT)\w*|\/\s*\(\s*\w*(m|mass|kg)\w*\s*\*\s*\w*(cp|Cp)\w*\s*\)/,
    vars: [{ s: "Q", sig: "calor", un: "J" }, { s: "m", sig: "massa", un: "kg" }, { s: "c", sig: "calor específico", un: "J/(kg·K)" }, { s: "ΔT", sig: "variação de temperatura", un: "K" }], hipoteses: "capacidade concentrada", limites: "nós térmicos simplificados", resultado: "temperatura de disco/pistão" },
  { id: "f.dilatacao", nome: "Dilatação térmica linear", latex: "\\Delta L = \\alpha L_0 \\Delta T", re: /\b\w*alpha\w*\s*\*[^;\n]*(dT|deltaT|\bT\b|temp)/i,
    vars: [{ s: "α", sig: "coeficiente de dilatação", un: "1/K" }, { s: "L_0", sig: "comprimento inicial", un: "m" }, { s: "ΔT", sig: "variação de temperatura", un: "K" }], hipoteses: "regime linear", limites: "α tabelado/estimado", resultado: "folga de válvula a quente" },
  { id: "f.wiebe", nome: "Função de Wiebe (fração queimada)", latex: "x_b = 1 - e^{-a\\left(\\frac{\\theta-\\theta_0}{\\Delta\\theta}\\right)^{m+1}}", re: /wiebe|1\s*-\s*Math\.exp\(\s*-\s*\w*a\w*\s*\*/i,
    vars: [{ s: "x_b", sig: "fração de massa queimada", un: "—" }, { s: "θ", sig: "ângulo do virabrequim", un: "°" }, { s: "a, m", sig: "parâmetros de forma", un: "—" }], hipoteses: "combustão de chama única", limites: "parâmetros estimados", resultado: "pressão no ciclo de 720°" },
  { id: "f.hoop", nome: "Tensão circunferencial (aro)", latex: "\\sigma_\\theta = \\frac{p\\, r}{t}", re: /hoop|\*\s*\w*(r|raio|radius)\w*\s*\/\s*\w*(t|thick|parede|wall)\w*\b/i,
    vars: [{ s: "p", sig: "pressão interna", un: "Pa" }, { s: "r", sig: "raio", un: "m" }, { s: "t", sig: "espessura da parede", un: "m" }], hipoteses: "parede fina", limites: "espessura do cilindro estimada", resultado: "tensão na camisa" },
  { id: "f.euler", nome: "Flambagem de Euler", latex: "P_{cr} = \\frac{\\pi^2 E I}{(K L)^2}", re: /Math\.PI\s*\*\*\s*2\s*\*\s*\w*E|Math\.PI\s*\*\s*Math\.PI\s*\*\s*\w*E|\b\w*(buckl|flamb)\w*\s*=/i,
    vars: [{ s: "E", sig: "módulo de elasticidade", un: "Pa" }, { s: "I", sig: "momento de inércia de área", un: "m⁴" }, { s: "L", sig: "comprimento", un: "m" }, { s: "K", sig: "fator de apoio", un: "—" }], hipoteses: "coluna esbelta", limites: "geometria da biela estimada", resultado: "limite de compressão da biela" },
  { id: "f.bsfc", nome: "Consumo específico (BSFC)", latex: "\\dot V = \\frac{P\\cdot BSFC}{\\rho_f\\cdot 3600}", re: /BSFC/,
    vars: [{ s: "P", sig: "potência", un: "kW" }, { s: "BSFC", sig: "consumo específico", un: "kg/kWh" }, { s: "ρ_f", sig: "densidade do combustível", un: "kg/L" }], hipoteses: "plena carga", limites: "BSFC fixo por combustível", resultado: "litros/s queimados no passo" },
  { id: "f.relacao", nome: "Relação de transmissão final", latex: "i_f = \\frac{Z_{coroa}}{Z_{pinhão}}", re: /\b\w*(rear|coroa)\w*\s*\/\s*\w*(front|pinhao)\w*|\b\w*(front|pinhao)\w*\s*\/\s*\w*(rear|coroa)\w*/i,
    vars: [{ s: "Z", sig: "número de dentes", un: "—" }], hipoteses: "sem escorregamento", limites: "relações primária/câmbio não oficiais", resultado: "escala velocidades por marcha (gearSpeeds)" },
  { id: "f.v_roda", nome: "Velocidade linear da roda", latex: "v = \\omega_r\\, r_{roda}", re: /\*\s*\w*(rWheel|wheelR|rRoda|raioRoda|tireR|rTire)\w*/i,
    vars: [{ s: "ω_r", sig: "velocidade angular da roda", un: "rad/s" }, { s: "r", sig: "raio efetivo", un: "m" }], hipoteses: "rolamento puro", limites: "raio do pneu constante", resultado: "velocidade da moto" },
  { id: "f.tracao", nome: "Limite de tração", latex: "F_{max} = \\mu N", re: /\b\w*(mu|grip)\w*\s*\*\s*\w*(normal|N|load|Nr|Fz)\w*\b/i,
    vars: [{ s: "μ", sig: "coeficiente de atrito pneu-solo", un: "—" }, { s: "N", sig: "carga normal", un: "N" }], hipoteses: "atrito de Coulomb", limites: "μ do jogo, não ensaiado", resultado: "patinação na largada (SPIN_GRIP)" },
  { id: "f.transferencia", nome: "Transferência de carga longitudinal", latex: "\\Delta N = \\frac{m a h}{L}", re: /(cgHeight|cgH|hCg|alturaCG)\w*\s*\)?\s*\/\s*[\w.]*(wheelbase|entreEixos)\w*/i,
    vars: [{ s: "h", sig: "altura do centro de massa", un: "m" }, { s: "L", sig: "entre-eixos", un: "m" }, { s: "a", sig: "aceleração", un: "m/s²" }], hipoteses: "regime permanente", limites: "h estimado", resultado: "carga na roda traseira" },
  { id: "f.estequiometria", nome: "Razão ar-combustível / lambda", latex: "\\lambda = \\frac{AFR}{AFR_{esteq}}", re: /\bafr\w*\s*\/\s*\w*(stoich|esteq|14\.7)|lambda\w*\s*=\s*[^;\n]*\/\s*\w*(stoich|esteq)/i,
    vars: [{ s: "AFR", sig: "razão ar/combustível", un: "kg/kg" }, { s: "AFR_esteq", sig: "estequiométrica", un: "kg/kg" }], hipoteses: "combustível de composição média", limites: "mistura como fator do jogo", resultado: "riqueza da mistura" },
  { id: "f.conducao", nome: "Condução de calor (Fourier)", latex: "\\dot Q = k A \\frac{\\Delta T}{L}", re: /\bk\w*\s*\*\s*\w*A\w*\s*\*\s*\(?\s*\w*(dT|deltaT)\w*\s*\)?\s*\/\s*\w*(L|thick|esp)\w*/i,
    vars: [{ s: "k", sig: "condutividade", un: "W/(m·K)" }, { s: "A", sig: "área", un: "m²" }, { s: "L", sig: "espessura", un: "m" }], hipoteses: "regime unidimensional", limites: "—", resultado: "fluxo de calor" },
];

/** Grandezas citadas na especificação de leitura que precisam ser procuradas. */
export const THEORY_ONLY_NOTE = "Regra de detecção sem ocorrência no código: modelo apenas teórico, não implementado.";
