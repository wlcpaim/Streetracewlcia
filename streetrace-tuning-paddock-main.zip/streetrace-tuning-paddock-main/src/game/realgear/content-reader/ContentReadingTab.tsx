// Wiki StreetRace › Leitura de Conteúdo. Somente leitura: roda o leitor sobre o código atual
// e compara com a base gravada em realgear/content/.
import { useEffect, useMemo, useState } from "react";
import type { Leitura, PartDoc, Prop } from "./reader";
import { liveSources, pushHistory, readContentFile, readHistory, readManifest, syncToRealGear, type HistEntry } from "./store";

const VIEWS = ["Leitura completa", "Por categoria", "Peça individual", "Mecânicas", "Fórmulas", "Relações", "Relatório", "Pendências", "Histórico", "Exportar / RealGear"] as const;
type View = (typeof VIEWS)[number];
const TONE: Record<string, string> = { CONFIRMADO_NO_CODIGO: "bg-secondary", CONFIRMADO_POR_FONTE_TECNICA: "bg-primary text-primary-foreground", IMPLEMENTADO_SEM_VALIDACAO_FISICA: "bg-accent text-accent-foreground", MODELO_TEORICO: "bg-muted text-muted-foreground", ESTIMATIVA: "bg-accent text-accent-foreground", DADO_NAO_IDENTIFICADO: "bg-muted text-muted-foreground", NAO_IMPLEMENTADO: "bg-muted text-muted-foreground", INCONSISTENTE: "bg-destructive text-destructive-foreground" };
const Badge = ({ e }: { e: string }) => <span className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${TONE[e] ?? "bg-secondary"}`}>{e}</span>;
const v = (p: Prop) => (p.valor === null ? "DADO NÃO IDENTIFICADO" : `${p.valor} ${p.unidade}`);
const card = "rounded-xl bg-secondary/60 p-3 text-sm";
function download(name: string, text: string, type = "application/json") { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([text], { type })); a.download = name; a.click(); URL.revokeObjectURL(a.href); }

export function ContentReadingTab() {
  const [view, setView] = useState<View>("Leitura completa");
  const [L, setL] = useState<Leitura | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [man, setMan] = useState<Awaited<ReturnType<typeof readManifest>>>(null);
  const [hist, setHist] = useState<HistEntry[]>([]);
  const [cat, setCat] = useState("motor");
  const [pid, setPid] = useState("");
  const [q, setQ] = useState("");
  const [synced, setSynced] = useState(false);
  const [diff, setDiff] = useState<{ iguais: number; diferentes: string[]; ausentes: string[]; novos: string[] } | null>(null);
  useEffect(() => { readManifest().then(setMan); setHist(readHistory()); }, []);
  const run = async () => {
    setBusy(true); setErr(null);
    try { const [{ readContent }, src] = await Promise.all([import("./reader"), liveSources()]); const r = readContent(src, new Date().toISOString()); setL(r);
      const t = await readContentFile("audits/leitura-atual.json");
      if (t) { const base = new Map((JSON.parse(t).arquivos as { caminho: string; hash: string }[]).map((a) => [a.caminho, a.hash])); const cur = new Map(r.arquivos.map((a) => [a.caminho, a.hash]));
        setDiff({ iguais: [...cur].filter(([k, h]) => base.get(k) === h).length, diferentes: [...cur].filter(([k, h]) => base.has(k) && base.get(k) !== h).map(([k]) => k), ausentes: [...base.keys()].filter((k) => !cur.has(k)), novos: [...cur.keys()].filter((k) => !base.has(k)) }); } setHist(pushHistory(r)); setPid(r.pecas[0]?.id ?? ""); }
    catch (e) { console.error("Leitura de Conteúdo falhou", e); setErr(e instanceof Error ? e.message : String(e)); } finally { setBusy(false); }
  };
  const cats = useMemo(() => (L ? [...new Set(L.pecas.map((p) => p.categoria))] : []), [L]);
  const part: PartDoc | undefined = L?.pecas.find((p) => p.id === pid);
  const filt = (s: string) => s.toLowerCase().includes(q.toLowerCase());

  return (
    <div className="space-y-3">
      <div className={card}>
        <div className="flex flex-wrap items-center gap-2">
          <button disabled={busy} onClick={run} className="h-9 rounded-xl bg-primary px-3 font-display text-sm text-primary-foreground disabled:opacity-60">{busy ? "LENDO O REPOSITÓRIO…" : "INICIAR LEITURA COMPLETA"}</button>
          <span className="text-xs text-muted-foreground">Somente leitura: nenhuma fórmula, peça ou corrida é alterada.</span>
        </div>
        <p className="mt-2 text-xs">Base gravada no RealGear: {man ? <>leitura {man.data} · código <code>{man.codigo_hash.slice(0, 12)}</code> · {man.arquivos_gerados.length} arquivos</> : "não encontrada"}</p>
        {L && man && <p className="text-xs">{L.codigo_hash === man.codigo_hash ? "✔ código atual idêntico ao da base gravada" : "⚠ código lido difere da base gravada"}</p>}
        {diff && <p className="text-xs">Arquivos iguais à base: {diff.iguais} · alterados: {diff.diferentes.length} · não lidos neste navegador: {diff.ausentes.length} · novos: {diff.novos.length}{[...diff.diferentes, ...diff.ausentes, ...diff.novos].length ? <> — {[...diff.diferentes.map((x) => `alterado ${x}`), ...diff.ausentes.map((x) => `não lido ${x}`), ...diff.novos.map((x) => `novo ${x}`)].slice(0, 8).join(" · ")}</> : null}</p>}
        {err && <p className="text-xs text-destructive">{err}</p>}
      </div>
      <nav className="flex flex-wrap gap-1">{VIEWS.map((x) => <button key={x} onClick={() => setView(x)} className={`h-8 rounded-lg px-2 text-xs ${view === x ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>{x}</button>)}</nav>
      {!L && view !== "Histórico" && <p className={card}>Rode a leitura para ver o conteúdo identificado.</p>}

      {L && view === "Leitura completa" && (
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">{Object.entries(L.totais).map(([k, n]) => <div key={k} className={card}><div className="text-xs text-muted-foreground">{k.replace(/_/g, " ")}</div><div className="font-display text-xl tabular-nums">{n}</div></div>)}</div>
      )}
      {L && view === "Por categoria" && (
        <div className="space-y-2">
          <div className="flex flex-wrap gap-1">{cats.map((c) => <button key={c} onClick={() => setCat(c)} className={`h-8 rounded-lg px-2 text-xs ${cat === c ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>{c} ({L.pecas.filter((p) => p.categoria === c).length})</button>)}</div>
          {L.pecas.filter((p) => p.categoria === cat).map((p) => <button key={p.id} onClick={() => { setPid(p.id); setView("Peça individual"); }} className={`${card} block w-full text-left`}><b>{p.nome}</b> <span className="text-muted-foreground">· {p.subcategoria} · {p.marca}</span> <Badge e={p.status} /></button>)}
        </div>
      )}
      {L && view === "Peça individual" && (
        <div className="space-y-2">
          <select value={pid} onChange={(e) => setPid(e.target.value)} className="h-10 w-full rounded-xl bg-secondary px-3 text-sm">{L.pecas.map((p) => <option key={p.id} value={p.id}>{p.categoria} · {p.nome}</option>)}</select>
          {part && <div className="space-y-2">
            <div className={card}><b>{part.nome}</b> <Badge e={part.status} /><div className="text-xs text-muted-foreground"><code>{part.id}</code> · {part.marca} · {part.spec}</div><div className="text-xs">Registro: <code>{part.arquivo_registro?.arquivo}:{part.arquivo_registro?.linha}</code> · motos: {part.motos_compativeis.join(", ")}</div></div>
            <div className={card}><b>Propriedades físicas</b>{Object.entries(part.propriedades_fisicas).map(([k, p]) => <div key={k} className="flex flex-wrap justify-between gap-2 border-t border-border py-1 text-xs"><span>{k}</span><span className="tabular-nums">{v(p)}</span><Badge e={p.estado} /></div>)}</div>
            <div className={card}><b>Parâmetros de jogo</b>{Object.entries(part.parametros_jogo).map(([k, p]) => <div key={k} className="flex flex-wrap justify-between gap-2 border-t border-border py-1 text-xs"><span>{k} = {v(p)}</span><span className="text-muted-foreground">usado {p.usada_no_calculo ? "sim" : "não"} · testado {p.testada ? "sim" : "não"} · ensaio físico não</span></div>)}</div>
            <div className={card}><b>Onde o motor lê esta peça</b>{part.efeitos_calculados.map((e) => <div key={e.campo} className="mt-1"><div className="text-xs font-semibold">{e.campo}</div>{e.refs.slice(0, 5).map((r, i) => <div key={i} className="truncate text-[11px] text-muted-foreground"><code>{r.arquivo}:{r.linha}</code> {r.funcao} — {r.trecho}</div>)}</div>)}</div>
            <div className={card}><b>Instalação</b>{part.instalacao.map((s) => <div key={s.etapa} className="flex justify-between gap-2 border-t border-border py-1 text-xs"><span>{s.etapa} — {s.nota}</span><Badge e={s.estado} /></div>)}</div>
            <div className={card}><b>Fórmulas nas funções que leem a peça:</b> {part.formulas.join(", ") || "nenhuma detectada"}<br /><b>Kit inclui:</b> {part.dependencias.join(", ") || "—"}<br /><b>Testes:</b> {part.testes_relacionados.join(", ") || "nenhum cita este id"}</div>
          </div>}
        </div>
      )}
      {L && view === "Mecânicas" && (
        <div className="space-y-2"><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="filtrar" className="h-9 w-full rounded-xl bg-secondary px-3 text-sm" />
          {L.mecanicas.filter((m) => filt(m.id)).map((m) => <details key={m.id} className={card}><summary className="cursor-pointer"><b>{m.nome}</b> <span className="text-xs text-muted-foreground">{m.categoria}/{m.subcategoria} · {m.funcoes.length} funções · {m.formulas.length} fórmulas · {m.testes.length} testes</span> <Badge e={m.estado} /></summary>
            <p className="mt-1 text-xs">{m.objetivo}</p><p className="text-xs"><code>{m.arquivo}</code></p>
            <ul className="mt-1 text-[11px] text-muted-foreground">{m.funcoes.map((f) => <li key={f.linha} className="truncate">L{f.linha} {f.assinatura}</li>)}</ul>
            <p className="text-xs">Depende de: {m.dependencias.join(", ") || "—"}</p><p className="text-xs">Testes: {m.testes.join(", ") || "nenhum"}</p></details>)}
        </div>
      )}
      {L && view === "Fórmulas" && (
        <div className="space-y-2">{[...L.formulas, ...L.modelos_teoricos].map((f) => <details key={f.id} className={card}><summary className="cursor-pointer"><b>{f.nome}</b> <code className="text-xs">{f.latex}</code> <Badge e={f.estado} /> <span className="text-xs">{f.ocorrencias.length} ocorr.</span></summary>
          <ul className="mt-1 text-xs">{f.variaveis.map((x) => <li key={x.s}>{x.s}: {x.sig} [{x.un}]</li>)}</ul><p className="text-xs">Hipóteses: {f.hipoteses} · Limitações: {f.limites}</p>
          {f.ocorrencias.slice(0, 12).map((o, i) => <div key={i} className="truncate text-[11px] text-muted-foreground"><code>{o.arquivo}:{o.linha}</code> {o.funcao} — {o.trecho}</div>)}</details>)}</div>
      )}
      {L && view === "Relações" && (
        <div className="space-y-2">
          {L.perguntas.map((p) => <div key={p.pergunta} className={card}><div className="flex justify-between gap-2"><b>{p.pergunta}</b><Badge e={p.resposta} /></div><p className="text-xs">{p.nota}</p>{p.refs.slice(0, 3).map((r, i) => <div key={i} className="truncate text-[11px] text-muted-foreground"><code>{r.arquivo}:{r.linha}</code> {r.trecho}</div>)}</div>)}
          <div className={card}><b>{L.relacoes.length} relações</b> (importa / lida-por / kit-inclui)<div className="max-h-80 overflow-auto text-[11px]">{L.relacoes.filter((r) => r.tipo !== "importa").slice(0, 300).map((r, i) => <div key={i}>{r.de} → <i>{r.tipo}</i> → {r.para}</div>)}</div></div>
        </div>
      )}
      {L && view === "Relatório" && (
        <div className="space-y-2">
          <div className={card}><b>Inconsistências ({L.inconsistencias.length})</b>{L.inconsistencias.map((i) => <div key={i.id} className="mt-1 text-xs"><Badge e="INCONSISTENTE" /> {i.descricao}{i.refs.map((r, k) => <div key={k} className="truncate text-[11px] text-muted-foreground"><code>{r.arquivo}:{r.linha}</code> {r.trecho}</div>)}</div>)}</div>
          <div className={card}><b>Limitações da leitura</b><ul className="list-disc pl-4 text-xs">{L.limitacoes.map((l) => <li key={l}>{l}</li>)}</ul></div>
          <div className={card}><b>Arquivos analisados: {L.arquivos.length}</b> · código <code>{L.codigo_hash.slice(0, 16)}</code></div>
        </div>
      )}
      {L && view === "Pendências" && (
        <div className={card}><b>{L.pendencias.length} dados não identificados</b><div className="max-h-[28rem] overflow-auto text-[11px]">{L.pendencias.slice(0, 600).map((p, i) => <div key={i} className="border-t border-border py-0.5">{p.id} · {p.campo} — {p.motivo}</div>)}</div>{L.pendencias.length > 600 && <p className="text-xs">Lista completa na exportação.</p>}</div>
      )}
      {view === "Histórico" && (
        <div className={card}><b>Leituras feitas neste navegador</b>{hist.length ? hist.slice().reverse().map((h) => <div key={h.data} className="border-t border-border py-1 text-xs">{h.data} · <code>{h.codigo_hash.slice(0, 12)}</code> · {h.totais["pecas"]} peças · {h.totais["formulas_localizadas"]} fórmulas · {h.totais["inconsistencias"]} inconsistências</div>) : <p className="text-xs">Nenhuma ainda.</p>}<p className="mt-2 text-xs text-muted-foreground">Versões anteriores da base ficam preservadas em realgear/content/history/.</p></div>
      )}
      {L && view === "Exportar / RealGear" && (
        <div className={`${card} flex flex-wrap gap-2`}>
          <button onClick={() => download(`leitura-${L.data}.json`, JSON.stringify(L, null, 2))} className="h-9 rounded-xl bg-background px-3 text-sm">Leitura completa (JSON)</button>
          <button onClick={async () => { const { buildFiles } = await import("./writer"); download("catalogo-completo.csv", buildFiles(L)["index/catalogo-completo.csv"]!, "text/csv"); }} className="h-9 rounded-xl bg-background px-3 text-sm">Índice (CSV)</button>
          <button onClick={async () => { const { reportMd } = await import("./writer"); download("relatorio.md", reportMd(L), "text/markdown"); }} className="h-9 rounded-xl bg-background px-3 text-sm">Relatório (MD)</button>
          <button onClick={() => { syncToRealGear(L); setSynced(true); }} className="h-9 rounded-xl bg-primary px-3 text-sm text-primary-foreground">Sincronizar com RealGear</button>
          {synced && <span className="text-xs">Enviado. Veja RealGear › Conteúdo técnico.</span>}
        </div>
      )}
    </div>
  );
}
