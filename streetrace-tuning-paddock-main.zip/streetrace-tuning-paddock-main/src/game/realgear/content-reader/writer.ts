// Converte uma Leitura em arquivos separados (JSON / Markdown / CSV) para realgear/content/.
import { sha256 } from "../sha256";
import type { Leitura, PartDoc, MechDoc, Prop, Ref } from "./reader";

const j = (x: unknown) => JSON.stringify(x, null, 2) + "\n";
const ref = (r: Ref | null) => (r ? `\`${r.arquivo}:${r.linha}\`${r.funcao ? ` (${r.funcao})` : ""}` : "—");
const val = (p: Prop) => (p.valor === null ? "DADO NÃO IDENTIFICADO" : `${p.valor} ${p.unidade}`.trim());
const csv = (v: unknown) => { const s = String(v ?? ""); return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
export const partPath = (p: PartDoc) => `categories/${p.categoria}/${p.subcategoria}/${p.id_interno}`;
export const mechPath = (m: MechDoc) => `mechanics/${m.categoria}/${m.subcategoria}/${m.nome}`;

function partMd(p: PartDoc, L: Leitura) {
  const f = L.formulas.filter((x) => p.formulas.includes(x.id));
  return [`# ${p.nome}`, "", `- ID: \`${p.id}\` · interno \`${p.id_interno}\``, `- Marca: ${p.marca} · Spec: ${p.spec}`, `- Categoria: ${p.categoria} / ${p.subcategoria} · tipo \`${p.tipo}\`${p.slot ? ` · slot \`${p.slot}\`` : ""}`,
    `- Original de fábrica: ${p.original_de_fabrica ? "sim" : "não"} · Motos: ${p.motos_compativeis.join(", ")}`, `- Registro: ${ref(p.arquivo_registro)} · Status: **${p.status}**`, "",
    "## Função", p.funcao, "", "## Propriedades físicas", "| Propriedade | Valor | Estado | Origem |", "|---|---|---|---|",
    ...Object.entries(p.propriedades_fisicas).map(([k, v]) => `| ${k} | ${val(v)} | ${v.estado} | ${v.origem} |`), "",
    "## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)", "| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |", "|---|---|---|---|---|---|",
    ...Object.entries(p.parametros_jogo).map(([k, v]) => `| ${k} | ${val(v)} | ${v.usada_no_calculo ? "sim" : "não"} | ${v.testada ? "sim" : "não"} | não | ${v.estado} |`), "",
    "## Efeitos calculados pelo motor (onde a peça é lida)", ...(p.efeitos_calculados.length ? p.efeitos_calculados.flatMap((e) => [`### ${e.campo}`, ...e.refs.map((r) => `- ${ref(r)} — \`${r.trecho}\``)]) : ["Nenhuma leitura encontrada no código de cálculo."]), "",
    "## Fórmulas nas mesmas funções", ...(f.length ? f.map((x) => `- **${x.nome}**: $${x.latex}$ — ${x.variaveis.map((v) => `${v.s} = ${v.sig} [${v.un}]`).join("; ")}`) : ["Nenhuma fórmula detectada nas funções que leem esta peça."]), "",
    "## Instalação na motocicleta", ...p.instalacao.map((s) => `- ${s.etapa}: **${s.estado}** — ${s.nota}${s.refs[0] ? ` (${ref(s.refs[0])})` : ""}`), "",
    "## Dependências / kit", p.dependencias.length ? p.dependencias.map((d) => `- \`${d}\``).join("\n") : "—", "",
    "## Mecânicas relacionadas", p.mecanicas_relacionadas.map((m) => `- \`${m}\``).join("\n") || "—", "",
    "## Testes relacionados", p.testes_relacionados.map((t) => `- \`${t}\``).join("\n") || "Nenhum teste cita este id.", "",
    "## Dados pendentes", p.dados_pendentes.map((d) => `- ${d}: DADO NÃO IDENTIFICADO`).join("\n") || "—", "", `> Leitura ${L.data} · código ${L.codigo_hash.slice(0, 16)}`, ""].join("\n");
}
function mechMd(m: MechDoc, L: Leitura) {
  const f = L.formulas.filter((x) => m.formulas.includes(x.id));
  return [`# Mecânica: ${m.nome}`, "", `- ID: \`${m.id}\` · ${m.categoria} / ${m.subcategoria}`, `- Arquivo: \`${m.arquivo}\` (${m.linhas} linhas, sha256 ${m.hash.slice(0, 16)})`, `- Estado: **${m.estado}**`, "",
    "## Objetivo (cabeçalho do código)", m.objetivo, "", "## Funções exportadas (saídas)", ...m.funcoes.map((x) => `- L${x.linha}: \`${x.assinatura}\``), "", "## Entradas tipadas", m.entradas.map((e) => `- ${e}`).join("\n") || "—", "",
    "## Fórmulas", ...(f.length ? f.flatMap((x) => [`### ${x.nome}`, `$$${x.latex}$$`, ...x.variaveis.map((v) => `- ${v.s}: ${v.sig} [${v.un}]`), `- Hipóteses: ${x.hipoteses}`, `- Limitações: ${x.limites}`, ...x.ocorrencias.filter((o) => o.arquivo === m.arquivo).map((o) => `- ${ref(o)} \`${o.trecho}\``)]) : ["Nenhuma fórmula detectada."]), "",
    "## Dependências", m.dependencias.map((d) => `- \`${d}\``).join("\n") || "—", "", "## Dependentes", m.dependentes.map((d) => `- \`${d}\``).join("\n") || "—", "",
    "## Testes existentes", m.testes.map((t) => `- \`${t}\``).join("\n") || "Nenhum teste importa este módulo.", "", "## Limitações", m.limitacoes.map((l) => `- ${l}`).join("\n") || "—", "",
    "> Testes de software passando não equivalem a validação física.", ""].join("\n");
}

export function buildFiles(L: Leitura): Record<string, string> {
  const F: Record<string, string> = {};
  F["catalog/pecas.json"] = j(L.pecas.map((p) => ({ id: p.id, id_interno: p.id_interno, nome: p.nome, categoria: p.categoria, subcategoria: p.subcategoria, status: p.status, arquivo: `${partPath(p)}.json` })));
  F["catalog/itens.json"] = j(L.itens); F["catalog/motocicletas.json"] = j(L.motocicletas);
  for (const p of L.pecas) { F[`${partPath(p)}.json`] = j(p); F[`${partPath(p)}.md`] = partMd(p, L); }
  for (const m of L.mecanicas) { F[`${mechPath(m)}.json`] = j(m); F[`${mechPath(m)}.md`] = mechMd(m, L); }
  const steps = L.pecas[0]?.instalacao ?? [];
  F["mechanics/instalacao/processo.md"] = ["# Processo de instalação de peças", "", ...steps.flatMap((s) => [`## ${s.etapa} — ${s.estado}`, s.nota, ...s.refs.map((r) => `- ${ref(r)} \`${r.trecho}\``), ""]), "## Perguntas de engenharia", ...L.perguntas.flatMap((q) => [`### ${q.pergunta}`, `**${q.resposta}** — ${q.nota}`, ...q.refs.map((r) => `- ${ref(r)} \`${r.trecho}\``), ""])].join("\n");
  F["mechanics/instalacao/processo.json"] = j({ etapas: steps, perguntas: L.perguntas });
  F["physics/formulas.json"] = j(L.formulas); F["physics/modelos-teoricos.json"] = j(L.modelos_teoricos); F["physics/constantes.json"] = j(L.constantes);
  const units = new Map<string, Set<string>>(); for (const f of [...L.formulas, ...L.modelos_teoricos]) for (const v of f.variaveis) (units.get(v.un) ?? units.set(v.un, new Set()).get(v.un)!).add(`${v.s} (${v.sig})`);
  F["physics/unidades.json"] = j(Object.fromEntries([...units].map(([u, s]) => [u, [...s]])));
  F["physics/modelos.md"] = ["# Modelos físicos", "", "## Implementados (encontrados no código, sem validação física)", ...L.formulas.flatMap((f) => [`### ${f.nome}`, `$$${f.latex}$$`, ...f.variaveis.map((v) => `- ${v.s}: ${v.sig} [${v.un}]`), `- Hipóteses: ${f.hipoteses} · Limitações: ${f.limites}`, `- Resultado: ${f.resultado}`, `- Ocorrências: ${f.ocorrencias.length}`, ...f.ocorrencias.slice(0, 10).map((o) => `  - ${ref(o)} \`${o.trecho}\``), ""]), "## Apenas teóricos (não encontrados)", ...L.modelos_teoricos.map((f) => `- ${f.nome}: $${f.latex}$ — NAO_IMPLEMENTADO`), ""].join("\n");
  F["relationships/dependencias.json"] = j(L.relacoes.filter((r) => r.tipo === "importa"));
  F["relationships/componentes.json"] = j(L.relacoes.filter((r) => r.tipo !== "importa"));
  F["audits/leitura-atual.json"] = j({ versao_leitor: L.versao_leitor, data: L.data, codigo_hash: L.codigo_hash, totais: L.totais, inconsistencias: L.inconsistencias, perguntas: L.perguntas, limitacoes: L.limitacoes, arquivos: L.arquivos });
  F["audits/pendencias.json"] = j(L.pendencias);
  F["audits/relatorio.md"] = reportMd(L);
  const rows = [["id", "tipo", "nome", "categoria", "subcategoria", "status", "arquivo_origem", "linha", "pendencias", "documento"]];
  for (const p of L.pecas) rows.push([p.id, "peca", p.nome, p.categoria, p.subcategoria, p.status, p.arquivo_registro?.arquivo ?? "", String(p.arquivo_registro?.linha ?? ""), String(p.dados_pendentes.length), `${partPath(p)}.md`]);
  for (const i of [...L.itens, ...L.motocicletas]) rows.push([i.id, i.tipo, i.nome, i.categoria, "", i.status, i.arquivo_registro?.arquivo ?? "", String(i.arquivo_registro?.linha ?? ""), String(i.dados_pendentes.length), "catalog/" + (i.tipo === "motocicleta" ? "motocicletas" : "itens") + ".json"]);
  for (const m of L.mecanicas) rows.push([m.id, "mecanica", m.nome, m.categoria, m.subcategoria, m.estado, m.arquivo, "1", "0", `${mechPath(m)}.md`]);
  for (const f of L.formulas) rows.push([f.id, "formula", f.nome, "physics", "", f.estado, f.ocorrencias[0]?.arquivo ?? "", String(f.ocorrencias[0]?.linha ?? ""), "0", "physics/formulas.json"]);
  F["index/catalogo-completo.csv"] = rows.map((r) => r.map(csv).join(",")).join("\n") + "\n";
  F["README.md"] = ["# RealGear · content", "", "Base técnica gerada pela **Leitura de Conteúdo** do Wiki StreetRace (somente leitura; não altera a física).", "", `Leitura ${L.data} · leitor ${L.versao_leitor} · código \`${L.codigo_hash}\``, "", "- `catalog/` peças, itens, motos", "- `categories/<categoria>/<subcategoria>/<peça>.{json,md}`", "- `mechanics/<categoria>/<subcategoria>/<módulo>.{json,md}` + `mechanics/instalacao/`", "- `physics/` fórmulas, constantes, unidades, modelos", "- `relationships/` dependências e componentes", "- `audits/` leitura atual, pendências, relatório", "- `index/catalogo-completo.csv`", "- `history/` leituras anteriores preservadas", "", "Estados: CONFIRMADO_NO_CODIGO, CONFIRMADO_POR_FONTE_TECNICA, IMPLEMENTADO_SEM_VALIDACAO_FISICA, MODELO_TEORICO, ESTIMATIVA, DADO_NAO_IDENTIFICADO, NAO_IMPLEMENTADO, INCONSISTENTE.", ""].join("\n");
  const files = Object.keys(F).sort().map((p) => ({ caminho: p, sha256: sha256(F[p]!) }));
  F["manifest.json"] = j({ formato: "realgear.content/1.0.0", versao_leitor: L.versao_leitor, data: L.data, codigo_hash: L.codigo_hash, totais: L.totais, arquivos_gerados: files });
  return F;
}

export function reportMd(L: Leitura) {
  const t = L.totais; const cats = [...new Set(L.pecas.map((p) => p.categoria))];
  const expected = ["motor", "transmissao", "admissao-escape", "combustivel", "chassi-suspensao", "freios", "eletrica", "pneus-rodas", "dinamica"];
  return ["# Relatório da Leitura de Conteúdo", "", `Data ${L.data} · código \`${L.codigo_hash.slice(0, 16)}\` · leitor ${L.versao_leitor}`, "", "| Total | Valor |", "|---|---|", ...Object.entries(t).map(([k, v]) => `| ${k} | ${v} |`), "",
    "## Categorias com peças", cats.map((c) => `- ${c}: ${L.pecas.filter((p) => p.categoria === c).length}`).join("\n"), "", "## Categorias sem nenhuma peça cadastrada", expected.filter((c) => !cats.includes(c)).map((c) => `- ${c}`).join("\n") || "—", "",
    "## Inconsistências", ...(L.inconsistencias.length ? L.inconsistencias.map((i) => `- **${i.id}** — ${i.descricao}${i.refs.map((r) => `\n  - ${ref(r)} \`${r.trecho}\``).join("")}`) : ["Nenhuma detectada pelas regras."]), "",
    "## Perguntas de instalação", ...L.perguntas.map((q) => `- ${q.pergunta} → **${q.resposta}**`), "", "## Limitações da leitura", ...L.limitacoes.map((l) => `- ${l}`), "",
    "Cobertura: todas as peças de PARTS_CATALOG, serviços, perfis de comando, combustíveis e motos foram lidos. Propriedades físicas de material não cadastradas ficam como DADO NÃO IDENTIFICADO; nenhuma validação física foi declarada.", ""].join("\n");
}
