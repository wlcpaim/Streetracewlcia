// Leitura de Conteúdo — análise SOMENTE LEITURA do repositório StreetRace.
// Entrada: mapa caminho → texto do código-fonte. Saída: inventário rastreável (peças, itens,
// motos, mecânicas, fórmulas, relações, pendências). Nada aqui altera Setup, física ou catálogo.
import { PARTS_CATALOG, MODEL_PARTS, SLOT_LABEL, CAM_FX, CAM_LABEL, type Part } from "../../parts";
import { TITAN_160, FACTOR_150, SERVICES, FUEL_DENSITY, BSFC, type BikeModel } from "../../physics";
import { COMB_INFO } from "../../fuelmix";
import { CONSTANTS } from "../../physics-registry/constants";
import { ENGINE_CATALOG } from "../../data/engine_catalog";
import { sha256 } from "../sha256";
import { FORMULA_RULES, THEORY_ONLY_NOTE } from "./formulas";

export const READER_VERSION = "1.0.0";
export type Conf = "CONFIRMADO_NO_CODIGO" | "CONFIRMADO_POR_FONTE_TECNICA" | "IMPLEMENTADO_SEM_VALIDACAO_FISICA" | "MODELO_TEORICO" | "ESTIMATIVA" | "DADO_NAO_IDENTIFICADO" | "NAO_IMPLEMENTADO" | "INCONSISTENTE";
export const NI = "DADO NÃO IDENTIFICADO";
export interface Ref { arquivo: string; linha: number; funcao: string | null; trecho: string }
export interface Prop { valor: number | string | null; unidade: string; estado: Conf; origem: string; cadastrada: boolean; usada_no_calculo: boolean; testada: boolean; ensaio_fisico: false }
export interface FormulaHit { id: string; nome: string; latex: string; variaveis: { s: string; sig: string; un: string }[]; hipoteses: string; limites: string; resultado: string; estado: Conf; ocorrencias: Ref[] }
export interface InstallStep { etapa: string; estado: Conf; refs: Ref[]; nota: string }
export interface PartDoc {
  id: string; id_interno: string; nome: string; marca: string; spec: string; categoria: string; subcategoria: string; tipo: string; slot: string | null;
  original_de_fabrica: boolean; motos_compativeis: string[]; arquivo_registro: Ref | null; status: Conf;
  propriedades_fisicas: Record<string, Prop>; parametros_jogo: Record<string, Prop>;
  funcao: string; efeitos_calculados: { campo: string; refs: Ref[] }[]; formulas: string[]; mecanicas_relacionadas: string[];
  dependencias: string[]; instalacao: InstallStep[]; testes_relacionados: string[]; dados_pendentes: string[];
}
export interface ItemDoc { id: string; nome: string; tipo: string; categoria: string; dados: Record<string, Prop>; arquivo_registro: Ref | null; status: Conf; dados_pendentes: string[] }
export interface MechDoc {
  id: string; nome: string; categoria: string; subcategoria: string; arquivo: string; hash: string; objetivo: string;
  funcoes: { nome: string; assinatura: string; linha: number }[]; entradas: string[]; saidas: string[]; formulas: string[]; dependencias: string[]; dependentes: string[];
  testes: string[]; estado: Conf; limitacoes: string[]; linhas: number;
}
export interface Question { pergunta: string; resposta: Conf; refs: Ref[]; nota: string }
export interface Inconsistencia { id: string; descricao: string; refs: Ref[]; estado: "INCONSISTENTE" }
export interface Leitura {
  versao_leitor: string; data: string; codigo_hash: string; arquivos: { caminho: string; hash: string; linhas: number }[];
  pecas: PartDoc[]; itens: ItemDoc[]; motocicletas: ItemDoc[]; mecanicas: MechDoc[]; formulas: FormulaHit[]; modelos_teoricos: FormulaHit[];
  constantes: { id: string; valor: number; unidade: string; origem: string; fonte: string; estado: Conf }[];
  relacoes: { de: string; para: string; tipo: string; ref: Ref | null }[]; perguntas: Question[]; inconsistencias: Inconsistencia[];
  pendencias: { id: string; campo: string; motivo: string }[]; limitacoes: string[]; totais: Record<string, number>;
}

type Src = Record<string, string>;
const isTest = (p: string) => /(^|\/)src\/test\/|\.test\.tsx?$/.test(p);
const isOwn = (p: string) => p.includes("/realgear/content-reader/") || p.includes("/realgear/content/") || p.endsWith("routeTree.gen.ts"); // gerado automaticamente, não é conteúdo
const isCalc = (p: string) => p.endsWith(".ts") && !isTest(p) && !isOwn(p) && !p.endsWith(".d.ts") && !p.includes("/screens/") && !p.includes("/ui/");

function lineIdx(text: string) { const r = [0]; for (let i = 0; i < text.length; i++) if (text[i] === "\n") r.push(i + 1); return r; }
const lineOf = (idx: number[], pos: number) => { let lo = 0, hi = idx.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (idx[m]! <= pos) lo = m; else hi = m - 1; } return lo + 1; };
function enclosing(lines: string[], ln: number) {
  for (let i = ln - 1; i >= 0 && i >= ln - 120; i--) {
    const m = /^\s*(?:export\s+)?(?:async\s+)?function\s+(\w+)|^\s*(?:export\s+)?const\s+(\w+)\s*=\s*(?:\([^)]*\)|\w+)\s*(?::[^=]+)?=>|^\s*(?:export\s+)?const\s+(\w+)\s*=\s*(?:async\s*)?\(/.exec(lines[i]!);
    if (m) return m[1] ?? m[2] ?? m[3] ?? null;
  }
  return null;
}
class Index {
  lines = new Map<string, string[]>(); idx = new Map<string, number[]>();
  constructor(public src: Src) { for (const [p, t] of Object.entries(src)) { this.lines.set(p, t.split("\n")); this.idx.set(p, lineIdx(t)); } }
  find(re: RegExp, filter: (p: string) => boolean = isCalc, max = 40): Ref[] {
    const out: Ref[] = []; const g = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
    for (const [p, t] of Object.entries(this.src)) {
      if (!filter(p)) continue; g.lastIndex = 0; let m: RegExpExecArray | null; let last = -1;
      while ((m = g.exec(t)) && out.length < max) {
        const ln = lineOf(this.idx.get(p)!, m.index); if (ln === last) { if (m[0].length === 0) g.lastIndex++; continue; } last = ln;
        const L = this.lines.get(p)!; const raw = L[ln - 1]!.trim();
        const col = m.index - this.idx.get(p)![ln - 1]!; const cmt = L[ln - 1]!.indexOf("//");
        if (/^\s*(\/\/|\*|\/\*)/.test(raw) || /^\s*(import|export\s+(interface|type))\b/.test(raw) || (cmt >= 0 && col > cmt)) { if (m[0].length === 0) g.lastIndex++; continue; }
        out.push({ arquivo: p, linha: ln, funcao: enclosing(L, ln), trecho: raw.slice(0, 220) });
        if (m[0].length === 0) g.lastIndex++;
      }
    }
    return out;
  }
  firstLine(p: string, needle: string): Ref | null { const L = this.lines.get(p); if (!L) return null; const i = L.findIndex((l) => l.includes(needle)); return i < 0 ? null : { arquivo: p, linha: i + 1, funcao: enclosing(L, i + 1), trecho: L[i]!.trim().slice(0, 220) }; }
}
const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// Classificação estrutural: slot/tipo do catálogo → categoria da documentação.
const CAT: Record<string, [string, string]> = {
  cilindro: ["motor", "cilindro"], pistao: ["motor", "pistao"], biela: ["motor", "biela"], molas: ["motor", "molas-de-valvula"], cabecote: ["motor", "cabecote"], comando: ["motor", "comando-de-valvulas"], valvula: ["motor", "valvulas"], oleo: ["motor", "lubrificacao"],
  embreagem: ["transmissao", "embreagem"], pinhao: ["transmissao", "pinhao"], coroa: ["transmissao", "coroa"], kit: ["transmissao", "kit-relacao"],
  tbi: ["admissao-escape", "corpo-de-borboleta"], escape: ["admissao-escape", "escapamento"], bico: ["combustivel", "injetores"], bomba: ["combustivel", "bomba"],
  modulo: ["eletrica", "ecu"], vela: ["eletrica", "ignicao"], cabo: ["eletrica", "ignicao"], bateria: ["eletrica", "bateria"], susp: ["chassi-suspensao", "suspensao"], pneu: ["pneus-rodas", "pneus"], roda: ["pneus-rodas", "rodas"],
};
const STRUCT = new Set(["motor", "transmissao", "pneus-rodas", "chassi-suspensao", "admissao-escape"]);
const FIELD_INFO: Record<string, [string, string]> = {
  kg: ["massa (delta vs original)", "kg"], hp: ["potência somada", "cv"], hpMul: ["multiplicador de potência", "—"], rpm: ["deslocamento de rpm", "rpm"], crr: ["coef. rolamento", "—"], grip: ["aderência", "—"],
  oilLife: ["vida do óleo", "km"], stress: ["carga mecânica adicionada", "pontos de risco"], relief: ["alívio de carga", "pontos de risco"], flow: ["vazão relativa", "—"], need: ["demanda de combustível", "—"],
  clutchNm: ["capacidade de torque da embreagem", "N·m"], front: ["dentes do pinhão", "dentes"], rear: ["dentes da coroa", "dentes"], cavas: ["cavas de válvula", "bool"], prog: ["ECU programável", "bool"], consumable: ["consumível", "bool"], cam: ["perfil de comando", "—"], fix: ["alívio por causa de falha", "pontos"],
};
const RACE = (p: string) => /src\/game\/(physics|enginephys|mechlimits|exhaust|fuelmix|usage)\.ts$/.test(p);
// Cada pergunta: "impl" = implementação que responde SIM no caminho de corrida; "evid" = onde o tema aparece.
const QUESTIONS: { q: string; impl: RegExp; evid: RegExp; sim: string; nao: string }[] = [
  { q: "Uma peça mais pesada altera o centro de massa?", impl: /cgHeight\w*\s*[:=][^;\n]*(kg|mass)/, evid: /cgHeight\w*|alturaCG/, sim: "altura do CG recalculada a partir da massa", nao: "CG é constante estimada (EST.cgHeightM); a massa da peça só altera a massa total" },
  { q: "Uma peça mais pesada altera a massa total na aceleração?", impl: /stats\([^)]*\)\.kg|\.kg\b/, evid: /\.kg\b/, sim: "massa total = stats().kg + piloto entra em a = F/m", nao: "massa da peça não entra no cálculo" },
  { q: "Uma relação de transmissão diferente altera a rotação da roda?", impl: /s\.rear\s*\/\s*s\.front|STOCK_REAR\s*\/\s*STOCK_FRONT/, evid: /gearSpeeds|\.rear\b/, sim: "relação coroa/pinhão escala gearTop (gearSpeeds) e a força na roda", nao: "relação não encontrada no passo de corrida" },
  { q: "Um pistão diferente altera a massa alternativa?", impl: /(pistao|piston)\w*[^;\n]*(kg|mass|massa)\w*\s*[:=]|\b(mRec\w*|recip\w*|mPist\w*)\s*[:=]/i, evid: /massaPistao|pistao/, sim: "massa alternativa muda com o pistão", nao: "massa do pistão não identificada (ficha massaPistao = DESCONHECIDO); pistão atua por hpMul/stress/relief" },
  { q: "Uma biela diferente altera os esforços inerciais?", impl: /slots\.biela|["']biela["'][^\n]*as Slot\[\]/, evid: /rodLoads|biela/, sim: "biela instalada entra em hpMul, alívio por causa (fix) e no limite admissível; massa da biela não identificada, então a força inercial usa geometria estimada", nao: "biela não altera esforços calculados" },
  { q: "Um comando de válvulas diferente altera admissão e escape?", impl: /CAM_FX\[/, evid: /\.cam\b/, sim: "CAM_FX desloca rpm de pico, multiplica potência e soma risco (efeito agregado, sem levante/duração)", nao: "comando não lido" },
  { q: "Um pneu diferente altera o raio efetivo e a relação final?", impl: /tireRadius\(/, evid: /tireRadius|tire/, sim: "tireRadius() deriva o raio da medida do pneu (powertrain/kinematics)", nao: "na corrida o raio do pneu não muda com a peça; o pneu altera crr e grip via tireOf()" },
  { q: "Uma alteração no sistema de freios altera a desaceleração calculada?", impl: /brakeTorque|decel\w*\s*=|frenag\w*\s*=/i, evid: /brake|freio/i, sim: "frenagem calculada na corrida", nao: "a corrida (arrancada) não calcula frenagem; freio existe só como componente de auditoria" },
];

function parseDims(text: string) {
  const d: Record<string, Prop> = {};
  const base = (v: number | string, un: string, o: string): Prop => ({ valor: v, unidade: un, estado: "CONFIRMADO_NO_CODIGO", origem: `texto do catálogo (${o}); não verificado por ensaio`, cadastrada: true, usada_no_calculo: false, testada: false, ensaio_fisico: false });
  const dia = /Ø\s*([\d]+(?:,\d+)?)/.exec(text) ?? /\b(\d{2}(?:,\d+)?)\s*mm\b/.exec(text); if (dia) d["diametro_mm"] = base(Number(dia[1]!.replace(",", ".")), "mm", "nome/spec");
  const cc = /(\d{3}(?:,\d+)?)\s*cc\b/.exec(text); if (cc) d["volume_cm3"] = base(Number(cc[1]!.replace(",", ".")), "cm³", "nome/spec");
  const liga = /\b(4032|2618|7075|6061|cromo-?molibd\w*|tit[âa]nio|inox|alum[íi]nio|a[çc]o|forjad\w*|nitretad\w*)/i.exec(text); if (liga) d["material"] = base(liga[1]!, "—", "nome/spec");
  return d;
}

export function readContent(src: Src, now: string): Leitura {
  const ix = new Index(src);
  const paths = Object.keys(src).filter((p) => !isOwn(p)).sort();
  const arquivos = paths.map((p) => ({ caminho: p, hash: sha256(src[p]!), linhas: ix.lines.get(p)!.length }));
  const codigo_hash = sha256(arquivos.map((a) => `${a.caminho}:${a.hash}`).join("\n"));
  const tests = paths.filter(isTest);
  const testsMentioning = (re: RegExp) => tests.filter((t) => re.test(src[t]!));
  const BIKES: BikeModel[] = [TITAN_160, FACTOR_150];
  const regFile = "src/game/parts.ts";

  // ---- fórmulas
  const formulas: FormulaHit[] = []; const modelos: FormulaHit[] = [];
  for (const r of FORMULA_RULES) {
    const occ = ix.find(r.re, isCalc, 30);
    const h: FormulaHit = { id: r.id, nome: r.nome, latex: r.latex, variaveis: r.vars, hipoteses: r.hipoteses, limites: r.limites, resultado: r.resultado, estado: occ.length ? "IMPLEMENTADO_SEM_VALIDACAO_FISICA" : "MODELO_TEORICO", ocorrencias: occ };
    (occ.length ? formulas : modelos).push(occ.length ? h : { ...h, limites: THEORY_ONLY_NOTE });
  }
  const formulasIn = (file: string) => formulas.filter((f) => f.ocorrencias.some((o) => o.arquivo === file)).map((f) => f.id);
  const formulasInFns = (refs: Ref[]) => { const keys = new Set(refs.map((r) => `${r.arquivo}#${r.funcao}`)); return formulas.filter((f) => f.ocorrencias.some((o) => keys.has(`${o.arquivo}#${o.funcao}`))).map((f) => f.id); };

  // ---- uso de campos (onde o motor lê cada propriedade de peça)
  const fieldUse: Record<string, Ref[]> = {}; const fieldTested: Record<string, boolean> = {};
  for (const f of Object.keys(FIELD_INFO)) { fieldUse[f] = ix.find(new RegExp(`\\.${f}\\b(?!\\s*:)`), (p) => isCalc(p) && p !== regFile, 25); fieldTested[f] = testsMentioning(new RegExp(`\\b${f}\\b`)).length > 0; }

  // ---- mecânicas = módulos de cálculo
  const calcFiles = paths.filter(isCalc);
  const importsOf = (p: string) => [...src[p]!.matchAll(/from\s+["']([^"']+)["']/g)].map((m) => m[1]!);
  const resolve = (from: string, spec: string) => { if (spec.startsWith("@/")) spec = "src/" + spec.slice(2); else if (spec.startsWith(".")) { const parts = from.split("/").slice(0, -1); for (const s of spec.split("/")) { if (s === "..") parts.pop(); else if (s !== ".") parts.push(s); } spec = parts.join("/"); } else return null; return [spec, spec + ".ts", spec + ".tsx", spec + "/index.ts"].find((c) => c in src) ?? null; };
  const deps = new Map(calcFiles.map((p) => [p, importsOf(p).map((s) => resolve(p, s)).filter((x): x is string => !!x && isCalc(x))]));
  const mechId = (p: string) => p.replace(/^src\/game\//, "").replace(/\.ts$/, "").replace(/\//g, ".");
  const mechCat = (p: string): [string, string] => {
    const b = p.replace(/^src\/game\//, "");
    const rules: [RegExp, string, string][] = [[/^(enginephys|mechlimits|overhaul22|engine-sound)/, "motor", "ciclo-e-limites"], [/^exhaust/, "admissao-escape", "escapamento"], [/^fuelmix|physics-registry/, "combustivel", "combustao"], [/^physics\.ts/, "dinamica", "simulacao"], [/^realgear\/kinematics|realgear\/axles/, "transmissao", "cinematica"], [/^(tuning|acerto|machining|workshop|component-swap)/, "mecanicas", "preparacao"], [/^(damage|scrap|pericia|rootcause|mechanic)/, "mecanicas", "falhas-e-manutencao"], [/^usage/, "mecanicas", "desgaste"], [/^(offline|records|level|missions)/, "mecanicas", "corrida"], [/^(store|economy|credit|jobrun|trampo|settings)/, "mecanicas", "economia-e-progresso"], [/^realgear|^bugfix|^cloud|^intel|^nexus/, "auditoria", b.split("/")[0]!], [/^data\//, "dados", "catalogos"]];
    for (const [re, c, s] of rules) if (re.test(b)) return [c, s];
    return ["mecanicas", "outros"];
  };
  const mecanicas: MechDoc[] = calcFiles.map((p) => {
    const L = ix.lines.get(p)!; const head = L.slice(0, 12).filter((l) => /^\s*(\/\/|\*|\/\*\*)/.test(l)).map((l) => l.replace(/^\s*(\/\/+|\/\*\*|\*\/|\*)\s?/, "").trim()).filter(Boolean).join(" ");
    const funcoes = L.flatMap((l, i) => { const m = /^export\s+(?:async\s+)?function\s+(\w+)\s*(\([^)]*\))?|^export\s+const\s+(\w+)\s*=\s*(\([^)]*\))\s*(?::[^=]+)?=>/.exec(l); return m ? [{ nome: (m[1] ?? m[3])!, assinatura: l.trim().slice(0, 200), linha: i + 1 }] : []; });
    const params = new Set(funcoes.flatMap((f) => [...f.assinatura.matchAll(/(\w+)\s*:\s*([A-Z]\w+)/g)].map((m) => `${m[1]}: ${m[2]}`)));
    const [categoria, subcategoria] = mechCat(p); const base = p.split("/").pop()!.replace(/\.ts$/, "");
    const tst = tests.filter((t) => new RegExp(`from\\s+["'][^"']*${esc(base)}["']`).test(src[t]!));
    const lim: string[] = []; if (/ESTIMADO|estimad/i.test(src[p]!)) lim.push("contém valores marcados como estimados"); if (/DESCONHECIDO|unk\(/.test(src[p]!)) lim.push("contém dados desconhecidos que bloqueiam cálculo");
    return { id: `mec.${mechId(p)}`, nome: base, categoria, subcategoria, arquivo: p, hash: sha256(src[p]!), objetivo: head || NI, funcoes, entradas: [...params], saidas: funcoes.map((f) => `${f.nome}()`), formulas: formulasIn(p), dependencias: (deps.get(p) ?? []).map((d) => `mec.${mechId(d)}`), dependentes: [], testes: tst, estado: tst.length ? "IMPLEMENTADO_SEM_VALIDACAO_FISICA" : "CONFIRMADO_NO_CODIGO", limitacoes: lim, linhas: L.length };
  });
  const byId = new Map(mecanicas.map((m) => [m.id, m])); for (const m of mecanicas) for (const d of m.dependencias) byId.get(d)?.dependentes.push(m.id);

  // ---- passos de instalação: só referências encontradas no código
  const stepRefs = (re: RegExp, max = 6) => ix.find(re, (p) => !isTest(p) && !isOwn(p), max);
  const INSTALL: [string, RegExp, string][] = [
    ["1. Identificação da peça", /partById\(|slotPart\(/, "partById/slotPart resolvem o id no catálogo"],
    ["2. Verificação de compatibilidade", /MODEL_PARTS|inShop\(/, "MODEL_PARTS restringe peças por moto; inShop filtra a loja"],
    ["3. Sistema mecânico afetado", /SLOT_LABEL|\bSLOTS\b/, "slot define o sistema substituído"],
    ["4. Remoção/substituição do original", /swapComponent|component-swap|-original/, "component-swap remove usinagem do componente trocado"],
    ["5. Inclusão das propriedades físicas", /slots\.\w+|slotPart\(/, "physics lê a peça do slot"],
    ["6. Atualização de massa e distribuição de peso", /\.kg\b|exhaustKg/, "massa entra em stats(); distribuição de peso: ver perguntas"],
    ["7. Atualização de geometria", /buildOf|machOf|ccOf\(/, "buildOf/machOf/ccOf derivam geometria"],
    ["8. Relações mecânicas", /gearCalc|gearSpeeds|kinematics/, "relação final e cadeia cinemática"],
    ["9. Recalcular física", /\bengine\(|engineCalc|\bstats\(|\bstress\(/, "engine()/stats()/stress()"],
    ["10. Sistemas dependentes", /mechStep\(|\bstep\(/, "step() + mechStep() por passo de simulação"],
    ["11. Resultados da motocicleta", /simulate\(|finishS|vmaxKmh/, "tempo, velocidade e quebra"],
  ];
  const installSteps: InstallStep[] = INSTALL.map(([etapa, re, nota]) => { const refs = stepRefs(re); return { etapa, refs, nota: refs.length ? nota : `${NI}: etapa não encontrada no código`, estado: refs.length ? "CONFIRMADO_NO_CODIGO" : "NAO_IMPLEMENTADO" }; });

  // ---- peças
  const compat = (id: string) => { const models = Object.entries(MODEL_PARTS).filter(([, ids]) => ids.includes(id)).map(([m]) => m); return models.length ? models : BIKES.map((b) => b.id); };
  const pecas: PartDoc[] = PARTS_CATALOG.map((p: Part) => {
    const [categoria, subcategoria] = CAT[p.kind] ?? ["outros", p.kind];
    const params: Record<string, Prop> = {}; const efeitos: PartDoc["efeitos_calculados"] = []; const pend: string[] = [];
    for (const [f, [, un]] of Object.entries(FIELD_INFO)) {
      const v = (p as unknown as Record<string, unknown>)[f]; if (v === undefined) continue;
      const used = fieldUse[f]!.length > 0;
      params[f] = { valor: typeof v === "object" ? JSON.stringify(v) : (v as number | string), unidade: un, estado: used ? "IMPLEMENTADO_SEM_VALIDACAO_FISICA" : "INCONSISTENTE", origem: `${regFile} · PARTS_CATALOG["${p.id}"].${f} (valor de jogo)`, cadastrada: true, usada_no_calculo: used, testada: fieldTested[f]!, ensaio_fisico: false };
      if (used) efeitos.push({ campo: f, refs: fieldUse[f]!.slice(0, 8) });
    }
    params["preco"] = { valor: p.price, unidade: "R$ (BASE_USD)", estado: "CONFIRMADO_NO_CODIGO", origem: `${regFile} · price × 1,5 em PARTS_CATALOG`, cadastrada: true, usada_no_calculo: false, testada: false, ensaio_fisico: false };
    const fis: Record<string, Prop> = parseDims(`${p.name} ${p.spec}`);
    if (p.kg !== undefined) fis["massa_delta_kg"] = { ...params["kg"]! };
    const need = ["massa_kg", "material", ...(STRUCT.has(categoria) ? ["comprimento_mm", "diametro_mm", "densidade_kg_m3", "modulo_elasticidade_Pa", "coef_poisson", "limite_escoamento_Pa", "resistencia_tracao_Pa", "condutividade_W_mK", "calor_especifico_J_kgK", "tolerancias", "tratamento_termico"] : [])];
    for (const k of need) if (!fis[k]) { fis[k] = { valor: null, unidade: "—", estado: "DADO_NAO_IDENTIFICADO", origem: NI, cadastrada: false, usada_no_calculo: false, testada: false, ensaio_fisico: false }; pend.push(k); }
    const slotRefs = p.kind in SLOT_LABEL ? ix.find(new RegExp(`slots\\.${p.kind}\\b|slotPart\\([^)]*["']${p.kind}["']|["']${p.kind}["'][^\\n]*as Slot\\[\\]`), (x) => isCalc(x), 15) : p.kind === "comando" ? fieldUse["cam"]! : p.kind === "pinhao" || p.kind === "coroa" ? [...fieldUse["front"]!, ...fieldUse["rear"]!].slice(0, 15) : [];
    if (slotRefs.length) efeitos.unshift({ campo: `slot:${p.kind}`, refs: slotRefs });
    const allRefs = efeitos.flatMap((e) => e.refs);
    const rel = [...new Set(allRefs.map((r) => `mec.${mechId(r.arquivo)}`))].filter((m) => byId.has(m));
    const depIds = p.bundle ? [p.bundle.bico, p.bundle.modulo, p.bundle.molas, p.bundle.bomba, p.bundle.biela, `pinhao-${p.bundle.front}`, `coroa-${p.bundle.rear}`].filter((x): x is string => !!x) : [];
    return {
      id: `${categoria}.${subcategoria}.${p.id}`, id_interno: p.id, nome: p.name, marca: p.brand, spec: p.spec, categoria, subcategoria, tipo: p.kind, slot: p.kind in SLOT_LABEL ? p.kind : null,
      original_de_fabrica: !!p.factory, motos_compativeis: compat(p.id), arquivo_registro: ix.firstLine(regFile, `"${p.id}"`) ?? ix.firstLine(regFile, p.kind === "pinhao" ? "const pinhao" : p.kind === "coroa" ? "const coroa" : p.id),
      status: efeitos.length ? "IMPLEMENTADO_SEM_VALIDACAO_FISICA" : "CONFIRMADO_NO_CODIGO", propriedades_fisicas: fis, parametros_jogo: params,
      funcao: `${SLOT_LABEL[p.kind as keyof typeof SLOT_LABEL] ?? p.kind}: ${p.spec}`, efeitos_calculados: efeitos, formulas: formulasInFns(allRefs), mecanicas_relacionadas: rel, dependencias: depIds,
      instalacao: installSteps, testes_relacionados: testsMentioning(new RegExp(`["']${esc(p.id)}["']`)), dados_pendentes: pend,
    };
  });

  // ---- itens (serviços, comandos, combustíveis) e motos
  const svcFile = "src/game/data/workshop_services.json";
  const P = (v: number | string | null, un: string, o: string, e: Conf = "CONFIRMADO_NO_CODIGO", used = true): Prop => ({ valor: v, unidade: un, estado: v === null ? "DADO_NAO_IDENTIFICADO" : e, origem: o, cadastrada: v !== null, usada_no_calculo: used && v !== null, testada: false, ensaio_fisico: false });
  const itens: ItemDoc[] = [
    ...SERVICES.map((s) => ({ id: `oficina.${s.group}.${s.id}`, nome: s.name, tipo: "servico-oficina", categoria: "mecanicas/preparacao", arquivo_registro: ix.firstLine(svcFile, `"${s.id}"`), status: "IMPLEMENTADO_SEM_VALIDACAO_FISICA" as Conf,
      dados: Object.fromEntries(Object.entries(s).filter(([k, v]) => !["id", "name", "group"].includes(k) && (typeof v === "number" || typeof v === "boolean" || typeof v === "string")).map(([k, v]) => [k, P(v as number, FIELD_INFO[k]?.[1] ?? "—", `${svcFile} · ${s.id}.${k} (valor de jogo)`, "IMPLEMENTADO_SEM_VALIDACAO_FISICA")])), dados_pendentes: [] })),
    ...Object.entries(CAM_FX).map(([c, fx]) => ({ id: `motor.comando.perfil-${c}`, nome: `Comando ${CAM_LABEL[c as keyof typeof CAM_LABEL]}`, tipo: "perfil-comando", categoria: "motor/comando-de-valvulas", arquivo_registro: ix.firstLine(regFile, "CAM_FX"), status: "IMPLEMENTADO_SEM_VALIDACAO_FISICA" as Conf,
      dados: { rpm: P(fx.rpm, "rpm", "parts.ts CAM_FX"), mul: P(fx.mul, "—", "parts.ts CAM_FX"), risk: P(fx.risk, "pontos", "parts.ts CAM_FX"), levante_mm: P(null, "mm", NI), duracao_graus: P(null, "°", NI) }, dados_pendentes: ["levante_mm", "duracao_graus"] })),
    ...Object.entries(COMB_INFO).map(([c, i]) => ({ id: `combustivel.combustiveis.${c}`, nome: i.label, tipo: "combustivel", categoria: "combustivel/combustiveis", arquivo_registro: ix.firstLine("src/game/fuelmix.ts", `${c}: {`), status: "IMPLEMENTADO_SEM_VALIDACAO_FISICA" as Conf,
      dados: { kmL: P(i.kmL, "km/L", "fuelmix.ts COMB_INFO"), octanagem: P(i.octane, "RON", "fuelmix.ts COMB_INFO (aproximado)", "ESTIMATIVA", false), composicao: P(null, "—", NI) }, dados_pendentes: ["composicao"] })),
  ];
  const motocicletas: ItemDoc[] = BIKES.map((b) => {
    const cat = ENGINE_CATALOG[b.id]; const dados: Record<string, Prop> = {};
    for (const k of ["cc", "hpGas", "hpEth", "rpmPeak", "torqueGas", "torqueEth", "rpmLimit", "dryWeight", "tank", "topSpeed", "gears", "stockExhaustKg"] as const) dados[k] = P(b[k], { cc: "cm³", hpGas: "cv", hpEth: "cv", rpmPeak: "rpm", torqueGas: "kgf·m", torqueEth: "kgf·m", rpmLimit: "rpm", dryWeight: "kg", tank: "L", topSpeed: "km/h", gears: "—", stockExhaustKg: "kg" }[k], `physics.ts ${b.id === "titan160" ? "TITAN_160" : "FACTOR_150"}.${k}`);
    dados["gearTop"] = P(b.gearTop.join(" / "), "km/h no corte por marcha", "physics.ts gearTop");
    const pend: string[] = [];
    for (const [k, v] of Object.entries(cat?.p ?? {})) { const e: Conf = v.valor === null ? "DADO_NAO_IDENTIFICADO" : v.origem === "OFICIAL" ? "CONFIRMADO_POR_FONTE_TECNICA" : v.origem === "CALCULADO" ? "IMPLEMENTADO_SEM_VALIDACAO_FISICA" : v.origem === "ESTIMADO" ? "ESTIMATIVA" : "CONFIRMADO_NO_CODIGO"; dados[`ficha.${k}`] = { valor: v.valor, unidade: v.unidade, estado: e, origem: `engine_catalog.ts · ${v.fonte || NI}`, cadastrada: v.valor !== null, usada_no_calculo: false, testada: false, ensaio_fisico: false }; if (v.valor === null) pend.push(`ficha.${k}`); }
    return { id: `motocicleta.${b.id}`, nome: b.name, tipo: "motocicleta", categoria: "motocicletas", arquivo_registro: ix.firstLine("src/game/physics.ts", `id: "${b.id}"`), status: "IMPLEMENTADO_SEM_VALIDACAO_FISICA", dados, dados_pendentes: pend };
  });

  // ---- constantes
  const constantes = [
    ...Object.values(CONSTANTS).map((c) => ({ id: c.id, valor: c.valor, unidade: c.unidade, origem: c.origem, fonte: c.fonte, estado: (c.origem === "OFICIAL" ? "CONFIRMADO_POR_FONTE_TECNICA" : c.origem === "ESTIMADO" ? "ESTIMATIVA" : "IMPLEMENTADO_SEM_VALIDACAO_FISICA") as Conf })),
    ...Object.entries(FUEL_DENSITY).map(([f, v]) => ({ id: `physics.FUEL_DENSITY.${f}`, valor: v, unidade: "kg/L", origem: "CODIGO", fonte: "physics.ts FUEL_DENSITY", estado: "IMPLEMENTADO_SEM_VALIDACAO_FISICA" as Conf })),
    ...Object.entries(BSFC).map(([f, v]) => ({ id: `physics.BSFC.${f}`, valor: v, unidade: "kg/kWh", origem: "CODIGO", fonte: "physics.ts BSFC", estado: "IMPLEMENTADO_SEM_VALIDACAO_FISICA" as Conf })),
  ];

  // ---- relações
  const relacoes: Leitura["relacoes"] = [];
  for (const m of mecanicas) for (const d of m.dependencias) relacoes.push({ de: m.id, para: d, tipo: "importa", ref: null });
  for (const p of pecas) { for (const m of p.mecanicas_relacionadas) relacoes.push({ de: p.id, para: m, tipo: "lida-por", ref: p.efeitos_calculados[0]?.refs[0] ?? null }); for (const d of p.dependencias) { const t = pecas.find((x) => x.id_interno === d); if (t) relacoes.push({ de: p.id, para: t.id, tipo: "kit-inclui", ref: p.arquivo_registro }); } }

  // ---- perguntas de instalação
  const perguntas: Question[] = QUESTIONS.map((x) => { const impl = ix.find(x.impl, RACE, 6); const refs = impl.length ? impl : ix.find(x.evid, isCalc, 4); return { pergunta: x.q, resposta: impl.length ? "CONFIRMADO_NO_CODIGO" : "NAO_IMPLEMENTADO", refs, nota: impl.length ? x.sim : x.nao }; });

  // ---- inconsistências
  const inc: Inconsistencia[] = [];
  const ids = PARTS_CATALOG.map((p) => p.id); const dup = ids.filter((x, i) => ids.indexOf(x) !== i); if (dup.length) inc.push({ id: "inc.ids-duplicados", descricao: `IDs duplicados no catálogo: ${[...new Set(dup)].join(", ")}`, refs: [], estado: "INCONSISTENTE" });
  for (const p of PARTS_CATALOG) if (p.bundle) for (const d of [p.bundle.bico, p.bundle.modulo, p.bundle.molas, p.bundle.bomba, p.bundle.biela].filter(Boolean) as string[]) if (!ids.includes(d)) inc.push({ id: `inc.kit.${p.id}.${d}`, descricao: `Kit ${p.id} referencia peça inexistente ${d}`, refs: [], estado: "INCONSISTENTE" });
  for (const [m, list] of Object.entries(MODEL_PARTS)) for (const d of list) if (!ids.includes(d)) inc.push({ id: `inc.model.${m}.${d}`, descricao: `MODEL_PARTS[${m}] referencia peça inexistente ${d}`, refs: [], estado: "INCONSISTENTE" });
  for (const [f, refs] of Object.entries(fieldUse)) if (!refs.length && PARTS_CATALOG.some((p) => (p as unknown as Record<string, unknown>)[f] !== undefined)) inc.push({ id: `inc.campo-sem-uso.${f}`, descricao: `Campo de peça "${f}" está cadastrado mas não foi encontrado leitura dele no código de cálculo`, refs: [], estado: "INCONSISTENTE" });
  const strokes = ix.find(/\b\w*(stroke|curso)\w*\s*[:=]\s*(0\.0\d+|\d{2}(\.\d+)?)\b/i, isCalc, 20);
  const official = Object.values(ENGINE_CATALOG).map((e) => e.p["curso"]?.valor).filter((v): v is number => typeof v === "number");
  const bad = strokes.filter((r) => { const m = /(?:stroke|curso)\w*\s*[:=]\s*(0\.0\d+|\d{2}(?:\.\d+)?)/i.exec(r.trecho); if (!m) return false; const v = Number(m[1]); const mm = v < 1 ? v * 1000 : v; return !official.some((o) => Math.abs(o - mm) < 0.01); });
  if (bad.length) inc.push({ id: "inc.curso-literal", descricao: `Curso literal no código não corresponde à ficha por moto (${official.join(" / ")} mm)`, refs: bad, estado: "INCONSISTENTE" });

  const pendencias = [
    ...pecas.flatMap((p) => p.dados_pendentes.map((c) => ({ id: p.id, campo: c, motivo: NI }))),
    ...[...itens, ...motocicletas].flatMap((i) => i.dados_pendentes.map((c) => ({ id: i.id, campo: c, motivo: NI }))),
    ...installSteps.filter((s) => s.estado === "NAO_IMPLEMENTADO").map((s) => ({ id: "instalacao", campo: s.etapa, motivo: "etapa não implementada" })),
  ];
  const props = [...pecas.flatMap((p) => Object.values(p.propriedades_fisicas)), ...[...itens, ...motocicletas].flatMap((i) => Object.values(i.dados))];
  const totais = {
    pecas: pecas.length, itens: itens.length, motocicletas: motocicletas.length, mecanicas: mecanicas.length, mecanicas_implementadas: mecanicas.filter((m) => m.funcoes.length > 0).length, mecanicas_apenas_documentadas: mecanicas.filter((m) => m.funcoes.length === 0).length,
    formulas_localizadas: formulas.length, ocorrencias_de_formulas: formulas.reduce((a, f) => a + f.ocorrencias.length, 0), modelos_teoricos_nao_implementados: modelos.length, relacoes: relacoes.length,
    dados_fisicos_identificados: props.filter((p) => p.valor !== null).length, dados_ausentes: props.filter((p) => p.valor === null).length, inconsistencias: inc.length, arquivos_analisados: arquivos.length, pendencias: pendencias.length,
  };
  return {
    versao_leitor: READER_VERSION, data: now, codigo_hash, arquivos, pecas, itens, motocicletas, mecanicas, formulas, modelos_teoricos: modelos, constantes, relacoes, perguntas, inconsistencias: inc, pendencias,
    limitacoes: [
      "Detecção de fórmulas por padrões textuais: uma expressão escrita de forma não prevista pode não ser localizada (falso negativo) e um padrão genérico pode casar trechos não físicos (verificar o trecho citado).",
      "Atribuição de fórmula a peça: só quando a fórmula ocorre na mesma função que lê o campo/slot da peça.",
      "Valores de peças são parâmetros de jogo; nenhum foi validado por ensaio físico.",
      "Arquivos de interface (.tsx, ui/, screens/) entram no hash mas não na extração de mecânicas.",
    ],
    totais,
  };
}
