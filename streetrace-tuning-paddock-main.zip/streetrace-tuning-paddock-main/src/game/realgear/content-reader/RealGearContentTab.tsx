// RealGear › Conteúdo técnico: localiza e lê a base gravada em realgear/content/ (somente leitura).
import { useEffect, useState } from "react";
import { listContentFiles, readContentFile, readManifest, readSync, type HistEntry } from "./store";

export function RealGearContentTab() {
  const [man, setMan] = useState<Awaited<ReturnType<typeof readManifest>>>(null);
  const [sync, setSync] = useState<HistEntry | null>(null);
  const [file, setFile] = useState("audits/relatorio.md");
  const [text, setText] = useState("");
  const [q, setQ] = useState("");
  const files = listContentFiles();
  useEffect(() => { readManifest().then(setMan); setSync(readSync()); }, []);
  useEffect(() => { readContentFile(file).then((t) => setText(t ?? "arquivo não encontrado")); }, [file]);
  return (
    <div className="space-y-2 text-sm">
      <div className="rounded-xl bg-secondary/60 p-3">
        <b>Base técnica (realgear/content)</b>
        <p className="text-xs">{man ? <>Leitura {man.data} · código <code>{man.codigo_hash.slice(0, 12)}</code> · {man.totais["pecas"]} peças · {man.totais["mecanicas"]} mecânicas · {man.totais["formulas_localizadas"]} fórmulas · {files.length} arquivos</> : "manifest.json não encontrado"}</p>
        <p className="text-xs">Última sincronização do Wiki: {sync ? <>{sync.data} · <code>{sync.codigo_hash.slice(0, 12)}</code> {man && (sync.codigo_hash === man.codigo_hash ? "✔ igual à base" : "⚠ difere da base gravada")}</> : "nenhuma"}</p>
      </div>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="buscar arquivo (ex.: pistao, biela, formulas)" className="h-9 w-full rounded-xl bg-secondary px-3" />
      <select value={file} onChange={(e) => setFile(e.target.value)} className="h-10 w-full rounded-xl bg-secondary px-3">{files.filter((f) => f.includes(q)).slice(0, 500).map((f) => <option key={f}>{f}</option>)}</select>
      <pre className="max-h-[32rem] overflow-auto whitespace-pre-wrap rounded-xl bg-secondary/60 p-3 text-[11px]">{text}</pre>
    </div>
  );
}
