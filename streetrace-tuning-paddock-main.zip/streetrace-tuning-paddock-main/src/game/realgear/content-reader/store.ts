// Acesso do RealGear (e do Wiki) à base gerada em realgear/content/ — somente leitura.
import { cloudStore } from "@/game/cloud/cloud-store";
import type { Leitura } from "./reader";

const stored = import.meta.glob("../content/**/*.{json,md,csv}", { query: "?raw" }) as Record<string, () => Promise<unknown>>;
/** Módulo ?raw → texto (aceita default ou o próprio valor, conforme o empacotador). */
const rawText = (m: unknown): string | null => (typeof m === "string" ? m : m && typeof (m as { default?: unknown }).default === "string" ? (m as { default: string }).default : null);
const key = (rel: string) => `../content/${rel}`;
export const listContentFiles = () => Object.keys(stored).map((k) => k.replace("../content/", "")).sort();
export async function readContentFile(rel: string): Promise<string | null> { const f = stored[key(rel)]; return f ? rawText(await f()) : null; }
export async function readManifest(): Promise<{ data: string; codigo_hash: string; totais: Record<string, number>; arquivos_gerados: { caminho: string; sha256: string }[] } | null> {
  const t = await readContentFile("manifest.json"); return t ? JSON.parse(t) : null;
}
export async function readPartDoc(idInterno: string) {
  const idx = await readContentFile("catalog/pecas.json"); if (!idx) return null;
  const e = (JSON.parse(idx) as { id_interno: string; arquivo: string }[]).find((x) => x.id_interno === idInterno);
  const t = e ? await readContentFile(e.arquivo) : null; return t ? JSON.parse(t) : null;
}

/** Leitura ao vivo: lê o código-fonte atual do navegador e roda o mesmo leitor do script. */
export async function liveSources(): Promise<Record<string, string>> {
  const g = import.meta.glob("/src/**/*.{ts,tsx,json}", { query: "?raw" }) as Record<string, () => Promise<unknown>>;
  const out: Record<string, string> = {};
  await Promise.all(Object.entries(g).map(async ([k, f]) => { const rel = k.replace(/^\//, ""); if (rel.startsWith("src/game/realgear/content/")) return; const t = rawText(await f()); if (t !== null) out[rel] = t; }));
  return out;
}

export const HISTORY_KEY = "streetrace-content-reading-history";
export const SYNC_KEY = "realgear-content-sync";
export interface HistEntry { data: string; codigo_hash: string; totais: Record<string, number> }
export function readHistory(): HistEntry[] { try { return JSON.parse(cloudStore.getItem(HISTORY_KEY) ?? "[]"); } catch { return []; } }
export function pushHistory(L: Leitura) { const h = [...readHistory(), { data: L.data, codigo_hash: L.codigo_hash, totais: L.totais }].slice(-50); cloudStore.setItem(HISTORY_KEY, JSON.stringify(h)); return h; }
export function syncToRealGear(L: Leitura) { cloudStore.setItem(SYNC_KEY, JSON.stringify({ data: L.data, codigo_hash: L.codigo_hash, totais: L.totais })); }
export function readSync(): HistEntry | null { try { return JSON.parse(cloudStore.getItem(SYNC_KEY) ?? "null"); } catch { return null; } }
