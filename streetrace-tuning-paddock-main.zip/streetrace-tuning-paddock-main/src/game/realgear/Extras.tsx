import { useMemo, useState } from "react";
import { download, jsonBlob, layerFile, openSource, zipBlob, type LayerLog } from "./logs";

const btn = "rounded-lg bg-secondary px-3 py-1.5 text-xs";
export function OpenSourceTab() {
  const src = useMemo(openSource, []);
  const [f, setF] = useState(0);
  const zip = () => download(zipBlob({ "realgear-opensource.json": src, ...Object.fromEntries(src.arquivos.map((a) => [`json/${a.arquivo.split("/").pop()}.json`, a])) }), "realgear-opensource.zip");
  return (
    <section className="space-y-2">
      <p className="text-sm text-muted-foreground">Todo o código da Engrenagem Real em JSON ({src.arquivos.length} arquivos).</p>
      <div className="flex flex-wrap gap-1">
        <button className={btn} onClick={() => download(jsonBlob(src), "realgear-opensource.json")}>Baixar JSON</button>
        <button className={btn} onClick={zip}>Baixar ZIP</button>
        <button className={btn} onClick={() => navigator.clipboard.writeText(JSON.stringify(src, null, 2))}>Copiar JSON</button>
      </div>
      <div className="flex flex-wrap gap-1">{src.arquivos.map((a, i) => <button key={a.arquivo} onClick={() => setF(i)} className={`rounded px-2 py-1 font-mono text-[11px] ${i === f ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>{a.arquivo.split("/").pop()}</button>)}</div>
      <pre className="max-h-[65dvh] overflow-auto whitespace-pre-wrap rounded-lg bg-secondary p-2 font-mono text-[11px]">{JSON.stringify(src.arquivos[f], null, 2)}</pre>
    </section>
  );
}

export function LogsTab({ logs, nomes }: { logs: LayerLog[]; nomes: { n: number; nome: string }[] }) {
  const [sel, setSel] = useState<number | "todas">(1);
  const by = (n: number) => logs.filter((l) => l.camada.n === n);
  const shown = sel === "todas" ? logs : by(sel);
  const zipAll = () => download(zipBlob({ "resumo-geral.json": { total: logs.length, camadas: nomes.map((c) => ({ ...c, testes: by(c.n).length })) }, ...Object.fromEntries(nomes.map((c) => [`logs/${layerFile(c.n, c.nome)}`, by(c.n)])) }), "realgear-logs.zip");
  const one = sel === "todas" ? null : nomes.find((c) => c.n === sel);
  return (
    <section className="space-y-2">
      <div className="flex flex-wrap gap-1">
        <button className={btn} onClick={zipAll}>Baixar ZIP (todas as camadas)</button>
        {one && <button className={btn} onClick={() => download(zipBlob({ [layerFile(one.n, one.nome)]: shown }), `realgear-${layerFile(one.n, one.nome).replace(".json", ".zip")}`)}>Baixar ZIP desta camada</button>}
        <button className={btn} onClick={() => download(jsonBlob(shown), "realgear-logs.json")}>Baixar JSON</button>
      </div>
      <div className="grid gap-2 sm:grid-cols-[220px_1fr]">
        <nav className="flex max-h-[65dvh] flex-col gap-1 overflow-auto">
          <button onClick={() => setSel("todas")} className={`rounded px-2 py-1 text-left text-xs ${sel === "todas" ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>Todas ({logs.length})</button>
          {nomes.map((c) => <button key={c.n} onClick={() => setSel(c.n)} className={`rounded px-2 py-1 text-left text-xs ${sel === c.n ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>{c.n}. {c.nome} ({by(c.n).length})</button>)}
        </nav>
        <pre className="max-h-[65dvh] overflow-auto whitespace-pre-wrap rounded-lg bg-secondary p-2 font-mono text-[11px]">{shown.length ? JSON.stringify(shown, null, 2) : "Nenhum teste registrado. Envie um projeto ao funil."}</pre>
      </div>
    </section>
  );
}
