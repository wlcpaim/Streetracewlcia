# RealGear · content

Base técnica gerada pela **Leitura de Conteúdo** do Wiki StreetRace (somente leitura; não altera a física).

Leitura 2026-11-14T02:12:01.595Z · leitor 1.0.0 · código `dbeb9561e5ab30c9dcb39745c5e5d606424891a93f0c67a8c126737b0e94523c`

- `catalog/` peças, itens, motos
- `categories/<categoria>/<subcategoria>/<peça>.{json,md}`
- `mechanics/<categoria>/<subcategoria>/<módulo>.{json,md}` + `mechanics/instalacao/`
- `physics/` fórmulas, constantes, unidades, modelos
- `relationships/` dependências e componentes
- `audits/` leitura atual, pendências, relatório
- `index/catalogo-completo.csv`
- `history/` leituras anteriores preservadas

Estados: CONFIRMADO_NO_CODIGO, CONFIRMADO_POR_FONTE_TECNICA, IMPLEMENTADO_SEM_VALIDACAO_FISICA, MODELO_TEORICO, ESTIMATIVA, DADO_NAO_IDENTIFICADO, NAO_IMPLEMENTADO, INCONSISTENTE.
