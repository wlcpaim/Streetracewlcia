# TBI Ø 36 mm

- ID: `admissao-escape.corpo-de-borboleta.tbi-36` · interno `tbi-36`
- Marca: Power Racing · Spec: Alumínio usinado
- Categoria: admissao-escape / corpo-de-borboleta · tipo `tbi` · slot `tbi`
- Original de fábrica: não · Motos: titan160, factor150
- Registro: `src/game/parts.ts:244` · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
Corpo de borboleta: Alumínio usinado

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| diametro_mm | 36 mm | CONFIRMADO_NO_CODIGO | texto do catálogo (nome/spec); não verificado por ensaio |
| material | Alumínio — | CONFIRMADO_NO_CODIGO | texto do catálogo (nome/spec); não verificado por ensaio |
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| comprimento_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| densidade_kg_m3 | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| modulo_elasticidade_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| coef_poisson | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| limite_escoamento_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| resistencia_tracao_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| condutividade_W_mK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| calor_especifico_J_kgK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tolerancias | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tratamento_termico | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| stress | 4 pontos de risco | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| need | 0.15 — | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| preco | 3570 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:tbi
- `src/game/airflow.ts:27` (tbiBoreMm) — `const id = s.slots.tbi ?? "tbi-original";`
- `src/game/pericia.ts:77` (pericia) — `admissao: { filtroDeAr: s.airFilter, tbi: partById(s.slots.tbi) ?? s.slots.tbi, bico: partById(s.slots.bico) ?? s.slots.bico, bomba: partById(s.slots.bomba) ?? s.slots.bomba, modulo: partById(s.slots.modulo) ?? s.slots.m`
- `src/game/physics.ts:425` (mixtureCalc) — `const need = blendNeed(s) * (1 + (cyl.need ?? 0) + (slotPart(s.slots.tbi, "tbi").need ?? 0) + svc(s).reduce((n, x) => n + (x.need ?? 0), 0) + (s.airFilter === "caixa" ? AIRBOX.need : 0));`
- `src/game/physics.ts:721` (has) — `add("Cabeçote empenado", slotPart(s.slots.tbi, "tbi").stress ?? 0, "TBI maior: mais ar, mais calor no cabeçote");`
- `src/game/rootcause.ts:36` (fuelTree) — `const cyl = partById(s.slots.cilindro), tbi = partById(s.slots.tbi);`
- `src/nexus/aeic.ts:66` (D) — `D("D", "tbi", "Corpo de borboleta, borboleta e eixo", { when: "inj", peca: "tbi", usa: ["physics.ts#slots.tbi"], liga: ["coletor"] }),`
### stress
- `src/game/engineering/eng.ts:88` (measure) — `return { finishS: r.result.finishS, t0_100: r.result.t0_100, vmaxKmh: r.result.vmaxKmh, fuelL: r.result.fuelUsedL, stress: r.stress.value, quebrou: r.breakdown?.cause ?? (r.result.stalled ? "motor apagou" : null), hp: r.`
- `src/game/engineering/eng.ts:106` (pct) — `"Segurança": cat(m.stress < b.stress, m.stress === b.stress, b.stress ? pct(m.stress, b.stress) : 0),`
- `src/game/engineering/eng.ts:110` (pct) — `const txt = `Tempo ${m.finishS.toFixed(3)} s vs ${b.finishS.toFixed(3)} s (ganho ${g.toFixed(2)}%), stress ${m.stress.toFixed(1)} vs ${b.stress.toFixed(1)}.`;`
- `src/game/engineering/eng.ts:113` (pct) — `if (m.stress > b.stress + 10) return { classe: "BOA", categorias, justificativa: txt + " Carga acima do limite da EXCELENTE." };`
- `src/game/engineering/eng.ts:114` (pct) — `if (repetivel && m.stress <= b.stress) return { classe: "PERFEITA", categorias, justificativa: txt + " Repetição idêntica confirmada." };`
- `src/game/engineering/eng.ts:119` (byBest) — `export const byBest = (a: { classe: Classe; m: Metricas }, b: { classe: Classe; m: Metricas }) => RANK[b.classe] - RANK[a.classe] || (a.m.finishS ?? 1e9) - (b.m.finishS ?? 1e9) || a.m.stress - b.m.stress;`
- `src/game/engineering/eng.ts:204` (finalize) — ``Referência original: ${job.base?.finishS?.toFixed(3)} s · ${job.base?.vmaxKmh.toFixed(1)} km/h · stress ${job.base?.stress.toFixed(1)}`,`
- `src/game/mechlimits.ts:124` (clutchKgMul) — `const honed = !cyl.stress || has("brunimento");`
### need
- `src/game/autopecas/autopecas.ts:91` (vm) — `C.push({ nome: "Multiplicador do kit", formula: "P × hpMul", conta: `hpMul = ${p?.hpMul ?? 1}; demanda extra de combustível ${n((p?.need ?? 0) * 100, 0)} %`, resultado: `×${p?.hpMul ?? 1}`, origem: "JOGO" });`
- `src/game/enginephys.ts:243` (demandGs) — `const demandGs = (kW * bsfc) / 3600 * Math.max(1, m.need);`
- `src/game/kits/kit70.ts:51` (has) — `it.push({ grupo: "Alimentação", peca: "Bico injetor", id: s.slots.bico ?? null, classe: fc.lean > 0.02 ? "INCOMPATÍVEL" : fc.dutyPct > 85 ? "EXIGE ADAPTAÇÃO" : "COMPATÍVEL", motivo: `No pico (${e.rpmPeak} rpm) pede ${fc.`
- `src/game/nexus-update/registry.ts:31` (partFields) — `f.push(F.kg, F.hpMul, F.stress, F.relief, F.need);`
- `src/game/nexus-update/registry.ts:65` (categories) — `const svc: Item[] = SERVICES.map((s) => ({ key: `svc:${s.id}`, name: s.name, group: gl.get(s.group) ?? s.group, obj: s as unknown as Record<string, unknown>, fields: [F.name, F.price, F.hpMul, F.rpmPeak, F.need, F.stress`
- `src/game/part-sheet.ts:22` (P) — `form: [`V = π/4 × D² × curso = ${f(cc, 1)} cc`, `hp ∝ V × mul_peça (hpMul ${P("cilindro")?.hpMul ?? 1}) → hp motor ${f(e.hp, 2)} cv`, `demanda comb. +${Math.round((P("cilindro")?.need ?? 0) * 100)}% sobre o bico`],`
- `src/game/pericia.ts:78` (pericia) — `vazaoEMisturaPorGiro: rpms.map((rpm) => { const m = mixtureAt(s, rpm, e.rpmPeak); return { rpm, combustivelPedido: r3(m.need), combustivelEntregue: r3(m.supply), situacao: m.lean > 0.02 ? "pobre" : m.lean < -0.02 ? "rica`
- `src/game/physics.ts:422` (blendNeed) — `const blendNeed = (s: Setup) => blendFx(s, true).need;`

## Fórmulas nas mesmas funções
- **Potência mecânica / torque**: $P = T\,\omega \;\Leftrightarrow\; T = P/\omega$ — P = potência [W]; T = torque [N·m]; ω = velocidade angular [rad/s]
- **Segunda lei de Newton**: $a = \frac{F}{m}$ — a = aceleração [m/s²]; F = força resultante [N]; m = massa [kg]
- **Função de Wiebe (fração queimada)**: $x_b = 1 - e^{-a\left(\frac{\theta-\theta_0}{\Delta\theta}\right)^{m+1}}$ — x_b = fração de massa queimada [—]; θ = ângulo do virabrequim [°]; a, m = parâmetros de forma [—]
- **Flambagem de Euler**: $P_{cr} = \frac{\pi^2 E I}{(K L)^2}$ — E = módulo de elasticidade [Pa]; I = momento de inércia de área [m⁴]; L = comprimento [m]; K = fator de apoio [—]

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
—

## Mecânicas relacionadas
- `mec.airflow`
- `mec.pericia`
- `mec.physics`
- `mec.rootcause`
- `mec.src.nexus.aeic`
- `mec.engineering.eng`
- `mec.mechlimits`
- `mec.autopecas.autopecas`
- `mec.enginephys`
- `mec.kits.kit70`
- `mec.nexus-update.registry`
- `mec.part-sheet`

## Testes relacionados
- `src/test/fuel-air-physics.test.ts`
- `src/test/rootcause.test.ts`

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- comprimento_mm: DADO NÃO IDENTIFICADO
- densidade_kg_m3: DADO NÃO IDENTIFICADO
- modulo_elasticidade_Pa: DADO NÃO IDENTIFICADO
- coef_poisson: DADO NÃO IDENTIFICADO
- limite_escoamento_Pa: DADO NÃO IDENTIFICADO
- resistencia_tracao_Pa: DADO NÃO IDENTIFICADO
- condutividade_W_mK: DADO NÃO IDENTIFICADO
- calor_especifico_J_kgK: DADO NÃO IDENTIFICADO
- tolerancias: DADO NÃO IDENTIFICADO
- tratamento_termico: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
