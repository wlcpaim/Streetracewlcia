# Escape inox Extreme HP

- ID: `admissao-escape.escapamento.escape-inox-completo` · interno `escape-inox-completo`
- Marca: GRS · Spec: Ø 33 mm · 800 mm
- Categoria: admissao-escape / escapamento · tipo `escape` · slot `escape`
- Original de fábrica: não · Motos: titan160, factor150
- Registro: `src/game/parts.ts:260` · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
Escapamento: Ø 33 mm · 800 mm

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| diametro_mm | 33 mm | CONFIRMADO_NO_CODIGO | texto do catálogo (nome/spec); não verificado por ensaio |
| material | inox — | CONFIRMADO_NO_CODIGO | texto do catálogo (nome/spec); não verificado por ensaio |
| massa_delta_kg | -3.9 kg | IMPLEMENTADO_SEM_VALIDACAO_FISICA | src/game/parts.ts · PARTS_CATALOG["escape-inox-completo"].kg (valor de jogo) |
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| comprimento_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| densidade_kg_m3 | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| modulo_elasticidade_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| coef_poisson | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| limite_escoamento_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| resistencia_tracao_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| condutividade_W_mK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| calor_especifico_J_kgK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tolerancias | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tratamento_termico | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| kg | -3.9 kg | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| stress | 3 pontos de risco | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| flow | 1.03 — | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| preco | 1635 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:escape
- `src/game/engine-sound.ts:113` (ecuVoice) — `const exhaust = typeof src === "string" ? src : src.slots.escape;`
- `src/game/kits/kit70.ts:54` (has) — `it.push({ grupo: "Escapamento", peca: "Escapamento", id: s.slots.escape ?? null, classe: has("escape", "escape-original") ? "EXIGE ADAPTAÇÃO" : "COMPATÍVEL", motivo: `Vazão/ressonância avaliadas por exhaust.ts para ${cc `
- `src/game/mechanic.ts:134` (pullAdvice) — `if (s.slots.escape === "escape-original" && e.hp > 17) return "O escape original tá estrangulando. O motor quer soltar mais gás.";`
- `src/game/missions.ts:65` (d) — `{ id: "m-escape", title: "Ronco novo", desc: "Monta um escapamento esportivo e confere no dinamômetro.", cash: 700, xp: 8, go: { label: "GARAGEM", scene: "garage" }, done: (p) => p.setup.slots.escape !== "escape-original`
- `src/game/pericia.ts:80` (pericia) — `escape: { id: s.slots.escape, peca: partById(s.slots.escape) ?? null },`
- `src/game/physics.ts:534` (exhaustId) — `export const exhaustId = (s: Setup) => (s.exhaust === "dore" && (s.slots.escape ?? "escape-original") === "escape-original" ? "escape-dore" : s.slots.escape);`
- `src/game/physics.ts:779` (tireCalc) — `for (const k of ["bateria", "susp", "pneu", "escape", "embreagem", "roda"] as Slot[]) kg += slotPart(s.slots[k], k).kg ?? 0;`
- `src/nexus/aeic.ts:79` (D) — `D("F", "escape", "Escapamento (curva, intermediário, silenciador, ponteira)", { peca: "escape", usa: ["physics.ts#slots.escape", "enginephys.ts#exhaustFlow"], liga: ["cabecote"] }),`
### kg
- `src/game/autopecas/analise.ts:21` (buildAnalise) — `const motos = BIKES.map((b) => { const e = engine(b, STOCK_SETUP), s = stats(b, STOCK_SETUP); return { id: b.id, nome: b.name, hp: s.hp, torque: s.torque, kg: s.kg, rpmPeak: e.rpmPeak, rpmLimit: e.rpmLimit, marchas: gear`
- `src/game/autopecas/analise.ts:40` (analiseTXT) — `for (const m of a.motos) L.push(`- ${m.nome}: ${m.hp} cv · ${m.torque} kgf·m · ${m.kg} kg · pico ${m.rpmPeak} rpm · corte ${m.rpmLimit} rpm · marchas ${m.marchas.join("/")} km/h · carga ${m.carga}`);`
- `src/game/autopecas/autopecas.ts:80` (w) — `C.push({ nome: "Relação peso/potência", formula: "kg/cv = massa seca / P", conta: `${n(st1.kg, 1)} / ${n(st1.hp, 1)}`, resultado: `${n(st1.kg / st1.hp, 2)} kg/cv`, origem: "CALCULADO" });`
- `src/game/autopecas/autopecas.ts:124` (lhv) — `const g = gearSpeeds(b, s1), r = tireRadius(b.tires) ?? NaN, i = s1.rear / s1.front, m = st1.kg + 75;`
- `src/game/autopecas/autopecas.ts:131` (lhv) — `C.push({ nome: "Massa com piloto", formula: "m = massa da moto + piloto 75 kg", conta: `${n(st1.kg, 1)} + 75`, resultado: `${n(m, 1)} kg`, origem: "CALCULADO" });`
- `src/game/engineering/dados/audit.ts:216` (assinatura) — `return { hp: e.hp, rpm: e.rpmLimit, kg: st.kg, top: gearSpeeds(b, s).at(-1) ?? 0, cap: clutchCapNm(s), duty: injectionAt(b, s, 8000, 1).duty, crr: t.crr, grip: t.grip, cc: ccOf(b, s) };`
- `src/game/engineering/dados/audit.ts:226` (ficha) — `{ nome: "Massa vs original", valor: p.kg ?? null, unidade: "kg", origem: p.kg != null ? "JOGO" : "AUSENTE", fonte: "parts.ts › kg" },`
- `src/game/engineering/dados/audit.ts:264` (igualStd) — `const declara = !igualStd && (p.hpMul != null || (p.flow != null && p.flow !== 1) || p.clutchNm != null || p.front != null || p.rear != null || !!p.cam || p.crr != null || p.grip != null || p.kg != null || p.cc != null |`
### stress
- `src/game/engineering/eng.ts:88` (measure) — `return { finishS: r.result.finishS, t0_100: r.result.t0_100, vmaxKmh: r.result.vmaxKmh, fuelL: r.result.fuelUsedL, stress: r.stress.value, quebrou: r.breakdown?.cause ?? (r.result.stalled ? "motor apagou" : null), hp: r.`
- `src/game/engineering/eng.ts:106` (pct) — `"Segurança": cat(m.stress < b.stress, m.stress === b.stress, b.stress ? pct(m.stress, b.stress) : 0),`
- `src/game/engineering/eng.ts:110` (pct) — `const txt = `Tempo ${m.finishS.toFixed(3)} s vs ${b.finishS.toFixed(3)} s (ganho ${g.toFixed(2)}%), stress ${m.stress.toFixed(1)} vs ${b.stress.toFixed(1)}.`;`
- `src/game/engineering/eng.ts:113` (pct) — `if (m.stress > b.stress + 10) return { classe: "BOA", categorias, justificativa: txt + " Carga acima do limite da EXCELENTE." };`
- `src/game/engineering/eng.ts:114` (pct) — `if (repetivel && m.stress <= b.stress) return { classe: "PERFEITA", categorias, justificativa: txt + " Repetição idêntica confirmada." };`
- `src/game/engineering/eng.ts:119` (byBest) — `export const byBest = (a: { classe: Classe; m: Metricas }, b: { classe: Classe; m: Metricas }) => RANK[b.classe] - RANK[a.classe] || (a.m.finishS ?? 1e9) - (b.m.finishS ?? 1e9) || a.m.stress - b.m.stress;`
- `src/game/engineering/eng.ts:204` (finalize) — ``Referência original: ${job.base?.finishS?.toFixed(3)} s · ${job.base?.vmaxKmh.toFixed(1)} km/h · stress ${job.base?.stress.toFixed(1)}`,`
- `src/game/mechlimits.ts:124` (clutchKgMul) — `const honed = !cyl.stress || has("brunimento");`
### flow
- `src/game/engineering/dados/audit.ts:232` (ficha) — `if (p.flow != null) dados.push({ nome: "Vazão relativa", valor: p.flow, unidade: "× original", origem: "JOGO", fonte: "parts.ts › flow" });`
- `src/game/engineering/dados/audit.ts:257` (rel) — `if (p.kind === "bico") checks.push(chk("vazao", "Vazão absoluta do bico", "INCONCLUSIVO", `vazão relativa ${fx(p.flow)}× sobre base ESTIMADA (EST.injFlowCcMin)`));`
- `src/game/engineering/dados/audit.ts:264` (igualStd) — `const declara = !igualStd && (p.hpMul != null || (p.flow != null && p.flow !== 1) || p.clutchNm != null || p.front != null || p.rear != null || !!p.cam || p.crr != null || p.grip != null || p.kg != null || p.cc != null |`
- `src/game/enginephys.ts:234` (flowOf) — `const flowOf = (id: string | undefined, k: "bico" | "bomba") => slotPart(id, k).flow ?? 1;`
- `src/game/intel/qa.ts:20` (experiments) — `const bico = PARTS_CATALOG_FREE.filter((p) => p.kind === "bico" && (p.flow ?? 1) > ((PARTS_CATALOG_FREE.find((x) => x.id === s.slots.bico)?.flow) ?? 1)).sort((a, z) => (a.flow ?? 1) - (z.flow ?? 1))[0];`
- `src/game/nexus-update/registry.ts:34` (partFields) — `if (p.flow !== undefined) f.push({ k: "flow", label: "Vazão", type: "number", formula: "fuelChain: vazão do bico/bomba" });`
- `src/game/overhaul22.ts:169` (mapAirGs) — `const bicoMul = slotPart(s.slots.bico, "bico").flow ?? 1;`
- `src/game/overhaul22.ts:172` (pumpGs) — `const pumpGs = ((EST.pumpLh * (slotPart(s.slots.bomba, "bomba").flow ?? 1)) * rho * 1000) / 3600;`

## Fórmulas nas mesmas funções
- **Velocidade angular**: $\omega = \frac{2\pi n}{60}$ — ω = velocidade angular [rad/s]; n = rotação [rpm]
- **Potência mecânica / torque**: $P = T\,\omega \;\Leftrightarrow\; T = P/\omega$ — P = potência [W]; T = torque [N·m]; ω = velocidade angular [rad/s]
- **Segunda lei de Newton**: $a = \frac{F}{m}$ — a = aceleração [m/s²]; F = força resultante [N]; m = massa [kg]
- **Flambagem de Euler**: $P_{cr} = \frac{\pi^2 E I}{(K L)^2}$ — E = módulo de elasticidade [Pa]; I = momento de inércia de área [m⁴]; L = comprimento [m]; K = fator de apoio [—]
- **Consumo específico (BSFC)**: $\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$ — P = potência [kW]; BSFC = consumo específico [kg/kWh]; ρ_f = densidade do combustível [kg/L]

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
—

## Mecânicas relacionadas
- `mec.engine-sound`
- `mec.kits.kit70`
- `mec.mechanic`
- `mec.missions`
- `mec.pericia`
- `mec.physics`
- `mec.src.nexus.aeic`
- `mec.autopecas.analise`
- `mec.autopecas.autopecas`
- `mec.engineering.dados.audit`
- `mec.engineering.eng`
- `mec.mechlimits`
- `mec.enginephys`
- `mec.intel.qa`
- `mec.nexus-update.registry`
- `mec.overhaul22`

## Testes relacionados
Nenhum teste cita este id.

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- comprimento_mm: DADO NÃO IDENTIFICADO
- densidade_kg_m3: DADO NÃO IDENTIFICADO
- modulo_elasticidade_Pa: DADO NÃO IDENTIFICADO
- coef_poisson: DADO NÃO IDENTIFICADO
- limite_escoamento_Pa: DADO NÃO IDENTIFICADO
- resistencia_tracao_Pa: DADO NÃO IDENTIFICADO
- condutividade_W_mK: DADO NÃO IDENTIFICADO
- calor_especifico_J_kgK: DADO NÃO IDENTIFICADO
- tolerancias: DADO NÃO IDENTIFICADO
- tratamento_termico: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
