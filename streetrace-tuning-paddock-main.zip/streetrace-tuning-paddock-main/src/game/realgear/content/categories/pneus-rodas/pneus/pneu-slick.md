# Slick 90/90-18 · 130/70-17

- ID: `pneus-rodas.pneus.pneu-slick` · interno `pneu-slick`
- Marca: Pirelli · Spec: Slick de arrancada
- Categoria: pneus-rodas / pneus · tipo `pneu` · slot `pneu`
- Original de fábrica: não · Motos: titan160, factor150
- Registro: `src/game/parts.ts:254` · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
Pneus: Slick de arrancada

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| massa_delta_kg | 0.9 kg | IMPLEMENTADO_SEM_VALIDACAO_FISICA | src/game/parts.ts · PARTS_CATALOG["pneu-slick"].kg (valor de jogo) |
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| material | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| comprimento_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| diametro_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| densidade_kg_m3 | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| modulo_elasticidade_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| coef_poisson | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| limite_escoamento_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| resistencia_tracao_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| condutividade_W_mK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| calor_especifico_J_kgK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tolerancias | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tratamento_termico | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| kg | 0.9 kg | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| crr | 1.12 — | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| grip | 1.42 — | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| preco | 2835 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:pneu
- `src/game/physics.ts:764` (tireCalc) — `const t = slotPart(s.slots.pneu, "pneu");`
- `src/game/physics.ts:779` (tireCalc) — `for (const k of ["bateria", "susp", "pneu", "escape", "embreagem", "roda"] as Slot[]) kg += slotPart(s.slots[k], k).kg ?? 0;`
- `src/game/physics.ts:862` (rearTireDynM) — `const tp = slotPart(s.slots.pneu, "pneu"), key = b.id + "|" + tp.id;`
- `src/game/physics.ts:966` (launchRpm) — `const mu = MU_ASPHALT * tireOf(s).grip * tempGrip(slotPart(s.slots.pneu, "pneu"), TIRE.ambC);`
- `src/game/physics.ts:1058` (tEng) — `const tp = slotPart(s.slots.pneu, "pneu"), rec = recPsiOf(b.id);`
- `src/game/preparador/preparador.ts:98` (tracao) — `const tracao = (b: BikeModel, s: Setup) => tractionLimit(MU_ASPHALT * (slotPart(s.slots.pneu, "pneu").grip ?? 1), stats(b, s, b.tank).kg);`
- `src/game/preparador/preparador.ts:104` (melhorPneu) — `const ok = opts.filter((t) => tracao(b, t) >= F).sort((a, z) => (partById(a.slots.pneu)?.price ?? 0) - (partById(z.slots.pneu)?.price ?? 0));`
- `src/game/stresscheck/diagnose.ts:16` (tabelaMarchas) — `const tp = slotPart(s.slots.pneu, "pneu"), r = rearTireRadiusM(tp.factory ? b.tires : tp.name) ?? rearTireRadiusM(b.tires);`
- `src/game/stresscheck/monitor.ts:75` (row) — `const tp = slotPart(s.slots.pneu, "pneu"), r = rearTireRadiusM(tp.factory ? b.tires : tp.name) ?? rearTireRadiusM(b.tires);`
- `src/game/stresscheck/monitor.ts:379` (add) — `const tire = slotPart(s.slots.pneu, "pneu");`
- `src/game/usage.ts:25` (tireWearMul) — `const t = slotPart(s.slots.pneu, "pneu");`
- `src/game/workshop.ts:222` (tireChange) — `const previous = p.setup.slots.pneu;`
### kg
- `src/game/autopecas/analise.ts:21` (buildAnalise) — `const motos = BIKES.map((b) => { const e = engine(b, STOCK_SETUP), s = stats(b, STOCK_SETUP); return { id: b.id, nome: b.name, hp: s.hp, torque: s.torque, kg: s.kg, rpmPeak: e.rpmPeak, rpmLimit: e.rpmLimit, marchas: gear`
- `src/game/autopecas/analise.ts:40` (analiseTXT) — `for (const m of a.motos) L.push(`- ${m.nome}: ${m.hp} cv · ${m.torque} kgf·m · ${m.kg} kg · pico ${m.rpmPeak} rpm · corte ${m.rpmLimit} rpm · marchas ${m.marchas.join("/")} km/h · carga ${m.carga}`);`
- `src/game/autopecas/autopecas.ts:80` (w) — `C.push({ nome: "Relação peso/potência", formula: "kg/cv = massa seca / P", conta: `${n(st1.kg, 1)} / ${n(st1.hp, 1)}`, resultado: `${n(st1.kg / st1.hp, 2)} kg/cv`, origem: "CALCULADO" });`
- `src/game/autopecas/autopecas.ts:124` (lhv) — `const g = gearSpeeds(b, s1), r = tireRadius(b.tires) ?? NaN, i = s1.rear / s1.front, m = st1.kg + 75;`
- `src/game/autopecas/autopecas.ts:131` (lhv) — `C.push({ nome: "Massa com piloto", formula: "m = massa da moto + piloto 75 kg", conta: `${n(st1.kg, 1)} + 75`, resultado: `${n(m, 1)} kg`, origem: "CALCULADO" });`
- `src/game/engineering/dados/audit.ts:216` (assinatura) — `return { hp: e.hp, rpm: e.rpmLimit, kg: st.kg, top: gearSpeeds(b, s).at(-1) ?? 0, cap: clutchCapNm(s), duty: injectionAt(b, s, 8000, 1).duty, crr: t.crr, grip: t.grip, cc: ccOf(b, s) };`
- `src/game/engineering/dados/audit.ts:226` (ficha) — `{ nome: "Massa vs original", valor: p.kg ?? null, unidade: "kg", origem: p.kg != null ? "JOGO" : "AUSENTE", fonte: "parts.ts › kg" },`
- `src/game/engineering/dados/audit.ts:264` (igualStd) — `const declara = !igualStd && (p.hpMul != null || (p.flow != null && p.flow !== 1) || p.clutchNm != null || p.front != null || p.rear != null || !!p.cam || p.crr != null || p.grip != null || p.kg != null || p.cc != null |`
### crr
- `src/game/engineering/dados/audit.ts:216` (assinatura) — `return { hp: e.hp, rpm: e.rpmLimit, kg: st.kg, top: gearSpeeds(b, s).at(-1) ?? 0, cap: clutchCapNm(s), duty: injectionAt(b, s, 8000, 1).duty, crr: t.crr, grip: t.grip, cc: ccOf(b, s) };`
- `src/game/engineering/dados/audit.ts:264` (igualStd) — `const declara = !igualStd && (p.hpMul != null || (p.flow != null && p.flow !== 1) || p.clutchNm != null || p.front != null || p.rear != null || !!p.cam || p.crr != null || p.grip != null || p.kg != null || p.cc != null |`
- `src/game/enginephys.ts:371` (vehicleAt) — `const roll = tire.crr * m * g;`
- `src/game/intel/bikemap.ts:27` (vChain) — `const roll = tire.crr * m * G, drag100 = 0.5 * RHO * CDA * (100 / 3.6) ** 2;`
- `src/game/intel/bikemap.ts:75` (vChain) — `{ nome: "Coef. de rolamento", formula: "crr(v) = 0,015 × composto × δ/δrec × [1 + 0,6·(v/33,3)²·(δ/δrec)^1,5] (parado)", conta: `${s.psi} psi · rec ${STOCK_PSI}`, valor: f(tire.crr, 5), origem: "CALCULADO" },`
- `src/game/intel/bikemap.ts:95` (vChain) — `{ nome: "Rolamento", formula: "F = crr × m × g", conta: `${f(tire.crr, 4)} × ${f(m, 1)} × 9,81`, valor: `${f(roll, 1)} N`, origem: "CALCULADO" },`
- `src/game/part-sheet.ts:54` (P) — `form: [`grip = composto × μ_pressão(${s.psi} psi, rec ${STOCK_PSI}) × (1 − 0,18×desgaste) = ${f(tire.grip, 4)}`, `crr = ${f(tire.crr, 5)}`, `tração = 0,62 × ${f(m, 1)} × 9,81 × 1,05 × grip = ${f(trac, 1)} N`],`
- `src/game/physics.ts:767` (tireCalc) — `return { crr: crrAt(s.psi, DEFAULT_REC_PSI, 0, t.crr ?? 1), grip: (t.grip ?? 1) * ts.muPsi * (1 - 0.18 * (s.tireWear ?? 0)), deflM: ts.deflM, muPsi: ts.muPsi };`
### grip
- `src/game/engineering/dados/audit.ts:216` (assinatura) — `return { hp: e.hp, rpm: e.rpmLimit, kg: st.kg, top: gearSpeeds(b, s).at(-1) ?? 0, cap: clutchCapNm(s), duty: injectionAt(b, s, 8000, 1).duty, crr: t.crr, grip: t.grip, cc: ccOf(b, s) };`
- `src/game/engineering/dados/audit.ts:264` (igualStd) — `const declara = !igualStd && (p.hpMul != null || (p.flow != null && p.flow !== 1) || p.clutchNm != null || p.front != null || p.rear != null || !!p.cam || p.crr != null || p.grip != null || p.kg != null || p.cc != null |`
- `src/game/enginephys.ts:377` (vehicleAt) — `Fx = Math.min(driveN, EST.mu * tire.grip * nRear);`
- `src/game/enginephys.ts:380` (vehicleAt) — `return { m, drag, roll, nRear, nFront: m * g - nRear, traction: EST.mu * tire.grip * nRear, Fx, slipLimited: driveN > Fx, a, wheelie: nRear >= m * g };`
- `src/game/intel/audit.ts:88` (wLim) — `found: `tração = 0,62×m×g×1,05×grip(${n(tire.grip, 3)}); patinando entrega fixo ×0,85`, expected: "força = μ(slip)×N, com slip = (v_roda − v)/v", formula: "κ = (ω_roda×r − v)/v; μ(κ) curva de pneu", diffAbs: null, diffPc`
- `src/game/intel/bikemap.ts:25` (vChain) — `const trac = 0.62 * m * G * 1.05 * tire.grip;`
- `src/game/intel/bikemap.ts:74` (vChain) — `{ nome: "Aderência", formula: "grip = composto × (1 + (28 − psi)×0,008) × (1 − 0,18×desgaste)", conta: `psi ${s.psi}, desgaste ${f((s.tireWear ?? 0) * 100, 0)}%`, valor: f(tire.grip, 4), origem: "CALCULADO" },`
- `src/game/intel/bikemap.ts:93` (vChain) — `{ nome: "Limite de tração", formula: "F_tração = 0,62 × m × g × 1,05 × grip", conta: `0,62 × ${f(m, 1)} × 9,81 × 1,05 × ${f(tire.grip, 3)}`, valor: `${f(trac, 0)} N`, origem: "CALCULADO" },`

## Fórmulas nas mesmas funções
- **Velocidade angular**: $\omega = \frac{2\pi n}{60}$ — ω = velocidade angular [rad/s]; n = rotação [rpm]
- **Potência mecânica / torque**: $P = T\,\omega \;\Leftrightarrow\; T = P/\omega$ — P = potência [W]; T = torque [N·m]; ω = velocidade angular [rad/s]
- **Segunda lei de Newton**: $a = \frac{F}{m}$ — a = aceleração [m/s²]; F = força resultante [N]; m = massa [kg]
- **Arrasto aerodinâmico**: $F_d = \tfrac12 \rho C_d A v^2$ — F_d = força de arrasto [N]; ρ = densidade do ar [kg/m³]; C_dA = área de arrasto [m²]; v = velocidade relativa ao ar [m/s]
- **Resistência ao rolamento**: $F_r = C_{rr}\, m\, g$ — C_rr = coeficiente de rolamento [—]; m = massa [kg]; g = gravidade [m/s²]
- **Pressão / tensão normal**: $p = \frac{F}{A},\quad \sigma = \frac{F}{A}$ — F = força [N]; A = área [m²]; σ, p = tensão / pressão [Pa]
- **Função de Wiebe (fração queimada)**: $x_b = 1 - e^{-a\left(\frac{\theta-\theta_0}{\Delta\theta}\right)^{m+1}}$ — x_b = fração de massa queimada [—]; θ = ângulo do virabrequim [°]; a, m = parâmetros de forma [—]
- **Consumo específico (BSFC)**: $\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$ — P = potência [kW]; BSFC = consumo específico [kg/kWh]; ρ_f = densidade do combustível [kg/L]
- **Relação de transmissão final**: $i_f = \frac{Z_{coroa}}{Z_{pinhão}}$ — Z = número de dentes [—]
- **Limite de tração**: $F_{max} = \mu N$ — μ = coeficiente de atrito pneu-solo [—]; N = carga normal [N]
- **Transferência de carga longitudinal**: $\Delta N = \frac{m a h}{L}$ — h = altura do centro de massa [m]; L = entre-eixos [m]; a = aceleração [m/s²]
- **Razão ar-combustível / lambda**: $\lambda = \frac{AFR}{AFR_{esteq}}$ — AFR = razão ar/combustível [kg/kg]; AFR_esteq = estequiométrica [kg/kg]

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
—

## Mecânicas relacionadas
- `mec.physics`
- `mec.preparador.preparador`
- `mec.stresscheck.diagnose`
- `mec.stresscheck.monitor`
- `mec.usage`
- `mec.workshop`
- `mec.autopecas.analise`
- `mec.autopecas.autopecas`
- `mec.engineering.dados.audit`
- `mec.enginephys`
- `mec.intel.bikemap`
- `mec.part-sheet`
- `mec.intel.audit`

## Testes relacionados
Nenhum teste cita este id.

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- material: DADO NÃO IDENTIFICADO
- comprimento_mm: DADO NÃO IDENTIFICADO
- diametro_mm: DADO NÃO IDENTIFICADO
- densidade_kg_m3: DADO NÃO IDENTIFICADO
- modulo_elasticidade_Pa: DADO NÃO IDENTIFICADO
- coef_poisson: DADO NÃO IDENTIFICADO
- limite_escoamento_Pa: DADO NÃO IDENTIFICADO
- resistencia_tracao_Pa: DADO NÃO IDENTIFICADO
- condutividade_W_mK: DADO NÃO IDENTIFICADO
- calor_especifico_J_kgK: DADO NÃO IDENTIFICADO
- tolerancias: DADO NÃO IDENTIFICADO
- tratamento_termico: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
