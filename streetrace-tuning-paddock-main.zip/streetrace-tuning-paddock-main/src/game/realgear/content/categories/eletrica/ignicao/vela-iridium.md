# Iridium IX CPR8EAIX-9

- ID: `eletrica.ignicao.vela-iridium` · interno `vela-iridium`
- Marca: NGK · Spec: Irídio Ø 0,6 mm
- Categoria: eletrica / ignicao · tipo `vela` · slot `vela`
- Original de fábrica: não · Motos: titan160, factor150
- Registro: `src/game/parts.ts:199` · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
Vela: Irídio Ø 0,6 mm

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| diametro_mm | 0.6 mm | CONFIRMADO_NO_CODIGO | texto do catálogo (nome/spec); não verificado por ensaio |
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| material | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| hp | 0.1 cv | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| preco | 134.9 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:vela
- `src/game/physics.ts:635` (engineCalc) — `hp += (slotPart(s.slots.vela, "vela").hp ?? 0) + (slotPart(s.slots.cabo, "cabo").hp ?? 0);`
- `src/nexus/aeic.ts:86` (D) — `D("H", "vela", "Vela de ignição (eletrodos)", { peca: "vela", usa: ["physics.ts#slots.vela"], liga: ["cabo", "cabecote"] }),`
### hp
- `src/game/admin-lab.ts:59` (runTest) — `pts.push({ t: r3(st.t), x: r3(st.x), kmh: r3(st.v * 3.6), rpm: Math.round(st.rpm), gear: st.gear, hp: st.shiftT > 0 ? 0 : r3(e.hp * shape * (1 - st.slip)), slip: r3(st.slip), spin: !!st.spin, shifting: st.shiftT > 0, fue`
- `src/game/agr/agr.ts:55` (enginePeaks) — `const h = e.hp * powerShape(rpm, e.rpmPeak, b, s) * mixFactor(s, rpm, e.rpmPeak) * exhaustShape(b, s, rpm, e.rpmPeak);`
- `src/game/agr/agr.ts:137` (analyse) — `faixas.push(`Torque máximo ${eng.tq} kgf·m a ${eng.tqRpm} rpm; potência máxima ${eng.hp} cv a ${eng.rpmPeak} rpm; corte ${eng.rpmLimit} rpm`);`
- `src/game/autopecas/analise.ts:21` (buildAnalise) — `const motos = BIKES.map((b) => { const e = engine(b, STOCK_SETUP), s = stats(b, STOCK_SETUP); return { id: b.id, nome: b.name, hp: s.hp, torque: s.torque, kg: s.kg, rpmPeak: e.rpmPeak, rpmLimit: e.rpmLimit, marchas: gear`
- `src/game/autopecas/analise.ts:40` (analiseTXT) — `for (const m of a.motos) L.push(`- ${m.nome}: ${m.hp} cv · ${m.torque} kgf·m · ${m.kg} kg · pico ${m.rpmPeak} rpm · corte ${m.rpmLimit} rpm · marchas ${m.marchas.join("/")} km/h · carga ${m.carga}`);`
- `src/game/autopecas/autopecas.ts:74` (dossier) — `C.push({ nome: "Potência no virabrequim", formula: "P = hp_base × Π(multiplicadores de cada peça)", conta: `fábrica ${n(st0.hp, 1)} cv → com a peça ${n(st1.hp, 1)} cv`, resultado: `${st1.hp - st0.hp >= 0 ? "+" : ""}${n((`
- `src/game/autopecas/autopecas.ts:80` (w) — `C.push({ nome: "Relação peso/potência", formula: "kg/cv = massa seca / P", conta: `${n(st1.kg, 1)} / ${n(st1.hp, 1)}`, resultado: `${n(st1.kg / st1.hp, 2)} kg/cv`, origem: "CALCULADO" });`
- `src/game/autopecas/autopecas.ts:119` (lhv) — `C.push({ nome: "Potência com tanque 100 %", formula: "P × blendFx(mistura).hpMul", conta: `${n(st0.hp, 1)} → ${n(st1.hp, 1)} cv`, resultado: `×${n(st1.hp / st0.hp, 3)}`, origem: "JOGO" });`

## Fórmulas nas mesmas funções
- **Velocidade angular**: $\omega = \frac{2\pi n}{60}$ — ω = velocidade angular [rad/s]; n = rotação [rpm]
- **Potência mecânica / torque**: $P = T\,\omega \;\Leftrightarrow\; T = P/\omega$ — P = potência [W]; T = torque [N·m]; ω = velocidade angular [rad/s]
- **Consumo específico (BSFC)**: $\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$ — P = potência [kW]; BSFC = consumo específico [kg/kWh]; ρ_f = densidade do combustível [kg/L]

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
—

## Mecânicas relacionadas
- `mec.physics`
- `mec.src.nexus.aeic`
- `mec.admin-lab`
- `mec.agr.agr`
- `mec.autopecas.analise`
- `mec.autopecas.autopecas`

## Testes relacionados
Nenhum teste cita este id.

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- material: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
