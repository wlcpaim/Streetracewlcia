# Race PnP

- ID: `eletrica.ecu.modulo-pnp-race` · interno `modulo-pnp-race`
- Marca: Rev Street · Spec: Corte livre + curva de ponto esportiva
- Categoria: eletrica / ecu · tipo `modulo` · slot `modulo`
- Original de fábrica: não · Motos: titan160, factor150
- Registro: `src/game/parts.ts:112` (coroa) · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
Módulo: Corte livre + curva de ponto esportiva

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| material | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| hpMul | 1.02 — | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| rpm | 1800 rpm | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| preco | 689.8 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:modulo
- `src/game/admin-lab.ts:110` (pick) — `const fl: Setup = { ...k220, compression: 13.5, cam: "a75", slots: { ...k220.slots, modulo: PARTS_CATALOG.find((p) => p.kind === "modulo" && /prog|athlon/i.test(p.id + p.name))?.id ?? k220.slots.modulo, tbi: pick("tbi", `
- `src/game/autopecas/autopecas.ts:41` (setupFor) — `if (p.bundle.modulo) s.slots.modulo = p.bundle.modulo;`
- `src/game/engine-sound.ts:67` (ecuVoice) — `const prog = !!slotPart(src.slots.modulo, "modulo").prog;`
- `src/game/ignition.ts:69` (effectiveModulo) — `const m = slotPart(s.slots.modulo, "modulo");`
- `src/game/ignition.ts:70` (effectiveModulo) — `return fitsBike(m, b.id) ? m : slotPart("modulo-original", "modulo");`
- `src/game/kits/kit70.ts:52` (has) — `it.push({ grupo: "Alimentação", peca: "Módulo / remapeamento", id: s.slots.modulo ?? null, classe: partById(s.slots.modulo ?? "")?.prog ? "COMPATÍVEL" : "EXIGE ADAPTAÇÃO", motivo: "Mistura por faixa só com módulo program`
- `src/game/mechlimits.ts:121` (clutchKgMul) — `const prog = !!slotPart(s.slots.modulo, "modulo").prog;`
- `src/game/mechlimits.ts:123` (clutchKgMul) — `const timingOver = mt != null && (prog || s.slots.modulo === SERVITEC_ID) ? Math.max(0, mt - timingOptimum(b, s)) : 0;`
- `src/game/missions.ts:66` (d) — `{ id: "m-modulo", title: "Mais giro", desc: "Monta um módulo de ignição de preparação.", cash: 800, xp: 8, go: { label: "GARAGEM", scene: "garage" }, done: (p) => p.setup.slots.modulo !== "modulo-original" },`
- `src/game/pericia.ts:30` (factors) — `if (JSON.stringify(s.ecu) !== JSON.stringify(S.ecu)) f.push({ id: "ecu", nome: "Mapa do módulo", revert: (x) => ({ ...x, ecu: S.ecu }), solo: () => ({ ...S, ecu: s.ecu, slots: { ...S.slots, modulo: s.slots.modulo } }) })`
- `src/game/pericia.ts:77` (pericia) — `admissao: { filtroDeAr: s.airFilter, tbi: partById(s.slots.tbi) ?? s.slots.tbi, bico: partById(s.slots.bico) ?? s.slots.bico, bomba: partById(s.slots.bomba) ?? s.slots.bomba, modulo: partById(s.slots.modulo) ?? s.slots.m`
- `src/game/physics.ts:426` (mixtureCalc) — `const mod = slotPart(s.slots.modulo, "modulo");`
- `src/game/physics.ts:459` (mapTiming) — `const mod = slotPart(s.slots.modulo, "modulo");`
- `src/game/physics.ts:463` (mapTiming) — `const isProg = memoS((s: Setup) => !!slotPart(s.slots.modulo, "modulo").prog);`
- `src/game/physics.ts:478` (mixtureAt) — `if (s.slots.modulo === SERVITEC_ID) supply = (m.supply * servitecPulse(rpm)) / servitecPulse(servitecMap().rpmPeak);`
### hpMul
- `src/game/autopecas/autopecas.ts:91` (vm) — `C.push({ nome: "Multiplicador do kit", formula: "P × hpMul", conta: `hpMul = ${p?.hpMul ?? 1}; demanda extra de combustível ${n((p?.need ?? 0) * 100, 0)} %`, resultado: `×${p?.hpMul ?? 1}`, origem: "JOGO" });`
- `src/game/autopecas/autopecas.ts:119` (lhv) — `C.push({ nome: "Potência com tanque 100 %", formula: "P × blendFx(mistura).hpMul", conta: `${n(st0.hp, 1)} → ${n(st1.hp, 1)} cv`, resultado: `×${n(st1.hp / st0.hp, 3)}`, origem: "JOGO" });`
- `src/game/engineering/dados/audit.ts:264` (igualStd) — `const declara = !igualStd && (p.hpMul != null || (p.flow != null && p.flow !== 1) || p.clutchNm != null || p.front != null || p.rear != null || !!p.cam || p.crr != null || p.grip != null || p.kg != null || p.cc != null |`
- `src/game/nexus-update/registry.ts:31` (partFields) — `f.push(F.kg, F.hpMul, F.stress, F.relief, F.need);`
- `src/game/nexus-update/registry.ts:65` (categories) — `const svc: Item[] = SERVICES.map((s) => ({ key: `svc:${s.id}`, name: s.name, group: gl.get(s.group) ?? s.group, obj: s as unknown as Record<string, unknown>, fields: [F.name, F.price, F.hpMul, F.rpmPeak, F.need, F.stress`
- `src/game/part-sheet.ts:22` (P) — `form: [`V = π/4 × D² × curso = ${f(cc, 1)} cc`, `hp ∝ V × mul_peça (hpMul ${P("cilindro")?.hpMul ?? 1}) → hp motor ${f(e.hp, 2)} cv`, `demanda comb. +${Math.round((P("cilindro")?.need ?? 0) * 100)}% sobre o bico`],`
- `src/game/physics.ts:643` (engineCalc) — `mul *= bfx.hpMul;`
- `src/game/physics.ts:645` (engineCalc) — `mul *= oil.hpMul ?? 1;`
### rpm
- `src/game/admin-lab.ts:47` (runTest) — `flow.tick(st.t, st.x, st.gear, st.rpm, st.shiftT > 0 ? 0 : 1 - st.slip * 0.5, DT);`
- `src/game/admin-lab.ts:51` (runTest) — `flow.events.push({ t: r3(st.t), x: r3(st.x), gear: st.gear, rpm: Math.round(st.rpm), evento: `QUEBROU: ${bp.cause} · ${bp.fisica}` });`
- `src/game/admin-lab.ts:58` (runTest) — `const shape = powerShape(st.rpm, e.rpmPeak, b, s) * mixFactor(s, st.rpm, e.rpmPeak) * exhaustShape(b, s, st.rpm, e.rpmPeak);`
- `src/game/admin-lab.ts:59` (runTest) — `pts.push({ t: r3(st.t), x: r3(st.x), kmh: r3(st.v * 3.6), rpm: Math.round(st.rpm), gear: st.gear, hp: st.shiftT > 0 ? 0 : r3(e.hp * shape * (1 - st.slip)), slip: r3(st.slip), spin: !!st.spin, shifting: st.shiftT > 0, fue`
- `src/game/admin-lab.ts:70` (runTest) — `pericia: broke ? pericia(b, s, distance, { label: meta.label, cause: broke.cause, atM: broke.atM, rpm: broke.rpm, gear: broke.gear, fuelUsedL: r3(b.tank - st.fuel), tail: pts.slice(-20), fluxo: flow.events, calorPistao: `
- `src/game/admin-lab.ts:78` (breakReport) — `cause, riskPct: Math.round(x.risk * 100), atM: r3(st.x), atS: r3(st.t), rpm: Math.round(st.rpm), gear: st.gear, kmh: r3(st.v * 3.6),`
- `src/game/admin-lab.ts:82` (breakReport) — `causaRaiz: causaRaiz(b, s, cause, st.rpm),`
- `src/game/agr/agr.ts:74` (runTrack) — `let prevGear = 1, prevRpm = st.rpm, prevV = 0;`

## Fórmulas nas mesmas funções
- **Potência mecânica / torque**: $P = T\,\omega \;\Leftrightarrow\; T = P/\omega$ — P = potência [W]; T = torque [N·m]; ω = velocidade angular [rad/s]
- **Segunda lei de Newton**: $a = \frac{F}{m}$ — a = aceleração [m/s²]; F = força resultante [N]; m = massa [kg]
- **Função de Wiebe (fração queimada)**: $x_b = 1 - e^{-a\left(\frac{\theta-\theta_0}{\Delta\theta}\right)^{m+1}}$ — x_b = fração de massa queimada [—]; θ = ângulo do virabrequim [°]; a, m = parâmetros de forma [—]
- **Flambagem de Euler**: $P_{cr} = \frac{\pi^2 E I}{(K L)^2}$ — E = módulo de elasticidade [Pa]; I = momento de inércia de área [m⁴]; L = comprimento [m]; K = fator de apoio [—]
- **Consumo específico (BSFC)**: $\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$ — P = potência [kW]; BSFC = consumo específico [kg/kWh]; ρ_f = densidade do combustível [kg/L]

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
—

## Mecânicas relacionadas
- `mec.admin-lab`
- `mec.autopecas.autopecas`
- `mec.engine-sound`
- `mec.ignition`
- `mec.kits.kit70`
- `mec.mechlimits`
- `mec.missions`
- `mec.pericia`
- `mec.physics`
- `mec.engineering.dados.audit`
- `mec.nexus-update.registry`
- `mec.part-sheet`
- `mec.agr.agr`

## Testes relacionados
- `src/test/physics-21.test.ts`

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- material: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
