# ECU PGM-FI

- ID: `eletrica.ecu.modulo-original` · interno `modulo-original`
- Marca: Honda · Spec: Corte 9.000 rpm
- Categoria: eletrica / ecu · tipo `modulo` · slot `modulo`
- Original de fábrica: sim · Motos: titan160, factor150
- Registro: `src/game/parts.ts:166` (coroa) · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
Módulo: Corte 9.000 rpm

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| material | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| preco | 0 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:modulo
- `src/game/admin-lab.ts:110` (pick) — `const fl: Setup = { ...k220, compression: 13.5, cam: "a75", slots: { ...k220.slots, modulo: PARTS_CATALOG.find((p) => p.kind === "modulo" && /prog|athlon/i.test(p.id + p.name))?.id ?? k220.slots.modulo, tbi: pick("tbi", `
- `src/game/autopecas/autopecas.ts:41` (setupFor) — `if (p.bundle.modulo) s.slots.modulo = p.bundle.modulo;`
- `src/game/engine-sound.ts:67` (ecuVoice) — `const prog = !!slotPart(src.slots.modulo, "modulo").prog;`
- `src/game/ignition.ts:69` (effectiveModulo) — `const m = slotPart(s.slots.modulo, "modulo");`
- `src/game/ignition.ts:70` (effectiveModulo) — `return fitsBike(m, b.id) ? m : slotPart("modulo-original", "modulo");`
- `src/game/kits/kit70.ts:52` (has) — `it.push({ grupo: "Alimentação", peca: "Módulo / remapeamento", id: s.slots.modulo ?? null, classe: partById(s.slots.modulo ?? "")?.prog ? "COMPATÍVEL" : "EXIGE ADAPTAÇÃO", motivo: "Mistura por faixa só com módulo program`
- `src/game/mechlimits.ts:121` (clutchKgMul) — `const prog = !!slotPart(s.slots.modulo, "modulo").prog;`
- `src/game/mechlimits.ts:123` (clutchKgMul) — `const timingOver = mt != null && (prog || s.slots.modulo === SERVITEC_ID) ? Math.max(0, mt - timingOptimum(b, s)) : 0;`
- `src/game/missions.ts:66` (d) — `{ id: "m-modulo", title: "Mais giro", desc: "Monta um módulo de ignição de preparação.", cash: 800, xp: 8, go: { label: "GARAGEM", scene: "garage" }, done: (p) => p.setup.slots.modulo !== "modulo-original" },`
- `src/game/pericia.ts:30` (factors) — `if (JSON.stringify(s.ecu) !== JSON.stringify(S.ecu)) f.push({ id: "ecu", nome: "Mapa do módulo", revert: (x) => ({ ...x, ecu: S.ecu }), solo: () => ({ ...S, ecu: s.ecu, slots: { ...S.slots, modulo: s.slots.modulo } }) })`
- `src/game/pericia.ts:77` (pericia) — `admissao: { filtroDeAr: s.airFilter, tbi: partById(s.slots.tbi) ?? s.slots.tbi, bico: partById(s.slots.bico) ?? s.slots.bico, bomba: partById(s.slots.bomba) ?? s.slots.bomba, modulo: partById(s.slots.modulo) ?? s.slots.m`
- `src/game/physics.ts:426` (mixtureCalc) — `const mod = slotPart(s.slots.modulo, "modulo");`
- `src/game/physics.ts:459` (mapTiming) — `const mod = slotPart(s.slots.modulo, "modulo");`
- `src/game/physics.ts:463` (mapTiming) — `const isProg = memoS((s: Setup) => !!slotPart(s.slots.modulo, "modulo").prog);`
- `src/game/physics.ts:478` (mixtureAt) — `if (s.slots.modulo === SERVITEC_ID) supply = (m.supply * servitecPulse(rpm)) / servitecPulse(servitecMap().rpmPeak);`

## Fórmulas nas mesmas funções
- **Potência mecânica / torque**: $P = T\,\omega \;\Leftrightarrow\; T = P/\omega$ — P = potência [W]; T = torque [N·m]; ω = velocidade angular [rad/s]
- **Flambagem de Euler**: $P_{cr} = \frac{\pi^2 E I}{(K L)^2}$ — E = módulo de elasticidade [Pa]; I = momento de inércia de área [m⁴]; L = comprimento [m]; K = fator de apoio [—]

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
—

## Mecânicas relacionadas
- `mec.admin-lab`
- `mec.autopecas.autopecas`
- `mec.engine-sound`
- `mec.ignition`
- `mec.kits.kit70`
- `mec.mechlimits`
- `mec.missions`
- `mec.pericia`
- `mec.physics`

## Testes relacionados
- `src/test/stock-return.test.ts`

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- material: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
