# Bico AV 240 lb

- ID: `combustivel.injetores.bico-240` · interno `bico-240`
- Marca: Pro Racing · Spec: 14 furos
- Categoria: combustivel / injetores · tipo `bico` · slot `bico`
- Original de fábrica: não · Motos: titan160, factor150
- Registro: `src/game/parts.ts:113` (coroa) · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
Bico injetor: 14 furos

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| material | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| flow | 1.55 — | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| preco | 1140 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:bico
- `src/game/autopecas/autopecas.ts:40` (setupFor) — `s.slots.bico = p.bundle.bico; s.cam = p.bundle.cam; s.front = p.bundle.front ?? s.front; s.rear = p.bundle.rear ?? s.rear;`
- `src/game/enginephys.ts:249` (pumpCcMin) — `const injCcMin = EST.injFlowCcMin * flowOf(s.slots.bico, "bico") * Math.sqrt(railBar / 3);`
- `src/game/intel/qa.ts:20` (experiments) — `const bico = PARTS_CATALOG_FREE.filter((p) => p.kind === "bico" && (p.flow ?? 1) > ((PARTS_CATALOG_FREE.find((x) => x.id === s.slots.bico)?.flow) ?? 1)).sort((a, z) => (a.flow ?? 1) - (z.flow ?? 1))[0];`
- `src/game/kits/kit70.ts:51` (has) — `it.push({ grupo: "Alimentação", peca: "Bico injetor", id: s.slots.bico ?? null, classe: fc.lean > 0.02 ? "INCOMPATÍVEL" : fc.dutyPct > 85 ? "EXIGE ADAPTAÇÃO" : "COMPATÍVEL", motivo: `No pico (${e.rpmPeak} rpm) pede ${fc.`
- `src/game/overhaul22.ts:169` (mapAirGs) — `const bicoMul = slotPart(s.slots.bico, "bico").flow ?? 1;`
- `src/game/overhaul22.ts:176` (injGs) — `const injGs = ((EST.injFlowCcMin * (slotPart(s.slots.bico, "bico").flow ?? 1) * Math.sqrt(rail / EST.railBar)) / 60) * rho * openFrac;`
- `src/game/pericia.ts:77` (pericia) — `admissao: { filtroDeAr: s.airFilter, tbi: partById(s.slots.tbi) ?? s.slots.tbi, bico: partById(s.slots.bico) ?? s.slots.bico, bomba: partById(s.slots.bomba) ?? s.slots.bomba, modulo: partById(s.slots.modulo) ?? s.slots.m`
- `src/game/physics.ts:427` (line) — `const line = (slotPart(s.slots.bico, "bico").flow ?? 1) * (slotPart(s.slots.bomba, "bomba").flow ?? 1);`
- `src/game/physics.ts:477` (mixtureAt) — `let supply = m.supply + (slotPart(s.slots.bico, "bico")?.flow ?? 1) * ((isProg(s) ? bandTrim(s.ecu, rpm) : 0) / 100);`
- `src/game/preparador/preparador.ts:71` (afinarAthlon) — `const flow = slotPart(s.slots.bico, "bico").flow ?? 1;`
- `src/game/realgear/bridge/exporter.ts:25` (exportProject) — `const bico = partById(s.slots.bico), emb = partById(s.slots.embreagem);`
- `src/game/rootcause.ts:22` (fuelChain) — `const bico = flowOf(s.slots.bico), bomba = flowOf(s.slots.bomba);`
- `src/game/rootcause.ts:47` (fuelTree) — `cad.push({ nivel: 4, pergunta: "O bico conseguiu passar o que o motor pedia?", achado: `${nome(s.slots.bico)} vaza ${c.bico}×; precisava de ${c.bicoNeeded}× nesse giro.${!bicoOk && bombaOk ? (c.bomba > 1 ? " Não adianta `
- `src/nexus/aeic.ts:68` (D) — `D("D", "bico", "Bico injetor", { when: "inj", peca: "bico", usa: ["physics.ts#slots.bico", "enginephys.ts#injectionAt"], liga: ["bomba", "ecu"] }),`
### flow
- `src/game/engineering/dados/audit.ts:232` (ficha) — `if (p.flow != null) dados.push({ nome: "Vazão relativa", valor: p.flow, unidade: "× original", origem: "JOGO", fonte: "parts.ts › flow" });`
- `src/game/engineering/dados/audit.ts:257` (rel) — `if (p.kind === "bico") checks.push(chk("vazao", "Vazão absoluta do bico", "INCONCLUSIVO", `vazão relativa ${fx(p.flow)}× sobre base ESTIMADA (EST.injFlowCcMin)`));`
- `src/game/engineering/dados/audit.ts:264` (igualStd) — `const declara = !igualStd && (p.hpMul != null || (p.flow != null && p.flow !== 1) || p.clutchNm != null || p.front != null || p.rear != null || !!p.cam || p.crr != null || p.grip != null || p.kg != null || p.cc != null |`
- `src/game/enginephys.ts:234` (flowOf) — `const flowOf = (id: string | undefined, k: "bico" | "bomba") => slotPart(id, k).flow ?? 1;`
- `src/game/intel/qa.ts:20` (experiments) — `const bico = PARTS_CATALOG_FREE.filter((p) => p.kind === "bico" && (p.flow ?? 1) > ((PARTS_CATALOG_FREE.find((x) => x.id === s.slots.bico)?.flow) ?? 1)).sort((a, z) => (a.flow ?? 1) - (z.flow ?? 1))[0];`
- `src/game/nexus-update/registry.ts:34` (partFields) — `if (p.flow !== undefined) f.push({ k: "flow", label: "Vazão", type: "number", formula: "fuelChain: vazão do bico/bomba" });`
- `src/game/overhaul22.ts:169` (mapAirGs) — `const bicoMul = slotPart(s.slots.bico, "bico").flow ?? 1;`
- `src/game/overhaul22.ts:172` (pumpGs) — `const pumpGs = ((EST.pumpLh * (slotPart(s.slots.bomba, "bomba").flow ?? 1)) * rho * 1000) / 3600;`

## Fórmulas nas mesmas funções
- **Potência mecânica / torque**: $P = T\,\omega \;\Leftrightarrow\; T = P/\omega$ — P = potência [W]; T = torque [N·m]; ω = velocidade angular [rad/s]
- **Segunda lei de Newton**: $a = \frac{F}{m}$ — a = aceleração [m/s²]; F = força resultante [N]; m = massa [kg]
- **Relação de transmissão final**: $i_f = \frac{Z_{coroa}}{Z_{pinhão}}$ — Z = número de dentes [—]

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
—

## Mecânicas relacionadas
- `mec.autopecas.autopecas`
- `mec.enginephys`
- `mec.intel.qa`
- `mec.kits.kit70`
- `mec.overhaul22`
- `mec.pericia`
- `mec.physics`
- `mec.preparador.preparador`
- `mec.realgear.bridge.exporter`
- `mec.rootcause`
- `mec.src.nexus.aeic`
- `mec.engineering.dados.audit`
- `mec.nexus-update.registry`

## Testes relacionados
- `src/test/mech-identity.test.ts`
- `src/test/mechlimits.test.ts`

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- material: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
