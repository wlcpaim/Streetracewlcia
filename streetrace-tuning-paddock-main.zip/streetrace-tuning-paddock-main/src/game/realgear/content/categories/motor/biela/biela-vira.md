# Virabrequim balanceado + biela forjada

- ID: `motor.biela.biela-vira` · interno `biela-vira`
- Marca: Hot Rods · Spec: Dinâmico · Ø do olhal sem ficha
- Categoria: motor / biela · tipo `biela` · slot `biela`
- Original de fábrica: não · Motos: titan160, factor150
- Registro: `src/game/parts.ts:236` · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
Biela: Dinâmico · Ø do olhal sem ficha

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| material | forjada — | CONFIRMADO_NO_CODIGO | texto do catálogo (nome/spec); não verificado por ensaio |
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| comprimento_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| diametro_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| densidade_kg_m3 | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| modulo_elasticidade_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| coef_poisson | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| limite_escoamento_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| resistencia_tracao_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| condutividade_W_mK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| calor_especifico_J_kgK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tolerancias | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tratamento_termico | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| hpMul | 1.015 — | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| fix | {"Biela quebrada":40,"Motor fundiu":10} pontos | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| preco | 6450 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:biela
- `src/game/autopecas/autopecas.ts:45` (setupFor) — `if (p.bundle.biela) s.slots.biela = p.bundle.biela;`
- `src/game/engineering/dados/audit.ts:108` (conexoes) — `const cyl = slotPart(s.slots.cilindro, "cilindro"), pis = slotPart(s.slots.pistao, "pistao"), bie = slotPart(s.slots.biela, "biela");`
- `src/game/kits/kit70.ts:23` (rodPinOf) — `const rodPinOf = (b: BikeModel, s: Setup) => { const id = s.slots.biela ?? "biela-original"; const x = partById(id); return x?.pinMm ?? (x?.factory || id === "biela-original" ? pinOf(b.id) : null); };`
- `src/game/kits/kit70.ts:40` (has) — `const rodName = partById(s.slots.biela ?? "biela-original")?.name ?? "biela";`
- `src/game/kits/kit70.ts:46` (has) — `it.push({ grupo: "Motor", peca: "Biela", id: s.slots.biela ?? null, classe: has("biela", "biela-original") ? "EXIGE ADAPTAÇÃO" : "COMPATÍVEL", motivo: has("biela", "biela-original") ? "Biela original com pistão maior: ca`
- `src/game/physics.ts:175` (finite) — `if (slots.biela === "vira-ww3") { slots.vira = "vira-ww3"; slots.biela = STOCK_SLOTS.biela; }`
- `src/game/physics.ts:648` (engineCalc) — `for (const k of ["molas", "biela"] as Slot[]) mul *= slotPart(s.slots[k], k).hpMul ?? 1;`
- `src/game/physics.ts:745` (over) — `for (const k of ["embreagem", "molas", "biela"] as Slot[]) for (const [c, v] of Object.entries(slotPart(s.slots[k], k).fix ?? {})) fixes[c] = (fixes[c] ?? 0) + v;`
- `src/game/preparador/preparador.ts:120` (podeServico) — `return validarConjunto(t.slots.pistao, t.slots.biela, bikeId).aprovado;`
- `src/game/realgear/funnel.ts:120` (w5) — `sol5 = solucionarC5(mats, { biela: s.slots.biela, pistao: s.slots.pistao });`
- `src/game/realgear/knowledge/solver.ts:15` (solucionarC5) — `const rod = perfilDe("biela", slots.biela), pis = perfilDe("pistao", slots.pistao);`
- `src/game/workshop.ts:52` (runService) — `if ((setup.slots.pistao !== p.setup.slots.pistao || setup.slots.biela !== p.setup.slots.biela) && !validarConjunto(setup.slots.pistao, setup.slots.biela, p.activeBike).aprovado) return p;`
- `src/game/workshop.ts:104` (mountKit4) — `if (!validarConjunto(setup.slots.pistao, setup.slots.biela, p.activeBike).aprovado) return p;`
- `src/nexus/aeic.ts:40` (D) — `D("A", "biela", "Biela (pé, olhal, bucha)", { dados: ["c:biela"], peca: "biela", usa: ["physics.ts#slots.biela", "enginephys.ts#rodLoads"], liga: ["pino", "virabrequim"] }),`
### hpMul
- `src/game/autopecas/autopecas.ts:91` (vm) — `C.push({ nome: "Multiplicador do kit", formula: "P × hpMul", conta: `hpMul = ${p?.hpMul ?? 1}; demanda extra de combustível ${n((p?.need ?? 0) * 100, 0)} %`, resultado: `×${p?.hpMul ?? 1}`, origem: "JOGO" });`
- `src/game/autopecas/autopecas.ts:119` (lhv) — `C.push({ nome: "Potência com tanque 100 %", formula: "P × blendFx(mistura).hpMul", conta: `${n(st0.hp, 1)} → ${n(st1.hp, 1)} cv`, resultado: `×${n(st1.hp / st0.hp, 3)}`, origem: "JOGO" });`
- `src/game/engineering/dados/audit.ts:264` (igualStd) — `const declara = !igualStd && (p.hpMul != null || (p.flow != null && p.flow !== 1) || p.clutchNm != null || p.front != null || p.rear != null || !!p.cam || p.crr != null || p.grip != null || p.kg != null || p.cc != null |`
- `src/game/nexus-update/registry.ts:31` (partFields) — `f.push(F.kg, F.hpMul, F.stress, F.relief, F.need);`
- `src/game/nexus-update/registry.ts:65` (categories) — `const svc: Item[] = SERVICES.map((s) => ({ key: `svc:${s.id}`, name: s.name, group: gl.get(s.group) ?? s.group, obj: s as unknown as Record<string, unknown>, fields: [F.name, F.price, F.hpMul, F.rpmPeak, F.need, F.stress`
- `src/game/part-sheet.ts:22` (P) — `form: [`V = π/4 × D² × curso = ${f(cc, 1)} cc`, `hp ∝ V × mul_peça (hpMul ${P("cilindro")?.hpMul ?? 1}) → hp motor ${f(e.hp, 2)} cv`, `demanda comb. +${Math.round((P("cilindro")?.need ?? 0) * 100)}% sobre o bico`],`
- `src/game/physics.ts:643` (engineCalc) — `mul *= bfx.hpMul;`
- `src/game/physics.ts:645` (engineCalc) — `mul *= oil.hpMul ?? 1;`
### fix
- `src/game/cloud/cloud.server.ts:69` (startRun) — `if (fixState.failures.length) { await beat("Fix Center", "realgear.fix/1"); await beat("Repair Sandbox", "runFunnel overrides"); }`
- `src/game/cloud/cloud.server.ts:135` (settleAxles) — `fix_report: (inv?.fix ?? null) as never, sandbox_report: (inv?.sandbox ?? null) as never,`
- `src/game/cloud/cloud.server.ts:138` (settleAxles) — `if (inv) { await logEvent(runId, "Fix Center", "CAUSA RAIZ", inv.fix.causaRaiz.map((a) => `${a.metric}: ${a.culpado}`).join("; ")); await logEvent(runId, "Repair Sandbox", "REPRODUÇÃO", inv.sandbox.mensagem); await beat(`
- `src/game/cloud/cloud.server.ts:146` (settleInvestigation) — `if (response.schema !== "realgear.fix/1.0.0" || !py || typeof py !== "object" || py.failureId !== ev.failureId) {`
- `src/game/cloud/cloud.server.ts:154` (settleInvestigation) — `await beat("Python Investigator", "realgear.fix/1.0.0");`
- `src/game/intel/audit.ts:148` (promptFor) — ``4. Esperado / abordagem: ${f.expected}. Fórmula de referência: ${f.formula}. Correção sugerida: ${f.fix}`,`
- `src/game/mechlimits.ts:91` (fixOf) — `const fixOf = (s: Setup, slot: "biela" | "molas" | "embreagem", cause: string) => (slotPart(s.slots[slot], slot).fix ?? {})[cause] ?? 0;`
- `src/game/physics.ts:678` (valveFloatRpm) — `return 10300 - cam.risk * 40 - liftSvc * 150 + ((slotPart(s.slots.molas, "molas").fix ?? {})["Válvula atropelada"] ?? 0) * 40;`

## Fórmulas nas mesmas funções
- **Velocidade angular**: $\omega = \frac{2\pi n}{60}$ — ω = velocidade angular [rad/s]; n = rotação [rpm]
- **Potência mecânica / torque**: $P = T\,\omega \;\Leftrightarrow\; T = P/\omega$ — P = potência [W]; T = torque [N·m]; ω = velocidade angular [rad/s]
- **Segunda lei de Newton**: $a = \frac{F}{m}$ — a = aceleração [m/s²]; F = força resultante [N]; m = massa [kg]
- **Função de Wiebe (fração queimada)**: $x_b = 1 - e^{-a\left(\frac{\theta-\theta_0}{\Delta\theta}\right)^{m+1}}$ — x_b = fração de massa queimada [—]; θ = ângulo do virabrequim [°]; a, m = parâmetros de forma [—]
- **Consumo específico (BSFC)**: $\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$ — P = potência [kW]; BSFC = consumo específico [kg/kWh]; ρ_f = densidade do combustível [kg/L]

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
—

## Mecânicas relacionadas
- `mec.autopecas.autopecas`
- `mec.engineering.dados.audit`
- `mec.kits.kit70`
- `mec.physics`
- `mec.preparador.preparador`
- `mec.realgear.funnel`
- `mec.realgear.knowledge.solver`
- `mec.workshop`
- `mec.src.nexus.aeic`
- `mec.nexus-update.registry`
- `mec.part-sheet`
- `mec.cloud.cloud.server`
- `mec.intel.audit`
- `mec.mechlimits`

## Testes relacionados
Nenhum teste cita este id.

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- comprimento_mm: DADO NÃO IDENTIFICADO
- diametro_mm: DADO NÃO IDENTIFICADO
- densidade_kg_m3: DADO NÃO IDENTIFICADO
- modulo_elasticidade_Pa: DADO NÃO IDENTIFICADO
- coef_poisson: DADO NÃO IDENTIFICADO
- limite_escoamento_Pa: DADO NÃO IDENTIFICADO
- resistencia_tracao_Pa: DADO NÃO IDENTIFICADO
- condutividade_W_mK: DADO NÃO IDENTIFICADO
- calor_especifico_J_kgK: DADO NÃO IDENTIFICADO
- tolerancias: DADO NÃO IDENTIFICADO
- tratamento_termico: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
