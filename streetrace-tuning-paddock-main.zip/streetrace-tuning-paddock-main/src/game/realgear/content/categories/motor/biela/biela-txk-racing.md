# Biela · pino 15 mm

- ID: `motor.biela.biela-txk-racing` · interno `biela-txk-racing`
- Marca: TXK · Spec: pino 15 mm · pistões: Zayma 70 mm p15, Metal Leve 61,3 mm (4MM)
- Categoria: motor / biela · tipo `biela` · slot `biela`
- Original de fábrica: não · Motos: titan160, factor150
- Registro: `src/game/parts.ts:110` (coroa) · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
Biela: pino 15 mm · pistões: Zayma 70 mm p15, Metal Leve 61,3 mm (4MM)

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| diametro_mm | 15 mm | CONFIRMADO_NO_CODIGO | texto do catálogo (nome/spec); não verificado por ensaio |
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| material | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| comprimento_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| densidade_kg_m3 | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| modulo_elasticidade_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| coef_poisson | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| limite_escoamento_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| resistencia_tracao_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| condutividade_W_mK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| calor_especifico_J_kgK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tolerancias | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tratamento_termico | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| fix | {"Biela quebrada":15} pontos | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| preco | 1170 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:biela
- `src/game/autopecas/autopecas.ts:45` (setupFor) — `if (p.bundle.biela) s.slots.biela = p.bundle.biela;`
- `src/game/engineering/dados/audit.ts:108` (conexoes) — `const cyl = slotPart(s.slots.cilindro, "cilindro"), pis = slotPart(s.slots.pistao, "pistao"), bie = slotPart(s.slots.biela, "biela");`
- `src/game/kits/kit70.ts:23` (rodPinOf) — `const rodPinOf = (b: BikeModel, s: Setup) => { const id = s.slots.biela ?? "biela-original"; const x = partById(id); return x?.pinMm ?? (x?.factory || id === "biela-original" ? pinOf(b.id) : null); };`
- `src/game/kits/kit70.ts:40` (has) — `const rodName = partById(s.slots.biela ?? "biela-original")?.name ?? "biela";`
- `src/game/kits/kit70.ts:46` (has) — `it.push({ grupo: "Motor", peca: "Biela", id: s.slots.biela ?? null, classe: has("biela", "biela-original") ? "EXIGE ADAPTAÇÃO" : "COMPATÍVEL", motivo: has("biela", "biela-original") ? "Biela original com pistão maior: ca`
- `src/game/physics.ts:175` (finite) — `if (slots.biela === "vira-ww3") { slots.vira = "vira-ww3"; slots.biela = STOCK_SLOTS.biela; }`
- `src/game/physics.ts:648` (engineCalc) — `for (const k of ["molas", "biela"] as Slot[]) mul *= slotPart(s.slots[k], k).hpMul ?? 1;`
- `src/game/physics.ts:745` (over) — `for (const k of ["embreagem", "molas", "biela"] as Slot[]) for (const [c, v] of Object.entries(slotPart(s.slots[k], k).fix ?? {})) fixes[c] = (fixes[c] ?? 0) + v;`
- `src/game/preparador/preparador.ts:120` (podeServico) — `return validarConjunto(t.slots.pistao, t.slots.biela, bikeId).aprovado;`
- `src/game/realgear/funnel.ts:120` (w5) — `sol5 = solucionarC5(mats, { biela: s.slots.biela, pistao: s.slots.pistao });`
- `src/game/realgear/knowledge/solver.ts:15` (solucionarC5) — `const rod = perfilDe("biela", slots.biela), pis = perfilDe("pistao", slots.pistao);`
- `src/game/workshop.ts:52` (runService) — `if ((setup.slots.pistao !== p.setup.slots.pistao || setup.slots.biela !== p.setup.slots.biela) && !validarConjunto(setup.slots.pistao, setup.slots.biela, p.activeBike).aprovado) return p;`
- `src/game/workshop.ts:104` (mountKit4) — `if (!validarConjunto(setup.slots.pistao, setup.slots.biela, p.activeBike).aprovado) return p;`
- `src/nexus/aeic.ts:40` (D) — `D("A", "biela", "Biela (pé, olhal, bucha)", { dados: ["c:biela"], peca: "biela", usa: ["physics.ts#slots.biela", "enginephys.ts#rodLoads"], liga: ["pino", "virabrequim"] }),`
### fix
- `src/game/cloud/cloud.server.ts:69` (startRun) — `if (fixState.failures.length) { await beat("Fix Center", "realgear.fix/1"); await beat("Repair Sandbox", "runFunnel overrides"); }`
- `src/game/cloud/cloud.server.ts:135` (settleAxles) — `fix_report: (inv?.fix ?? null) as never, sandbox_report: (inv?.sandbox ?? null) as never,`
- `src/game/cloud/cloud.server.ts:138` (settleAxles) — `if (inv) { await logEvent(runId, "Fix Center", "CAUSA RAIZ", inv.fix.causaRaiz.map((a) => `${a.metric}: ${a.culpado}`).join("; ")); await logEvent(runId, "Repair Sandbox", "REPRODUÇÃO", inv.sandbox.mensagem); await beat(`
- `src/game/cloud/cloud.server.ts:146` (settleInvestigation) — `if (response.schema !== "realgear.fix/1.0.0" || !py || typeof py !== "object" || py.failureId !== ev.failureId) {`
- `src/game/cloud/cloud.server.ts:154` (settleInvestigation) — `await beat("Python Investigator", "realgear.fix/1.0.0");`
- `src/game/intel/audit.ts:148` (promptFor) — ``4. Esperado / abordagem: ${f.expected}. Fórmula de referência: ${f.formula}. Correção sugerida: ${f.fix}`,`
- `src/game/mechlimits.ts:91` (fixOf) — `const fixOf = (s: Setup, slot: "biela" | "molas" | "embreagem", cause: string) => (slotPart(s.slots[slot], slot).fix ?? {})[cause] ?? 0;`
- `src/game/physics.ts:678` (valveFloatRpm) — `return 10300 - cam.risk * 40 - liftSvc * 150 + ((slotPart(s.slots.molas, "molas").fix ?? {})["Válvula atropelada"] ?? 0) * 40;`

## Fórmulas nas mesmas funções
- **Velocidade angular**: $\omega = \frac{2\pi n}{60}$ — ω = velocidade angular [rad/s]; n = rotação [rpm]
- **Potência mecânica / torque**: $P = T\,\omega \;\Leftrightarrow\; T = P/\omega$ — P = potência [W]; T = torque [N·m]; ω = velocidade angular [rad/s]
- **Consumo específico (BSFC)**: $\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$ — P = potência [kW]; BSFC = consumo específico [kg/kWh]; ρ_f = densidade do combustível [kg/L]

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
—

## Mecânicas relacionadas
- `mec.autopecas.autopecas`
- `mec.engineering.dados.audit`
- `mec.kits.kit70`
- `mec.physics`
- `mec.preparador.preparador`
- `mec.realgear.funnel`
- `mec.realgear.knowledge.solver`
- `mec.workshop`
- `mec.src.nexus.aeic`
- `mec.cloud.cloud.server`
- `mec.intel.audit`
- `mec.mechlimits`

## Testes relacionados
- `src/test/biela-txk.test.ts`
- `src/test/kit4-clutch.test.ts`
- `src/test/kit4-pistao.test.ts`
- `src/test/kit70.test.ts`
- `src/test/part-signature.test.ts`
- `src/test/pins.test.ts`
- `src/test/stock-return.test.ts`

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- material: DADO NÃO IDENTIFICADO
- comprimento_mm: DADO NÃO IDENTIFICADO
- densidade_kg_m3: DADO NÃO IDENTIFICADO
- modulo_elasticidade_Pa: DADO NÃO IDENTIFICADO
- coef_poisson: DADO NÃO IDENTIFICADO
- limite_escoamento_Pa: DADO NÃO IDENTIFICADO
- resistencia_tracao_Pa: DADO NÃO IDENTIFICADO
- condutividade_W_mK: DADO NÃO IDENTIFICADO
- calor_especifico_J_kgK: DADO NÃO IDENTIFICADO
- tolerancias: DADO NÃO IDENTIFICADO
- tratamento_termico: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
