# Cilindro 61,3 mm (4 mm)

- ID: `motor.cilindro.cilindro-4mm` · interno `cilindro-4mm`
- Marca: KMP · Spec: Ø 61,3 mm · 190 cc · par do pistão 61,3 mm pino 15 mm
- Categoria: motor / cilindro · tipo `cilindro` · slot `cilindro`
- Original de fábrica: não · Motos: titan160, factor150
- Registro: `src/game/parts.ts:110` (coroa) · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
Cilindro: Ø 61,3 mm · 190 cc · par do pistão 61,3 mm pino 15 mm

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| diametro_mm | 61.3 mm | CONFIRMADO_NO_CODIGO | texto do catálogo (nome/spec); não verificado por ensaio |
| volume_cm3 | 190 cm³ | CONFIRMADO_NO_CODIGO | texto do catálogo (nome/spec); não verificado por ensaio |
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| material | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| comprimento_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| densidade_kg_m3 | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| modulo_elasticidade_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| coef_poisson | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| limite_escoamento_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| resistencia_tracao_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| condutividade_W_mK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| calor_especifico_J_kgK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tolerancias | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tratamento_termico | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| hpMul | 1.2 — | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| stress | 15 pontos de risco | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| need | 0.15 — | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| preco | 2235 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:cilindro
- `src/game/engineering/dados/audit.ts:108` (conexoes) — `const cyl = slotPart(s.slots.cilindro, "cilindro"), pis = slotPart(s.slots.pistao, "pistao"), bie = slotPart(s.slots.biela, "biela");`
- `src/game/engineering/dados/pipeline.ts:42` (nexusRevisar) — `const cyl = slotPart(a.snapshot.slots.cilindro, "cilindro"), d = boreOf(cyl, a.bikeId), s = strokeReal(a.bikeId, a.snapshot);`
- `src/game/mechanic.ts:135` (pullAdvice) — `if (s.airFilter === "original" && s.slots.cilindro !== "cilindro-original") return "Motor maior respirando pelo filtro original. Ele quer mais ar.";`
- `src/game/mechanic.ts:136` (pullAdvice) — `if (s.slots.cilindro === "cilindro-original" && dist >= 500) return "O conjunto tá redondo. Pra andar mais, tem que fuçar a moto.";`
- `src/game/mechlimits.ts:99` (buildOf) — `const cyl = slotPart(s.slots.cilindro, "cilindro");`
- `src/game/physics.ts:176` (finite) — `if (slots.cilindro === "cilindro-4mm" && slots.vira === STOCK_SLOTS.vira) slots.vira = "vira-ww3";`
- `src/game/physics.ts:424` (mixtureCalc) — `const cyl = slotPart(s.slots.cilindro, "cilindro");`
- `src/game/physics.ts:537` (ccOf) — `const c = slotPart(s.slots.cilindro, "cilindro");`
- `src/game/physics.ts:646` (engineCalc) — `mul *= slotPart(s.slots.cilindro, "cilindro").hpMul ?? 1;`
- `src/game/physics.ts:713` (add) — `const cyl = slotPart(s.slots.cilindro, "cilindro");`
- `src/game/records.ts:30` (displacement) — `const cc = CYL_CC[s.slots.cilindro ?? "cilindro-original"] ?? 162.7;`
- `src/game/rootcause.ts:36` (fuelTree) — `const cyl = partById(s.slots.cilindro), tbi = partById(s.slots.tbi);`
- `src/game/workshop.ts:89` (kit4Done) — `export const kit4Done = (p: Player) => p.setup.slots.cilindro === KIT4_CYL && p.setup.cam === KIT4_BUNDLE.cam && p.setup.services.includes("pino-2") && kit4Pieces().every((id) => { const k = partById(id)?.kind as Slot; r`
- `src/nexus/aeic.ts:36` (D) — `D("A", "cilindro", "Cilindro / camisa", { dados: ["c:diametro"], peca: "cilindro", usa: ["physics.ts#slots.cilindro", "enginephys.ts#cylVol"], liga: ["pistao", "cabecote"] }),`
### hpMul
- `src/game/autopecas/autopecas.ts:91` (vm) — `C.push({ nome: "Multiplicador do kit", formula: "P × hpMul", conta: `hpMul = ${p?.hpMul ?? 1}; demanda extra de combustível ${n((p?.need ?? 0) * 100, 0)} %`, resultado: `×${p?.hpMul ?? 1}`, origem: "JOGO" });`
- `src/game/autopecas/autopecas.ts:119` (lhv) — `C.push({ nome: "Potência com tanque 100 %", formula: "P × blendFx(mistura).hpMul", conta: `${n(st0.hp, 1)} → ${n(st1.hp, 1)} cv`, resultado: `×${n(st1.hp / st0.hp, 3)}`, origem: "JOGO" });`
- `src/game/engineering/dados/audit.ts:264` (igualStd) — `const declara = !igualStd && (p.hpMul != null || (p.flow != null && p.flow !== 1) || p.clutchNm != null || p.front != null || p.rear != null || !!p.cam || p.crr != null || p.grip != null || p.kg != null || p.cc != null |`
- `src/game/nexus-update/registry.ts:31` (partFields) — `f.push(F.kg, F.hpMul, F.stress, F.relief, F.need);`
- `src/game/nexus-update/registry.ts:65` (categories) — `const svc: Item[] = SERVICES.map((s) => ({ key: `svc:${s.id}`, name: s.name, group: gl.get(s.group) ?? s.group, obj: s as unknown as Record<string, unknown>, fields: [F.name, F.price, F.hpMul, F.rpmPeak, F.need, F.stress`
- `src/game/part-sheet.ts:22` (P) — `form: [`V = π/4 × D² × curso = ${f(cc, 1)} cc`, `hp ∝ V × mul_peça (hpMul ${P("cilindro")?.hpMul ?? 1}) → hp motor ${f(e.hp, 2)} cv`, `demanda comb. +${Math.round((P("cilindro")?.need ?? 0) * 100)}% sobre o bico`],`
- `src/game/physics.ts:643` (engineCalc) — `mul *= bfx.hpMul;`
- `src/game/physics.ts:645` (engineCalc) — `mul *= oil.hpMul ?? 1;`
### stress
- `src/game/engineering/eng.ts:88` (measure) — `return { finishS: r.result.finishS, t0_100: r.result.t0_100, vmaxKmh: r.result.vmaxKmh, fuelL: r.result.fuelUsedL, stress: r.stress.value, quebrou: r.breakdown?.cause ?? (r.result.stalled ? "motor apagou" : null), hp: r.`
- `src/game/engineering/eng.ts:106` (pct) — `"Segurança": cat(m.stress < b.stress, m.stress === b.stress, b.stress ? pct(m.stress, b.stress) : 0),`
- `src/game/engineering/eng.ts:110` (pct) — `const txt = `Tempo ${m.finishS.toFixed(3)} s vs ${b.finishS.toFixed(3)} s (ganho ${g.toFixed(2)}%), stress ${m.stress.toFixed(1)} vs ${b.stress.toFixed(1)}.`;`
- `src/game/engineering/eng.ts:113` (pct) — `if (m.stress > b.stress + 10) return { classe: "BOA", categorias, justificativa: txt + " Carga acima do limite da EXCELENTE." };`
- `src/game/engineering/eng.ts:114` (pct) — `if (repetivel && m.stress <= b.stress) return { classe: "PERFEITA", categorias, justificativa: txt + " Repetição idêntica confirmada." };`
- `src/game/engineering/eng.ts:119` (byBest) — `export const byBest = (a: { classe: Classe; m: Metricas }, b: { classe: Classe; m: Metricas }) => RANK[b.classe] - RANK[a.classe] || (a.m.finishS ?? 1e9) - (b.m.finishS ?? 1e9) || a.m.stress - b.m.stress;`
- `src/game/engineering/eng.ts:204` (finalize) — ``Referência original: ${job.base?.finishS?.toFixed(3)} s · ${job.base?.vmaxKmh.toFixed(1)} km/h · stress ${job.base?.stress.toFixed(1)}`,`
- `src/game/mechlimits.ts:124` (clutchKgMul) — `const honed = !cyl.stress || has("brunimento");`
### need
- `src/game/autopecas/autopecas.ts:91` (vm) — `C.push({ nome: "Multiplicador do kit", formula: "P × hpMul", conta: `hpMul = ${p?.hpMul ?? 1}; demanda extra de combustível ${n((p?.need ?? 0) * 100, 0)} %`, resultado: `×${p?.hpMul ?? 1}`, origem: "JOGO" });`
- `src/game/enginephys.ts:243` (demandGs) — `const demandGs = (kW * bsfc) / 3600 * Math.max(1, m.need);`
- `src/game/kits/kit70.ts:51` (has) — `it.push({ grupo: "Alimentação", peca: "Bico injetor", id: s.slots.bico ?? null, classe: fc.lean > 0.02 ? "INCOMPATÍVEL" : fc.dutyPct > 85 ? "EXIGE ADAPTAÇÃO" : "COMPATÍVEL", motivo: `No pico (${e.rpmPeak} rpm) pede ${fc.`
- `src/game/nexus-update/registry.ts:31` (partFields) — `f.push(F.kg, F.hpMul, F.stress, F.relief, F.need);`
- `src/game/nexus-update/registry.ts:65` (categories) — `const svc: Item[] = SERVICES.map((s) => ({ key: `svc:${s.id}`, name: s.name, group: gl.get(s.group) ?? s.group, obj: s as unknown as Record<string, unknown>, fields: [F.name, F.price, F.hpMul, F.rpmPeak, F.need, F.stress`
- `src/game/part-sheet.ts:22` (P) — `form: [`V = π/4 × D² × curso = ${f(cc, 1)} cc`, `hp ∝ V × mul_peça (hpMul ${P("cilindro")?.hpMul ?? 1}) → hp motor ${f(e.hp, 2)} cv`, `demanda comb. +${Math.round((P("cilindro")?.need ?? 0) * 100)}% sobre o bico`],`
- `src/game/pericia.ts:78` (pericia) — `vazaoEMisturaPorGiro: rpms.map((rpm) => { const m = mixtureAt(s, rpm, e.rpmPeak); return { rpm, combustivelPedido: r3(m.need), combustivelEntregue: r3(m.supply), situacao: m.lean > 0.02 ? "pobre" : m.lean < -0.02 ? "rica`
- `src/game/physics.ts:422` (blendNeed) — `const blendNeed = (s: Setup) => blendFx(s, true).need;`

## Fórmulas nas mesmas funções
- **Potência mecânica / torque**: $P = T\,\omega \;\Leftrightarrow\; T = P/\omega$ — P = potência [W]; T = torque [N·m]; ω = velocidade angular [rad/s]
- **Segunda lei de Newton**: $a = \frac{F}{m}$ — a = aceleração [m/s²]; F = força resultante [N]; m = massa [kg]
- **Área do pistão / cilindrada**: $A = \frac{\pi D^2}{4},\quad V_d = A\,S$ — D = diâmetro [m]; S = curso [m]; A = área [m²]; V_d = cilindrada [m³]
- **Função de Wiebe (fração queimada)**: $x_b = 1 - e^{-a\left(\frac{\theta-\theta_0}{\Delta\theta}\right)^{m+1}}$ — x_b = fração de massa queimada [—]; θ = ângulo do virabrequim [°]; a, m = parâmetros de forma [—]
- **Flambagem de Euler**: $P_{cr} = \frac{\pi^2 E I}{(K L)^2}$ — E = módulo de elasticidade [Pa]; I = momento de inércia de área [m⁴]; L = comprimento [m]; K = fator de apoio [—]
- **Consumo específico (BSFC)**: $\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$ — P = potência [kW]; BSFC = consumo específico [kg/kWh]; ρ_f = densidade do combustível [kg/L]

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
- `bico-170`
- `modulo-remap`
- `biela-txk-racing`
- `pinhao-undefined`
- `coroa-undefined`

## Mecânicas relacionadas
- `mec.engineering.dados.audit`
- `mec.engineering.dados.pipeline`
- `mec.mechanic`
- `mec.mechlimits`
- `mec.physics`
- `mec.records`
- `mec.rootcause`
- `mec.workshop`
- `mec.src.nexus.aeic`
- `mec.autopecas.autopecas`
- `mec.nexus-update.registry`
- `mec.part-sheet`
- `mec.engineering.eng`
- `mec.enginephys`
- `mec.kits.kit70`
- `mec.pericia`

## Testes relacionados
- `src/test/acerto.test.ts`
- `src/test/autopecas.test.ts`
- `src/test/biela-txk.test.ts`
- `src/test/eng-dados.test.ts`
- `src/test/exhaust.test.ts`
- `src/test/facil-track.test.ts`
- `src/test/kit4-clutch.test.ts`
- `src/test/kit4mm-pino.test.ts`
- `src/test/kit4mm.test.ts`
- `src/test/kit70.test.ts`
- `src/test/part-signature.test.ts`
- `src/test/physics-overhaul-022.test.ts`
- `src/test/preparador.test.ts`
- `src/test/save-guard.test.ts`
- `src/test/scrap.test.ts`
- `src/test/startgame.test.ts`
- `src/test/stock-return.test.ts`
- `src/test/usage.test.ts`
- `src/test/workshop.test.ts`

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- material: DADO NÃO IDENTIFICADO
- comprimento_mm: DADO NÃO IDENTIFICADO
- densidade_kg_m3: DADO NÃO IDENTIFICADO
- modulo_elasticidade_Pa: DADO NÃO IDENTIFICADO
- coef_poisson: DADO NÃO IDENTIFICADO
- limite_escoamento_Pa: DADO NÃO IDENTIFICADO
- resistencia_tracao_Pa: DADO NÃO IDENTIFICADO
- condutividade_W_mK: DADO NÃO IDENTIFICADO
- calor_especifico_J_kgK: DADO NÃO IDENTIFICADO
- tolerancias: DADO NÃO IDENTIFICADO
- tratamento_termico: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
