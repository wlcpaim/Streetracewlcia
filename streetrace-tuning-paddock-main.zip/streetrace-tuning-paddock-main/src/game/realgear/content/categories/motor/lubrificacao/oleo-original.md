# Mineral 10W-30 · 1 L

- ID: `motor.lubrificacao.oleo-original` · interno `oleo-original`
- Marca: Honda · Spec: Mineral
- Categoria: motor / lubrificacao · tipo `oleo` · slot `oleo`
- Original de fábrica: não · Motos: titan160
- Registro: `src/game/parts.ts:208` · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
Óleo: Mineral

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| material | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| comprimento_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| diametro_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| densidade_kg_m3 | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| modulo_elasticidade_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| coef_poisson | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| limite_escoamento_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| resistencia_tracao_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| condutividade_W_mK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| calor_especifico_J_kgK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tolerancias | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tratamento_termico | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| hpMul | 1 — | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| oilLife | 1000 km | sim | não | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| consumable | true bool | sim | não | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| preco | 59.9 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:oleo
- `src/game/physics.ts:644` (engineCalc) — `const oil = slotPart(s.slots.oleo, "oleo");`
- `src/game/stresscheck/monitor.ts:361` (add) — `add({ id: "oilC", grupo: "Lubrificação", label: "Temperatura do óleo", componente: "Óleo", valor: r1(oilC), unidade: "°C", limite: null, uso: null, nivel: "INDETERMINADO", origem: "estimado", formula: "C·dT/dt = 4·(T_pis`
- `src/game/stresscheck/monitor.ts:386` (add) — `const oil = slotPart(s.slots.oleo, "oleo");`
- `src/game/workshop.ts:229` (pending) — `const oilLife = partById(p.setup.slots.oleo)?.oilLife ?? 1000;`
- `src/game/workshop.ts:239` (oilCost) — `const oil = partById(p.setup.slots.oleo);`
- `src/game/workshop.ts:252` (orders) — `const oil = partById(p.setup.slots.oleo);`
- `src/game/workshop.ts:253` (orders) — `out.push({ id: "oil", label: "Troca de óleo", sub: `${oil?.brand ?? ""} ${oil?.name ?? ""} · ${Math.round(p.setup.oilKm)} km`.trim(), price: oilCost(p), run: (pl, n) => oilChange(pl, pl.setup.slots.oleo, n) });`
- `src/nexus/aeic.ts:84` (D) — `D("G", "oleo", "Óleo do motor", { peca: "oleo", usa: ["physics.ts#slots.oleo", "physics.ts#oilKm"], liga: ["bomba-oleo"] }),`
### hpMul
- `src/game/autopecas/autopecas.ts:91` (vm) — `C.push({ nome: "Multiplicador do kit", formula: "P × hpMul", conta: `hpMul = ${p?.hpMul ?? 1}; demanda extra de combustível ${n((p?.need ?? 0) * 100, 0)} %`, resultado: `×${p?.hpMul ?? 1}`, origem: "JOGO" });`
- `src/game/autopecas/autopecas.ts:119` (lhv) — `C.push({ nome: "Potência com tanque 100 %", formula: "P × blendFx(mistura).hpMul", conta: `${n(st0.hp, 1)} → ${n(st1.hp, 1)} cv`, resultado: `×${n(st1.hp / st0.hp, 3)}`, origem: "JOGO" });`
- `src/game/engineering/dados/audit.ts:264` (igualStd) — `const declara = !igualStd && (p.hpMul != null || (p.flow != null && p.flow !== 1) || p.clutchNm != null || p.front != null || p.rear != null || !!p.cam || p.crr != null || p.grip != null || p.kg != null || p.cc != null |`
- `src/game/nexus-update/registry.ts:31` (partFields) — `f.push(F.kg, F.hpMul, F.stress, F.relief, F.need);`
- `src/game/nexus-update/registry.ts:65` (categories) — `const svc: Item[] = SERVICES.map((s) => ({ key: `svc:${s.id}`, name: s.name, group: gl.get(s.group) ?? s.group, obj: s as unknown as Record<string, unknown>, fields: [F.name, F.price, F.hpMul, F.rpmPeak, F.need, F.stress`
- `src/game/part-sheet.ts:22` (P) — `form: [`V = π/4 × D² × curso = ${f(cc, 1)} cc`, `hp ∝ V × mul_peça (hpMul ${P("cilindro")?.hpMul ?? 1}) → hp motor ${f(e.hp, 2)} cv`, `demanda comb. +${Math.round((P("cilindro")?.need ?? 0) * 100)}% sobre o bico`],`
- `src/game/physics.ts:643` (engineCalc) — `mul *= bfx.hpMul;`
- `src/game/physics.ts:645` (engineCalc) — `mul *= oil.hpMul ?? 1;`
### oilLife
- `src/game/physics.ts:649` (engineCalc) — `mul *= 1 - Math.min(0.05, Math.max(0, s.oilKm / (oil.oilLife ?? 1000) - 1) * 0.02);`
- `src/game/stresscheck/monitor.ts:387` (add) — `const oilU = s.oilKm / (oil.oilLife ?? 1000);`
- `src/game/stresscheck/monitor.ts:388` (add) — `add({ id: "oilWear", grupo: "Desgaste", label: "Vida do óleo", componente: "Óleo", valor: Math.round(s.oilKm), unidade: "km", limite: oil.oilLife ?? 1000, uso: oilU, origem: "ficha", formula: "km desde a troca / vida do `
- `src/game/workshop.ts:229` (pending) — `const oilLife = partById(p.setup.slots.oleo)?.oilLife ?? 1000;`
### consumable
- `src/game/preparador/preparador.ts:89` (melhorEmbreagem) — `const opts = PARTS_CATALOG.filter((p) => p.kind === "embreagem" && (p.clutchNm ?? 0) >= T * 1.15 && !p.consumable).sort((a, z) => a.price - z.price);`
- `src/game/store.ts:192` (migr) — `const mounted = [...Object.values(st.slots ?? {}), `pinhao-${st.front}`, `coroa-${st.rear}`].filter((id): id is string => !!id && !!partById(id) && !partById(id)!.consumable && !isFactoryPiece(id));`
- `src/game/workshop.ts:44` (runService) — `if (part?.consumable) continue;`
- `src/game/workshop.ts:57` (runService) — `for (const pid of x.install || x.prepFor ? [] : needs(p, x).req) if (partById(pid)?.consumable) { const i = parts.indexOf(pid); if (i >= 0) parts.splice(i, 1); }`

## Fórmulas nas mesmas funções
- **Potência mecânica / torque**: $P = T\,\omega \;\Leftrightarrow\; T = P/\omega$ — P = potência [W]; T = torque [N·m]; ω = velocidade angular [rad/s]
- **Segunda lei de Newton**: $a = \frac{F}{m}$ — a = aceleração [m/s²]; F = força resultante [N]; m = massa [kg]
- **Função de Wiebe (fração queimada)**: $x_b = 1 - e^{-a\left(\frac{\theta-\theta_0}{\Delta\theta}\right)^{m+1}}$ — x_b = fração de massa queimada [—]; θ = ângulo do virabrequim [°]; a, m = parâmetros de forma [—]
- **Consumo específico (BSFC)**: $\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$ — P = potência [kW]; BSFC = consumo específico [kg/kWh]; ρ_f = densidade do combustível [kg/L]

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
—

## Mecânicas relacionadas
- `mec.physics`
- `mec.stresscheck.monitor`
- `mec.workshop`
- `mec.src.nexus.aeic`
- `mec.autopecas.autopecas`
- `mec.engineering.dados.audit`
- `mec.nexus-update.registry`
- `mec.part-sheet`
- `mec.preparador.preparador`
- `mec.store`

## Testes relacionados
- `src/test/multimodelo.test.ts`

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- material: DADO NÃO IDENTIFICADO
- comprimento_mm: DADO NÃO IDENTIFICADO
- diametro_mm: DADO NÃO IDENTIFICADO
- densidade_kg_m3: DADO NÃO IDENTIFICADO
- modulo_elasticidade_Pa: DADO NÃO IDENTIFICADO
- coef_poisson: DADO NÃO IDENTIFICADO
- limite_escoamento_Pa: DADO NÃO IDENTIFICADO
- resistencia_tracao_Pa: DADO NÃO IDENTIFICADO
- condutividade_W_mK: DADO NÃO IDENTIFICADO
- calor_especifico_J_kgK: DADO NÃO IDENTIFICADO
- tolerancias: DADO NÃO IDENTIFICADO
- tratamento_termico: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
