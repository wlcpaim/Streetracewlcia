# Pistão 70,0 mm · pino 14 mm

- ID: `motor.pistao.pistao-70mm-p14` · interno `pistao-70mm-p14`
- Marca: Aftermarket · Spec: 70mm · não forjado · travas e anéis inclusos · biela pino 14 mm: original Titan, Metal Leve STD, WW3 STD
- Categoria: motor / pistao · tipo `pistao` · slot `pistao`
- Original de fábrica: não · Motos: titan160, factor150
- Registro: `src/game/parts.ts:116` (coroa) · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
Pistão: 70mm · não forjado · travas e anéis inclusos · biela pino 14 mm: original Titan, Metal Leve STD, WW3 STD

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| diametro_mm | 70 mm | CONFIRMADO_NO_CODIGO | texto do catálogo (nome/spec); não verificado por ensaio |
| material | forjado — | CONFIRMADO_NO_CODIGO | texto do catálogo (nome/spec); não verificado por ensaio |
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| comprimento_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| densidade_kg_m3 | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| modulo_elasticidade_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| coef_poisson | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| limite_escoamento_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| resistencia_tracao_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| condutividade_W_mK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| calor_especifico_J_kgK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tolerancias | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tratamento_termico | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| relief | 10 pontos de risco | sim | não | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| preco | 1335 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:pistao
- `src/game/autopecas/autopecas.ts:44` (setupFor) — `if (p.bundle.pistao) s.slots.pistao = p.bundle.pistao;`
- `src/game/engineering/dados/audit.ts:108` (conexoes) — `const cyl = slotPart(s.slots.cilindro, "cilindro"), pis = slotPart(s.slots.pistao, "pistao"), bie = slotPart(s.slots.biela, "biela");`
- `src/game/kits/kit70.ts:39` (has) — `const pinB = rodPinOf(b, s), pinP = pinOfPart(s.slots.pistao), p70 = /^pistao-70mm/.test(s.slots.pistao ?? "");`
- `src/game/kits/kit70.ts:41` (has) — `it.push({ grupo: "Cilindro", peca: "Pistão 70,0 mm", id: s.slots.pistao ?? null,`
- `src/game/kits/kit70.ts:44` (has) — `for (const peca of ["Travas do pino", "Jogo de anéis 70 mm"]) it.push({ grupo: "Cilindro", peca, id: p70 ? s.slots.pistao! : null, classe: p70 ? "COMPATÍVEL" : "INCOMPATÍVEL", motivo: p70 ? "Acompanham o pistão 70 mm." :`
- `src/game/kits/kit70.ts:49` (has) — `it.push({ grupo: "Cabeçote", peca: "Cavas de válvula", id: "cavas-pistao", classe: s.services.includes("cavas-pistao") || partById(s.slots.pistao ?? "")?.cavas ? "COMPATÍVEL" : "EXIGE ADAPTAÇÃO", motivo: "Conferir interf`
- `src/game/machining.ts:34` (medidas) — `const cavasPart = !!slotPart(s.slots.pistao, "pistao").cavas || s.services.includes("cavas-pistao");`
- `src/game/mechlimits.ts:98` (buildOf) — `const pis = slotPart(s.slots.pistao, "pistao");`
- `src/game/physics.ts:647` (engineCalc) — `mul *= slotPart(s.slots.pistao, "pistao").hpMul ?? 1;`
- `src/game/physics.ts:714` (add) — `const pis = slotPart(s.slots.pistao, "pistao");`
- `src/game/preparador/preparador.ts:120` (podeServico) — `return validarConjunto(t.slots.pistao, t.slots.biela, bikeId).aprovado;`
- `src/game/realgear/funnel.ts:120` (w5) — `sol5 = solucionarC5(mats, { biela: s.slots.biela, pistao: s.slots.pistao });`
- `src/game/realgear/knowledge/solver.ts:15` (solucionarC5) — `const rod = perfilDe("biela", slots.biela), pis = perfilDe("pistao", slots.pistao);`
- `src/game/rootcause.ts:65` (valveTree) — `const pis = partById(s.slots.pistao), list = svcs(s);`
- `src/game/rootcause.ts:84` (knockTree) — `const pis = partById(s.slots.pistao);`
### relief
- `src/game/nexus-update/registry.ts:31` (partFields) — `f.push(F.kg, F.hpMul, F.stress, F.relief, F.need);`
- `src/game/nexus-update/registry.ts:65` (categories) — `const svc: Item[] = SERVICES.map((s) => ({ key: `svc:${s.id}`, name: s.name, group: gl.get(s.group) ?? s.group, obj: s as unknown as Record<string, unknown>, fields: [F.name, F.price, F.hpMul, F.rpmPeak, F.need, F.stress`
- `src/game/physics.ts:752` (relief) — `const relief = (pis.relief ?? 0) + list.reduce((n, x) => n + (x.relief ?? 0), 0);`

## Fórmulas nas mesmas funções
- **Velocidade angular**: $\omega = \frac{2\pi n}{60}$ — ω = velocidade angular [rad/s]; n = rotação [rpm]
- **Potência mecânica / torque**: $P = T\,\omega \;\Leftrightarrow\; T = P/\omega$ — P = potência [W]; T = torque [N·m]; ω = velocidade angular [rad/s]
- **Segunda lei de Newton**: $a = \frac{F}{m}$ — a = aceleração [m/s²]; F = força resultante [N]; m = massa [kg]

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
—

## Mecânicas relacionadas
- `mec.autopecas.autopecas`
- `mec.engineering.dados.audit`
- `mec.kits.kit70`
- `mec.machining`
- `mec.mechlimits`
- `mec.physics`
- `mec.preparador.preparador`
- `mec.realgear.funnel`
- `mec.realgear.knowledge.solver`
- `mec.rootcause`
- `mec.nexus-update.registry`

## Testes relacionados
- `src/test/kit70.test.ts`
- `src/test/workshop.test.ts`

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- comprimento_mm: DADO NÃO IDENTIFICADO
- densidade_kg_m3: DADO NÃO IDENTIFICADO
- modulo_elasticidade_Pa: DADO NÃO IDENTIFICADO
- coef_poisson: DADO NÃO IDENTIFICADO
- limite_escoamento_Pa: DADO NÃO IDENTIFICADO
- resistencia_tracao_Pa: DADO NÃO IDENTIFICADO
- condutividade_W_mK: DADO NÃO IDENTIFICADO
- calor_especifico_J_kgK: DADO NÃO IDENTIFICADO
- tolerancias: DADO NÃO IDENTIFICADO
- tratamento_termico: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
