# Comando Gritador · Alta

- ID: `motor.comando-de-valvulas.comando-a72` · interno `comando-a72`
- Marca: Morumbi Racing · Spec: Adm 7,2 · Esc 7,0 mm
- Categoria: motor / comando-de-valvulas · tipo `comando`
- Original de fábrica: não · Motos: titan160, factor150
- Registro: `src/game/parts.ts:276` · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
comando: Adm 7,2 · Esc 7,0 mm

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| material | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| comprimento_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| diametro_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| densidade_kg_m3 | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| modulo_elasticidade_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| coef_poisson | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| limite_escoamento_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| resistencia_tracao_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| condutividade_W_mK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| calor_especifico_J_kgK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tolerancias | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tratamento_termico | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| consumable | true bool | sim | não | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| cam | a72 — | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| preco | 1335 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:comando
- `src/game/agr/agr.ts:46` (snapshotOf) — `fuel: s.fuel, psi: s.psi, compression: s.compression, cam: String(s.cam),`
- `src/game/autopecas/autopecas.ts:37` (setupFor) — `else if (p.kind === "comando" && p.cam) s.cam = p.cam;`
- `src/game/autopecas/autopecas.ts:40` (setupFor) — `s.slots.bico = p.bundle.bico; s.cam = p.bundle.cam; s.front = p.bundle.front ?? s.front; s.rear = p.bundle.rear ?? s.rear;`
- `src/game/engine-sound.ts:122` (ecuVoice) — `: { cc: displacement(src), cam: src.cam, compression: src.compression, intake: src.airFilter !== "original", ...ecuVoice(src) };`
- `src/game/engine-sound.ts:371` (accel) — `const cam = this.v.cam === "ma" ? 2.4 : this.v.cam === "mb" ? 1.4 : 1;`
- `src/game/engineering/dados/audit.ts:168` (add) — `chk("sincronismo", "Sincronismo e duração do comando", "PENDENTE", `comando "${s.cam}": duração e ângulos de abertura sem ficha`),`
- `src/game/engineering/dados/audit.ts:264` (igualStd) — `const declara = !igualStd && (p.hpMul != null || (p.flow != null && p.flow !== 1) || p.clutchNm != null || p.front != null || p.rear != null || !!p.cam || p.crr != null || p.grip != null || p.kg != null || p.cc != null |`
- `src/game/engineering/dados/audit.ts:299` (auditar) — `const montadas = new Set([...Object.values(snapshot.slots), `comando-${snapshot.cam}`]);`
- `src/game/engineering/eng.ts:69` (buildSetup) — `if (d.cam !== STOCK_SETUP.cam) s.cam = d.cam;`
- `src/game/mechlimits.ts:106` (has) — `const cam = CAM_FX[s.cam] ?? CAM_FX.original;`
- `src/game/nexus-update/registry.ts:98` (categories) — `const ids = [k.id, "cilindro-4mm", b.pistao, b.biela, b.bico, b.modulo, b.molas, b.bomba, "embreagem-p21-grau", `comando-${b.cam}`].filter((x): x is string => !!x);`
- `src/game/part-sheet.ts:69` (block) — `const cam = CAM_FX[s.cam] ?? CAM_FX.original;`
- `src/game/part-sheet.ts:70` (block) — `block("comando", CAM_LABEL[s.cam] ?? s.cam, { desc: "Abre e fecha as válvulas; define onde o motor tem força.", fis: "Levantamento, duração e cruzamento de válvulas.",`
- `src/game/pericia.ts:23` (factors) — `if (s.cam !== S.cam) f.push({ id: "cam", nome: `Comando ${CAM_LABEL[s.cam]}`, revert: (x) => ({ ...x, cam: S.cam }), solo: () => ({ ...S, cam: s.cam }) });`
- `src/game/pericia.ts:74` (pericia) — `motor: { cilindradaCc: displacement(s), ...e, ficha: stats(b, s, b.tank), taxa: s.compression, comando: CAM_LABEL[s.cam], km: s.km, oleoKm: s.oilKm },`
- `src/game/physics.ts:200` (finite) — `const cam = typeof raw.cam === "string" && raw.cam in CAM_FX ? raw.cam as Cam : STOCK_SETUP.cam;`
- `src/game/physics.ts:447` (flow) — `const rpmPeak = TITAN_160.rpmPeak + (CAM_FX[kit.bundle!.cam] ?? CAM_FX.original).rpm + list.reduce((n, x) => n + (x.rpmPeak ?? 0), 0);`
- `src/game/physics.ts:639` (engineCalc) — `const cam = CAM_FX[s.cam] ?? CAM_FX.original;`
- `src/game/physics.ts:676` (valveFloatRpm) — `const cam = CAM_FX[s.cam] ?? CAM_FX.original;`
- `src/game/physics.ts:725` (has) — `if (!cavas) add("Válvula atropelada", (CAM_FX[s.cam] ?? CAM_FX.original).risk, "Comando bravo sem cavas no pistão");`
- `src/game/prancha/board.ts:77` (add) — `dados: [{ k: "Perfil", v: s.cam, o: "PEÇA INSTALADA" }, { k: "Pico de potência", v: `${e.rpmPeak} rpm`, o: "CALCULADO" }, { k: "Flutuação de válvula", v: `${bd.floatRpm} rpm`, o: "ESTIMADO" }, nc("Levante"), nc("Duração"`
- `src/game/preload-report.ts:48` (H) — `const cam = CAM_FX[s.cam] ?? CAM_FX.original;`
- `src/game/preload-report.ts:49` (H) — `L.push(`- COMANDO    ${CAM_LABEL[s.cam] ?? s.cam}  [pico ${cam.rpm >= 0 ? "+" : ""}${cam.rpm} rpm · hp ×${cam.mul}]`, `- CABEÇOTE   taxa ${s.compression}:1`, `- RELAÇÃO    ${s.front}×${s.rear} | pneu ${s.psi} psi | desga`
- `src/game/preparador/preparador.ts:61` (comKit) — `return { ...s, cam: k.cam, services: [...s.services.filter((id) => !(k.services && /^pino-/.test(id))), ...(k.services ?? []).filter((id) => !s.services.includes(id))] };`
- `src/game/preparador/preparador.ts:164` (linhas) — `if (novo.cam !== atual.cam) out.push({ item: "comando", acao: "substituir", detalhe: `Comando ${novo.cam}`, preco: 0, noEstoque: true });`
### consumable
- `src/game/preparador/preparador.ts:89` (melhorEmbreagem) — `const opts = PARTS_CATALOG.filter((p) => p.kind === "embreagem" && (p.clutchNm ?? 0) >= T * 1.15 && !p.consumable).sort((a, z) => a.price - z.price);`
- `src/game/store.ts:192` (migr) — `const mounted = [...Object.values(st.slots ?? {}), `pinhao-${st.front}`, `coroa-${st.rear}`].filter((id): id is string => !!id && !!partById(id) && !partById(id)!.consumable && !isFactoryPiece(id));`
- `src/game/workshop.ts:44` (runService) — `if (part?.consumable) continue;`
- `src/game/workshop.ts:57` (runService) — `for (const pid of x.install || x.prepFor ? [] : needs(p, x).req) if (partById(pid)?.consumable) { const i = parts.indexOf(pid); if (i >= 0) parts.splice(i, 1); }`
### cam
- `src/game/agr/agr.ts:46` (snapshotOf) — `fuel: s.fuel, psi: s.psi, compression: s.compression, cam: String(s.cam),`
- `src/game/autopecas/autopecas.ts:37` (setupFor) — `else if (p.kind === "comando" && p.cam) s.cam = p.cam;`
- `src/game/autopecas/autopecas.ts:40` (setupFor) — `s.slots.bico = p.bundle.bico; s.cam = p.bundle.cam; s.front = p.bundle.front ?? s.front; s.rear = p.bundle.rear ?? s.rear;`
- `src/game/engine-sound.ts:122` (ecuVoice) — `: { cc: displacement(src), cam: src.cam, compression: src.compression, intake: src.airFilter !== "original", ...ecuVoice(src) };`
- `src/game/engine-sound.ts:371` (accel) — `const cam = this.v.cam === "ma" ? 2.4 : this.v.cam === "mb" ? 1.4 : 1;`
- `src/game/engineering/dados/audit.ts:168` (add) — `chk("sincronismo", "Sincronismo e duração do comando", "PENDENTE", `comando "${s.cam}": duração e ângulos de abertura sem ficha`),`
- `src/game/engineering/dados/audit.ts:264` (igualStd) — `const declara = !igualStd && (p.hpMul != null || (p.flow != null && p.flow !== 1) || p.clutchNm != null || p.front != null || p.rear != null || !!p.cam || p.crr != null || p.grip != null || p.kg != null || p.cc != null |`
- `src/game/engineering/dados/audit.ts:299` (auditar) — `const montadas = new Set([...Object.values(snapshot.slots), `comando-${snapshot.cam}`]);`

## Fórmulas nas mesmas funções
- **Flambagem de Euler**: $P_{cr} = \frac{\pi^2 E I}{(K L)^2}$ — E = módulo de elasticidade [Pa]; I = momento de inércia de área [m⁴]; L = comprimento [m]; K = fator de apoio [—]
- **Consumo específico (BSFC)**: $\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$ — P = potência [kW]; BSFC = consumo específico [kg/kWh]; ρ_f = densidade do combustível [kg/L]

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
—

## Mecânicas relacionadas
- `mec.agr.agr`
- `mec.autopecas.autopecas`
- `mec.engine-sound`
- `mec.engineering.dados.audit`
- `mec.engineering.eng`
- `mec.mechlimits`
- `mec.nexus-update.registry`
- `mec.part-sheet`
- `mec.pericia`
- `mec.physics`
- `mec.prancha.board`
- `mec.preload-report`
- `mec.preparador.preparador`
- `mec.store`
- `mec.workshop`

## Testes relacionados
Nenhum teste cita este id.

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- material: DADO NÃO IDENTIFICADO
- comprimento_mm: DADO NÃO IDENTIFICADO
- diametro_mm: DADO NÃO IDENTIFICADO
- densidade_kg_m3: DADO NÃO IDENTIFICADO
- modulo_elasticidade_Pa: DADO NÃO IDENTIFICADO
- coef_poisson: DADO NÃO IDENTIFICADO
- limite_escoamento_Pa: DADO NÃO IDENTIFICADO
- resistencia_tracao_Pa: DADO NÃO IDENTIFICADO
- condutividade_W_mK: DADO NÃO IDENTIFICADO
- calor_especifico_J_kgK: DADO NÃO IDENTIFICADO
- tolerancias: DADO NÃO IDENTIFICADO
- tratamento_termico: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
