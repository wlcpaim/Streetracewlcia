# Molas duplas reforçadas

- ID: `motor.molas-de-valvula.molas-duplas` · interno `molas-duplas`
- Marca: Kibbel · Spec: Dupla · pratos aço
- Categoria: motor / molas-de-valvula · tipo `molas` · slot `molas`
- Original de fábrica: não · Motos: titan160, factor150
- Registro: `src/game/parts.ts:228` · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
Molas de válvula: Dupla · pratos aço

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| material | aço — | CONFIRMADO_NO_CODIGO | texto do catálogo (nome/spec); não verificado por ensaio |
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| comprimento_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| diametro_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| densidade_kg_m3 | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| modulo_elasticidade_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| coef_poisson | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| limite_escoamento_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| resistencia_tracao_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| condutividade_W_mK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| calor_especifico_J_kgK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tolerancias | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tratamento_termico | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| fix | {"Válvula atropelada":25} pontos | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| preco | 1380 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:molas
- `src/game/autopecas/autopecas.ts:42` (setupFor) — `if (p.bundle.molas) s.slots.molas = p.bundle.molas;`
- `src/game/kits/kit70.ts:50` (has) — `it.push({ grupo: "Cabeçote", peca: "Molas de válvula", id: s.slots.molas ?? null, classe: has("molas", "molas-original") ? "EXIGE ADAPTAÇÃO" : "COMPATÍVEL", motivo: `Corte ${e.rpmLimit} rpm.` });`
- `src/game/overhaul22.ts:195` (valve22) — `const springMul = s.slots.molas === "molas-duplas" ? 1.35 : s.slots.molas === "molas-pratos" ? 1.35 : 1;`
- `src/game/overhaul22.ts:196` (valve22) — `const mass = EST22.valveMassKg * (s.slots.molas === "molas-pratos" ? 0.85 : 1);`
- `src/game/physics.ts:648` (engineCalc) — `for (const k of ["molas", "biela"] as Slot[]) mul *= slotPart(s.slots[k], k).hpMul ?? 1;`
- `src/game/physics.ts:678` (valveFloatRpm) — `return 10300 - cam.risk * 40 - liftSvc * 150 + ((slotPart(s.slots.molas, "molas").fix ?? {})["Válvula atropelada"] ?? 0) * 40;`
- `src/game/physics.ts:745` (over) — `for (const k of ["embreagem", "molas", "biela"] as Slot[]) for (const [c, v] of Object.entries(slotPart(s.slots[k], k).fix ?? {})) fixes[c] = (fixes[c] ?? 0) + v;`
- `src/game/rootcause.ts:68` (valveTree) — `const molas = s.services.includes("molas-duplas") || s.slots.molas !== STOCK_SETUP.slots.molas;`
- `src/game/stresscheck/monitor.ts:357` (add) — `const valveFactory = s.cam === "original" && s.slots.molas === STOCK_SLOTS.molas && k.floatRpm >= valveFloatRpm(STOCK_SETUP) && st.rpm <= this.lim + 1;`
- `src/nexus/aeic.ts:48` (D) — `D("B", "molas", "Molas, pratos e travas das válvulas", { peca: "molas", usa: ["physics.ts#slots.molas", "enginephys.ts#valveTrain"], liga: ["valv-adm", "valv-esc"] }),`
### fix
- `src/game/cloud/cloud.server.ts:69` (startRun) — `if (fixState.failures.length) { await beat("Fix Center", "realgear.fix/1"); await beat("Repair Sandbox", "runFunnel overrides"); }`
- `src/game/cloud/cloud.server.ts:135` (settleAxles) — `fix_report: (inv?.fix ?? null) as never, sandbox_report: (inv?.sandbox ?? null) as never,`
- `src/game/cloud/cloud.server.ts:138` (settleAxles) — `if (inv) { await logEvent(runId, "Fix Center", "CAUSA RAIZ", inv.fix.causaRaiz.map((a) => `${a.metric}: ${a.culpado}`).join("; ")); await logEvent(runId, "Repair Sandbox", "REPRODUÇÃO", inv.sandbox.mensagem); await beat(`
- `src/game/cloud/cloud.server.ts:146` (settleInvestigation) — `if (response.schema !== "realgear.fix/1.0.0" || !py || typeof py !== "object" || py.failureId !== ev.failureId) {`
- `src/game/cloud/cloud.server.ts:154` (settleInvestigation) — `await beat("Python Investigator", "realgear.fix/1.0.0");`
- `src/game/intel/audit.ts:148` (promptFor) — ``4. Esperado / abordagem: ${f.expected}. Fórmula de referência: ${f.formula}. Correção sugerida: ${f.fix}`,`
- `src/game/mechlimits.ts:91` (fixOf) — `const fixOf = (s: Setup, slot: "biela" | "molas" | "embreagem", cause: string) => (slotPart(s.slots[slot], slot).fix ?? {})[cause] ?? 0;`
- `src/game/physics.ts:678` (valveFloatRpm) — `return 10300 - cam.risk * 40 - liftSvc * 150 + ((slotPart(s.slots.molas, "molas").fix ?? {})["Válvula atropelada"] ?? 0) * 40;`

## Fórmulas nas mesmas funções
- **Potência mecânica / torque**: $P = T\,\omega \;\Leftrightarrow\; T = P/\omega$ — P = potência [W]; T = torque [N·m]; ω = velocidade angular [rad/s]
- **Função de Wiebe (fração queimada)**: $x_b = 1 - e^{-a\left(\frac{\theta-\theta_0}{\Delta\theta}\right)^{m+1}}$ — x_b = fração de massa queimada [—]; θ = ângulo do virabrequim [°]; a, m = parâmetros de forma [—]

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
—

## Mecânicas relacionadas
- `mec.autopecas.autopecas`
- `mec.kits.kit70`
- `mec.overhaul22`
- `mec.physics`
- `mec.rootcause`
- `mec.stresscheck.monitor`
- `mec.src.nexus.aeic`
- `mec.cloud.cloud.server`
- `mec.intel.audit`
- `mec.mechlimits`

## Testes relacionados
- `src/test/physics-overhaul-022.test.ts`

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- comprimento_mm: DADO NÃO IDENTIFICADO
- diametro_mm: DADO NÃO IDENTIFICADO
- densidade_kg_m3: DADO NÃO IDENTIFICADO
- modulo_elasticidade_Pa: DADO NÃO IDENTIFICADO
- coef_poisson: DADO NÃO IDENTIFICADO
- limite_escoamento_Pa: DADO NÃO IDENTIFICADO
- resistencia_tracao_Pa: DADO NÃO IDENTIFICADO
- condutividade_W_mK: DADO NÃO IDENTIFICADO
- calor_especifico_J_kgK: DADO NÃO IDENTIFICADO
- tolerancias: DADO NÃO IDENTIFICADO
- tratamento_termico: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
