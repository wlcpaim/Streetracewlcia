# Cilindro 57,3 mm (STD)

- ID: `motor.cilindro.cilindro-std-honda` · interno `cilindro-std-honda`
- Marca: KMP · Spec: STD
- Categoria: motor / cilindro · tipo `cilindro` · slot `cilindro`
- Original de fábrica: não · Motos: titan160, factor150
- Registro: `src/game/parts.ts:285` · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
Cilindro: STD

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| diametro_mm | 57.3 mm | CONFIRMADO_NO_CODIGO | texto do catálogo (nome/spec); não verificado por ensaio |
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| material | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| comprimento_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| densidade_kg_m3 | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| modulo_elasticidade_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| coef_poisson | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| limite_escoamento_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| resistencia_tracao_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| condutividade_W_mK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| calor_especifico_J_kgK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tolerancias | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tratamento_termico | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| preco | 1035 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:cilindro
- `src/game/engineering/dados/audit.ts:108` (conexoes) — `const cyl = slotPart(s.slots.cilindro, "cilindro"), pis = slotPart(s.slots.pistao, "pistao"), bie = slotPart(s.slots.biela, "biela");`
- `src/game/engineering/dados/pipeline.ts:42` (nexusRevisar) — `const cyl = slotPart(a.snapshot.slots.cilindro, "cilindro"), d = boreOf(cyl, a.bikeId), s = strokeReal(a.bikeId, a.snapshot);`
- `src/game/mechanic.ts:135` (pullAdvice) — `if (s.airFilter === "original" && s.slots.cilindro !== "cilindro-original") return "Motor maior respirando pelo filtro original. Ele quer mais ar.";`
- `src/game/mechanic.ts:136` (pullAdvice) — `if (s.slots.cilindro === "cilindro-original" && dist >= 500) return "O conjunto tá redondo. Pra andar mais, tem que fuçar a moto.";`
- `src/game/mechlimits.ts:99` (buildOf) — `const cyl = slotPart(s.slots.cilindro, "cilindro");`
- `src/game/physics.ts:176` (finite) — `if (slots.cilindro === "cilindro-4mm" && slots.vira === STOCK_SLOTS.vira) slots.vira = "vira-ww3";`
- `src/game/physics.ts:424` (mixtureCalc) — `const cyl = slotPart(s.slots.cilindro, "cilindro");`
- `src/game/physics.ts:537` (ccOf) — `const c = slotPart(s.slots.cilindro, "cilindro");`
- `src/game/physics.ts:646` (engineCalc) — `mul *= slotPart(s.slots.cilindro, "cilindro").hpMul ?? 1;`
- `src/game/physics.ts:713` (add) — `const cyl = slotPart(s.slots.cilindro, "cilindro");`
- `src/game/records.ts:30` (displacement) — `const cc = CYL_CC[s.slots.cilindro ?? "cilindro-original"] ?? 162.7;`
- `src/game/rootcause.ts:36` (fuelTree) — `const cyl = partById(s.slots.cilindro), tbi = partById(s.slots.tbi);`
- `src/game/workshop.ts:89` (kit4Done) — `export const kit4Done = (p: Player) => p.setup.slots.cilindro === KIT4_CYL && p.setup.cam === KIT4_BUNDLE.cam && p.setup.services.includes("pino-2") && kit4Pieces().every((id) => { const k = partById(id)?.kind as Slot; r`
- `src/nexus/aeic.ts:36` (D) — `D("A", "cilindro", "Cilindro / camisa", { dados: ["c:diametro"], peca: "cilindro", usa: ["physics.ts#slots.cilindro", "enginephys.ts#cylVol"], liga: ["pistao", "cabecote"] }),`

## Fórmulas nas mesmas funções
- **Área do pistão / cilindrada**: $A = \frac{\pi D^2}{4},\quad V_d = A\,S$ — D = diâmetro [m]; S = curso [m]; A = área [m²]; V_d = cilindrada [m³]
- **Consumo específico (BSFC)**: $\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$ — P = potência [kW]; BSFC = consumo específico [kg/kWh]; ρ_f = densidade do combustível [kg/L]

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
—

## Mecânicas relacionadas
- `mec.engineering.dados.audit`
- `mec.engineering.dados.pipeline`
- `mec.mechanic`
- `mec.mechlimits`
- `mec.physics`
- `mec.records`
- `mec.rootcause`
- `mec.workshop`
- `mec.src.nexus.aeic`

## Testes relacionados
Nenhum teste cita este id.

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- material: DADO NÃO IDENTIFICADO
- comprimento_mm: DADO NÃO IDENTIFICADO
- densidade_kg_m3: DADO NÃO IDENTIFICADO
- modulo_elasticidade_Pa: DADO NÃO IDENTIFICADO
- coef_poisson: DADO NÃO IDENTIFICADO
- limite_escoamento_Pa: DADO NÃO IDENTIFICADO
- resistencia_tracao_Pa: DADO NÃO IDENTIFICADO
- condutividade_W_mK: DADO NÃO IDENTIFICADO
- calor_especifico_J_kgK: DADO NÃO IDENTIFICADO
- tolerancias: DADO NÃO IDENTIFICADO
- tratamento_termico: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
