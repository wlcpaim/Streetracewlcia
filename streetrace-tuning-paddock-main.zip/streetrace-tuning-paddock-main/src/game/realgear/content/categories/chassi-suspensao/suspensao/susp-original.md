# Garfo telescópico · amortecedor duplo

- ID: `chassi-suspensao.suspensao.susp-original` · interno `susp-original`
- Marca: Honda · Spec: Original
- Categoria: chassi-suspensao / suspensao · tipo `susp` · slot `susp`
- Original de fábrica: sim · Motos: titan160, factor150
- Registro: `src/game/parts.ts:184` (coroa) · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
Suspensão: Original

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| massa_delta_kg | 0 kg | IMPLEMENTADO_SEM_VALIDACAO_FISICA | src/game/parts.ts · PARTS_CATALOG["susp-original"].kg (valor de jogo) |
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| material | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| comprimento_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| diametro_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| densidade_kg_m3 | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| modulo_elasticidade_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| coef_poisson | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| limite_escoamento_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| resistencia_tracao_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| condutividade_W_mK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| calor_especifico_J_kgK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tolerancias | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tratamento_termico | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| kg | 0 kg | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| preco | 0 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:susp
- `src/game/physics.ts:779` (tireCalc) — `for (const k of ["bateria", "susp", "pneu", "escape", "embreagem", "roda"] as Slot[]) kg += slotPart(s.slots[k], k).kg ?? 0;`
### kg
- `src/game/autopecas/analise.ts:21` (buildAnalise) — `const motos = BIKES.map((b) => { const e = engine(b, STOCK_SETUP), s = stats(b, STOCK_SETUP); return { id: b.id, nome: b.name, hp: s.hp, torque: s.torque, kg: s.kg, rpmPeak: e.rpmPeak, rpmLimit: e.rpmLimit, marchas: gear`
- `src/game/autopecas/analise.ts:40` (analiseTXT) — `for (const m of a.motos) L.push(`- ${m.nome}: ${m.hp} cv · ${m.torque} kgf·m · ${m.kg} kg · pico ${m.rpmPeak} rpm · corte ${m.rpmLimit} rpm · marchas ${m.marchas.join("/")} km/h · carga ${m.carga}`);`
- `src/game/autopecas/autopecas.ts:80` (w) — `C.push({ nome: "Relação peso/potência", formula: "kg/cv = massa seca / P", conta: `${n(st1.kg, 1)} / ${n(st1.hp, 1)}`, resultado: `${n(st1.kg / st1.hp, 2)} kg/cv`, origem: "CALCULADO" });`
- `src/game/autopecas/autopecas.ts:124` (lhv) — `const g = gearSpeeds(b, s1), r = tireRadius(b.tires) ?? NaN, i = s1.rear / s1.front, m = st1.kg + 75;`
- `src/game/autopecas/autopecas.ts:131` (lhv) — `C.push({ nome: "Massa com piloto", formula: "m = massa da moto + piloto 75 kg", conta: `${n(st1.kg, 1)} + 75`, resultado: `${n(m, 1)} kg`, origem: "CALCULADO" });`
- `src/game/engineering/dados/audit.ts:216` (assinatura) — `return { hp: e.hp, rpm: e.rpmLimit, kg: st.kg, top: gearSpeeds(b, s).at(-1) ?? 0, cap: clutchCapNm(s), duty: injectionAt(b, s, 8000, 1).duty, crr: t.crr, grip: t.grip, cc: ccOf(b, s) };`
- `src/game/engineering/dados/audit.ts:226` (ficha) — `{ nome: "Massa vs original", valor: p.kg ?? null, unidade: "kg", origem: p.kg != null ? "JOGO" : "AUSENTE", fonte: "parts.ts › kg" },`
- `src/game/engineering/dados/audit.ts:264` (igualStd) — `const declara = !igualStd && (p.hpMul != null || (p.flow != null && p.flow !== 1) || p.clutchNm != null || p.front != null || p.rear != null || !!p.cam || p.crr != null || p.grip != null || p.kg != null || p.cc != null |`

## Fórmulas nas mesmas funções
- **Velocidade angular**: $\omega = \frac{2\pi n}{60}$ — ω = velocidade angular [rad/s]; n = rotação [rpm]
- **Potência mecânica / torque**: $P = T\,\omega \;\Leftrightarrow\; T = P/\omega$ — P = potência [W]; T = torque [N·m]; ω = velocidade angular [rad/s]
- **Consumo específico (BSFC)**: $\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$ — P = potência [kW]; BSFC = consumo específico [kg/kWh]; ρ_f = densidade do combustível [kg/L]

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
—

## Mecânicas relacionadas
- `mec.physics`
- `mec.autopecas.analise`
- `mec.autopecas.autopecas`
- `mec.engineering.dados.audit`

## Testes relacionados
Nenhum teste cita este id.

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- material: DADO NÃO IDENTIFICADO
- comprimento_mm: DADO NÃO IDENTIFICADO
- diametro_mm: DADO NÃO IDENTIFICADO
- densidade_kg_m3: DADO NÃO IDENTIFICADO
- modulo_elasticidade_Pa: DADO NÃO IDENTIFICADO
- coef_poisson: DADO NÃO IDENTIFICADO
- limite_escoamento_Pa: DADO NÃO IDENTIFICADO
- resistencia_tracao_Pa: DADO NÃO IDENTIFICADO
- condutividade_W_mK: DADO NÃO IDENTIFICADO
- calor_especifico_J_kgK: DADO NÃO IDENTIFICADO
- tolerancias: DADO NÃO IDENTIFICADO
- tratamento_termico: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
