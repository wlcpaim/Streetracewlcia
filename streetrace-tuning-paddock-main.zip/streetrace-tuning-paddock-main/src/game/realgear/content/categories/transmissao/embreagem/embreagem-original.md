# Discos e molas

- ID: `transmissao.embreagem.embreagem-original` · interno `embreagem-original`
- Marca: Honda · Spec: Original
- Categoria: transmissao / embreagem · tipo `embreagem` · slot `embreagem`
- Original de fábrica: sim · Motos: titan160, factor150
- Registro: `src/game/parts.ts:213` · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
Embreagem: Original

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| material | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| comprimento_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| diametro_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| densidade_kg_m3 | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| modulo_elasticidade_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| coef_poisson | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| limite_escoamento_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| resistencia_tracao_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| condutividade_W_mK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| calor_especifico_J_kgK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tolerancias | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tratamento_termico | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| clutchNm | 22 N·m | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| preco | 0 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:embreagem
- `src/game/kits/kit70.ts:53` (has) — `it.push({ grupo: "Transmissão", peca: "Embreagem", id: s.slots.embreagem ?? null, classe: clutch >= torque ? "COMPATÍVEL" : "INCOMPATÍVEL", motivo: `Capacidade ${r1(clutch)} N·m vs torque ${torque} N·m (T = P/ω no pico).`
- `src/game/physics.ts:745` (over) — `for (const k of ["embreagem", "molas", "biela"] as Slot[]) for (const [c, v] of Object.entries(slotPart(s.slots[k], k).fix ?? {})) fixes[c] = (fixes[c] ?? 0) + v;`
- `src/game/physics.ts:779` (tireCalc) — `for (const k of ["bateria", "susp", "pneu", "escape", "embreagem", "roda"] as Slot[]) kg += slotPart(s.slots[k], k).kg ?? 0;`
- `src/game/realgear/bridge/exporter.ts:25` (exportProject) — `const bico = partById(s.slots.bico), emb = partById(s.slots.embreagem);`
- `src/game/parts.ts:368` (clutchCapNm) — `(slotPart(s.slots.embreagem, "embreagem").clutchNm ?? 22) * (s.services.includes(CLUTCH_SPORT) ? CLUTCH_SPORT_MUL : 1);`
### clutchNm
- `src/game/engineering/dados/audit.ts:231` (ficha) — `if (p.clutchNm != null) dados.push({ nome: "Capacidade da embreagem", valor: p.clutchNm, unidade: "N·m", origem: "JOGO", fonte: "parts.ts › clutchNm" });`
- `src/game/engineering/dados/audit.ts:243` (ficha) — `if (p.kind === "embreagem") { const tq = torqueNm(b, { ...STOCK_SETUP }); checks.push(p.clutchNm == null ? chk("cap", "Capacidade ≥ torque da moto original", "PENDENTE", "peça não declara capacidade de torque") : chk("ca`
- `src/game/engineering/dados/audit.ts:264` (igualStd) — `const declara = !igualStd && (p.hpMul != null || (p.flow != null && p.flow !== 1) || p.clutchNm != null || p.front != null || p.rear != null || !!p.cam || p.crr != null || p.grip != null || p.kg != null || p.cc != null |`
- `src/game/mechlimits.ts:237` (omegaGb) — `const slipW = st.shiftT > 0 || omega <= omegaGb ? 0 : clutchSlipW(Math.min(ph.crankNm, k.clutchNm), omega, omegaGb);`
- `src/game/nexus-update/registry.ts:36` (partFields) — `if (p.clutchNm !== undefined) f.push({ k: "clutchNm", label: "Capacidade embreagem", type: "number", unit: "N·m", formula: "patina se torque > clutchNm" });`
- `src/game/part-sheet.ts:51` (P) — `form: [`capacidade = ${P("embreagem")?.clutchNm ?? 22} N·m`, `torque motor = ${f(tqNm, 1)} N·m → ${tqNm > (P("embreagem")?.clutchNm ?? 22) ? "PATINA" : "acopla"}`, "P_patinagem = T × Δω"],`
- `src/game/prancha/board.ts:86` (add) — `dados: [emb.v, { k: "Capacidade de torque", v: `${f(bd.clutchNm, 1)} N·m`, o: "ESTIMADO" }, { k: "Capacidade térmica", v: `${f(bd.clutchCapJ / 1000, 1)} kJ`, o: "ESTIMADO" }, nc("Nº de discos"), nc("Massa")],`
- `src/game/preload-report.ts:44` (H) — `const fx = p ? [p.hp && `+${p.hp} cv`, p.hpMul && p.hpMul !== 1 && `hp ×${p.hpMul}`, p.kg && `${p.kg > 0 ? "+" : ""}${p.kg} kg`, p.flow && `vazão ×${p.flow}`, p.need && `pede +${Math.round(p.need * 100)}% comb.`, p.clutc`

## Fórmulas nas mesmas funções
- **Velocidade angular**: $\omega = \frac{2\pi n}{60}$ — ω = velocidade angular [rad/s]; n = rotação [rpm]
- **Potência mecânica / torque**: $P = T\,\omega \;\Leftrightarrow\; T = P/\omega$ — P = potência [W]; T = torque [N·m]; ω = velocidade angular [rad/s]
- **Segunda lei de Newton**: $a = \frac{F}{m}$ — a = aceleração [m/s²]; F = força resultante [N]; m = massa [kg]
- **Função de Wiebe (fração queimada)**: $x_b = 1 - e^{-a\left(\frac{\theta-\theta_0}{\Delta\theta}\right)^{m+1}}$ — x_b = fração de massa queimada [—]; θ = ângulo do virabrequim [°]; a, m = parâmetros de forma [—]
- **Flambagem de Euler**: $P_{cr} = \frac{\pi^2 E I}{(K L)^2}$ — E = módulo de elasticidade [Pa]; I = momento de inércia de área [m⁴]; L = comprimento [m]; K = fator de apoio [—]
- **Consumo específico (BSFC)**: $\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$ — P = potência [kW]; BSFC = consumo específico [kg/kWh]; ρ_f = densidade do combustível [kg/L]
- **Relação de transmissão final**: $i_f = \frac{Z_{coroa}}{Z_{pinhão}}$ — Z = número de dentes [—]

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
—

## Mecânicas relacionadas
- `mec.kits.kit70`
- `mec.physics`
- `mec.realgear.bridge.exporter`
- `mec.parts`
- `mec.engineering.dados.audit`
- `mec.mechlimits`
- `mec.nexus-update.registry`
- `mec.part-sheet`
- `mec.prancha.board`
- `mec.preload-report`

## Testes relacionados
- `src/test/kit4-clutch.test.ts`
- `src/test/v6.test.ts`

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- material: DADO NÃO IDENTIFICADO
- comprimento_mm: DADO NÃO IDENTIFICADO
- diametro_mm: DADO NÃO IDENTIFICADO
- densidade_kg_m3: DADO NÃO IDENTIFICADO
- modulo_elasticidade_Pa: DADO NÃO IDENTIFICADO
- coef_poisson: DADO NÃO IDENTIFICADO
- limite_escoamento_Pa: DADO NÃO IDENTIFICADO
- resistencia_tracao_Pa: DADO NÃO IDENTIFICADO
- condutividade_W_mK: DADO NÃO IDENTIFICADO
- calor_especifico_J_kgK: DADO NÃO IDENTIFICADO
- tolerancias: DADO NÃO IDENTIFICADO
- tratamento_termico: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
