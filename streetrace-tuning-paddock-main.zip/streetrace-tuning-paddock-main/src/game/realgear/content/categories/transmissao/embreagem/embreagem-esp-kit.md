# Discos esportivos + mola

- ID: `transmissao.embreagem.embreagem-esp-kit` · interno `embreagem-esp-kit`
- Marca: Aftermarket · Spec: Material para preparar a embreagem montada
- Categoria: transmissao / embreagem · tipo `embreagem` · slot `embreagem`
- Original de fábrica: não · Motos: titan160, factor150
- Registro: `src/game/parts.ts:223` · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
Embreagem: Material para preparar a embreagem montada

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| material | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| comprimento_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| diametro_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| densidade_kg_m3 | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| modulo_elasticidade_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| coef_poisson | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| limite_escoamento_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| resistencia_tracao_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| condutividade_W_mK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| calor_especifico_J_kgK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tolerancias | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tratamento_termico | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| consumable | true bool | sim | não | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| preco | 480 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:embreagem
- `src/game/kits/kit70.ts:53` (has) — `it.push({ grupo: "Transmissão", peca: "Embreagem", id: s.slots.embreagem ?? null, classe: clutch >= torque ? "COMPATÍVEL" : "INCOMPATÍVEL", motivo: `Capacidade ${r1(clutch)} N·m vs torque ${torque} N·m (T = P/ω no pico).`
- `src/game/physics.ts:745` (over) — `for (const k of ["embreagem", "molas", "biela"] as Slot[]) for (const [c, v] of Object.entries(slotPart(s.slots[k], k).fix ?? {})) fixes[c] = (fixes[c] ?? 0) + v;`
- `src/game/physics.ts:779` (tireCalc) — `for (const k of ["bateria", "susp", "pneu", "escape", "embreagem", "roda"] as Slot[]) kg += slotPart(s.slots[k], k).kg ?? 0;`
- `src/game/realgear/bridge/exporter.ts:25` (exportProject) — `const bico = partById(s.slots.bico), emb = partById(s.slots.embreagem);`
- `src/game/parts.ts:368` (clutchCapNm) — `(slotPart(s.slots.embreagem, "embreagem").clutchNm ?? 22) * (s.services.includes(CLUTCH_SPORT) ? CLUTCH_SPORT_MUL : 1);`
### consumable
- `src/game/preparador/preparador.ts:89` (melhorEmbreagem) — `const opts = PARTS_CATALOG.filter((p) => p.kind === "embreagem" && (p.clutchNm ?? 0) >= T * 1.15 && !p.consumable).sort((a, z) => a.price - z.price);`
- `src/game/store.ts:192` (migr) — `const mounted = [...Object.values(st.slots ?? {}), `pinhao-${st.front}`, `coroa-${st.rear}`].filter((id): id is string => !!id && !!partById(id) && !partById(id)!.consumable && !isFactoryPiece(id));`
- `src/game/workshop.ts:44` (runService) — `if (part?.consumable) continue;`
- `src/game/workshop.ts:57` (runService) — `for (const pid of x.install || x.prepFor ? [] : needs(p, x).req) if (partById(pid)?.consumable) { const i = parts.indexOf(pid); if (i >= 0) parts.splice(i, 1); }`

## Fórmulas nas mesmas funções
- **Potência mecânica / torque**: $P = T\,\omega \;\Leftrightarrow\; T = P/\omega$ — P = potência [W]; T = torque [N·m]; ω = velocidade angular [rad/s]
- **Relação de transmissão final**: $i_f = \frac{Z_{coroa}}{Z_{pinhão}}$ — Z = número de dentes [—]

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
—

## Mecânicas relacionadas
- `mec.kits.kit70`
- `mec.physics`
- `mec.realgear.bridge.exporter`
- `mec.parts`
- `mec.preparador.preparador`
- `mec.store`
- `mec.workshop`

## Testes relacionados
- `src/test/kit4-clutch.test.ts`

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- material: DADO NÃO IDENTIFICADO
- comprimento_mm: DADO NÃO IDENTIFICADO
- diametro_mm: DADO NÃO IDENTIFICADO
- densidade_kg_m3: DADO NÃO IDENTIFICADO
- modulo_elasticidade_Pa: DADO NÃO IDENTIFICADO
- coef_poisson: DADO NÃO IDENTIFICADO
- limite_escoamento_Pa: DADO NÃO IDENTIFICADO
- resistencia_tracao_Pa: DADO NÃO IDENTIFICADO
- condutividade_W_mK: DADO NÃO IDENTIFICADO
- calor_especifico_J_kgK: DADO NÃO IDENTIFICADO
- tolerancias: DADO NÃO IDENTIFICADO
- tratamento_termico: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
