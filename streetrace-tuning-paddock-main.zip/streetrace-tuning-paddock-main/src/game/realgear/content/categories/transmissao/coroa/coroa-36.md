# Coroa 36T

- ID: `transmissao.coroa.coroa-36` · interno `coroa-36`
- Marca: Riffel · Spec: 428 · 36T
- Categoria: transmissao / coroa · tipo `coroa`
- Original de fábrica: não · Motos: titan160, factor150
- Registro: `src/game/parts.ts:75` (coroa) · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
coroa: 428 · 36T

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| material | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| comprimento_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| diametro_mm | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| densidade_kg_m3 | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| modulo_elasticidade_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| coef_poisson | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| limite_escoamento_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| resistencia_tracao_Pa | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| condutividade_W_mK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| calor_especifico_J_kgK | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tolerancias | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| tratamento_termico | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| rear | 36 dentes | sim | sim | não | IMPLEMENTADO_SEM_VALIDACAO_FISICA |
| preco | 134.9 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:coroa
- `src/game/acerto.ts:23` (bestSetup) — `const fronts = new Set([STOCK_FRONT, p.setup.front]);`
- `src/game/acerto.ts:27` (bestSetup) — `if (x.kind === "kit") pairs.push([x.front!, x.rear!]);`
- `src/game/acerto.ts:28` (bestSetup) — `if (x.kind === "pinhao") fronts.add(x.front!);`
- `src/game/acerto.ts:65` (has) — `const ownsF = preset.front === STOCK_FRONT || p.parts.some((id) => partById(id)?.front === preset.front);`
- `src/game/acerto.ts:72` (has) — `front: ownsF ? preset.front : p.setup.front,`
- `src/game/admin-lab.ts:94` (scenarios) — `if (p.kind === "pinhao" && p.front) out.push({ id: `peca:${p.id}`, group: "Relação", label: `Pinhão ${p.front}`, setup: { ...STOCK_SETUP, front: p.front } });`
- `src/game/agr/agr.ts:44` (snapshotOf) — `bikeId: b.id, bike: b.name, gear: `${s.front}x${s.rear}`,`
- `src/game/agr/maps.ts:49` (applyMap) — `const hasF = p.parts.includes(`pinhao-${m.setup.front}`), hasR = p.parts.includes(`coroa-${m.setup.rear}`);`
- `src/game/agr/maps.ts:50` (applyMap) — `if (m.setup.front !== p.setup.front || m.setup.rear !== p.setup.rear) {`
- `src/game/agr/maps.ts:51` (applyMap) — `if (hasF && hasR) setup = { ...setup, front: m.setup.front, rear: m.setup.rear };`
- `src/game/agr/maps.ts:52` (applyMap) — `else avisos.push(`Relação do mapa ${m.setup.front}x${m.setup.rear} não está no estoque: mantida ${p.setup.front}x${p.setup.rear}`);`
- `src/game/autopecas/autopecas.ts:34` (setupFor) — `if (p.kind === "kit") { s.front = p.front ?? s.front; s.rear = p.rear ?? s.rear; }`
- `src/game/autopecas/autopecas.ts:35` (setupFor) — `else if (p.kind === "pinhao") s.front = p.front ?? s.front;`
- `src/game/autopecas/autopecas.ts:40` (setupFor) — `s.slots.bico = p.bundle.bico; s.cam = p.bundle.cam; s.front = p.bundle.front ?? s.front; s.rear = p.bundle.rear ?? s.rear;`
- `src/game/autopecas/autopecas.ts:106` (vm) — `const i0 = s0.rear / s0.front, i1 = s1.rear / s1.front;`
### rear
- `src/game/acerto.ts:24` (bestSetup) — `const rears = new Set([STOCK_REAR, p.setup.rear]);`
- `src/game/acerto.ts:27` (bestSetup) — `if (x.kind === "kit") pairs.push([x.front!, x.rear!]);`
- `src/game/acerto.ts:29` (bestSetup) — `if (x.kind === "coroa") rears.add(x.rear!);`
- `src/game/acerto.ts:66` (has) — `const ownsR = preset.rear === STOCK_REAR || p.parts.some((id) => partById(id)?.rear === preset.rear);`
- `src/game/acerto.ts:73` (has) — `rear: ownsR ? preset.rear : p.setup.rear,`
- `src/game/admin-lab.ts:95` (scenarios) — `if (p.kind === "coroa" && p.rear) out.push({ id: `peca:${p.id}`, group: "Relação", label: `Coroa ${p.rear}`, setup: { ...STOCK_SETUP, rear: p.rear } });`
- `src/game/agr/agr.ts:44` (snapshotOf) — `bikeId: b.id, bike: b.name, gear: `${s.front}x${s.rear}`,`
- `src/game/agr/maps.ts:49` (applyMap) — `const hasF = p.parts.includes(`pinhao-${m.setup.front}`), hasR = p.parts.includes(`coroa-${m.setup.rear}`);`

## Fórmulas nas mesmas funções
Nenhuma fórmula detectada nas funções que leem esta peça.

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
—

## Mecânicas relacionadas
- `mec.acerto`
- `mec.admin-lab`
- `mec.agr.agr`
- `mec.agr.maps`
- `mec.autopecas.autopecas`

## Testes relacionados
- `src/test/oem-servitec.test.ts`

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- material: DADO NÃO IDENTIFICADO
- comprimento_mm: DADO NÃO IDENTIFICADO
- diametro_mm: DADO NÃO IDENTIFICADO
- densidade_kg_m3: DADO NÃO IDENTIFICADO
- modulo_elasticidade_Pa: DADO NÃO IDENTIFICADO
- coef_poisson: DADO NÃO IDENTIFICADO
- limite_escoamento_Pa: DADO NÃO IDENTIFICADO
- resistencia_tracao_Pa: DADO NÃO IDENTIFICADO
- condutividade_W_mK: DADO NÃO IDENTIFICADO
- calor_especifico_J_kgK: DADO NÃO IDENTIFICADO
- tolerancias: DADO NÃO IDENTIFICADO
- tratamento_termico: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
