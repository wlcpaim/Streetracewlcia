# Virabrequim

- ID: `outros.vira.vira-original` · interno `vira-original`
- Marca: Honda · Spec: Original
- Categoria: outros / vira · tipo `vira` · slot `vira`
- Original de fábrica: sim · Motos: titan160, factor150
- Registro: `src/game/parts.ts:239` · Status: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Função
Virabrequim: Original

## Propriedades físicas
| Propriedade | Valor | Estado | Origem |
|---|---|---|---|
| massa_kg | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |
| material | DADO NÃO IDENTIFICADO | DADO_NAO_IDENTIFICADO | DADO NÃO IDENTIFICADO |

## Parâmetros de jogo (cadastrado / usado / testado / ensaio físico)
| Campo | Valor | Usado no cálculo | Testado | Ensaio físico | Estado |
|---|---|---|---|---|---|
| preco | 0 R$ (BASE_USD) | não | não | não | CONFIRMADO_NO_CODIGO |

## Efeitos calculados pelo motor (onde a peça é lida)
### slot:vira
- `src/game/kits/kit70.ts:47` (has) — `it.push({ grupo: "Motor", peca: "Virabrequim", id: s.slots.vira ?? null, classe: "COMPATÍVEL", motivo: `Curso ${stroke ?? "?"} mm (ficha ${S ?? "?"} mm${stroke !== S ? " + pino cursado" : ""}).` });`
- `src/game/physics.ts:175` (finite) — `if (slots.biela === "vira-ww3") { slots.vira = "vira-ww3"; slots.biela = STOCK_SLOTS.biela; }`
- `src/game/physics.ts:176` (finite) — `if (slots.cilindro === "cilindro-4mm" && slots.vira === STOCK_SLOTS.vira) slots.vira = "vira-ww3";`
- `src/nexus/aeic.ts:41` (D) — `D("A", "virabrequim", "Virabrequim (munhões, contrapesos, moente)", { dados: ["c:curso"], peca: "vira", usa: ["physics.ts#slots.vira", "enginephys.ts#pistonX"], liga: ["biela", "prim-motora", "corrente-comando"] }),`

## Fórmulas nas mesmas funções
- **Potência mecânica / torque**: $P = T\,\omega \;\Leftrightarrow\; T = P/\omega$ — P = potência [W]; T = torque [N·m]; ω = velocidade angular [rad/s]
- **Consumo específico (BSFC)**: $\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$ — P = potência [kW]; BSFC = consumo específico [kg/kWh]; ρ_f = densidade do combustível [kg/L]

## Instalação na motocicleta
- 1. Identificação da peça: **CONFIRMADO_NO_CODIGO** — partById/slotPart resolvem o id no catálogo (`src/game/acerto.ts:65` (has))
- 2. Verificação de compatibilidade: **CONFIRMADO_NO_CODIGO** — MODEL_PARTS restringe peças por moto; inShop filtra a loja (`src/game/screens/Pecas.tsx:214` (list))
- 3. Sistema mecânico afetado: **CONFIRMADO_NO_CODIGO** — slot define o sistema substituído (`src/game/acerto.ts:38` (slotOpts))
- 4. Remoção/substituição do original: **CONFIRMADO_NO_CODIGO** — component-swap remove usinagem do componente trocado (`src/game/acerto.ts:33` (slotOpts))
- 5. Inclusão das propriedades físicas: **CONFIRMADO_NO_CODIGO** — physics lê a peça do slot (`src/game/admin-lab.ts:110` (pick))
- 6. Atualização de massa e distribuição de peso: **CONFIRMADO_NO_CODIGO** — massa entra em stats(); distribuição de peso: ver perguntas (`src/game/autopecas/analise.ts:21` (buildAnalise))
- 7. Atualização de geometria: **CONFIRMADO_NO_CODIGO** — buildOf/machOf/ccOf derivam geometria (`src/game/admin-lab.ts:41` (runTest))
- 8. Relações mecânicas: **CONFIRMADO_NO_CODIGO** — relação final e cadeia cinemática (`src/game/agr/agr.ts:68` (runTrack))
- 9. Recalcular física: **CONFIRMADO_NO_CODIGO** — engine()/stats()/stress() (`src/game/admin-lab.ts:37` (runTest))
- 10. Sistemas dependentes: **CONFIRMADO_NO_CODIGO** — step() + mechStep() por passo de simulação (`src/game/admin-lab.ts:46` (runTest))
- 11. Resultados da motocicleta: **CONFIRMADO_NO_CODIGO** — tempo, velocidade e quebra (`src/game/acerto.ts:15` (score))

## Dependências / kit
—

## Mecânicas relacionadas
- `mec.kits.kit70`
- `mec.physics`
- `mec.src.nexus.aeic`

## Testes relacionados
- `src/test/vira-stroke.test.ts`

## Dados pendentes
- massa_kg: DADO NÃO IDENTIFICADO
- material: DADO NÃO IDENTIFICADO

> Leitura 2026-11-14T02:12:01.595Z · código dbeb9561e5ab30c9
