# Relatório da Leitura de Conteúdo

Data 2026-11-09T21:11:28.923Z · código `74e70853db8420f8` · leitor 1.0.0

| Total | Valor |
|---|---|
| pecas | 126 |
| itens | 64 |
| motocicletas | 2 |
| mecanicas | 93 |
| mecanicas_implementadas | 78 |
| mecanicas_apenas_documentadas | 15 |
| formulas_localizadas | 16 |
| ocorrencias_de_formulas | 88 |
| modelos_teoricos_nao_implementados | 6 |
| relacoes | 1080 |
| dados_fisicos_identificados | 318 |
| dados_ausentes | 1274 |
| inconsistencias | 2 |
| arquivos_analisados | 306 |
| pendencias | 1274 |

## Categorias com peças
- motor: 34
- combustivel: 11
- admissao-escape: 11
- transmissao: 28
- eletrica: 24
- chassi-suspensao: 10
- pneus-rodas: 8

## Categorias sem nenhuma peça cadastrada
- freios
- dinamica

## Inconsistências
- **inc.campo-sem-uso.consumable** — Campo de peça "consumable" está cadastrado mas não foi encontrado leitura dele no código de cálculo
- **inc.curso-literal** — Curso literal no código não corresponde à ficha por moto (63.096 / 57.9 mm)
  - `src/game/enginephys.ts:26` `strokeMm: 63, // ficha Honda CG 160`
  - `src/game/mechlimits.ts:11` `const STROKE_MM = 63;`
  - `src/game/realgear/funnel.ts:31` `titan160: { boreMm: 57.3, strokeMm: 63.0, rodMm: null },`
  - `src/game/realgear/funnel.ts:34` `const MECH_STROKE_SRC = 63; // espelho de STROKE_MM em mechlimits.ts (o investigador confere a linha real)`

## Perguntas de instalação
- Uma peça mais pesada altera o centro de massa? → **NAO_IMPLEMENTADO**
- Uma peça mais pesada altera a massa total na aceleração? → **CONFIRMADO_NO_CODIGO**
- Uma relação de transmissão diferente altera a rotação da roda? → **CONFIRMADO_NO_CODIGO**
- Um pistão diferente altera a massa alternativa? → **NAO_IMPLEMENTADO**
- Uma biela diferente altera os esforços inerciais? → **CONFIRMADO_NO_CODIGO**
- Um comando de válvulas diferente altera admissão e escape? → **CONFIRMADO_NO_CODIGO**
- Um pneu diferente altera o raio efetivo e a relação final? → **NAO_IMPLEMENTADO**
- Uma alteração no sistema de freios altera a desaceleração calculada? → **NAO_IMPLEMENTADO**

## Limitações da leitura
- Detecção de fórmulas por padrões textuais: uma expressão escrita de forma não prevista pode não ser localizada (falso negativo) e um padrão genérico pode casar trechos não físicos (verificar o trecho citado).
- Atribuição de fórmula a peça: só quando a fórmula ocorre na mesma função que lê o campo/slot da peça.
- Valores de peças são parâmetros de jogo; nenhum foi validado por ensaio físico.
- Arquivos de interface (.tsx, ui/, screens/) entram no hash mas não na extração de mecânicas.

Cobertura: todas as peças de PARTS_CATALOG, serviços, perfis de comando, combustíveis e motos foram lidos. Propriedades físicas de material não cadastradas ficam como DADO NÃO IDENTIFICADO; nenhuma validação física foi declarada.
