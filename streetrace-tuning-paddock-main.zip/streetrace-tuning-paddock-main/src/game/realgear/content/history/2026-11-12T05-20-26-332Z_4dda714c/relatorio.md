# Relatório da Leitura de Conteúdo

Data 2026-11-12T05:20:26.332Z · código `4dda714ca1fa313f` · leitor 1.0.0

| Total | Valor |
|---|---|
| pecas | 142 |
| itens | 74 |
| motocicletas | 2 |
| mecanicas | 148 |
| mecanicas_implementadas | 129 |
| mecanicas_apenas_documentadas | 19 |
| formulas_localizadas | 16 |
| ocorrencias_de_formulas | 148 |
| modelos_teoricos_nao_implementados | 6 |
| relacoes | 1647 |
| dados_fisicos_identificados | 375 |
| dados_ausentes | 1409 |
| inconsistencias | 1 |
| arquivos_analisados | 463 |
| pendencias | 1409 |

## Categorias com peças
- motor: 42
- combustivel: 11
- admissao-escape: 11
- transmissao: 30
- eletrica: 26
- chassi-suspensao: 10
- pneus-rodas: 10
- outros: 2

## Categorias sem nenhuma peça cadastrada
- freios
- dinamica

## Inconsistências
- **inc.curso-literal** — Curso literal no código não corresponde à ficha por moto (63.096 / 57.9 / 57.8 / 49.5 mm)
  - `src/game/enginephys.ts:27` `strokeMm: 63, // ESTIMADO: fallback só para moto sem curso no catálogo (geoOf prefere ENGINE_CATALOG)`
  - `src/game/intel/changelog.ts:39` `{ id: "2026-11-10-geometria-catalogo", date: "2026-11-10", title: "Curso e biela do catálogo na física do motor", changes: ["mechlimits: removidos STROKE_MM = 63 e ROD_MM = 102,5; buildOf/physicsAt usam geoOf()", "geoOf `

## Perguntas de instalação
- Uma peça mais pesada altera o centro de massa? → **NAO_IMPLEMENTADO**
- Uma peça mais pesada altera a massa total na aceleração? → **CONFIRMADO_NO_CODIGO**
- Uma relação de transmissão diferente altera a rotação da roda? → **CONFIRMADO_NO_CODIGO**
- Um pistão diferente altera a massa alternativa? → **NAO_IMPLEMENTADO**
- Uma biela diferente altera os esforços inerciais? → **CONFIRMADO_NO_CODIGO**
- Um comando de válvulas diferente altera admissão e escape? → **CONFIRMADO_NO_CODIGO**
- Um pneu diferente altera o raio efetivo e a relação final? → **NAO_IMPLEMENTADO**
- Uma alteração no sistema de freios altera a desaceleração calculada? → **NAO_IMPLEMENTADO**

## Limitações da leitura
- Detecção de fórmulas por padrões textuais: uma expressão escrita de forma não prevista pode não ser localizada (falso negativo) e um padrão genérico pode casar trechos não físicos (verificar o trecho citado).
- Atribuição de fórmula a peça: só quando a fórmula ocorre na mesma função que lê o campo/slot da peça.
- Valores de peças são parâmetros de jogo; nenhum foi validado por ensaio físico.
- Arquivos de interface (.tsx, ui/, screens/) entram no hash mas não na extração de mecânicas.

Cobertura: todas as peças de PARTS_CATALOG, serviços, perfis de comando, combustíveis e motos foram lidos. Propriedades físicas de material não cadastradas ficam como DADO NÃO IDENTIFICADO; nenhuma validação física foi declarada.
