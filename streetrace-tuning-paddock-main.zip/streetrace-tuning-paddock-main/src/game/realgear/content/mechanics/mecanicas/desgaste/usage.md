# Mecânica: usage

- ID: `mec.usage` · mecanicas / desgaste
- Arquivo: `src/game/usage.ts` (41 linhas, sha256 e29bbbfd3a7835d4)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Street use crossed with the engine model: delivery consumption, tire wear and trip time all come from the real setup. Titan 160 stock on gasolina in city traffic. */ Game-scale tire life (km) for the factory compound. */ Each street race launch scrubs this many km-equivalent of tread. */

## Funções exportadas (saídas)
- L15: `export function jobKmPerL(b: BikeModel, s: Setup) {`
- L24: `export function tireWearMul(s: Setup) {`
- L31: `export const tireWear = (tireKm: number) => Math.min(1, Math.max(0, tireKm / TIRE_LIFE_KM));`
- L34: `export function hpTripMul(b: BikeModel, s: Setup) {`

## Entradas tipadas
- b: BikeModel
- s: Setup

## Fórmulas
### Consumo específico (BSFC)
$$\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$$
- P: potência [kW]
- BSFC: consumo específico [kg/kWh]
- ρ_f: densidade do combustível [kg/L]
- Hipóteses: plena carga
- Limitações: BSFC fixo por combustível
- `src/game/usage.ts:17` (lPerKwh) `const lPerKwh = (f: Setup["fuel"]) => BSFC[f] / FUEL_DENSITY[f];`

## Dependências
- `mec.physics`
- `mec.parts`

## Dependentes
- `mec.jobrun`

## Testes existentes
- `src/test/usage.test.ts`

## Limitações
- contém valores marcados como estimados

> Testes de software passando não equivalem a validação física.
