# Mecânica: settings

- ID: `mec.settings` · mecanicas / economia-e-progresso
- Arquivo: `src/game/settings.ts` (57 linhas, sha256 a046298add87605a)
- Estado: **CONFIRMADO_NO_CODIGO**

## Objetivo (cabeçalho do código)
Player sound settings (cloudStore). Defaults: geral no máximo, cada canal na metade. Each channel's 50% equals the game's original level, so 100% doubles it. Older saves keep their channels but the engine starts at max once. */

## Funções exportadas (saídas)
- L29: `export function getSound(): SoundSettings {`
- L34: `export function setSound(k: SoundKey, v: number) {`
- L45: `export function onSound(f: () => void) {`
- L53: `export function soundMul(k: Exclude<SoundKey, "master">) {`

## Entradas tipadas
- k: SoundKey
- k: Exclude

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.cloud.cloud-store`

## Dependentes
- `mec.assets`
- `mec.engine-sound`
- `mec.ui-sound`

## Testes existentes
Nenhum teste importa este módulo.

## Limitações
—

> Testes de software passando não equivalem a validação física.
