# Mecânica: offline

- ID: `mec.offline` · mecanicas / corrida
- Arquivo: `src/game/offline.ts` (88 linhas, sha256 8e3ef5633baba44c)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Offline races: the computer rides a real Titan 160 build per level (parts change its hp), fixed and deterministic. Computer bike per level (Titan): Fácil kit 190 + Dore ~19 cv, Médio 205 + Dore + Athlon ~24 cv, Difícil 220 cursado + Athlon ~30 cv. */

## Funções exportadas (saídas)
- L66: `export function oppSetup(d: Difficulty, distance: number): Setup {`
- L73: `export function racePrize(d: Difficulty, distance: number) {`
- L83: `export function oppTime(d: Difficulty, distance: number) {`

## Entradas tipadas
- d: Difficulty

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.physics`

## Dependentes
- `mec.records`

## Testes existentes
- `src/test/bible2026.test.ts`
- `src/test/challenges.test.ts`
- `src/test/difficulty.test.ts`
- `src/test/facil-track.test.ts`
- `src/test/offline.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
