# Mecânica: jobrun

- ID: `mec.jobrun` · mecanicas / economia-e-progresso
- Arquivo: `src/game/jobrun.ts` (193 linhas, sha256 2040c63a5af63b9e)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Background Trampo runtime: shifts per workplace on the map, stacked offers, a delivery list (up to MAX_RUNS, done one after another) and payout summaries.

## Funções exportadas (saídas)
- L21: `export const workplace = (id: string) => WORKPLACES.find((w) => w.id === id)!;`
- L44: `export const useRun = () => useSyncExternalStore((f) => (subs.add(f), () => subs.delete(f)), () => rs, () => rs);`
- L45: `export const getNotices = () => rs.notices;`
- L49: `export function notify(msg: string, kind: NoticeKind = "warn") {`
- L60: `export function stackBlock(runs: Run[], kind: JobKind): string | null {`
- L70: `export function toggleShift(id: string) {`
- L84: `export function pushOffer(from: string, level: number) {`
- L102: `export const dropOffer = (id: string) => { dismissed.add(id); emit({ offers: rs.offers.filter((o) => o.id !== id) }); };`
- L104: `export const refuseOffer = (id: string) => {`
- L112: `export function setBoard(board: Offer[]) {`
- L118: `export function acceptBlock(o: Offer): string | null {`
- L124: `export const pruneOffers = () => {`
- L132: `export function accept(o: Offer, now = Date.now()) {`
- L151: `export function settle(now = Date.now()) {`
- L192: `export const closeSummary = () => emit({ summaries: rs.summaries.slice(1) });`

## Entradas tipadas
- kind: NoticeKind
- runs: Run
- kind: JobKind
- board: Offer
- o: Offer

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.fuelmix`
- `mec.missions`
- `mec.level`
- `mec.trampo`
- `mec.credit`
- `mec.store`
- `mec.physics`
- `mec.mechlimits`
- `mec.usage`

## Dependentes
—

## Testes existentes
- `src/game/delivery-timing.test.ts`
- `src/test/challenges.test.ts`
- `src/test/jobrun.test.ts`
- `src/test/routes.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
