# Mecânica: pericia

- ID: `mec.pericia` · mecanicas / falhas-e-manutencao
- Arquivo: `src/game/pericia.ts` (86 linhas, sha256 d32472030351276a)
- Estado: **CONFIRMADO_NO_CODIGO**

## Objetivo (cabeçalho do código)
Perícia de quebra: after a break, 1000 deterministic tests isolate the culprit and audit the whole engine. Drops undefined optionals so the object fits Setup under exactOptionalPropertyTypes. */

## Funções exportadas (saídas)
- L45: `export function pericia(b: BikeModel, s: Setup, distance: number, ctx: { label: string; cause: string; atM: number; rpm: number; gear: number; fuelUsedL: number; tail: unknown[]; fluxo?: FluxoEvento[]`

## Entradas tipadas
- b: BikeModel
- s: Setup

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.mechlimits`
- `mec.physics`
- `mec.parts`
- `mec.physics`
- `mec.records`
- `mec.rootcause`

## Dependentes
- `mec.admin-lab`

## Testes existentes
Nenhum teste importa este módulo.

## Limitações
—

> Testes de software passando não equivalem a validação física.
