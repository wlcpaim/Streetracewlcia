# Mecânica: formulas

- ID: `mec.mechanic-master.formulas` · mecanicas / falhas-e-manutencao
- Arquivo: `src/game/mechanic-master/formulas.ts` (17 linhas, sha256 c6b28599bc772bf9)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Biblioteca de fórmulas com unidades e verificação numérica independente.

## Funções exportadas (saídas)
- L16: `export const auditarFormulas = () => FORMULAS.map((f) => { const r = f.check(); const erro = Math.abs(r.obtido - r.esperado) / Math.abs(r.esperado) * 100; return { ...f, ...r, erro, ok: erro < 0.5 }; `

## Entradas tipadas
—

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
—

## Dependentes
—

## Testes existentes
- `src/test/encyclopedia-formulas.test.ts`
- `src/test/eng-dados.test.ts`
- `src/test/mechanic-master.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
