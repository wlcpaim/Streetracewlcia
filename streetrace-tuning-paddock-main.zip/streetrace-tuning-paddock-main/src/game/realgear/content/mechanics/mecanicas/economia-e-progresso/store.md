# Mecânica: store

- ID: `mec.store` · mecanicas / economia-e-progresso
- Arquivo: `src/game/store.ts` (270 linhas, sha256 8065576c9ef6b89f)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
DADO NÃO IDENTIFICADO

## Funções exportadas (saídas)
- L126: `export const setLedgerScene = (s: string) => { scene = s; };`
- L128: `export const ledgerTag = (label: string) => { tag = label; };`
- L164: `export function loadSave() {`
- L236: `export function getPlayer() {`
- L240: `export function setPlayer(fn: (p: Player) => Player) {`
- L248: `export function createPlayer(name: string) {`
- L253: `export function resetPlayer() {`
- L258: `export function usePlayer() {`
- L269: `export const brl = (n: number) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL", minimumFractionDigits: 0, maximumFractionDigits: 0 });`

## Entradas tipadas
- p: Player

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.cloud.cloud-store`
- `mec.physics`
- `mec.parts`

## Dependentes
- `mec.acerto`
- `mec.agr.maps`
- `mec.cloud.save-guard`
- `mec.credit`
- `mec.garage`
- `mec.jobrun`
- `mec.level`
- `mec.missions`
- `mec.records`
- `mec.scrap`
- `mec.workshop`

## Testes existentes
- `src/test/acerto.test.ts`
- `src/test/content-reading.test.ts`
- `src/test/dino-ui.test.tsx`
- `src/test/engine-safe.test.ts`
- `src/test/fuel-save-fixes.test.ts`
- `src/test/garage-bolinha.test.ts`
- `src/test/helpers-kit.ts`
- `src/test/intelligence.test.ts`
- `src/test/jobpay.test.ts`
- `src/test/jobrun.test.ts`
- `src/test/kit4-pistao.test.ts`
- `src/test/level.test.ts`
- `src/test/live-intake.test.ts`
- `src/test/offline.test.ts`
- `src/test/physics-reengenharia.test.ts`
- `src/test/prep-services.test.ts`
- `src/test/routes.test.ts`
- `src/test/scrap.test.ts`
- `src/test/stock-return.test.ts`
- `src/test/workshop.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
