# Mecânica: credit

- ID: `mec.credit` · mecanicas / economia-e-progresso
- Arquivo: `src/game/credit.ts` (68 linhas, sha256 3bdfb71850fa52ca)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Cartão de crédito: diagnosis, repair and maintenance go on the card first; cash only covers what the free limit can't. Purchases can be split up to 12x; every income pays the due installment of each open purchase automatically. Limit grows this much every time the bill is fully paid. */

## Funções exportadas (saídas)
- L13: `export const creditLimit = (p: Player) => p.creditLimit ?? CREDIT_START;`
- L14: `export const creditDebt = (p: Player) => p.creditDebt ?? 0;`
- L15: `export const creditFree = (p: Player) => r2(creditLimit(p) - creditDebt(p));`
- L18: `export function plans(p: Player): Installment[] {`
- L26: `export const nextBill = (p: Player) => r2(plans(p).reduce((s, i) => s + i.amount, 0));`
- L29: `export const canCharge = (p: Player, cost: number) => Math.max(0, cost - Math.max(0, creditFree(p))) <= p.money;`
- L32: `export function chargeCard(p: Player, cost: number, n = 1, label = "Oficina"): Player | null {`
- L44: `export const chargeRepair = (p: Player, cost: number) => chargeCard(p, cost, 1);`
- L47: `export function settle(p: Player): Player {`
- L65: `export function earn(p: Player, amount: number): Player {`

## Entradas tipadas
- p: Player

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.store`

## Dependentes
- `mec.jobrun`
- `mec.level`
- `mec.scrap`
- `mec.workshop`

## Testes existentes
- `src/test/offline.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
