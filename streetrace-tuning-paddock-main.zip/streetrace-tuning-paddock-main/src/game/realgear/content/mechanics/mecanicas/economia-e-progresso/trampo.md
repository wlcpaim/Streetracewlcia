# Mecânica: trampo

- ID: `mec.trampo` · mecanicas / economia-e-progresso
- Arquivo: `src/game/trampo.ts` (148 linhas, sha256 3c829fab42860c6d)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Trampo: random delivery / moto-táxi calls, XP and street popularity. Stops of a delivery route (1–3), each with street, order and its own pay. */

## Funções exportadas (saídas)
- L20: `export const xpForKm = (km: number) => Math.max(1, Math.round(km * XP_PER_KM));`
- L23: `export const xpToNext = (level: number) => Math.round(8 + level * level * 4);`
- L26: `export const tripSeconds = (level: number) => Math.round(25 * Math.pow(0.985, level - 1));`
- L28: `export const ticketMul = (level: number) => Math.pow(1.1, level - 1);`
- L41: `export function payRange(id: string) {`
- L50: `export function courierLevel(jobsDone: number) {`
- L57: `export const courierMul = (jobsDone: number) => (courierLevel(jobsDone).level >= 5 ? 1.15 : 1);`
- L58: `export const workUnlocked = (id: string, level: number) => level >= (WORK_REQ[id] ?? 1);`
- L63: `export const jobSeconds = (kind: JobKind, km: number) => Math.max(10, Math.min(MAX_TRIP_S[kind], Math.round((km / MAX_KM[kind]) * MAX_TRIP_S[kind])));`
- L64: `export const jobPay = (kind: JobKind, km: number, rate = PAY_PER_KM[kind]) => Math.round(km * rate);`
- L83: `export function rollJob(kind: JobKind, _level: number, rnd = Math.random, from = "pizzaria", mul = 1): Job & { secs: number } {`
- L112: `export const routeSeconds = (j: Pick<Job, "kind" | "km" | "stops"> & { place?: string }) => (j.place === "Açaí da Praça" && j.stops?.length ? j.stops.length * ACAI_STOP_S : j.stops?.length ? j.stops.r`
- L115: `export const callMean = (level: number, accepted = 0) => Math.max(30, 90 * Math.pow(0.97, level - 1) * Math.pow(0.997, accepted));`
- L116: `export const nextCallDelay = (level: number, accepted = 0, rnd = Math.random) => callMean(level, accepted) * (0.7 + rnd() * 0.6);`
- L119: `export function addXp(level: number, xp: number, gained: number) {`
- L137: `export function popularity(wins: number) {`

## Entradas tipadas
- kind: JobKind
- j: Pick

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
—

## Dependentes
- `mec.jobrun`
- `mec.level`
- `mec.nexus-update.registry`

## Testes existentes
- `src/test/courier.test.ts`
- `src/test/delivery-board.test.ts`
- `src/test/jobpay.test.ts`
- `src/test/offline.test.ts`
- `src/test/quit-penalty.test.ts`
- `src/test/routes.test.ts`
- `src/test/trampo.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
