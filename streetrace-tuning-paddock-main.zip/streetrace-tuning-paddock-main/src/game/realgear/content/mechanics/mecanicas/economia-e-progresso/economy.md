# Mecânica: economy

- ID: `mec.economy` · mecanicas / economia-e-progresso
- Arquivo: `src/game/economy.ts` (89 linhas, sha256 851111c417309b35)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Live economy pegged to the real USD/BRL rate. Prices in the catalog are the base at BASE_USD; each part passes a share of the dollar move to the counter price (imports 100%, national parts less).

## Funções exportadas (saídas)
- L23: `export async function refreshUsd() {`
- L48: `export const onUsd = (f: () => void) => (subs.add(f), () => subs.delete(f));`
- L51: `export function usdRate(now = Date.now()) {`
- L57: `export const usdQuote = () => live;`
- L61: `export function usdShare(x: Pick<Part, "brand" | "spec" | "factory">) {`
- L68: `export function priceNow(x: Part, _rate?: number) {`
- L74: `export const fuelUsdMul = (_rate?: number) => 1; // combustível com preço fixo`
- L76: `export function news(rate = usdRate()) {`

## Entradas tipadas
- x: Pick
- x: Part

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.cloud.cloud-store`
- `mec.parts`

## Dependentes
- `mec.physics`
- `mec.preparador.preparador`
- `mec.scrap`
- `mec.workshop`

## Testes existentes
- `src/test/autopecas-carb.test.ts`
- `src/test/economy.test.ts`
- `src/test/scrap.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
