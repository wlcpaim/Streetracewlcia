# Mecânica: mechanic

- ID: `mec.mechanic` · mecanicas / falhas-e-manutencao
- Arquivo: `src/game/mechanic.ts` (145 linhas, sha256 28c920d6f4828b14)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
O mecânico: lê a física do motor e fala como preparador. Aponta a direção, nunca a peça/valor exato. O que foi encontrado na desmontagem. */ Por que aconteceu (física). */ O que precisa mudar pra não repetir (direção, sem receita pronta). */

## Funções exportadas (saídas)
- L73: `export function forensic(cause: string): Forensic {`
- L78: `export function rebuildWarning(s: Setup, bike: BikeModel = TITAN_160): string | null {`
- L90: `export function pullAdvice(s: Setup, rep: Rep, dist: number, bike: BikeModel = TITAN_160): string {`
- L144: `export const afrOf = (s: Setup, rpm: number, bike: BikeModel = TITAN_160) => afrAt(bike, s, rpm, engine(bike, s).rpmPeak);`

## Entradas tipadas
- s: Setup
- bike: BikeModel
- rep: Rep

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.physics`
- `mec.mech-identity`

## Dependentes
- `mec.admin-lab`

## Testes existentes
- `src/test/mech-identity.test.ts`
- `src/test/mechanic.test.ts`
- `src/test/multimodelo.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
