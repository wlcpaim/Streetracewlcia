# Mecânica: missions

- ID: `mec.missions` · mecanicas / corrida
- Arquivo: `src/game/missions.ts` (113 linhas, sha256 fd7c69c903d61681)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Missions panel (map + garage); a mission is done when its check passes and pays once when claimed.

## Funções exportadas (saídas)
- L26: `export const claimed = (p: Player, id: string) => (p.missions ?? []).includes(id);`
- L28: `export const missionsReady = (p: Player): number => { const c = currentMission(p); return c ? (c.done(p) ? 1 : 0) : extrasReady(p); };`
- L30: `export const currentMission = (p: Player) => MISSIONS.find((m) => !claimed(p, m.id));`
- L31: `export const unlocked = (p: Player, m: Mission) => claimed(p, m.id) || currentMission(p)?.id === m.id;`
- L32: `export const missionsLeft = (p: Player) => MISSIONS.filter((m) => !claimed(p, m.id)).length;`
- L35: `export const missionSpot = (p: Player) => { const c = currentMission(p); return c && !c.done(p) ? c.spot : undefined; };`
- L38: `export const requestWork = (id: string) => { pendingWork = id; window.dispatchEvent(new Event("open-work")); };`
- L39: `export const takeWork = () => { const w = pendingWork; pendingWork = null; return w; };`
- L42: `export const skipTotals = (p: Player) => {`
- L47: `export const campaignDone = (p: Player) => !currentMission(p);`
- L52: `export const newDaily = (p: Player): Daily => ({ day: today(), jobs: p.jobsDone ?? 0, races: p.reports.length, wins: p.wins ?? 0, claimed: [] });`
- L98: `export const dailyClaimed = (p: Player, id: string) => !!p.daily && p.daily.day === today() && p.daily.claimed.includes(id);`
- L100: `export const extrasReady = (p: Player) =>`
- L105: `export const requestMissions = () => { pendingMissions = true; };`
- L106: `export const takeMissions = () => { const v = pendingMissions; pendingMissions = false; return v; };`
- L109: `export const inTutorial = (p: Player) => { const c = currentMission(p); return !!c && c.id !== "level-3"; };`
- L112: `export const engineSafe = (p: Player) => inTutorial(p) || p.level < 5;`

## Entradas tipadas
- p: Player
- m: Mission

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.store`
- `mec.physics`

## Dependentes
- `mec.cloud.save-guard`
- `mec.jobrun`

## Testes existentes
- `src/test/challenges.test.ts`
- `src/test/engine-safe.test.ts`
- `src/test/level.test.ts`
- `src/test/prep-services.test.ts`
- `src/test/routes.test.ts`
- `src/test/tutorial-progress.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
