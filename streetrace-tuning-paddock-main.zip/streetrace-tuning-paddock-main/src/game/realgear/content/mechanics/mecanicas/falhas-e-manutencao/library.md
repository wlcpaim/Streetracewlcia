# Mecânica: library

- ID: `mec.mechanic-master.library` · mecanicas / falhas-e-manutencao
- Arquivo: `src/game/mechanic-master/library.ts` (24 linhas, sha256 911676f0f376bb2f)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Ficha técnica derivada do catálogo ativo do jogo (sem inventar): campos não presentes ficam DESCONHECIDO.

## Funções exportadas (saídas)
- L7: `export function fichaDaPeca(p: Part): Ficha {`
- L18: `export function biblioteca(): Entrada[] {`
- L23: `export const fabricantes = () => [...new Set(PARTS_CATALOG.map((p) => p.brand).filter(Boolean))].sort();`

## Entradas tipadas
- p: Part

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.parts`
- `mec.mechanic-master.types`

## Dependentes
—

## Testes existentes
- `src/test/mechanic-master.test.ts`

## Limitações
- contém dados desconhecidos que bloqueiam cálculo

> Testes de software passando não equivalem a validação física.
