# Mecânica: records

- ID: `mec.records` · mecanicas / corrida
- Arquivo: `src/game/records.ts` (98 linhas, sha256 4680b952ca25fb8a)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Records: drag tracks, displacement classes, player bests and the world top 10. Official drag tracks, in menu order (1/8, 1/4, 1/2, 1 milha) plus the official Bololo 4-mile track. Força Livre is a bike class, never a track. */

## Funções exportadas (saídas)
- L16: `export const trackOf = (d: number) => TRACKS.find((t) => Math.abs(t.m - d) < 0.5);`
- L29: `export function displacement(s: Setup) {`
- L35: `export const classOf = (cc: number): ClassId => CLASSES.find((c) => cc <= c.max)!.id;`
- L37: `export const fitsClass = (cc: number, c: ClassId) => cc <= CLASSES.find((x) => x.id === c)!.max;`
- L40: `export function leaderOf(rs: TestReport[], distance: number, cc: number): TestReport | null {`
- L48: `export function playerBest(rs: TestReport[], t: TrackId, c: ClassId): Entry | null {`
- L67: `export function worldTop(t: TrackId, c: ClassId): Entry[] {`
- L83: `export function ranking(rs: TestReport[], name: string, t: TrackId, c: ClassId) {`

## Entradas tipadas
- s: Setup
- c: ClassId
- rs: TestReport
- t: TrackId

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.physics`
- `mec.offline`
- `mec.physics`
- `mec.store`

## Dependentes
- `mec.admin-lab`
- `mec.agr.agr`
- `mec.engine-sound`
- `mec.intel.sweep`
- `mec.mmr.x1-core`
- `mec.pericia`

## Testes existentes
- `src/test/agr.test.ts`
- `src/test/records.test.ts`
- `src/test/x1-calib.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
