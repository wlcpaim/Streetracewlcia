# Mecânica: level

- ID: `mec.level` · mecanicas / corrida
- Arquivo: `src/game/level.ts` (39 linhas, sha256 bcc1752e50abc387)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Level-up perks: every XP gain goes through gainXp() so cash bonus, card limit and delivery speed stay consistent. Cash bonus for reaching `level`: R$ 500 base, +3% compounded per level (level 2 = 500 +3%). */ Card limit grows 2.5% per level gained. */ Delivery/ride time multiplier: −1% per level. */

## Funções exportadas (saídas)
- L7: `export const levelBonus = (level: number) => Math.round(500 * Math.pow(1.03, Math.max(0, level - 1)));`
- L11: `export const tripMul = (level: number) => Math.pow(0.99, Math.max(0, level - 1));`
- L13: `export function gainXp(pl: Player, gained: number): { player: Player; ups: number; bonus: number } {`
- L23: `export function totalXp(level: number, xp: number) {`
- L29: `export const fromTotalXp = (total: number) => addXp(1, 0, Math.max(0, total));`
- L31: `export const peakXp = (pl: Pick<Player, "level" | "xp" | "maxXp">) => Math.max(pl.maxXp ?? 0, totalXp(pl.level, pl.xp ?? 0));`
- L34: `export function quitPenalty(pl: Pick<Player, "level" | "xp" | "maxXp">) {`

## Entradas tipadas
- pl: Player
- player: Player
- pl: Pick

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.trampo`
- `mec.credit`
- `mec.store`

## Dependentes
- `mec.cloud.save-guard`
- `mec.jobrun`

## Testes existentes
- `src/test/level.test.ts`
- `src/test/quit-penalty.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
