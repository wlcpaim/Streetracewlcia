# Mecânica: damage

- ID: `mec.damage` · mecanicas / falhas-e-manutencao
- Arquivo: `src/game/damage.ts` (50 linhas, sha256 799a8d5279a45ede)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Collateral damage of an engine failure: what else the break took with it. Deterministic per failure + odometer so the same break always reads the same laudo. Remaining condition 0..1. */ Replacement part cost (R$, estimativa de jogo). */

## Funções exportadas (saídas)
- L33: `export function damageSpecs(cause: string): Spec[] {`
- L37: `export function collateral(cause: string, km = 0): Damage[] {`
- L47: `export function partsBill(cause: string) {`

## Entradas tipadas
—

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
—

## Dependentes
- `mec.admin-lab`
- `mec.scrap`
- `mec.workshop`

## Testes existentes
- `src/test/no-dice.test.ts`
- `src/test/workshop.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
