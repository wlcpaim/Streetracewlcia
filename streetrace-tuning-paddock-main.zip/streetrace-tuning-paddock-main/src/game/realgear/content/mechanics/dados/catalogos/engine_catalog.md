# Mecânica: engine_catalog

- ID: `mec.data.engine_catalog` · dados / catalogos
- Arquivo: `src/game/data/engine_catalog.ts` (48 linhas, sha256 367bf9eb2313018d)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Catálogo técnico por fabricante/modelo/ano/versão. Cada grandeza tem valor, unidade (SI ou declarada), fonte, data de consulta, confiança e origem. Sem evidência = DESCONHECIDO (valor null). Fonte de geometria: src/game/data/biblia_2026.json (ficha do fabricante transcrita).

## Funções exportadas (saídas)
- L45: `export const strokeMmOf = (bikeId: string): number | null => { const v = ENGINE_CATALOG[bikeId]?.p["curso"]?.valor; return typeof v === "number" ? v : null; };`
- L47: `export const rodMmOf = (bikeId: string): number | null => { const v = ENGINE_CATALOG[bikeId]?.p["biela"]?.valor; return typeof v === "number" ? v : null; };`

## Entradas tipadas
—

## Fórmulas
### Área do pistão / cilindrada
$$A = \frac{\pi D^2}{4},\quad V_d = A\,S$$
- D: diâmetro [m]
- S: curso [m]
- A: área [m²]
- V_d: cilindrada [m³]
- Hipóteses: cilindro perfeito
- Limitações: sem folgas
- `src/game/data/engine_catalog.ts:13` (vd) `const vd = (d: number, s: number) => Math.round((Math.PI / 4) * d * d * s / 100) / 10; // cm³`

## Dependências
- `mec.physics-registry.constants`

## Dependentes
- `mec.engineering.dados.audit`
- `mec.engineering.dados.pipeline`
- `mec.enginephys`
- `mec.kits.kit70`
- `mec.nitro.lab`
- `mec.physics`
- `mec.pins.pins`
- `mec.platform.platforms`
- `mec.prancha.board`
- `mec.realgear.fix.investigator`
- `mec.realgear.kinematics`
- `mec.src.nexus.aeic`
- `mec.src.nexus.caim`
- `mec.src.nexus.reconstrucao`

## Testes existentes
- `src/test/physics-constants.test.ts`
- `src/test/reconstrucao.test.ts`

## Limitações
- contém dados desconhecidos que bloqueiam cálculo

> Testes de software passando não equivalem a validação física.
