# Mecânica: save-sync

- ID: `mec.cloud.save-sync` · auditoria / cloud
- Arquivo: `src/game/cloud/save-sync.ts` (10 linhas, sha256 e852344834ac43f1)
- Estado: **CONFIRMADO_NO_CODIGO**

## Objetivo (cabeçalho do código)
Compatibilidade: a nuvem agora é a única fonte (cloud-store.ts). Estas funções só repassam. Gravações já sobem pelo cloudStore; mantido para chamadas antigas. */

## Funções exportadas (saídas)
- L5: `export const cloudStatus = () => { const s = cloudState(); return { status: s.status, userId: s.userId }; };`
- L8: `export function pushLater(_kind: SaveKind) { /* nada */ }`
- L9: `export function startCloudSync(_onPulled: (kinds: SaveKind[]) => void) { startCloudStore(); }`

## Entradas tipadas
- _kind: SaveKind
- kinds: SaveKind

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.cloud.cloud-store`

## Dependentes
—

## Testes existentes
Nenhum teste importa este módulo.

## Limitações
—

> Testes de software passando não equivalem a validação física.
