# Mecânica: save-guard

- ID: `mec.cloud.save-guard` · auditoria / cloud
- Arquivo: `src/game/cloud/save-guard.ts` (75 linhas, sha256 a9c7e84151393eb1)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Validação autoritativa do save do piloto: o servidor compara o save novo com o último aceito e recusa dinheiro criado do nada, motos/peças não liberadas ou não pagas. Pura e determinística. Mesma fração de garage.ts (sem importar: ciclo store/garage). */

## Funções exportadas (saídas)
- L29: `export function checkSave(prev: Save, next: Save, elapsedS: number): Verdict {`

## Entradas tipadas
- prev: Save
- next: Save

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.missions`
- `mec.level`
- `mec.parts`
- `mec.physics`
- `mec.startgame`
- `mec.store`
- `mec.ignition`

## Dependentes
- `mec.cloud.save.functions`

## Testes existentes
- `src/test/factory-gear.test.ts`
- `src/test/fuel-save-fixes.test.ts`
- `src/test/garage-bolinha.test.ts`
- `src/test/save-guard.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
