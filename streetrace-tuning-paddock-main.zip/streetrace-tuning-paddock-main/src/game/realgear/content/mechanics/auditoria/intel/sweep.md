# Mecânica: sweep

- ID: `mec.intel.sweep` · auditoria / intel
- Arquivo: `src/game/intel/sweep.ts` (53 linhas, sha256 d6a8466b03da2afd)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Wikipedia StreetRace — Teste Geral: o cérebro varre cada peça, comando, taxa e combustível em cada moto e pista com o mesmo step() da corrida e a revisão física (physicsReview), e grava o resultado como TXT no feed "Ao Vivo". Somente leitura: não altera a física.

## Funções exportadas (saídas)
- L14: `export function variations(): Variation[] {`
- L27: `export function generalSweep(): { report: LiveReport; runs: number; fails: number } {`

## Entradas tipadas
- report: LiveReport

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.admin-lab`
- `mec.physics`
- `mec.parts`
- `mec.records`
- `mec.intel.changelog`
- `mec.preload-report`

## Dependentes
—

## Testes existentes
- `src/test/sweep.test.ts`

## Limitações
- contém valores marcados como estimados

> Testes de software passando não equivalem a validação física.
