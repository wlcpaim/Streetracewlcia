# Mecânica: audit

- ID: `mec.intel.audit` · auditoria / intel
- Arquivo: `src/game/intel/audit.ts` (156 linhas, sha256 feb2d66bfea96bc4)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Auditoria matemática: roda as funções reais com o setup escolhido e compara com equações físicas independentes. Somente leitura: nenhuma fórmula, parâmetro ou resultado do jogo é alterado aqui.

## Funções exportadas (saídas)
- L19: `export function auditSetup(b: BikeModel, s: Setup): Finding[] {`
- L127: `export function partsIntel() {`
- L138: `export const auditPart = (id: string) => partById(id);`
- L141: `export function promptFor(f: Finding, bikeName: string) {`

## Entradas tipadas
- b: BikeModel
- s: Setup
- f: Finding

## Fórmulas
### Velocidade angular
$$\omega = \frac{2\pi n}{60}$$
- ω: velocidade angular [rad/s]
- n: rotação [rpm]
- Hipóteses: rotação uniforme no passo
- Limitações: não modela flutuação cíclica
- `src/game/intel/audit.ts:55` (wLim) `const wLim = (e.rpmLimit * 2 * Math.PI) / 60;`
### Pressão / tensão normal
$$p = \frac{F}{A},\quad \sigma = \frac{F}{A}$$
- F: força [N]
- A: área [m²]
- σ, p: tensão / pressão [Pa]
- Hipóteses: distribuição uniforme
- Limitações: sem concentração de tensões
- `src/game/intel/audit.ts:75` (wLim) `found: contra.length ? contra.map((x) => `${x.r} rpm: AFR ${n(x.afr)} λ=${n(x.afr / stoich, 3)}`).join(" · ") : "sem contradição", expected: `pobre em relação ao estequiométrico com λ > 1 (AFR > ${stoich} no ${eth ? "eta`
### Consumo específico (BSFC)
$$\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$$
- P: potência [kW]
- BSFC: consumo específico [kg/kWh]
- ρ_f: densidade do combustível [kg/L]
- Hipóteses: plena carga
- Limitações: BSFC fixo por combustível
- `src/game/intel/audit.ts:116` (wLim) `found: `gasto ${n(r1.result.fuelUsedL, 4)} L em ${n(tSec, 2)} s`, expected: `≤ ${n(maxL, 4)} L (potência máxima o tempo todo)`, formula: "L/s = P(kW) × BSFC / ρ / 3600", diffAbs: r1.result.fuelUsedL - maxL, diffPct: null`
### Razão ar-combustível / lambda
$$\lambda = \frac{AFR}{AFR_{esteq}}$$
- AFR: razão ar/combustível [kg/kg]
- AFR_esteq: estequiométrica [kg/kg]
- Hipóteses: combustível de composição média
- Limitações: mistura como fator do jogo
- `src/game/intel/audit.ts:73` (wLim) `const contra = rows.filter((x) => x.lean > 0 && x.afr / stoich < 1);`
- `src/game/intel/audit.ts:75` (wLim) `found: contra.length ? contra.map((x) => `${x.r} rpm: AFR ${n(x.afr)} λ=${n(x.afr / stoich, 3)}`).join(" · ") : "sem contradição", expected: `pobre em relação ao estequiométrico com λ > 1 (AFR > ${stoich} no ${eth ? "eta`

## Dependências
- `mec.physics`
- `mec.rootcause`
- `mec.admin-lab`
- `mec.parts`
- `mec.intel.powertrain`

## Dependentes
- `mec.intel.preload-audit`

## Testes existentes
- `src/test/crossaudit.test.ts`
- `src/test/eng-dados.test.ts`
- `src/test/intelligence.test.ts`
- `src/test/topspeed-oem.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
