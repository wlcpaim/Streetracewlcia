# Mecânica: changelog

- ID: `mec.intel.changelog` · auditoria / intel
- Arquivo: `src/game/intel/changelog.ts` (82 linhas, sha256 8acf730ce5be4ef5)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Registro de atualizações da Inteligência (Wikipedia StreetRace). Toda mudança no jogo entra aqui com o que mudou e quais leis físicas a validam; physicsReview() recalcula cada lei de forma independente sobre as funções reais e informa o erro de cálculo. Somente leitura.

## Funções exportadas (saídas)
- L54: `export function physicsReview(s: Setup = STOCK_SETUP, bikeId = "titan160"): Check[] {`
- L72: `export function reviewTxt(): string {`

## Entradas tipadas
- s: Setup

## Fórmulas
### Potência mecânica / torque
$$P = T\,\omega \;\Leftrightarrow\; T = P/\omega$$
- P: potência [W]
- T: torque [N·m]
- ω: velocidade angular [rad/s]
- Hipóteses: regime quase estático
- Limitações: perdas internas tratadas por fatores do jogo
- `src/game/intel/changelog.ts:26` `{ id: "2026-11-11-kit70", date: "2026-11-11", title: "Kit 70mm peça por peça", changes: ["Cilindro encamisado 70,0 mm (camisa Ø 74) e pistões 70 mm pino 14/15 avulsos", "Cilindrada por moto: Titan π/4·70²·63,096 = 242,8 `
### Função de Wiebe (fração queimada)
$$x_b = 1 - e^{-a\left(\frac{\theta-\theta_0}{\Delta\theta}\right)^{m+1}}$$
- x_b: fração de massa queimada [—]
- θ: ângulo do virabrequim [°]
- a, m: parâmetros de forma [—]
- Hipóteses: combustão de chama única
- Limitações: parâmetros estimados
- `src/game/intel/changelog.ts:47` `{ id: "2026-11-08-overhaul20", date: "2026-11-08", title: "Física acoplada 2.0", changes: ["Ciclo Wiebe, biela 720°, embreagem térmica, injeção com duty"], checks: ["power-torque"] },`

## Dependências
- `mec.physics`
- `mec.exhaust`
- `mec.parts`
- `mec.intel.powertrain`
- `mec.overhaul22`

## Dependentes
- `mec.autopecas.analise`
- `mec.intel.sweep`
- `mec.realgear.bridge.exporter`
- `mec.realgear.funnel`
- `mec.src.nexus.connectors`

## Testes existentes
- `src/test/changelog.test.ts`

## Limitações
- contém valores marcados como estimados
- contém dados desconhecidos que bloqueiam cálculo

> Testes de software passando não equivalem a validação física.
