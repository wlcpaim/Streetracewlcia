# Mecânica: preload-audit

- ID: `mec.intel.preload-audit` · auditoria / intel
- Arquivo: `src/game/intel/preload-audit.ts` (40 linhas, sha256 fae2a0dbf530b573)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Lê um relatório TXT de preload (gerado no jogo ou colado) e audita os números entre si, sem rodar o jogo.

## Funções exportadas (saídas)
- L8: `export function parsePreload(txt: string): ParsedPreload {`
- L21: `export function auditPreload(p: ParsedPreload): Finding[] {`

## Entradas tipadas
- p: ParsedPreload

## Fórmulas
### Consumo específico (BSFC)
$$\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$$
- P: potência [kW]
- BSFC: consumo específico [kg/kWh]
- ρ_f: densidade do combustível [kg/L]
- Hipóteses: plena carga
- Limitações: BSFC fixo por combustível
- `src/game/intel/preload-audit.ts:37` (auditPreload) `if (p.tempo && p.gasto && p.cv) { const maxL = (p.cv * CV_KW * (p.combustivel === "etanol" ? 0.61 : 0.42)) / (p.combustivel === "etanol" ? 0.79 : 0.74) / 3600 * p.tempo; F.push({ ...base, id: "RP-06", pass: p.gasto <= ma`
### Razão ar-combustível / lambda
$$\lambda = \frac{AFR}{AFR_{esteq}}$$
- AFR: razão ar/combustível [kg/kg]
- AFR_esteq: estequiométrica [kg/kg]
- Hipóteses: combustível de composição média
- Limitações: mistura como fator do jogo
- `src/game/intel/preload-audit.ts:35` (auditPreload) `if (p.duties.length) F.push({ ...base, id: "RP-04", pass: !rich.length, sev: "alta", func: "afrAt()", title: "FALTA de combustível com AFR rico", found: rich.map((x) => `${x.rpm}: AFR ${x.afr} (λ ${(x.afr / st).toFixed(3`

## Dependências
- `mec.intel.powertrain`
- `mec.intel.audit`

## Dependentes
—

## Testes existentes
- `src/test/intelligence.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
