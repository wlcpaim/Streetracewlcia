# Mecânica: qa

- ID: `mec.intel.qa` · auditoria / intel
- Arquivo: `src/game/intel/qa.ts` (64 linhas, sha256 eec728b1dbf9c471)
- Estado: **CONFIRMADO_NO_CODIGO**

## Objetivo (cabeçalho do código)
Engenharia Inteligente: perguntas técnicas respondidas com os dados do código e da telemetria da corrida. Cada resposta diz a origem (MEDIDO/CALCULADO/ESTIMADO) e, quando falta dado, diz exatamente qual.

## Funções exportadas (saídas)
- L18: `export function experiments(b: BikeModel, s: Setup, m = 402.34) {`
- L31: `export function answers(b: BikeModel, s: Setup, m = 402.34): { run: RunResult; list: Answer[] } {`

## Entradas tipadas
- b: BikeModel
- s: Setup
- run: RunResult
- list: Answer

## Fórmulas
### Energia cinética
$$E_c = \tfrac12 m v^2$$
- E_c: energia cinética [J]
- m: massa [kg]
- v: velocidade [m/s]
- Hipóteses: translação pura
- Limitações: sem energia rotacional
- `src/game/intel/qa.ts:59` (vEnd) `const ke = 0.5 * mass * vEnd * vEnd / 1000;`

## Dependências
- `mec.intel.qa-deps`
- `mec.physics`
- `mec.rootcause`
- `mec.admin-lab`
- `mec.intel.powertrain`

## Dependentes
—

## Testes existentes
Nenhum teste importa este módulo.

## Limitações
- contém valores marcados como estimados

> Testes de software passando não equivalem a validação física.
