# Mecânica: history

- ID: `mec.realgear.history` · auditoria / realgear
- Arquivo: `src/game/realgear/history.ts` (16 linhas, sha256 e776029c6323659b)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Histórico permanente (somente acréscimo) das execuções da Engrenagem Real.

## Funções exportadas (saídas)
- L6: `export function readHistory(): Tentativa[] {`
- L10: `export function appendHistory(x: Execucao): Tentativa[] {`

## Entradas tipadas
- x: Execucao

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.cloud.cloud-store`
- `mec.realgear.funnel`

## Dependentes
- `mec.autopecas.autopecas`
- `mec.realgear.live-intake`

## Testes existentes
- `src/test/live-intake.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
