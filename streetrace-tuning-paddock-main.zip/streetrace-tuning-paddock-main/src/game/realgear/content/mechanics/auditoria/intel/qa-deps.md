# Mecânica: qa-deps

- ID: `mec.intel.qa-deps` · auditoria / intel
- Arquivo: `src/game/intel/qa-deps.ts` (3 linhas, sha256 9765b4fbb1a7cf7c)
- Estado: **CONFIRMADO_NO_CODIGO**

## Objetivo (cabeçalho do código)
DADO NÃO IDENTIFICADO

## Funções exportadas (saídas)

## Entradas tipadas
—

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.physics`
- `mec.parts`

## Dependentes
- `mec.intel.qa`

## Testes existentes
Nenhum teste importa este módulo.

## Limitações
—

> Testes de software passando não equivalem a validação física.
