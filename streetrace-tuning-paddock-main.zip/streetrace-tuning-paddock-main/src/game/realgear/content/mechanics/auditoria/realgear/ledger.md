# Mecânica: ledger

- ID: `mec.realgear.bridge.ledger` · auditoria / realgear
- Arquivo: `src/game/realgear/bridge/ledger.ts` (68 linhas, sha256 f34013125a0ad175)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Ponte: histórico append-only de exportações, recebimentos e respostas. Nada aqui altera Setup/save/física.

## Funções exportadas (saídas)
- L12: `export function localStore(): Store {`
- L18: `export function memoryStore(init: LedgerEvent[] = []): Store & { events: LedgerEvent[] } {`
- L24: `export function recordExport(st: Store, pkg: ProjectPackage) {`
- L30: `export function receivePackage(st: Store, input: string | unknown): Receipt {`
- L51: `export function acceptResponse(st: Store, current: ProjectPackage, input: string | unknown): Acceptance {`

## Entradas tipadas
- init: LedgerEvent
- events: LedgerEvent
- st: Store
- pkg: ProjectPackage
- current: ProjectPackage

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.cloud.cloud-store`
- `mec.realgear.bridge.contract`

## Dependentes
—

## Testes existentes
- `src/test/realgear-bridge.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
