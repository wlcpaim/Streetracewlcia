# Mecânica: save.functions

- ID: `mec.cloud.save.functions` · auditoria / cloud
- Arquivo: `src/game/cloud/save.functions.ts` (27 linhas, sha256 97e3e39922b66945)
- Estado: **CONFIRMADO_NO_CODIGO**

## Objetivo (cabeçalho do código)
Única porta de gravação do save do piloto: valida posse e transição no servidor (save-guard).

## Funções exportadas (saídas)

## Entradas tipadas
—

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.src.integrations.supabase.auth-middleware`
- `mec.cloud.save-guard`

## Dependentes
—

## Testes existentes
Nenhum teste importa este módulo.

## Limitações
—

> Testes de software passando não equivalem a validação física.
