# Mecânica: powertrain

- ID: `mec.intel.powertrain` · auditoria / intel
- Arquivo: `src/game/intel/powertrain.ts` (83 linhas, sha256 33b4788c802a49a4)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Potência e transmissão: CV no motor vs CV na roda, torque em cada ponto da cadeia e força na roda por marcha. Lê as funções reais (engine, powerShape, mixFactor, exhaustShape, gearSpeeds, ETA) — não é um segundo motor físico. 60000 / 2π: N·m × rpm / K = W·1000 → kW. (9550 é o arredondamento usual.) */

## Funções exportadas (saídas)
- L12: `export const cvToKw = (cv: number) => cv * CV_KW;`
- L13: `export const kwToCv = (kw: number) => kw / CV_KW;`
- L14: `export const torqueFromPower = (kw: number, rpm: number) => (rpm > 0 ? (kw * K_RPM) / rpm : NaN);`
- L15: `export const powerFromTorque = (nm: number, rpm: number) => (nm * rpm) / K_RPM;`
- L16: `export const wheelPower = (engineCv: number, eta: number) => {`
- L20: `export const lossPct = (eta: number) => { wheelPower(1, eta); return 100 * (1 - eta); };`
- L23: `export const tireRadius = (spec: string) => rearTireRadiusM(spec);`
- L25: `export const clutchCap = (s: Setup) => clutchCapNm(s);`
- L30: `export function curve(b: BikeModel, s: Setup, step = 250): CurvePoint[] {`
- L45: `export function powertrain(b: BikeModel, s: Setup) {`

## Entradas tipadas
- rpm: NaN
- s: Setup
- b: BikeModel

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.physics`
- `mec.parts`

## Dependentes
- `mec.autopecas.autopecas`
- `mec.engineering.dados.audit`
- `mec.intel.audit`
- `mec.intel.bikemap`
- `mec.intel.changelog`
- `mec.intel.preload-audit`
- `mec.intel.qa`
- `mec.intel.report`
- `mec.realgear.axles`
- `mec.realgear.funnel`
- `mec.realgear.kinematics`

## Testes existentes
- `src/test/intelligence.test.ts`

## Limitações
- contém valores marcados como estimados

> Testes de software passando não equivalem a validação física.
