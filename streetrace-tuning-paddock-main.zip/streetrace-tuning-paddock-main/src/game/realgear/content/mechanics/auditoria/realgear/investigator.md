# Mecânica: investigator

- ID: `mec.realgear.fix.investigator` · auditoria / realgear
- Arquivo: `src/game/realgear/fix/investigator.ts` (69 linhas, sha256 7e001b68c26e8eaf)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Investigador do código — espelho TS do python/realgear/investigator.py (mesmas regras, mesmas linhas). Lê o código-fonte REAL empacotado (?raw); nunca inventa a origem: sem regra demonstrável → determinado=false.

## Funções exportadas (saídas)
- L11: `export const codeVersion = (src = SOURCES) => sha256(Object.keys(src).sort().map((k) => `${k}\n${src[k]}`).join("\n"));`
- L12: `export const fileHash = (arquivo: string, src = SOURCES) => sha256(src[arquivo] ?? "");`
- L15: `export function findLine(src: string, re: RegExp): { linha: number; trecho: string; m: RegExpMatchArray } | null {`
- L20: `export const occurrences = (arquivo: string, src: string, re: RegExp): CodeRef[] =>`
- L22: `export function fichaOf(bikeId: string, src = SOURCES) {`
- L27: `export function investigate(ev: FailureEvent, src = SOURCES): PythonInvestigation {`

## Entradas tipadas
- re: RegExp
- m: RegExpMatchArray
- ev: FailureEvent

## Fórmulas
### Área do pistão / cilindrada
$$A = \frac{\pi D^2}{4},\quad V_d = A\,S$$
- D: diâmetro [m]
- S: curso [m]
- A: área [m²]
- V_d: cilindrada [m³]
- Hipóteses: cilindro perfeito
- Limitações: sem folgas
- `src/game/realgear/fix/investigator.ts:41` (vd) `const vd = (st: number) => r4((Math.PI / 4) * D * D * st / 1000);`

## Dependências
- `mec.realgear.sha256`
- `mec.data.engine_catalog`
- `mec.realgear.fix.contracts`

## Dependentes
- `mec.cloud.cloud.server`
- `mec.realgear.fix.pipeline`
- `mec.realgear.fix.wikipedia`
- `mec.src.nexus.connectors`
- `mec.src.nexus.orchestrator`

## Testes existentes
- `src/test/crossaudit.test.ts`
- `src/test/fixcenter.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
