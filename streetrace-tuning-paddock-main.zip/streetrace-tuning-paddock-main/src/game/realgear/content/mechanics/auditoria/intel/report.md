# Mecânica: report

- ID: `mec.intel.report` · auditoria / intel
- Arquivo: `src/game/intel/report.ts` (29 linhas, sha256 1ed9b5b2b1fd740b)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
DADO NÃO IDENTIFICADO

## Funções exportadas (saídas)
- L3: `export function transmissionTxt(b: BikeModel, s: Setup) {`

## Entradas tipadas
- b: BikeModel
- s: Setup

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.intel.powertrain`
- `mec.physics`

## Dependentes
- `mec.preload-report`

## Testes existentes
- `src/test/live-intake.test.ts`
- `src/test/part-sheet.test.ts`
- `src/test/physics-21.test.ts`

## Limitações
- contém valores marcados como estimados

> Testes de software passando não equivalem a validação física.
