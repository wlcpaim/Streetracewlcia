# Mecânica: materials

- ID: `mec.realgear.materials` · auditoria / realgear
- Arquivo: `src/game/realgear/materials.ts` (55 linhas, sha256 697d2144a5b44246)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
CAMADA 5 — Propriedades dos materiais. Somente leitura: classifica cada dado e só calcula tensão/FS quando seção resistente e escoamento existem com origem MEDIDA ou DOCUMENTADA. Nunca inventa valor.

## Funções exportadas (saídas)
- L19: `export const fundamentado = (d: DadoMat, aceitarInferencia = false) => (d.classificacao === "MEDIDO" || d.classificacao === "DOCUMENTADO" || (aceitarInferencia && (d.classificacao === "INFERIDO_KB" ||`
- L25: `export function dadosAtuais(rodLimitN: number, wallMm: number): DadoMat[] {`
- L38: `export function avaliarC5(dados: DadoMat[], forcaN: number | null, aceitarInferencia = false): ResultadoC5 {`

## Entradas tipadas
- d: DadoMat
- dados: DadoMat

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
—

## Dependentes
- `mec.realgear.funnel`
- `mec.realgear.knowledge.solver`

## Testes existentes
- `src/test/layer13.test.ts`
- `src/test/layer5-materials.test.ts`
- `src/test/realgear-solver.test.ts`

## Limitações
- contém valores marcados como estimados
- contém dados desconhecidos que bloqueiam cálculo

> Testes de software passando não equivalem a validação física.
