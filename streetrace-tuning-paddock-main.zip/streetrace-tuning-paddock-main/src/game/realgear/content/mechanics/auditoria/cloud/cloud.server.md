# Mecânica: cloud.server

- ID: `mec.cloud.cloud.server` · auditoria / cloud
- Arquivo: `src/game/cloud/cloud.server.ts` (184 linhas, sha256 a04b10467a63abf4)
- Estado: **CONFIRMADO_NO_CODIGO**

## Objetivo (cabeçalho do código)
Orquestração no servidor (Lovable Cloud). Toda escrita passa por aqui com o cliente de serviço; o navegador só lê. Relatórios recebidos são dados, nunca instruções.

## Funções exportadas (saídas)
- L16: `export async function logEvent(runId: string | null, module: string, step: string, message: string, data?: Json) {`
- L19: `export async function beat(module: string, version: string, error?: string) {`
- L28: `export async function startRun(specId: SpecId) {`
- L78: `export async function claimJob(worker: string) {`
- L101: `export async function submitResult(jobId: string, worker: string, response: PyResponse & { investigacao?: unknown }) {`
- L160: `export async function failJob(jobId: string, worker: string, error: string) {`
- L171: `export async function pingDb() {`
- L179: `export async function recoverJobs() {`

## Entradas tipadas
- specId: SpecId
- response: PyResponse

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.src.integrations.supabase.client.server`
- `mec.physics`
- `mec.realgear.funnel`
- `mec.realgear.fix.pipeline`
- `mec.realgear.fix.contracts`
- `mec.realgear.fix.investigator`
- `mec.realgear.fix.contracts`
- `mec.realgear.sha256`
- `mec.cloud.crossaudit`

## Dependentes
—

## Testes existentes
Nenhum teste importa este módulo.

## Limitações
—

> Testes de software passando não equivalem a validação física.
