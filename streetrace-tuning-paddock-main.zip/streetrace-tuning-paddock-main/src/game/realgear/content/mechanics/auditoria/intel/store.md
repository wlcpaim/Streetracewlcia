# Mecânica: store

- ID: `mec.intel.store` · auditoria / intel
- Arquivo: `src/game/intel/store.ts` (22 linhas, sha256 93beb249784d4970)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Conhecimento persistente da auditoria (neste aparelho): histórico, status dos bugs e propostas aguardando aprovação.

## Funções exportadas (saídas)
- L9: `export function readIntel(): IntelState {`
- L18: `export function writeIntel(s: IntelState) {`
- L21: `export const score = (passed: number, total: number) => (total ? Math.round((100 * passed) / total) : 0);`

## Entradas tipadas
- s: IntelState

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.cloud.cloud-store`

## Dependentes
—

## Testes existentes
- `src/test/acerto.test.ts`
- `src/test/content-reading.test.ts`
- `src/test/dino-ui.test.tsx`
- `src/test/engine-safe.test.ts`
- `src/test/fuel-save-fixes.test.ts`
- `src/test/garage-bolinha.test.ts`
- `src/test/helpers-kit.ts`
- `src/test/intelligence.test.ts`
- `src/test/jobpay.test.ts`
- `src/test/jobrun.test.ts`
- `src/test/kit4-pistao.test.ts`
- `src/test/level.test.ts`
- `src/test/live-intake.test.ts`
- `src/test/offline.test.ts`
- `src/test/physics-reengenharia.test.ts`
- `src/test/prep-services.test.ts`
- `src/test/routes.test.ts`
- `src/test/scrap.test.ts`
- `src/test/stock-return.test.ts`
- `src/test/workshop.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
