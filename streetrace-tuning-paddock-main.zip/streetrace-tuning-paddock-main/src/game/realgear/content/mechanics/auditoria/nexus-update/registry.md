# Mecânica: registry

- ID: `mec.nexus-update.registry` · auditoria / nexus-update
- Arquivo: `src/game/nexus-update/registry.ts` (151 linhas, sha256 f205057d4122ddef)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
NEXUS UPDATE: catálogo vivo de tudo que está no jogo. Edições ficam em cloudStore e são aplicadas in-place nos objetos reais (peças, serviços, motos, mapa, trampos, dinamômetro), então valem em todas as telas.

## Funções exportadas (saídas)
- L61: `export function categories(): Category[] {`
- L114: `export const defaultOf = (key: string, k: string) => defaults.get(key)?.[k];`
- L115: `export function readOverrides(): Overrides {`
- L120: `export const subscribe = (f: () => void) => { listeners.add(f); return () => listeners.delete(f); };`
- L122: `export const version = () => ver;`
- L125: `export function applyNexusOverrides() {`
- L133: `export function saveItem(key: string, values: Record<string, string | number | undefined>) {`
- L139: `export function resetItem(key: string) { const ov = readOverrides(); delete ov[key]; cloudStore.setItem(NU_KEY, JSON.stringify(ov)); applyNexusOverrides(); }`
- L140: `export function resetAll() { cloudStore.removeItem(NU_KEY); applyNexusOverrides(); }`
- L142: `export function validate(f: Field, raw: string): { v?: string | number | undefined; err?: string } {`

## Entradas tipadas
- values: Record
- f: Field

## Fórmulas
### Potência mecânica / torque
$$P = T\,\omega \;\Leftrightarrow\; T = P/\omega$$
- P: potência [W]
- T: torque [N·m]
- ω: velocidade angular [rad/s]
- Hipóteses: regime quase estático
- Limitações: perdas internas tratadas por fatores do jogo
- `src/game/nexus-update/registry.ts:50` (partFields) `{ k: "torqueGas", label: "Torque gasolina", type: "number", unit: "kgf·m", min: 0.3, max: 5, formula: "T = P / ω" },`
- `src/game/nexus-update/registry.ts:51` (partFields) `{ k: "torqueEth", label: "Torque etanol", type: "number", unit: "kgf·m", min: 0.3, max: 5, formula: "T = P / ω" },`
### Segunda lei de Newton
$$a = \frac{F}{m}$$
- a: aceleração [m/s²]
- F: força resultante [N]
- m: massa [kg]
- Hipóteses: corpo rígido, movimento retilíneo
- Limitações: sem inércia rotativa explícita salvo onde indicado
- `src/game/nexus-update/registry.ts:47` (partFields) `{ k: "dryWeight", label: "Peso seco", type: "number", unit: "kg", min: 60, max: 250, formula: "a = F / (moto + piloto + combustível)" },`

## Dependências
- `mec.cloud.cloud-store`
- `mec.parts`
- `mec.physics`
- `mec.trampo`
- `mec.nexus-update.dyno-config`

## Dependentes
—

## Testes existentes
- `src/test/nexus.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
