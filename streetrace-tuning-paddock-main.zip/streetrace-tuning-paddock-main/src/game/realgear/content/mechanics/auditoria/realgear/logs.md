# Mecânica: logs

- ID: `mec.realgear.logs` · auditoria / realgear
- Arquivo: `src/game/realgear/logs.ts` (36 linhas, sha256 e374efcc09a49ae4)
- Estado: **CONFIRMADO_NO_CODIGO**

## Objetivo (cabeçalho do código)
Log permanente de testes por camada (JSON) + exportação open source e ZIP.

## Funções exportadas (saídas)
- L8: `export function readLayerLogs(): LayerLog[] {`
- L11: `export function appendLayerLogs(p: Projeto, x: Execucao): LayerLog[] {`
- L18: `export const layerFile = (n: number, nome: string) => `camada-${String(n).padStart(2, "0")}-${slug(nome)}.json`;`
- L21: `export function openSource() {`
- L25: `export function zipBlob(files: Record<string, unknown>): Blob {`
- L30: `export function download(blob: Blob, name: string) {`
- L35: `export const jsonBlob = (x: unknown) => new Blob([JSON.stringify(x, null, 2)], { type: "application/json" });`

## Entradas tipadas
- p: Projeto
- x: Execucao
- files: Record
- blob: Blob

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.cloud.cloud-store`
- `mec.realgear.funnel`

## Dependentes
- `mec.autopecas.autopecas`
- `mec.realgear.live-intake`

## Testes existentes
Nenhum teste importa este módulo.

## Limitações
—

> Testes de software passando não equivalem a validação física.
