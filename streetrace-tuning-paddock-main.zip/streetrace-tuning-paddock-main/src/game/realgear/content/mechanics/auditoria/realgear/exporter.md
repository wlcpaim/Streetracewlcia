# Mecânica: exporter

- ID: `mec.realgear.bridge.exporter` · auditoria / realgear
- Arquivo: `src/game/realgear/bridge/exporter.ts` (108 linhas, sha256 47bb55198869f431)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Exportador da Wikipedia StreetRace: projeto aprovado pelo mecânico → pacote JSON de engenharia (SI). Função pura: lê a física do jogo, não altera o motor, o setup nem o save do jogador. Conversões explícitas para SI (cada uma nomeada no source do dado).

## Funções exportadas (saídas)
- L17: `export function exportProject(p: Projeto, createdAt = new Date().toISOString()): ExportResult {`

## Entradas tipadas
- p: Projeto

## Fórmulas
### Velocidade angular
$$\omega = \frac{2\pi n}{60}$$
- ω: velocidade angular [rad/s]
- n: rotação [rpm]
- Hipóteses: rotação uniforme no passo
- Limitações: não modela flutuação cíclica
- `src/game/realgear/bridge/exporter.ts:10` `export const MM_TO_M = 1e-3, CC_TO_M3 = 1e-6, L_TO_M3 = 1e-3, KG_L_TO_KG_M3 = 1e3, DEG_TO_RAD = Math.PI / 180, RPM_TO_RAD_S = (2 * Math.PI) / 60, CV_TO_W = 735.49875, KM_TO_M = 1e3, PCT_TO_1 = 1e-2;`
### Relação de transmissão final
$$i_f = \frac{Z_{coroa}}{Z_{pinhão}}$$
- Z: número de dentes [—]
- Hipóteses: sem escorregamento
- Limitações: relações primária/câmbio não oficiais
- `src/game/realgear/bridge/exporter.ts:67` (exportProject) `final_ratio: q(s.rear / s.front, "1", "CALCULADO", "rear / front"),`

## Dependências
- `mec.physics`
- `mec.parts`
- `mec.intel.changelog`
- `mec.realgear.funnel`
- `mec.realgear.bridge.contract`

## Dependentes
—

## Testes existentes
- `src/test/realgear-bridge.test.ts`

## Limitações
- contém valores marcados como estimados
- contém dados desconhecidos que bloqueiam cálculo

> Testes de software passando não equivalem a validação física.
