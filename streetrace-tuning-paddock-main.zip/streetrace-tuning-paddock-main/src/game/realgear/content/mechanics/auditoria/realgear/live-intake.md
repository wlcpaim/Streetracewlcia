# Mecânica: live-intake

- ID: `mec.realgear.live-intake` · auditoria / realgear
- Arquivo: `src/game/realgear/live-intake.ts` (42 linhas, sha256 a5ae950673963ee7)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Entrada automática: todo relatório ao vivo da Wikipedia (corrida ou dinamômetro) vira um projeto e passa pelo funil de 24 camadas com a mesma física. Somente leitura: nada volta para o Setup.

## Funções exportadas (saídas)
- L16: `export function liveProject(r: LiveReport, bike: BikeModel, setup: Setup): Projeto {`
- L21: `export function readIntake(): Intake[] {`
- L27: `export function analyzeLive(r: LiveReport, bike: BikeModel, setup: Setup): Intake {`

## Entradas tipadas
- r: LiveReport
- bike: BikeModel
- setup: Setup

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.cloud.cloud-store`
- `mec.physics`
- `mec.preload-report`
- `mec.realgear.funnel`
- `mec.realgear.history`
- `mec.realgear.logs`
- `mec.realgear.fix.pipeline`

## Dependentes
—

## Testes existentes
- `src/test/live-intake.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
