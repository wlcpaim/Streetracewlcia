# Mecânica: crossaudit

- ID: `mec.cloud.crossaudit` · auditoria / cloud
- Arquivo: `src/game/cloud/crossaudit.ts` (149 linhas, sha256 234f7b6ed07e135f)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
StreetRace Cloud Integration 4.0 — núcleo puro da auditoria cruzada TS × Python. Só leitura sobre axles.ts/kinematics.ts: não altera fórmulas, constantes nem a corrida.

## Funções exportadas (saídas)
- L14: `export function specOf(id: SpecId): MotoSpec {`
- L51: `export function missingFor(s: MotoSpec, c: CondIn = COND): string[] {`
- L70: `export function tsCompute(s: MotoSpec, c: CondIn = COND): TsResult {`
- L95: `export function compare(ts: TsResult, py: PyResponse): { status: CmpStatus; reason: string; rows: MetricCmp[] } {`
- L132: `export function investigateDivergence(spec: MotoSpec, c: CondIn, stored: TsResult, rows: MetricCmp[]) {`
- L148: `export const runKeyOf = (id: SpecId, spec: MotoSpec, c: CondIn, codeVersion: string) => shaOf({ id, spec, c, codeVersion, contract: CLOUD_CONTRACT, axles: AXLES_VERSION });`

## Entradas tipadas
- id: SpecId
- s: MotoSpec
- c: CondIn
- ts: TsResult
- py: PyResponse
- status: CmpStatus
- rows: MetricCmp
- spec: MotoSpec
- stored: TsResult
- contract: CLOUD_CONTRACT
- axles: AXLES_VERSION

## Fórmulas
### Potência mecânica / torque
$$P = T\,\omega \;\Leftrightarrow\; T = P/\omega$$
- P: potência [W]
- T: torque [N·m]
- ω: velocidade angular [rad/s]
- Hipóteses: regime quase estático
- Limitações: perdas internas tratadas por fatores do jogo
- `src/game/cloud/crossaudit.ts:82` (tsCompute) `i_total: o.iTotal, rpm_roda: last.rpm, torque_roda: last.torque, potencia_roda: last.torque * wRoda, potencia_entrada: c.torque * omega(c.rpm),`

## Dependências
- `mec.realgear.axles`
- `mec.realgear.kinematics`
- `mec.realgear.sha256`

## Dependentes
- `mec.cloud.cloud.functions`
- `mec.cloud.cloud.server`
- `mec.src.nexus.connectors`
- `mec.src.nexus.nexus.functions`
- `mec.src.nexus.nexus.server`
- `mec.src.nexus.orchestrator`

## Testes existentes
- `src/test/crossaudit.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
