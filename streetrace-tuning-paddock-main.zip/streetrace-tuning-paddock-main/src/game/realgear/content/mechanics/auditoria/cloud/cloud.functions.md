# Mecânica: cloud.functions

- ID: `mec.cloud.cloud.functions` · auditoria / cloud
- Arquivo: `src/game/cloud/cloud.functions.ts` (17 linhas, sha256 fef173e385561930)
- Estado: **CONFIRMADO_NO_CODIGO**

## Objetivo (cabeçalho do código)
Funções de servidor chamadas pela interface (RealGear → aba Nuvem). Escrita só via servidor.

## Funções exportadas (saídas)

## Entradas tipadas
—

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.cloud.crossaudit`

## Dependentes
—

## Testes existentes
Nenhum teste importa este módulo.

## Limitações
—

> Testes de software passando não equivalem a validação física.
