# Mecânica: cloud-store

- ID: `mec.cloud.cloud-store` · auditoria / cloud
- Arquivo: `src/game/cloud/cloud-store.ts` (220 linhas, sha256 e10fea28e73b5ba3)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Armazenamento do jogo 100% na nuvem (tabela game_saves, uma linha por usuário e chave). O save do piloto é por JOGADOR (kind "player:<uuid>"); demais chaves (som, ENG, ajustes) são da conta. Ao entrar, hydrate() baixa tudo, garante um jogador (players) e escolhe o ativo (account_state). authResolved só fica true depois que a sessão foi checada e, se houver conta, o jogador carregado: o CloudGate usa isso para nunca mostrar a landing a quem está logado.

## Funções exportadas (saídas)
- L26: `export const setPlayerSaver = (f: Saver) => { savePlayer = f; };`
- L34: `export const setEntering = (v: boolean) => { entering = v; try { if (v) sessionStorage.setItem("sr-entering", "1"); else sessionStorage.removeItem("sr-entering"); } catch { /* */ } emit(); };`
- L35: `export const isEntering = () => { if (entering) return true; try { return sessionStorage.getItem("sr-entering") === "1"; } catch { return false; } };`
- L36: `export const cloudState = () => ({ status, userId: uid, playerId: pid, authResolved, ready: status !== "offline" && status !== "carregando" });`
- L37: `export const onCloudStore = (f: () => void) => { subs.add(f); return () => { subs.delete(f); }; };`
- L38: `export const activePlayerId = () => pid;`
- L39: `export const myPlayers = () => players;`
- L40: `export const activePlayer = () => players.find((p) => p.id === pid) ?? null;`
- L80: `export async function flushNow() {`
- L98: `export async function createPlayerRow(name: string): Promise<PlayerRow> {`
- L133: `export function hydrate(id: string | null): Promise<void> {`
- L170: `export async function switchPlayer(next: string) {`
- L181: `export async function renamePlayerRow(id: string, name: string) {`
- L189: `export function startCloudStore() {`

## Entradas tipadas
- f: Saver

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.src.integrations.supabase.client`

## Dependentes
- `mec.anticheat.update-watch`
- `mec.audit-reset`
- `mec.autopecas.analise`
- `mec.autopecas.autopecas`
- `mec.bugfix.bugfix`
- `mec.cloud.save-sync`
- `mec.economy`
- `mec.engine-sound`
- `mec.engineering.dados.pipeline`
- `mec.engineering.eng`
- `mec.intel.store`
- `mec.intel.wikipedia`
- `mec.nexus-update.registry`
- `mec.nitro.lab`
- `mec.preload-report`
- `mec.realgear.bridge.ledger`
- `mec.realgear.fix.pipeline`
- `mec.realgear.history`
- `mec.realgear.live-intake`
- `mec.realgear.logs`
- `mec.settings`
- `mec.sound.library`
- `mec.store`

## Testes existentes
- `src/test/engine-safe.test.ts`
- `src/test/intelligence.test.ts`
- `src/test/jobrun.test.ts`
- `src/test/live-intake.test.ts`
- `src/test/routes.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
