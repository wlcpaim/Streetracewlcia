# Mecânica: funnel

- ID: `mec.realgear.funnel` · auditoria / realgear
- Arquivo: `src/game/realgear/funnel.ts` (303 linhas, sha256 35a17592e9fd3385)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
ENGRENAGEM REAL — funil de 24 camadas. Lê a física do jogo (somente leitura) e recalcula por rotas independentes no SI. Dado ausente = DESCONHECIDO e bloqueia; nunca é inventado.

## Funções exportadas (saídas)
- L44: `export function hashOf(x: unknown): string {`
- L71: `export function validCompression(cr: unknown): cr is number {`
- L75: `export function runFunnel(p: Projeto, at = new Date().toISOString(), ov: Overrides = {}): Execucao {`
- L288: `export function reportTxt(p: Projeto, x: Execucao, c: Camada): string {`
- L302: `export const stockProject = (b: BikeModel): Projeto => ({ id: `stock-${b.id}`, versao: "1", nome: `${b.name} original`, bike: b, setup: STOCK_SETUP, aprovadoMecanico: true, origem: "Wikipedia StreetRa`

## Entradas tipadas
- p: Projeto
- ov: Overrides
- x: Execucao
- c: Camada
- b: BikeModel
- setup: STOCK_SETUP

## Fórmulas
### Velocidade angular
$$\omega = \frac{2\pi n}{60}$$
- ω: velocidade angular [rad/s]
- n: rotação [rpm]
- Hipóteses: rotação uniforme no passo
- Limitações: não modela flutuação cíclica
- `src/game/realgear/funnel.ts:116` (w5) `const w5 = (2 * Math.PI * e.rpmLimit) / 60, F5 = kb.recKg * (kb.geo.strokeMm / 2000) * w5 * w5;`
- `src/game/realgear/funnel.ts:151` (crBack) `const rpm = e.rpmLimit, w = (2 * Math.PI * rpm) / 60, r = S / 2;`
### Potência mecânica / torque
$$P = T\,\omega \;\Leftrightarrow\; T = P/\omega$$
- P: potência [W]
- T: torque [N·m]
- ω: velocidade angular [rad/s]
- Hipóteses: regime quase estático
- Limitações: perdas internas tratadas por fatores do jogo
- `src/game/realgear/funnel.ts:163` (Tpk) `L.push({ ...base(9, "B", "Dinâmica, forças e torque", "T = P/ω em toda a curva, duas rotas."),`
- `src/game/realgear/funnel.ts:166` (Tpk) `equacoes: [{ nome: "T no pico", eq: "T = P/ω", subst: `${f(pk.kwMotor * 1000, 2)}/(2π·${pk.rpm}/60)`, resultado: Tpk, unidade: "N·m", dimensao: "M·L²·T⁻²" }],`
### Área do pistão / cilindrada
$$A = \frac{\pi D^2}{4},\quad V_d = A\,S$$
- D: diâmetro [m]
- S: curso [m]
- A: área [m²]
- V_d: cilindrada [m³]
- Hipóteses: cilindro perfeito
- Limitações: sem folgas
- `src/game/realgear/funnel.ts:107` (base) `const vdFicha = fic ? (Math.PI / 4) * (fic.boreMm / 10) ** 2 * (fic.strokeMm / 10) : NaN;`
- `src/game/realgear/funnel.ts:141` (orig5) `const D = boreCalc / 1000, S = (fic?.strokeMm ?? MECH_STROKE_MM) / 1000, Vd = (Math.PI / 4) * D * D * S, Vc = crOk ? Vd / (s.compression - 1) : NaN;`
### Pressão / tensão normal
$$p = \frac{F}{A},\quad \sigma = \frac{F}{A}$$
- F: força [N]
- A: área [m²]
- σ, p: tensão / pressão [Pa]
- Hipóteses: distribuição uniforme
- Limitações: sem concentração de tensões
- `src/game/realgear/funnel.ts:128` (orig5) `ausentes: c5.ausentes.map((a) => `${a.nome} — evidência: ${a.evidencia}`), modelo: "σ = F/A; FS = σ_y/σ (só com dados medidos ou documentados)",`
- `src/game/realgear/funnel.ts:203` (Tpk) `ausentes: falta13, modelo: "F = m·r·ω² (1ª ordem); σ = F/A; FS = σ_y/σ", hipoteses: [], limites: "Sem termo de 2ª ordem; tração pura no PMS.",`
### Força inercial alternativa
$$F_i = m\, r\, \omega^2 (\cos\theta + \lambda \cos 2\theta)$$
- m: massa alternativa [kg]
- r: raio da manivela [m]
- ω: velocidade angular [rad/s]
- λ: r/L biela [—]
- Hipóteses: biela rígida
- Limitações: massas alternativas estimadas
- `src/game/realgear/funnel.ts:191` (Tpk) `const Fin = kb.recKg * r * w * w;`
### Consumo específico (BSFC)
$$\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$$
- P: potência [kW]
- BSFC: consumo específico [kg/kWh]
- ρ_f: densidade do combustível [kg/L]
- Hipóteses: plena carga
- Limitações: BSFC fixo por combustível
- `src/game/realgear/funnel.ts:176` (Tpk) `const etaOtto = crOk ? 1 - Math.pow(s.compression, 1 - GAMMA) : NaN, etaBrake = 3.6e6 / (BSFC[s.fuel] * (LHV[s.fuel] ?? NaN));`
- `src/game/realgear/funnel.ts:177` (Tpk) `L.push({ ...crBlock, ...base(11, "B", "Termodinâmica e transferência de energia", "Rendimento efetivo (BSFC) abaixo do limite do ciclo Otto."),`
- `src/game/realgear/funnel.ts:178` (Tpk) `entradas: [{ nome: "BSFC", valor: BSFC[s.fuel], unidade: "kg/kWh", origem: "ESTIMADO" }, { nome: "PCI", valor: LHV[s.fuel] ?? null, unidade: "J/kg", origem: "ESTIMADO" }, { nome: "γ", valor: GAMMA, unidade: "—", origem: `
- `src/game/realgear/funnel.ts:180` (Tpk) `equacoes: [{ nome: "η_Otto", eq: "η = 1 − CR^(1−γ)", subst: `1 − ${s.compression}^(−0,3)`, resultado: etaOtto, unidade: "—", dimensao: "1" }, { nome: "η_efetivo", eq: "η = 3,6e6/(BSFC·PCI)", subst: `3,6e6/(${BSFC[s.fuel]`
- `src/game/realgear/funnel.ts:256` (qFuel) `const tL = long.result.finishS ?? NaN, maxL = ((e.hp * CV_W) / 1000) * BSFC[s.fuel] / FUEL_DENSITY[s.fuel] / 3600 * tL;`
- `src/game/realgear/funnel.ts:257` (qFuel) `L.push({ ...base(22, "D", "Resistência e funcionamento prolongado", "1000 m: consumo dentro do teto físico por BSFC."),`
- `src/game/realgear/funnel.ts:259` (qFuel) `ausentes: [], modelo: "L ≤ P_máx·BSFC/ρ·t", hipoteses: ["Teto usa a potência nominal o tempo todo."], limites: "1000 m, não endurance real.",`
- `src/game/realgear/funnel.ts:260` (qFuel) `equacoes: [{ nome: "teto de consumo", eq: "L = P·BSFC/ρ/3600·t", subst: `${f(e.hp * CV_W / 1000, 3)}·${BSFC[s.fuel]}/${FUEL_DENSITY[s.fuel]}/3600·${f(tL, 3)}`, resultado: maxL, unidade: "L", dimensao: "L³" }],`

## Dependências
- `mec.physics-registry.constants`
- `mec.physics`
- `mec.parts`
- `mec.mechlimits`
- `mec.rootcause`
- `mec.admin-lab`
- `mec.intel.powertrain`
- `mec.intel.changelog`
- `mec.realgear.materials`
- `mec.realgear.knowledge.solver`

## Dependentes
- `mec.autopecas.autopecas`
- `mec.bugfix.bugfix`
- `mec.cloud.cloud.server`
- `mec.realgear.axles`
- `mec.realgear.bridge.exporter`
- `mec.realgear.fix.contracts`
- `mec.realgear.fix.pipeline`
- `mec.realgear.fix.triage`
- `mec.realgear.fix.wikipedia`
- `mec.realgear.history`
- `mec.realgear.live-intake`
- `mec.realgear.logs`
- `mec.src.nexus.connectors`
- `mec.src.nexus.orchestrator`

## Testes existentes
- `src/test/bugfix.test.ts`
- `src/test/fixcenter.test.ts`
- `src/test/funnel-compression.test.ts`
- `src/test/layer13.test.ts`
- `src/test/layer5-materials.test.ts`
- `src/test/physics-constants.test.ts`
- `src/test/realgear-bridge.test.ts`
- `src/test/realgear-solver.test.ts`
- `src/test/realgear.test.ts`
- `src/test/triage.test.ts`

## Limitações
- contém valores marcados como estimados
- contém dados desconhecidos que bloqueiam cálculo

> Testes de software passando não equivalem a validação física.
