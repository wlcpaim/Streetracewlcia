# Mecânica: contract

- ID: `mec.realgear.bridge.contract` · auditoria / realgear
- Arquivo: `src/game/realgear/bridge/contract.ts` (145 linhas, sha256 af01fdeed03a2267)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Contrato JSON versionado entre a Wikipedia StreetRace (TypeScript) e a Engrenagem Real (Python). Mesmas regras em python/realgear/contract.py: SI, unidade obrigatória por grandeza, origem por dado, dado ausente = null + DESCONHECIDO, hash canônico idêntico nas duas linguagens. Grandeza física: valor em SI, unidade explícita, origem e de onde veio. */

## Funções exportadas (saídas)
- L58: `export function canonical(x: unknown): string {`
- L67: `export function fnv1a32(s: string): string {`
- L73: `export const packageHash = (p: Omit<ProjectPackage, "integrity">) => fnv1a32(canonical({ schema_version: p.schema_version, identification: p.identification, configuration: p.configuration, missing_dat`
- L91: `export function validatePackage(x: unknown): string[] {`
- L127: `export function validateResponse(x: unknown): string[] {`
- L142: `export function parseJson(txt: string): { ok: true; value: unknown } | { ok: false; error: string } {`

## Entradas tipadas
- p: Omit

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
—

## Dependentes
- `mec.realgear.bridge.exporter`
- `mec.realgear.bridge.ledger`
- `mec.realgear.knowledge.solver`

## Testes existentes
- `src/test/realgear-bridge.test.ts`

## Limitações
- contém valores marcados como estimados
- contém dados desconhecidos que bloqueiam cálculo

> Testes de software passando não equivalem a validação física.
