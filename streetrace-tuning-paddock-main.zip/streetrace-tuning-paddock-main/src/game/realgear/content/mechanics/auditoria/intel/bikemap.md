# Mecânica: bikemap

- ID: `mec.intel.bikemap` · auditoria / intel
- Arquivo: `src/game/intel/bikemap.ts` (102 linhas, sha256 0cc7d65e27dd9262)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Mapeamento da Moto — somente leitura. Cada módulo descreve uma parte real do jogo, as fórmulas que o código usa e os números calculados pelas próprias funções de physics.ts. Nada aqui muda a corrida; o que o jogo não calcula fica marcado como NAO_CALCULADO_NA_CORRIDA.

## Funções exportadas (saídas)
- L14: `export function bikeMap(b: BikeModel, s: Setup, fuelL = b.tank): Modulo[] {`

## Entradas tipadas
- b: BikeModel
- s: Setup

## Fórmulas
### Velocidade angular
$$\omega = \frac{2\pi n}{60}$$
- ω: velocidade angular [rad/s]
- n: rotação [rpm]
- Hipóteses: rotação uniforme no passo
- Limitações: não modela flutuação cíclica
- `src/game/intel/bikemap.ts:17` (w) `const w = (e.rpmLimit * 2 * Math.PI) / 60;`
### Potência mecânica / torque
$$P = T\,\omega \;\Leftrightarrow\; T = P/\omega$$
- P: potência [W]
- T: torque [N·m]
- ω: velocidade angular [rad/s]
- Hipóteses: regime quase estático
- Limitações: perdas internas tratadas por fatores do jogo
- `src/game/intel/bikemap.ts:36` (vChain) `{ nome: "Torque no corte", formula: "T = P/ω", conta: `${f(Pw, 0)} / ${f(w, 1)}`, valor: `${f(Pw / w, 2)} N·m`, origem: "CALCULADO" },`
### Segunda lei de Newton
$$a = \frac{F}{m}$$
- a: aceleração [m/s²]
- F: força resultante [N]
- m: massa [kg]
- Hipóteses: corpo rígido, movimento retilíneo
- Limitações: sem inércia rotativa explícita salvo onde indicado
- `src/game/intel/bikemap.ts:68` (vChain) `{ nome: "Massa girante", formula: "a = F/(m × 1,06)", conta: "6% somado à massa", valor: "fator 1,06", origem: "JOGO" },`
- `src/game/intel/bikemap.ts:97` (vChain) `{ nome: "Aceleração", formula: "a = (F − arrasto − rolamento)/(m × 1,06)", conta: "a cada passo da corrida", valor: "por passo", origem: "CALCULADO" },`
### Arrasto aerodinâmico
$$F_d = \tfrac12 \rho C_d A v^2$$
- F_d: força de arrasto [N]
- ρ: densidade do ar [kg/m³]
- C_dA: área de arrasto [m²]
- v: velocidade relativa ao ar [m/s]
- Hipóteses: escoamento turbulento, Cd constante
- Limitações: CdA do jogo, sem túnel de vento
- `src/game/intel/bikemap.ts:27` (vChain) `const roll = tire.crr * m * G, drag100 = 0.5 * RHO * CDA * (100 / 3.6) ** 2;`
### Resistência ao rolamento
$$F_r = C_{rr}\, m\, g$$
- C_rr: coeficiente de rolamento [—]
- m: massa [kg]
- g: gravidade [m/s²]
- Hipóteses: pista plana
- Limitações: Crr do catálogo de pneus, não medido
- `src/game/intel/bikemap.ts:27` (vChain) `const roll = tire.crr * m * G, drag100 = 0.5 * RHO * CDA * (100 / 3.6) ** 2;`
### Relação de transmissão final
$$i_f = \frac{Z_{coroa}}{Z_{pinhão}}$$
- Z: número de dentes [—]
- Hipóteses: sem escorregamento
- Limitações: relações primária/câmbio não oficiais
- `src/game/intel/bikemap.ts:50` (vChain) `{ id: "corrente", eixo: "A↔B", titulo: "Pinhão, corrente 428 e coroa (C → B)", fonte: "Setup.front/rear, gearSpeeds()",`

## Dependências
- `mec.physics`
- `mec.intel.powertrain`

## Dependentes
—

## Testes existentes
- `src/test/bikemap.test.ts`

## Limitações
- contém valores marcados como estimados

> Testes de software passando não equivalem a validação física.
