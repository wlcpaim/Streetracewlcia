# Mecânica: contracts

- ID: `mec.realgear.fix.contracts` · auditoria / realgear
- Arquivo: `src/game/realgear/fix/contracts.ts` (66 linhas, sha256 68ad1a4ec0c6ee9e)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
FIX CENTER — contratos versionados do ciclo RealGear → Python → Central de Falhas → Wikipedia → Sandbox. Únicas constantes que um patch pode mexer no sandbox. Critérios/tolerâncias de teste nunca entram aqui. */

## Funções exportadas (saídas)
- L65: `export const emptyFix = (): FixState => ({ schema: FIX_SCHEMA, failures: [], investigations: [], diagnoses: [], patches: [], executions: [], validations: [], status: {}, history: [], lock: null, activ`

## Entradas tipadas
- schema: FIX_SCHEMA

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.realgear.funnel`
- `mec.physics`

## Dependentes
- `mec.bugfix.bugfix`
- `mec.cloud.cloud.server`
- `mec.cloud.cloud.server`
- `mec.realgear.fix.investigator`
- `mec.realgear.fix.pipeline`
- `mec.realgear.fix.triage`
- `mec.realgear.fix.wikipedia`
- `mec.src.nexus.connectors`
- `mec.src.nexus.orchestrator`

## Testes existentes
- `src/test/bugfix.test.ts`
- `src/test/fixcenter.test.ts`
- `src/test/nexus-phase3.test.ts`
- `src/test/nexus.test.ts`
- `src/test/triage.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
