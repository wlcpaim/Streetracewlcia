# Mecânica: wikipedia

- ID: `mec.intel.wikipedia` · auditoria / intel
- Arquivo: `src/game/intel/wikipedia.ts` (103 linhas, sha256 00618ba27556dee7)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Wikipedia (pt) como base conceitual: REST page/summary + busca do MediaWiki, com cache, origem e data. Não é fonte de valores de preparação; serve para conceitos e para cruzar com as fórmulas do jogo.

## Funções exportadas (saídas)
- L44: `export function readCache(): WikiArticle[] {`
- L52: `export function concepts(extract: string) {`
- L69: `export async function search(q: string, limit = 6): Promise<{ title: string; snippet: string }[]> {`
- L81: `export async function fetchTopic(t: WikiTopic, force = false): Promise<WikiArticle> {`
- L97: `export async function fetchAll(onEach: (q: string, ok: boolean, err?: string) => void, force = false) {`

## Entradas tipadas
- t: WikiTopic

## Fórmulas
### Consumo específico (BSFC)
$$\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$$
- P: potência [kW]
- BSFC: consumo específico [kg/kWh]
- ρ_f: densidade do combustível [kg/L]
- Hipóteses: plena carga
- Limitações: BSFC fixo por combustível
- `src/game/intel/wikipedia.ts:34` `{ q: "Etanol", cat: "Combustível", sistemas: ["BSFC", "FUEL_DENSITY"] },`
- `src/game/intel/wikipedia.ts:35` `{ q: "Gasolina", cat: "Combustível", sistemas: ["BSFC", "FUEL_DENSITY"] },`

## Dependências
- `mec.cloud.cloud-store`

## Dependentes
—

## Testes existentes
- `src/test/fixcenter.test.ts`
- `src/test/intelligence.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
