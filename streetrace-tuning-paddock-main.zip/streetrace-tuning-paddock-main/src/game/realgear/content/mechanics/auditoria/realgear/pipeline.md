# Mecânica: pipeline

- ID: `mec.realgear.fix.pipeline` · auditoria / realgear
- Arquivo: `src/game/realgear/fix/pipeline.ts` (146 linhas, sha256 d632a31b75168311)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
FIX CENTER — Central de Falhas + Repair Sandbox + revalidação. Funções puras sobre FixState; persistência no fim. O sandbox só passa overrides ao runFunnel (isolado). A corrida e o código principal nunca mudam aqui: integração no código exige aprovação técnica (modelo físico fundamental).

## Funções exportadas (saídas)
- L21: `export function captureFailures(st: FixState, p: Projeto, x: Execucao, parentFailureId: string | null = null): { st: FixState; novos: FailureEvent[] } {`
- L41: `export const projectOf = (ev: FailureEvent): Projeto => ({ id: ev.projetoId, versao: ev.versao, nome: ev.projetoNome, bike: bikeModel(ev.bikeId), setup: ev.setup, aprovadoMecanico: true, origem: "Fix `
- L44: `export function validatePatch(st: FixState, p: RepairPatch, src = SOURCES): string[] {`
- L63: `export function runSandbox(st: FixState, patch: RepairPatch, at: string): { st: FixState; ex: RepairExecution } {`
- L85: `export function validate(st: FixState, patch: RepairPatch, ex: RepairExecution, at: string): { st: FixState; v: ValidationResult } {`
- L99: `export function submitPatch(st: FixState, patch: RepairPatch, at: string): { st: FixState; erros: string[] } {`
- L107: `export function applyAndRetest(st: FixState, patch: RepairPatch, at: string): FixState {`
- L120: `export function processFailure(st: FixState, failureId: string, at: string, inv?: PythonInvestigation): FixState {`
- L132: `export function revertPatch(st: FixState, patchId: string, at: string): FixState {`
- L138: `export function reproduce(ev: FailureEvent): { pass: boolean; observado: string } {`
- L144: `export function readFix(): FixState { try { const s = JSON.parse(cloudStore.getItem(FIX_KEY) ?? "null"); return s?.schema === FIX_SCHEMA ? { ...emptyFix(), ...s, lock: null } : emptyFix(); } catch { r`
- L145: `export function saveFix(st: FixState) { try { cloudStore.setItem(FIX_KEY, JSON.stringify(st)); } catch { /* cheio */ } return st; }`

## Entradas tipadas
- st: FixState
- p: Projeto
- x: Execucao
- novos: FailureEvent
- ev: FailureEvent
- p: RepairPatch
- patch: RepairPatch
- ex: RepairExecution
- v: ValidationResult

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.cloud.cloud-store`
- `mec.physics`
- `mec.admin-lab`
- `mec.realgear.funnel`
- `mec.realgear.sha256`
- `mec.realgear.fix.contracts`
- `mec.realgear.fix.investigator`
- `mec.realgear.fix.wikipedia`

## Dependentes
- `mec.autopecas.autopecas`
- `mec.bugfix.bugfix`
- `mec.cloud.cloud.server`
- `mec.realgear.fix.triage`
- `mec.realgear.live-intake`
- `mec.src.nexus.connectors`
- `mec.src.nexus.orchestrator`

## Testes existentes
- `src/test/bugfix.test.ts`
- `src/test/eng-dados.test.ts`
- `src/test/fixcenter.test.ts`
- `src/test/triage.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
