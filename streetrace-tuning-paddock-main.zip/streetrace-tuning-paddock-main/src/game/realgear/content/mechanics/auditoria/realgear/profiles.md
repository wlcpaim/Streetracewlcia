# Mecânica: profiles

- ID: `mec.realgear.knowledge.profiles` · auditoria / realgear
- Arquivo: `src/game/realgear/knowledge/profiles.ts` (35 linhas, sha256 aae4f633f5b8b4f2)
- Estado: **CONFIRMADO_NO_CODIGO**

## Objetivo (cabeçalho do código)
BASE DE CONHECIMENTO — perfis de material típicos de engenharia para monocilíndricos 150–160 cc arrefecidos a ar (Honda CG 160 Titan, Yamaha Factor 150, kits de performance tipo 4MM). Valores de literatura/catálogo, NÃO medidos: servem ao solucionador como INFERIDO_KB e sempre passam pela conferência rigorosa do NEXUS.

## Funções exportadas (saídas)
- L29: `export function perfilDe(peca: MaterialProfile["peca"], partId: string): { p: MaterialProfile; confianca: Confianca; base: string } | null {`

## Entradas tipadas
- peca: MaterialProfile
- p: MaterialProfile
- confianca: Confianca

## Fórmulas
### Pressão / tensão normal
$$p = \frac{F}{A},\quad \sigma = \frac{F}{A}$$
- F: força [N]
- A: área [m²]
- σ, p: tensão / pressão [Pa]
- Hipóteses: distribuição uniforme
- Limitações: sem concentração de tensões
- `src/game/realgear/knowledge/profiles.ts:20` `{ id: "pistao-fundido-ac8a", peca: "pistao", aplicaA: ["pistao-original"], liga: "Al-Si eutético fundido (AC8A / A332, ~12 % Si)", tratamento: "T6 (solubilização + envelhecimento)",`

## Dependências
—

## Dependentes
- `mec.realgear.knowledge.solver`

## Testes existentes
Nenhum teste importa este módulo.

## Limitações
—

> Testes de software passando não equivalem a validação física.
