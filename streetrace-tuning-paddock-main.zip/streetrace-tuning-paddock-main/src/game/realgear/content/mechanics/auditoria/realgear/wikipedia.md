# Mecânica: wikipedia

- ID: `mec.realgear.fix.wikipedia` · auditoria / realgear
- Arquivo: `src/game/realgear/fix/wikipedia.ts` (65 linhas, sha256 0fb75c5bda3a49d3)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Wikipedia StreetRace — segunda análise independente do relatório do investigador e geração do patch. Recalcula pela própria rota (SI, FICHA importada — não a linha lida por regex), nunca aceita a conclusão às cegas.

## Funções exportadas (saídas)
- L8: `export function rootOf(st: FixState, failureId: string): string {`
- L13: `export const chainOf = (st: FixState, failureId: string) => { const r = rootOf(st, failureId); return st.failures.filter((f) => rootOf(st, f.failureId) === r).map((f) => f.failureId); };`
- L15: `export function makePatch(ev: FailureEvent, inv: PythonInvestigation, value: number, revision: number, origem: RepairPatch["origem"], src = SOURCES): RepairPatch {`
- L33: `export function diagnose(st: FixState, ev: FailureEvent, inv: PythonInvestigation): WikipediaDiagnosis {`

## Entradas tipadas
- st: FixState
- ev: FailureEvent
- inv: PythonInvestigation
- origem: RepairPatch

## Fórmulas
### Área do pistão / cilindrada
$$A = \frac{\pi D^2}{4},\quad V_d = A\,S$$
- D: diâmetro [m]
- S: curso [m]
- A: área [m²]
- V_d: cilindrada [m³]
- Hipóteses: cilindro perfeito
- Limitações: sem folgas
- `src/game/realgear/fix/wikipedia.ts:46` (id) `const vdSI = fic ? (Math.PI / 4) * (fic.boreMm * 1e-3) ** 2 * (v * 1e-3) * 1e6 : NaN; // m³ → cm³`

## Dependências
- `mec.realgear.funnel`
- `mec.realgear.sha256`
- `mec.realgear.fix.contracts`
- `mec.realgear.fix.investigator`

## Dependentes
- `mec.realgear.fix.pipeline`

## Testes existentes
- `src/test/fixcenter.test.ts`
- `src/test/intelligence.test.ts`

## Limitações
- contém dados desconhecidos que bloqueiam cálculo

> Testes de software passando não equivalem a validação física.
