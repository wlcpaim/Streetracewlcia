# Mecânica: solver

- ID: `mec.realgear.knowledge.solver` · auditoria / realgear
- Arquivo: `src/game/realgear/knowledge/solver.ts` (56 linhas, sha256 6e8c8698dff556f0)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
SOLUCIONADOR da Camada 5: identifica gaps, resolve pela Base de Conhecimento e devolve evidências rastreáveis. Não altera Setup, catálogo nem física de corrida. A aprovação final é sempre do NEXUS (nexusConferirInferencia).

## Funções exportadas (saídas)
- L13: `export function solucionarC5(dados: DadoMat[], slots: { biela: string; pistao: string }): Solucao {`
- L37: `export function nexusConferirInferencia(s: Solucao, fatorSeguranca: number | null): ParecerInferencia {`

## Entradas tipadas
- dados: DadoMat
- s: Solucao

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.realgear.materials`
- `mec.realgear.knowledge.profiles`
- `mec.realgear.bridge.contract`

## Dependentes
- `mec.realgear.funnel`

## Testes existentes
- `src/test/realgear-solver.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
