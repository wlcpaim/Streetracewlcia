# Mecânica: bugfix

- ID: `mec.bugfix.bugfix` · auditoria / bugfix
- Arquivo: `src/game/bugfix/bugfix.ts` (78 linhas, sha256 2cc2714ef8f3c462)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
BUG FIX — Wikipedia resolve falhas do RealGear (Fix Center/sandbox), NEXUS confere a mudança e aprova, e o projeto volta ao funil. Nada aqui altera Setup, corrida ou código principal: só overrides de sandbox reexecutados no runFunnel.

## Funções exportadas (saídas)
- L21: `export const readBug = (): BugState => { try { const s = JSON.parse(cloudStore.getItem(BUGFIX_KEY) ?? "null"); return Array.isArray(s?.items) ? s : { items: [] }; } catch { return { items: [] }; } };`
- L22: `export const saveBug = (s: BugState) => { try { cloudStore.setItem(BUGFIX_KEY, JSON.stringify(s)); } catch { /* cheio */ } return s; };`
- L25: `export function sync(b: BugState, fx: FixState): BugState {`
- L33: `export function resolve(b: BugState, fx: FixState, failureId: string, at: string): { b: BugState; fx: FixState } {`
- L48: `export function nexusChecks(it: BugItem, fx: FixState): NexusCheck[] {`
- L65: `export function nexusReview(b: BugState, fx: FixState, failureId: string, at: string): BugState {`
- L77: `export const approved = (b: BugState) => b.items.filter((i) => i.etapa === "APROVADA NO FUNIL");`

## Entradas tipadas
- s: BugState
- b: BugState
- fx: FixState
- it: BugItem

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.cloud.cloud-store`
- `mec.realgear.funnel`
- `mec.realgear.sha256`
- `mec.realgear.fix.contracts`
- `mec.realgear.fix.pipeline`
- `mec.realgear.fix.triage`

## Dependentes
—

## Testes existentes
- `src/test/bugfix.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
