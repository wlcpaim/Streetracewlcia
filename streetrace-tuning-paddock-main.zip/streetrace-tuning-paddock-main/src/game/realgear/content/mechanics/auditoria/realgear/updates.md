# Mecânica: updates

- ID: `mec.realgear.updates` · auditoria / realgear
- Arquivo: `src/game/realgear/updates.ts` (86 linhas, sha256 777c6c8673742063)
- Estado: **CONFIRMADO_NO_CODIGO**

## Objetivo (cabeçalho do código)
Atualizações da Engrenagem Real: toda criação nova entra aqui, numerada.

## Funções exportadas (saídas)

## Entradas tipadas
—

## Fórmulas
### Consumo específico (BSFC)
$$\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$$
- P: potência [kW]
- BSFC: consumo específico [kg/kWh]
- ρ_f: densidade do combustível [kg/L]
- Hipóteses: plena carga
- Limitações: BSFC fixo por combustível
- `src/game/realgear/updates.ts:9` `"Rotas independentes: cilindrada da ficha vs jogo, CR de volta, P = T·ω, η efetivo < η Otto, fechamento de energia, teto de consumo por BSFC.",`

## Dependências
—

## Dependentes
—

## Testes existentes
Nenhum teste importa este módulo.

## Limitações
- contém valores marcados como estimados
- contém dados desconhecidos que bloqueiam cálculo

> Testes de software passando não equivalem a validação física.
