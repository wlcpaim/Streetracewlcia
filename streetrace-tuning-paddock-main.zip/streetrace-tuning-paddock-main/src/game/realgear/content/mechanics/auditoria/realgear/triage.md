# Mecânica: triage

- ID: `mec.realgear.fix.triage` · auditoria / realgear
- Arquivo: `src/game/realgear/fix/triage.ts` (73 linhas, sha256 46de13047c821869)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
TRIAGEM FÍSICA — classifica cada falha do funil pela física real e prioriza pela estatística das falhas registradas. Somente leitura: recalcula a camada com runFunnel (mesmo setup, mesmos overrides) e nunca inventa medição. Uma falha só vira patch quando há divergência demonstrável no código; limites de preparação voltam ao StreetRace com o número exato exigido; medições ausentes viram pedido de dado com as camadas que elas bloqueiam.

## Funções exportadas (saídas)
- L24: `export const rpmMaxInercia = (rpm: number, F: number, Flim: number) => rpm * Math.sqrt(Flim / F);`
- L26: `export const rpmMaxVm = (vMax: number, strokeM: number) => (vMax * 60) / (2 * strokeM);`
- L28: `export const fatorVazao = (dutyPct: number) => dutyPct / 100;`
- L32: `export function classify(ev: FailureEvent): Parcial {`
- L63: `export function triageAll(fx: FixState): Triagem[] {`
- L72: `export const triageOf = (fx: FixState, failureId: string) => { const ev = fx.failures.find((f) => f.failureId === failureId); if (!ev) return null; return triageAll({ ...fx }).find((t) => t.failureId `

## Entradas tipadas
- ev: FailureEvent
- fx: FixState

## Fórmulas
### Consumo específico (BSFC)
$$\dot V = \frac{P\cdot BSFC}{\rho_f\cdot 3600}$$
- P: potência [kW]
- BSFC: consumo específico [kg/kWh]
- ρ_f: densidade do combustível [kg/L]
- Hipóteses: plena carga
- Limitações: BSFC fixo por combustível
- `src/game/realgear/fix/triage.ts:56` (classify) `if (n === 22) return { categoria: "LIMITE FÍSICO DA PREPARAÇÃO", lei: "mechStep() / consumo por BSFC", calculo: [`observado: ${t.observado}`], exigencia: `Eliminar a causa física: ${t.observado}.` };`

## Dependências
- `mec.realgear.funnel`
- `mec.realgear.fix.contracts`
- `mec.realgear.fix.pipeline`

## Dependentes
- `mec.bugfix.bugfix`

## Testes existentes
- `src/test/triage.test.ts`

## Limitações
- contém valores marcados como estimados

> Testes de software passando não equivalem a validação física.
