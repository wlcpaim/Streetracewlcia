# Mecânica: dyno-config

- ID: `mec.nexus-update.dyno-config` · auditoria / nexus-update
- Arquivo: `src/game/nexus-update/dyno-config.ts` (3 linhas, sha256 0bad1bfda1f65bbe)
- Estado: **CONFIRMADO_NO_CODIGO**

## Objetivo (cabeçalho do código)
Editable dyno sweep parameters (NEXUS UPDATE). Mutated in place so the Dino screen reads current values.

## Funções exportadas (saídas)

## Entradas tipadas
—

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
—

## Dependentes
- `mec.nexus-update.registry`

## Testes existentes
Nenhum teste importa este módulo.

## Limitações
—

> Testes de software passando não equivalem a validação física.
