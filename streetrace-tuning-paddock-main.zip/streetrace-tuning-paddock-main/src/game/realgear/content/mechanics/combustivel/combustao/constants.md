# Mecânica: constants

- ID: `mec.physics-registry.constants` · combustivel / combustao
- Arquivo: `src/game/physics-registry/constants.ts` (83 linhas, sha256 978e69d82979facf)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Registry central de constantes físicas (SI). Todo módulo consome daqui; o teste physics-constants.test.ts falha se surgir outra cópia divergente no código. Investigação da divergência PCI (2026-11-09): - Enginephys usava 39,5 / 24,8 MJ/kg; RealGear usava 40,0 / 26,8 MJ/kg, ambos rotulados "gasolina C E27 / etanol hidratado". - 26,8 MJ/kg é o PCI do etanol ANIDRO (C2H5OH puro). O etanol hidratado (EHC, ANP: 92,5–94,6 % m/m de etanol) dilui com água e ainda gasta calor de vaporização dela: 26,8·0,935 − 0,066·2,44 ≈ 24,9 MJ/kg. Logo o rótulo do RealGear estava errado (grandeza = anidro, rótulo = hidratado). - Gasolina C E27: mistura em massa de gasolina A (PCI 43,0–44,0 MJ/kg) com ~28,6 % m/m de etanol anidro (27 % v/v, ρ 0,789 vs 0,74 kg/L): 0,714·43,5 + 0,286·26,8 ≈ 38,7 MJ/kg; faixa 38,4–39,5.

## Funções exportadas (saídas)
- L80: `export const K = (id: ConstId) => CONSTANTS[id].valor;`

## Entradas tipadas
- id: ConstId

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
—

## Dependentes
- `mec.airflow`
- `mec.autopecas.autopecas`
- `mec.carb`
- `mec.data.engine_catalog`
- `mec.enginephys`
- `mec.fuelmix`
- `mec.ground`
- `mec.physics`
- `mec.realgear.funnel`
- `mec.tire`
- `mec.vehicle-dynamics`
- `mec.src.nexus.caim`
- `mec.src.nexus.oem-mechanic`

## Testes existentes
- `src/test/physics-constants.test.ts`
- `src/test/physics-reengenharia.test.ts`
- `src/test/ve-energia.test.ts`

## Limitações
- contém valores marcados como estimados
- contém dados desconhecidos que bloqueiam cálculo

> Testes de software passando não equivalem a validação física.
