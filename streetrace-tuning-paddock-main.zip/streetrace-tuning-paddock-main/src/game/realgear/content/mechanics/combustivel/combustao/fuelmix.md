# Mecânica: fuelmix

- ID: `mec.fuelmix` · combustivel / combustao
- Arquivo: `src/game/fuelmix.ts` (117 linhas, sha256 413f3cd2826d27f0)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Fuel blends: four base fuels, a tank composition (Setup.blend fractions) and their effect on the engine. Effects are relative to the base fuel the bike model already uses (gasolina or etanol), so a pure tank of the base fuel stays neutral and stock vs stock still ties.

## Funções exportadas (saídas)
- L34: `export const chargeCoolK = (k: Comb) => Math.min(COOL_MAX_K, (EVAP_SHARE * FUEL_PROPS[k].hvap) / (FUEL_PROPS[k].afr * K("air.cp")));`
- L36: `export const energyPerAir = (k: Comb) => FUEL_PROPS[k].lhv / FUEL_PROPS[k].afr;`
- L39: `export function blendOf(s: Pick<Setup, "fuel" | "blend">): Record<Comb, number> {`
- L52: `export const baseFuel = (b: Record<Comb, number>): Setup["fuel"] => (b.etanol + b.metanol + b.nitrometano >= 0.5 ? "etanol" : "gasolina");`
- L59: `export function hpIndex(k: Comb, comp: number) {`
- L72: `export function blendFx(s: Pick<Setup, "fuel" | "blend" | "compression">, flex: boolean) {`
- L93: `export function pour(s: Pick<Setup, "fuel" | "blend">, fuelL: number, add: Blend) {`
- L107: `export const pumpComb = (f: "gasolina" | "etanol" | "podium"): Comb => (f === "gasolina" ? "gasc" : f);`
- L110: `export const isMixBreak = (cause: string | null | undefined) => !!cause && /mistura/i.test(cause);`
- L111: `export function drainIfMixBreak<P extends { fuelL: number; setup: Setup }>(p: P, cause: string | null | undefined): P {`

## Entradas tipadas
- k: Comb
- s: Pick
- b: Record
- add: Blend
- setup: Setup

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
- `mec.physics`
- `mec.physics-registry.constants`

## Dependentes
- `mec.jobrun`
- `mec.physics`
- `mec.rootcause`

## Testes existentes
- `src/test/fuel-air-physics.test.ts`
- `src/test/fuel-save-fixes.test.ts`
- `src/test/fuelmix.test.ts`

## Limitações
- contém valores marcados como estimados

> Testes de software passando não equivalem a validação física.
