# Processo de instalação de peças

## 1. Identificação da peça — CONFIRMADO_NO_CODIGO
partById/slotPart resolvem o id no catálogo
- `src/game/acerto.ts:65` (has) `const ownsF = preset.front === STOCK_FRONT || p.parts.some((id) => partById(id)?.front === preset.front);`
- `src/game/acerto.ts:66` (has) `const ownsR = preset.rear === STOCK_REAR || p.parts.some((id) => partById(id)?.rear === preset.rear);`
- `src/game/admin-lab.ts:105` (has) `const has = (id: string) => (partById(id) ? id : undefined);`
- `src/game/agr/agr.ts:45` (snapshotOf) `components: SLOT_ORDER.filter((k) => k in s.slots).map((k) => { const x = slotPart(s.slots[k], k); return { slot: k, part: `${x.brand} ${x.name}` }; }),`
- `src/game/airflow.ts:28` (tbiBoreMm) `const m = /Ø\s*(\d+(?:[.,]\d+)?)/.exec(partById(id)?.name ?? "");`
- `src/game/cloud/save-guard.ts:56` (checkSave) `const part = partById(id);`

## 2. Verificação de compatibilidade — CONFIRMADO_NO_CODIGO
MODEL_PARTS restringe peças por moto; inShop filtra a loja
- `src/game/screens/Pecas.tsx:214` (list) `const list = (MODEL_PARTS[bike] ?? []).map(partById).filter((x): x is Part => !!x);`
- `src/game/shop-catalog.ts:28` (inView) `export const STD_IDS = new Set(Object.values(MODEL_PARTS).flat());`
- `src/game/shop-catalog.ts:34` (onSale) `export const onSale = (x: Part) => KIT_IDS.includes(x.id) || !RETIRED.has(x.id) && inShop(x) && (SHOP_IDS[x.kind]?.includes(x.id) || !(STD_IDS.has(x.id) && /honda|-std/.test(x.id)) && (!SHOP_IDS[x.kind] || SHOP_IDS[x.kin`
- `src/game/shop-catalog.ts:51` (shopListing) `for (const [bike, label] of STD_BIKES) for (const id of MODEL_PARTS[bike] ?? []) { const p = partById(id); if (p) out.push({ id: p.id, grupo: `${g} · ${label}`, nome: p.name, part: p, bikeId: bike }); }`
- `src/game/parts.ts:300` `export const MODEL_PARTS: Record<string, string[]> = {`

## 3. Sistema mecânico afetado — CONFIRMADO_NO_CODIGO
slot define o sistema substituído
- `src/game/acerto.ts:38` (slotOpts) `...SLOTS.filter((sl) => sl !== "oleo").map((sl) => slotOpts(sl).map((id) => (s: Setup) => swapSlot(s, sl, id))),`
- `src/game/acerto.ts:64` (has) `for (const sl of SLOTS) if (sl !== "oleo" && has(preset.slots[sl])) setup = swapSlot(setup, sl, preset.slots[sl]);`
- `src/game/admin-lab.ts:32` (isSlot) `const isSlot = (k: string): k is Slot => (SLOTS as string[]).includes(k);`
- `src/game/autopecas/autopecas.ts:38` (setupFor) `else if ((SLOTS as string[]).includes(p.kind)) (s.slots as Record<string, string>)[p.kind] = p.id;`
- `src/game/intel/sweep.ts:16` (variations) `for (const slot of SLOTS) for (const p of PARTS_CATALOG.filter((p) => (p.kind as string) === slot && p.id !== `${slot}-original`))`
- `src/game/mech-identity.ts:23` (identify) `const modificadas = SLOTS.filter((k) => s.slots[k] && !slotPart(s.slots[k], k).factory).map((k) => slotPart(s.slots[k], k).name);`

## 4. Remoção/substituição do original — CONFIRMADO_NO_CODIGO
component-swap remove usinagem do componente trocado
- `src/game/acerto.ts:33` (slotOpts) `const slotOpts = (sl: Slot) => [`${sl}-original`, ...owned.filter((x) => x.kind === sl).map((x) => x.id)];`
- `src/game/acerto.ts:62` (has) `const has = (id: string) => id.endsWith("-original") || p.parts.includes(id);`
- `src/game/admin-lab.ts:93` (scenarios) `if (isSlot(p.kind) && !p.id.endsWith("-original")) out.push({ id: `peca:${p.id}`, group: `Peça · ${p.kind}`, label: `${p.brand} ${p.name}`, setup: withSlot(p.kind, p.id) });`
- `src/game/admin-lab.ts:106` (pick) `const pick = (slot: Slot, ...ids: string[]) => ids.map(has).find(Boolean) ?? `${slot}-original`;`
- `src/game/airflow.ts:27` (tbiBoreMm) `const id = s.slots.tbi ?? "tbi-original";`
- `src/game/airflow.ts:30` (tbiBoreMm) `if (id === "tbi-original") {`

## 5. Inclusão das propriedades físicas — CONFIRMADO_NO_CODIGO
physics lê a peça do slot
- `src/game/admin-lab.ts:110` (pick) `const fl: Setup = { ...k220, compression: 13.5, cam: "a75", slots: { ...k220.slots, modulo: PARTS_CATALOG.find((p) => p.kind === "modulo" && /prog|athlon/i.test(p.id + p.name))?.id ?? k220.slots.modulo, tbi: pick("tbi", `
- `src/game/agr/agr.ts:45` (snapshotOf) `components: SLOT_ORDER.filter((k) => k in s.slots).map((k) => { const x = slotPart(s.slots[k], k); return { slot: k, part: `${x.brand} ${x.name}` }; }),`
- `src/game/airflow.ts:27` (tbiBoreMm) `const id = s.slots.tbi ?? "tbi-original";`
- `src/game/autopecas/autopecas.ts:40` (setupFor) `s.slots.bico = p.bundle.bico; s.cam = p.bundle.cam; s.front = p.bundle.front ?? s.front; s.rear = p.bundle.rear ?? s.rear;`
- `src/game/autopecas/autopecas.ts:41` (setupFor) `if (p.bundle.modulo) s.slots.modulo = p.bundle.modulo;`
- `src/game/autopecas/autopecas.ts:42` (setupFor) `if (p.bundle.molas) s.slots.molas = p.bundle.molas;`

## 6. Atualização de massa e distribuição de peso — CONFIRMADO_NO_CODIGO
massa entra em stats(); distribuição de peso: ver perguntas
- `src/game/autopecas/analise.ts:21` (buildAnalise) `const motos = BIKES.map((b) => { const e = engine(b, STOCK_SETUP), s = stats(b, STOCK_SETUP); return { id: b.id, nome: b.name, hp: s.hp, torque: s.torque, kg: s.kg, rpmPeak: e.rpmPeak, rpmLimit: e.rpmLimit, marchas: gear`
- `src/game/autopecas/analise.ts:40` (analiseTXT) `for (const m of a.motos) L.push(`- ${m.nome}: ${m.hp} cv · ${m.torque} kgf·m · ${m.kg} kg · pico ${m.rpmPeak} rpm · corte ${m.rpmLimit} rpm · marchas ${m.marchas.join("/")} km/h · carga ${m.carga}`);`
- `src/game/autopecas/autopecas.ts:80` (w) `C.push({ nome: "Relação peso/potência", formula: "kg/cv = massa seca / P", conta: `${n(st1.kg, 1)} / ${n(st1.hp, 1)}`, resultado: `${n(st1.kg / st1.hp, 2)} kg/cv`, origem: "CALCULADO" });`
- `src/game/autopecas/autopecas.ts:124` (lhv) `const g = gearSpeeds(b, s1), r = tireRadius(b.tires) ?? NaN, i = s1.rear / s1.front, m = st1.kg + 75;`
- `src/game/autopecas/autopecas.ts:131` (lhv) `C.push({ nome: "Massa com piloto", formula: "m = massa da moto + piloto 75 kg", conta: `${n(st1.kg, 1)} + 75`, resultado: `${n(m, 1)} kg`, origem: "CALCULADO" });`
- `src/game/engineering/dados/audit.ts:216` (assinatura) `return { hp: e.hp, rpm: e.rpmLimit, kg: st.kg, top: gearSpeeds(b, s).at(-1) ?? 0, cap: clutchCapNm(s), duty: injectionAt(b, s, 8000, 1).duty, crr: t.crr, grip: t.grip, cc: ccOf(b, s) };`

## 7. Atualização de geometria — CONFIRMADO_NO_CODIGO
buildOf/machOf/ccOf derivam geometria
- `src/game/admin-lab.ts:41` (runTest) `const kb = buildOf(b, s);`
- `src/game/autopecas/autopecas.ts:84` (w) `const cc = ccOf(b, s1), S = (fic?.strokeMm ?? NaN) / 1000;`
- `src/game/engineering/dados/audit.ts:151` (add) `ccOf(b, s) * 1e-6, "physics.ccOf (cc declarado do kit)", tol.geometria);`
- `src/game/engineering/dados/audit.ts:164` (add) `const bd = buildOf(b, s);`
- `src/game/engineering/dados/audit.ts:216` (assinatura) `return { hp: e.hp, rpm: e.rpmLimit, kg: st.kg, top: gearSpeeds(b, s).at(-1) ?? 0, cap: clutchCapNm(s), duty: injectionAt(b, s, 8000, 1).duty, crr: t.crr, grip: t.grip, cc: ccOf(b, s) };`
- `src/game/engineering/dados/audit.ts:240` (ficha) `const c = conferir("vd", [{ sym: "D", valor: typeof d.valor === "number" ? d.valor / 1000 : null, unidade: "m", origem: d.origem }, { sym: "S", valor: typeof sr.valor === "number" ? sr.valor / 1000 : null, unidade: "m", `

## 8. Relações mecânicas — CONFIRMADO_NO_CODIGO
relação final e cadeia cinemática
- `src/game/agr/agr.ts:68` (runTrack) `const cuts = gearSpeeds(b, s);`
- `src/game/autopecas/analise.ts:21` (buildAnalise) `const motos = BIKES.map((b) => { const e = engine(b, STOCK_SETUP), s = stats(b, STOCK_SETUP); return { id: b.id, nome: b.name, hp: s.hp, torque: s.torque, kg: s.kg, rpmPeak: e.rpmPeak, rpmLimit: e.rpmLimit, marchas: gear`
- `src/game/autopecas/autopecas.ts:101` (vm) `const vT0 = gearSpeeds(b, s0).at(-1) ?? 0, vT1 = gearSpeeds(b, s1).at(-1) ?? 0;`
- `src/game/autopecas/autopecas.ts:112` (F0) `const g = gearSpeeds(b, s1), dt1 = drivetrain(b, s1);`
- `src/game/autopecas/autopecas.ts:124` (lhv) `const g = gearSpeeds(b, s1), r = tireRadius(b.tires) ?? NaN, i = s1.rear / s1.front, m = st1.kg + 75;`
- `src/game/cloud/crossaudit.ts:121` (compare) `i_total: "src/game/realgear/kinematics.ts · chain()", rpm_roda: "src/game/realgear/kinematics.ts · chain()", torque_roda: "src/game/realgear/kinematics.ts · chain()",`

## 9. Recalcular física — CONFIRMADO_NO_CODIGO
engine()/stats()/stress()
- `src/game/admin-lab.ts:37` (runTest) `const e = engine(b, s);`
- `src/game/admin-lab.ts:65` (runTest) `...meta, bike: b.name, distanceM: distance, setup: s, engine: e, stats: stats(b, s, b.tank), stress: stress(b, s), cc: displacement(s),`
- `src/game/admin-lab.ts:76` (breakReport) `const x = stress(b, s), f = forensic(cause), tot = x.causes.reduce((n, c) => n + c.load, 0) || 1;`
- `src/game/agr/agr.ts:52` (enginePeaks) `const e = engine(b, s);`
- `src/game/agr/agr.ts:60` (t) `const st = stress(b, s);`
- `src/game/agr/agr.ts:67` (runTrack) `const e = engine(b, s);`

## 10. Sistemas dependentes — CONFIRMADO_NO_CODIGO
step() + mechStep() por passo de simulação
- `src/game/admin-lab.ts:46` (runTest) `step(st, b, s, DT, distance);`
- `src/game/admin-lab.ts:48` (runTest) `const bp = mechStep(ms, st, b, s, kb, DT);`
- `src/game/admin-lab.ts:125` (runSuite) `return { generatedAt: new Date().toISOString(), engine: "src/game/physics.ts step() · DT 1/240 s · determinístico", total, checks: { stockByTrack: stockTie, stalled: runs.filter((r) => r.result.stalled).map((r) => r.id),`
- `src/game/agr/agr.ts:79` (runTrack) `step(st, b, s, DT, t.m);`
- `src/game/intel/audit.ts:33` (add) `fix: "Derivar o torque exibido da própria curva (P/ω) e sempre mostrar o rpm em que ele ocorre.", files: ["src/game/physics.ts", "src/game/preload-report.ts"], keep: ["resultado das corridas (step() usa P, não stats().to`
- `src/game/intel/audit.ts:48` (ficha) `add({ id: "TR-01", pass: ETA > 0 && ETA <= 1 && !bad, sev: "alta", func: "step() ETA", title: "Eficiência da transmissão dentro de 0–100% e CV roda ≤ CV motor",`

## 11. Resultados da motocicleta — CONFIRMADO_NO_CODIGO
tempo, velocidade e quebra
- `src/game/acerto.ts:15` (score) `const st = simulate(bike, s, d, bike.tank);`
- `src/game/admin-lab.ts:16` `result: { finishS: number | null; vmaxKmh: number; t0_60: number | null; t0_100: number | null; t100m: number | null; t500m: number | null; fuelUsedL: number; stalled: boolean; gearMaxKmh: number[]; spinS: number; slipS:`
- `src/game/admin-lab.ts:66` (runTest) `result: { finishS: broke || st.finishT === null ? null : r3(st.finishT), vmaxKmh: r3(st.top), t0_60: st.t60 && r3(st.t60), t0_100: st.t100 && r3(st.t100), t100m: st.t100m && r3(st.t100m), t500m: st.t500m && r3(st.t500m),`
- `src/game/admin-lab.ts:124` (runSuite) `const stockTie = TRACKS.map((t) => { const r = runs.filter((x) => x.id.endsWith(`|stock|${t.id}`)); return { track: t.label, times: r.map((x) => x.result.finishS) }; });`
- `src/game/admin-lab.ts:125` (runSuite) `return { generatedAt: new Date().toISOString(), engine: "src/game/physics.ts step() · DT 1/240 s · determinístico", total, checks: { stockByTrack: stockTie, stalled: runs.filter((r) => r.result.stalled).map((r) => r.id),`
- `src/game/engineering/EngPanel.tsx:91` (certifyBike) `<p className="text-sm">Progresso real: {j.casos.filter((c) => c.status !== "PENDENTE").length}/{j.casos.length} casos · descartados {j.descartes.length} · referência {f(j.base?.finishS)} s</p>`

## Perguntas de engenharia
### Uma peça mais pesada altera o centro de massa?
**NAO_IMPLEMENTADO** — CG é constante estimada (EST.cgHeightM); a massa da peça só altera a massa total
- `src/game/cloud/crossaudit.ts:57` (missingFor) `["massa moto", s.veiculo.massaMoto], ["massa piloto", s.veiculo.massaPiloto], ["altura CG", s.veiculo.alturaCG],`
- `src/game/cloud/crossaudit.ts:77` (tsCompute) `const L = axleLoads(v(veh.massaMoto) + v(veh.massaPiloto), c.a, v(veh.alturaCG), v(veh.entreEixos), v(veh.cgAteEixoTraseiro));`
- `src/game/enginephys.ts:55` `cgHeightM: 0.62, // moto + piloto (estimado)`
- `src/game/enginephys.ts:375` (vehicleAt) `nRear = m * g * EST.rearStaticShare + (m * a * EST.cgHeightM) / EST.wheelbaseM;`

### Uma peça mais pesada altera a massa total na aceleração?
**CONFIRMADO_NO_CODIGO** — massa total = stats().kg + piloto entra em a = F/m
- `src/game/enginephys.ts:367` (vehicleAt) `const m = stats(b, s, fuelL).kg + (s.riderKg ?? RIDER_KG);`
- `src/game/physics.ts:584` (exhaustKg) `export const exhaustKg = (s: Setup) => exhaustSpec(exhaustId(s)).kg;`
- `src/game/physics.ts:777` (tireCalc) `if (s.airFilter === "sem") kg -= AIR_FILTER.kg;`
- `src/game/physics.ts:778` (tireCalc) `if (s.airFilter === "caixa") kg -= AIRBOX.kg;`
- `src/game/physics.ts:779` (tireCalc) `for (const k of ["bateria", "susp", "pneu", "escape", "embreagem", "roda"] as Slot[]) kg += slotPart(s.slots[k], k).kg ?? 0;`

### Uma relação de transmissão diferente altera a rotação da roda?
**CONFIRMADO_NO_CODIGO** — relação coroa/pinhão escala gearTop (gearSpeeds) e a força na roda
- `src/game/physics.ts:888` (drivetrainCalc) `const cat = catalogRatios(b.id), rpm = engine(b, s).rpmLimit, r = rearTireDynM(b, s), fin = s.rear / s.front;`

### Um pistão diferente altera a massa alternativa?
**NAO_IMPLEMENTADO** — massa do pistão não identificada (ficha massaPistao = DESCONHECIDO); pistão atua por hpMul/stress/relief
- `src/game/admin-lab.ts:108` (pick) `const k190: Setup = { ...street, fuel: "etanol", compression: 11.5, cam: "ma66", slots: { ...street.slots, cilindro: pick("cilindro", "cilindro-4mm"), pistao: pick("pistao", "pistao-forjado") }, services: ["dutos", "valv`
- `src/game/admin-lab.ts:109` (pick) `const k220: Setup = { ...k190, compression: 12.5, cam: "a72", slots: { ...k190.slots, cilindro: pick("cilindro", "cilindro-220"), biela: pick("biela", "biela-vira"), molas: pick("molas", "molas-pratos") }, services: ["du`
- `src/game/agr/agr.ts:40` (r) `const SLOT_ORDER: Slot[] = ["cilindro", "pistao", "biela", "vira", "molas", "tbi", "bico", "bomba", "escape", "modulo", "vela", "cabo", "embreagem", "pneu", "roda", "susp", "bateria", "oleo"];`
- `src/game/autopecas/autopecas.ts:44` (setupFor) `if (p.bundle.pistao) s.slots.pistao = p.bundle.pistao;`

### Uma biela diferente altera os esforços inerciais?
**CONFIRMADO_NO_CODIGO** — biela instalada entra em hpMul, alívio por causa (fix) e no limite admissível; massa da biela não identificada, então a força inercial usa geometria estimada
- `src/game/physics.ts:175` (finite) `if (slots.biela === "vira-ww3") { slots.vira = "vira-ww3"; slots.biela = STOCK_SLOTS.biela; }`
- `src/game/physics.ts:648` (engineCalc) `for (const k of ["molas", "biela"] as Slot[]) mul *= slotPart(s.slots[k], k).hpMul ?? 1;`
- `src/game/physics.ts:745` (over) `for (const k of ["embreagem", "molas", "biela"] as Slot[]) for (const [c, v] of Object.entries(slotPart(s.slots[k], k).fix ?? {})) fixes[c] = (fixes[c] ?? 0) + v;`

### Um comando de válvulas diferente altera admissão e escape?
**CONFIRMADO_NO_CODIGO** — CAM_FX desloca rpm de pico, multiplica potência e soma risco (efeito agregado, sem levante/duração)
- `src/game/mechlimits.ts:106` (has) `const cam = CAM_FX[s.cam] ?? CAM_FX.original;`
- `src/game/physics.ts:447` (flow) `const rpmPeak = TITAN_160.rpmPeak + (CAM_FX[kit.bundle!.cam] ?? CAM_FX.original).rpm + list.reduce((n, x) => n + (x.rpmPeak ?? 0), 0);`
- `src/game/physics.ts:639` (engineCalc) `const cam = CAM_FX[s.cam] ?? CAM_FX.original;`
- `src/game/physics.ts:676` (valveFloatRpm) `const cam = CAM_FX[s.cam] ?? CAM_FX.original;`
- `src/game/physics.ts:725` (has) `if (!cavas) add("Válvula atropelada", (CAM_FX[s.cam] ?? CAM_FX.original).risk, "Comando bravo sem cavas no pistão");`

### Um pneu diferente altera o raio efetivo e a relação final?
**NAO_IMPLEMENTADO** — na corrida o raio do pneu não muda com a peça; o pneu altera crr e grip via tireOf()
- `src/game/admin-lab.ts:128` (runSuite) `export const tireInfo = tireOf;`
- `src/game/agr/agr.ts:26` (physicsVersion) `fuelL: number; tireCMax: number | null; spinS: number; wheelieS: number;`
- `src/game/agr/agr.ts:73` (runTrack) `let rpmMin = Infinity, rpmMax = 0, limiterS = 0, kwPeak = 0, kwSum = 0, wSum = 0, n = 0, accPeak = 0, tireCMax: number | null = null, spinS = 0, wheelieS = 0;`
- `src/game/agr/agr.ts:90` (kw) `if (st.gr?.tireC != null) tireCMax = Math.max(tireCMax ?? -Infinity, st.gr.tireC);`

### Uma alteração no sistema de freios altera a desaceleração calculada?
**NAO_IMPLEMENTADO** — a corrida (arrancada) não calcula frenagem; freio existe só como componente de auditoria
- `src/game/admin-lab.ts:104` (scenarios) `out.push({ id: "leve", group: "Chassi", label: "Desmontada + sem filtro", setup: { ...STOCK_SETUP, removed: { mirrors: true, rabeta: true, frontBrake: true }, airFilter: "sem" } });`
- `src/game/admin-lab.ts:107` (pick) `const street: Setup = { ...STOCK_SETUP, airFilter: "sem", removed: { mirrors: true, rabeta: true, frontBrake: true }, slots: { ...STOCK_SETUP.slots, escape: pick("escape", "escape-dore") }, cam: "mb63", front: 15, rear: `
- `src/game/cloud/crossaudit.ts:71` (tsCompute) `const r = runBatteries(s, { marcha: c.marcha, rpm: c.rpm, torque: c.torque, vVeiculo: c.v, acel: c.a, FtFreioA: 1500, FtFreioB: 800 });`
- `src/game/nexus-update/registry.ts:70` (categories) `{ k: "frontBrake", label: "Freio dianteiro", type: "number", unit: "kg", min: 0, max: 10, formula: "kg total −= frontBrake" }] };`
