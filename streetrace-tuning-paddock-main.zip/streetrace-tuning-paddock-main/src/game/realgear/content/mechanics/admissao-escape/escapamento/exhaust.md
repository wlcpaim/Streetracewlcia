# Mecânica: exhaust

- ID: `mec.exhaust` · admissao-escape / escapamento
- Arquivo: `src/game/exhaust.ts` (88 linhas, sha256 20e29655184c4a17)
- Estado: **IMPLEMENTADO_SEM_VALIDACAO_FISICA**

## Objetivo (cabeçalho do código)
Exhaust system: geometry + gas flow → power curve multiplier. No fixed hp per pipe. Values are balance knobs (EXHAUST_SPECS / EXH_K); physics.ts reads exhaustAt() for engine and dyno. Internal pipe diameter (mm). */ Total length header → outlet (mm): sets the pulse-tuned rpm. */ Flow restriction 0..1 (silencer + catalyst + bends). */ Flow efficiency 0..1: how much of the pulse tuning the geometry actually delivers. */

## Funções exportadas (saídas)
- L53: `export const exhaustSpec = (id: string | undefined) => EXHAUST_SPECS[id ?? ""] ?? EXHAUST_SPECS["escape-original"]!;`
- L64: `export function flowEff(x: ExhaustSpec, cc: number, rpm: number) {`
- L77: `export function exhaustAt(id: string | undefined, cc: number, stockCc: number, rpm: number) {`
- L82: `export function exhaustInfo(id: string | undefined, cc: number, rpm: number) {`

## Entradas tipadas
- x: ExhaustSpec

## Fórmulas
Nenhuma fórmula detectada.

## Dependências
—

## Dependentes
- `mec.enginephys`
- `mec.intel.changelog`
- `mec.overhaul22`
- `mec.part-sheet`
- `mec.physics`
- `mec.preload-report`

## Testes existentes
- `src/test/changelog.test.ts`
- `src/test/exhaust.test.ts`

## Limitações
—

> Testes de software passando não equivalem a validação física.
