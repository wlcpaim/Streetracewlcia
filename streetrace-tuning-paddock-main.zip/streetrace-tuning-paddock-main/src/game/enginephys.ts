import { K, LHV_BY_FUEL } from "./physics-registry/constants";
/**
 * Física acoplada do motor (overhaul 2.0). Funções puras, todas com unidade SI no nome ou no
 * comentário. Cada grandeza é marcada como calculada, estimada (parâmetro de modelo sem medição),
 * ficha (catálogo do fabricante/jogo) ou faltante. Nada aqui usa probabilidade.
 *
 * Usado por mechlimits.ts (pressão de cilindro, forças na biela, folga com dilatação, embreagem
 * térmica) e pelo relatório ao vivo (overhaulTxt). O passo da corrida (physics.step) continua sendo
 * a fonte do desempenho; os módulos de transmissão/dinâmica veicular aqui o auditam.
 */
import { slotPart } from "./parts";
import { rodMmOf, strokeMmOf } from "./data/engine_catalog";
import { exhaustSpec } from "./exhaust";
import { BSFC, ETA, FUEL_DENSITY, RIDER_KG, ccOf, drivetrain, engine, pinOffsetMm, exhaustId, exhaustShape, mixFactor, mixtureAt, mixState, LAMBDA_TARGET, AFR_STOICH, powerShape, stats, tireOf, type BikeModel, type Setup } from "./physics";

export type Status = "PASS" | "WARNING" | "OVERLOAD" | "FAILURE" | "INSUFFICIENT_DATA" | "NOT_VALIDATED";
export type Src = "calculado" | "estimado" | "ficha" | "medido";

export const CV_W = 735.49875;
const P_ATM_PA = 101325;
const R_AIR = 287.05; // J/(kg·K)
const GAMMA = 1.32; // mistura queimada/não queimada, média (estimado)
const DEG = Math.PI / 180;

/** Parâmetros sem medição: cada um aparece no relatório como ESTIMADO. */
export const EST = {
  strokeMm: 63, // ESTIMADO: fallback só para moto sem curso no catálogo (geoOf prefere ENGINE_CATALOG)
  rodMm: 102.5, // ESTIMADO: fallback só para moto sem biela no catálogo (geoOf prefere ENGINE_CATALOG)
  rodAreaMm2: 95, // seção I da biela original (estimado)
  rodE_GPa: 210, // aço forjado
  rodYieldMPa: 750, // aço 4140 temperado (estimado)
  rodI_mm4: 1500, // momento de inércia mínimo da seção (estimado)
  rodUtsMPa: 1000, // ruptura aço 4140 temperado (estimado)
  rodFatigueMPa: 420, // limite de fadiga corrigido (estimado)
  tIntakeK: 320, // ar admitido aquecido
  lambdaWot: 0.88, // = physics.LAMBDA_TARGET (fonte única da mistura)
  sparkBtdc: 26, // avanço base em plena carga (°)
  burnDeg: 52, // duração da combustão 10–90% (Wiebe)
  wiebeA: 5,
  wiebeM: 2,
  combEff: 0.96,
  wallLoss: 0.22, // fração do calor perdida para as paredes durante a queima
  injFlowCcMin: 118, // bico original a 3 bar (estimado)
  injDeadMs: 0.9,
  railBar: 3,
  pumpLh: 32, // bomba original na pressão de linha (estimado)
  clutchKg: 0.9, // discos + separadores (estimado)
  clutchCp: 900, // J/(kg·K)
  clutchHA: 6, // W/K resfriamento no óleo (estimado)
  clutchLimC: 320, // material de atrito perde coeficiente/vitrifica (estimado)
  clutchStartC: 80,
  pistonAlpha: 21e-6, // liga Al-Si, 1/K
  compHeightMm: 30, // altura de compressão do pistão (estimado)
  rollingFactor: K("tire.rolling_factor"), // raio dinâmico / estático (registry, ESTIMADO)
  cgHeightM: 0.62, // moto + piloto (estimado)
  wheelbaseM: 1.315, // ficha CG 160
  rearStaticShare: 0.58, // estimado
  mu: 1.1, // atrito pneu de rua em asfalto seco (estimado)
  cd: 0.6,
  frontalM2: 0.45, // Cd·A = 0,27 m² igual ao passo da corrida
};

/** Combustível: AFR estequiométrico e PCI. Gasolina C brasileira (E27) e etanol hidratado (E100h). */
export const FUEL = {
  gasolina: { label: "Gasolina C (E27)", afr: AFR_STOICH.gasolina, lhv: LHV_BY_FUEL.gasolina },
  etanol: { label: "Etanol hidratado (~5% água)", afr: AFR_STOICH.etanol, lhv: LHV_BY_FUEL.etanol },
} as const;

const rr = (n: number, d = 1) => Math.round(n * 10 ** d) / 10 ** d;

// ===================== 01 TORQUE E POTÊNCIA =====================
/** Potência no virabrequim (W) em plena carga a um rpm, da mesma curva do passo da corrida. */
export function crankW(b: BikeModel, s: Setup, rpm: number, load = 1) {
  const e = engine(b, s);
  return e.hp * CV_W * powerShape(rpm, e.rpmPeak, b, s) * mixFactor(s, rpm, e.rpmPeak) * exhaustShape(b, s, rpm, e.rpmPeak) * load;
}
export const omegaOf = (rpm: number) => (rpm * 2 * Math.PI) / 60;
/** T = P/ω (N·m). */
export const torqueNm = (b: BikeModel, s: Setup, rpm: number, load = 1) => (rpm > 0 ? crankW(b, s, rpm, load) / omegaOf(rpm) : 0);

/** Curva unificada: torque máximo e torque no pico de potência são grandezas distintas. */
export function torqueCurve(b: BikeModel, s: Setup) {
  const e = engine(b, s);
  const rows: { rpm: number; W: number; cv: number; Nm: number; wheelCv: number }[] = [];
  for (let rpm = 3000; rpm <= e.rpmLimit; rpm += 250) {
    const W = crankW(b, s, rpm);
    rows.push({ rpm, W, cv: W / CV_W, Nm: W / omegaOf(rpm), wheelCv: (W * ETA) / CV_W });
  }
  const pk = rows.reduce((a, z) => (z.W > a.W ? z : a));
  const tq = rows.reduce((a, z) => (z.Nm > a.Nm ? z : a));
  const st = stats(b, s);
  return { rows, peakPower: pk, peakTorque: tq, torqueAtPeakPowerNm: pk.Nm, tableTorqueNm: st.torque * 9.80665 };
}

// ===================== 06 COMBUSTÃO / PRESSÃO DE CILINDRO =====================
export interface Geo { strokeMm: number; rodMm: number; strokeOrigem: "CATALOGO" | "ESTIMADO"; rodOrigem: "CATALOGO" | "ESTIMADO"; cc: number; boreMm: number; areaM2: number; rM: number; lM: number; vdM3: number; vcM3: number; cr: number }
export function geoOf(b: BikeModel, s: Setup): Geo {
  const cc = ccOf(b, s);
  // geometria do modelo vem do catálogo; EST só entra quando o catálogo não tem o valor (marcado ESTIMADO)
  const sCat = strokeMmOf(b.id), lCat = rodMmOf(b.id);
  const strokeMm = (sCat ?? EST.strokeMm) + pinOffsetMm(s), rodMm = lCat ?? EST.rodMm;
  const boreMm = Math.sqrt((cc * 4000) / (Math.PI * strokeMm));
  const areaM2 = (Math.PI * (boreMm / 1000) ** 2) / 4;
  const vdM3 = cc * 1e-6;
  return { strokeMm, rodMm, strokeOrigem: sCat !== null ? "CATALOGO" : "ESTIMADO", rodOrigem: lCat !== null ? "CATALOGO" : "ESTIMADO", cc, boreMm, areaM2, rM: strokeMm / 2000, lM: rodMm / 1000, vdM3, vcM3: vdM3 / (s.compression - 1), cr: s.compression };
}
/** Deslocamento do pistão desde o PMS (m) para o ângulo θ (rad). */
export function pistonX(g: Geo, th: number) {
  const k = g.rM / g.lM;
  return g.rM * (1 - Math.cos(th)) + g.lM * (1 - Math.sqrt(1 - k * k * Math.sin(th) ** 2));
}
export const cylVol = (g: Geo, th: number) => g.vcM3 + g.areaM2 * pistonX(g, th);
/** a(θ) = r·ω²·(cosθ + (r/l)·cos2θ)  (m/s², positivo = para baixo no PMS). */
export const pistonAcc = (g: Geo, omega: number, th: number) => g.rM * omega * omega * (Math.cos(th) + (g.rM / g.lM) * Math.cos(2 * th));

/** Atrito mecânico médio (FMEP, bar), Chen & Flynn: a + b·Pmáx + c·Sp + d·Sp² (constantes do registry, ESTIMADO p/ moto). */
export function fmepBar(pMaxBar: number, strokeMm: number, rpm: number) {
  const sp = (2 * (strokeMm / 1000) * rpm) / 60;
  return K("friction.chen_flynn.a") + K("friction.chen_flynn.b") * pMaxBar + K("friction.chen_flynn.c") * sp + K("friction.chen_flynn.d") * sp * sp;
}
/** BMEP (bar) da potência que a corrida entrega no virabrequim: 4π·T/Vd. */
export const bmepBar = (b: BikeModel, s: Setup, rpm: number) => (4 * Math.PI * torqueNm(b, s, rpm)) / geoOf(b, s).vdM3 / 1e5;

/**
 * Eficiência volumétrica EXIGIDA pela energia (caim-3): o ar que o cilindro precisa admitir para o ciclo
 * fechado produzir o trabalho que a corrida entrega mais o atrito: IMEP(VE) = BMEP + FMEP. O ciclo é linear
 * na pressão de admissão (P₀ e Q ∝ VE), então VE = (BMEP + a + c·Sp + d·Sp²) / (IMEP₁ − b·Pmáx₁), com IMEP₁
 * e Pmáx₁ do ciclo a VE = 1. Limitada ao teto típico de aspirado de 2 válvulas (ve.na_typical_max): onde a corrida pede mais
 * ar do que cabe, o ciclo fica sem ar e o CAIM aponta a contradição (nunca escondida).
 */
export function veRequired(b: BikeModel, s: Setup, rpm: number, unit?: Cycle) {
  const u = unit ?? closedCycle(b, s, rpm, 1, 0, 0), g = geoOf(b, s), sp = (2 * (g.strokeMm / 1000) * rpm) / 60;
  const lin = K("friction.chen_flynn.a") + K("friction.chen_flynn.c") * sp + K("friction.chen_flynn.d") * sp * sp;
  return Math.max(0, (bmepBar(b, s, rpm) + lin) / Math.max(1e-6, u.imepBar - K("friction.chen_flynn.b") * u.pMaxBar));
}
/** VE de plena carga usada pelo ciclo: a exigida pela energia, limitada ao teto típico de aspirado (ve.na_typical_max). */
export function veAt(b: BikeModel, s: Setup, rpm: number) {
  return Math.min(K("ve.na_typical_max"), veRequired(b, s, rpm));
}

export interface Cycle {
  pCompBar: number; // pressão no PMS sem combustão (motoring)
  pMaxBar: number; // pico com combustão
  thPeakDeg: number; // ângulo do pico depois do PMS
  airMg: number;
  fuelMg: number;
  lambda: number;
  afr: number;
  qJ: number; // calor liberado
  imepBar: number;
  pAt: (thRad: number) => number; // Pa, -π..π em torno do PMS de combustão
}

/** Ciclo fechado: compressão politrópica + liberação de calor de Wiebe com o avanço real. VE vem de veRequired. */
export function cycleAt(b: BikeModel, s: Setup, rpm: number, load: number, knock = 0, timingAdvDeg = 0): Cycle {
  const unit = closedCycle(b, s, rpm, 1, 0, timingAdvDeg);
  const veFull = Math.min(K("ve.na_typical_max"), veRequired(b, s, rpm, unit));
  return closedCycle(b, s, rpm, veFull * Math.max(0.12, load), knock, timingAdvDeg);
}
function closedCycle(b: BikeModel, s: Setup, rpm: number, ve: number, knock: number, timingAdvDeg: number): Cycle {
  const g = geoOf(b, s);
  const e = engine(b, s);
  const fuel = FUEL[e.eth ? "etanol" : "gasolina"];
  const pIvc = P_ATM_PA * ve;
  const vIvc = cylVol(g, -Math.PI);
  const airKg = (pIvc * vIvc) / (R_AIR * EST.tIntakeK);
  // massa de combustível entregue = massa de ar / AFR_actual da fonte única (mixState)
  const lambda = mixState(b, s, rpm, e.rpmPeak).lambda_mix;
  const fuelKg = airKg / (fuel.afr * lambda);
  const burnable = Math.min(1, 1 / lambda); // excesso de combustível não queima
  const qJ = fuelKg * fuel.lhv * burnable * EST.combEff * (1 - EST.wallLoss);
  const soc = -(EST.sparkBtdc + timingAdvDeg) * DEG;
  const dur = EST.burnDeg * DEG;
  const xb = (th: number) => (th < soc ? 0 : 1 - Math.exp(-EST.wiebeA * Math.min(1, (th - soc) / dur) ** (EST.wiebeM + 1)));
  const N = 360;
  const dth = (2 * Math.PI) / N;
  const P = new Float64Array(N + 1);
  const Pm = new Float64Array(N + 1);
  P[0] = Pm[0] = pIvc;
  let w = 0, pMax = pIvc, thPk = 0;
  for (let i = 0; i < N; i++) {
    const th = -Math.PI + i * dth, th2 = th + dth;
    const v1 = cylVol(g, th), v2 = cylVol(g, th2), dV = v2 - v1, vm = (v1 + v2) / 2;
    const dQ = qJ * (xb(th2) - xb(th));
    P[i + 1] = P[i]! + (-GAMMA * P[i]! * dV + (GAMMA - 1) * dQ) / vm;
    Pm[i + 1] = Pm[i]! * (v1 / v2) ** GAMMA;
    w += ((P[i]! + P[i + 1]!) / 2) * dV;
    if (P[i + 1]! > pMax) { pMax = P[i + 1]!; thPk = th2; }
  }
  const kmul = 1 + knock * 0.6; // ESTIMADO: pico extra da detonação (sem modelo validado de autoignição)
  const pAt = (th: number) => {
    const i = Math.max(0, Math.min(N, Math.round((th + Math.PI) / dth)));
    const pi = P[i]!; return pi * (pi > pIvc * 4 ? kmul : 1);
  };
  return {
    pCompBar: Pm[N / 2]! / 1e5, pMaxBar: (pMax * kmul) / 1e5, thPeakDeg: thPk / DEG, airMg: airKg * 1e6, fuelMg: fuelKg * 1e6, lambda, afr: fuel.afr * lambda, qJ,
    imepBar: w / g.vdM3 / 1e5 / 2 * 2, // trabalho do ciclo fechado / Vd (bombeamento à parte)
    pAt,
  };
}

// ===================== 02 BIELA E FORÇAS INTERNAS =====================
export interface RodLoad { tensionN: number; tensionDeg: number; compressionN: number; compressionDeg: number; gasPeakN: number; inertiaTdcN: number; sigmaTensMPa: number; sigmaCompMPa: number; bucklingN: number; strainUe: number; crankPinN: number }
/** Varre 720° do ciclo de 4 tempos: F_pistão = F_gás − m·a; F_biela = F_pistão / cos β. */
export function rodLoads(g: Geo, cyc: Cycle, rpm: number, recKg: number): RodLoad {
  const omega = omegaOf(rpm);
  const k = g.rM / g.lM;
  let tens = 0, tDeg = 0, comp = 0, cDeg = 0, gasPk = 0, pin = 0;
  for (let d = 0; d < 720; d += 2) {
    const th = d * DEG;
    // 0° = PMS de combustão; 360° = PMS de cruzamento (escape/admissão)
    const local = d < 180 ? th : d >= 540 ? th - 4 * Math.PI : null;
    const p = local !== null ? cyc.pAt(local) : d < 360 ? P_ATM_PA * 1.15 : P_ATM_PA * 0.85;
    const fGas = (p - P_ATM_PA) * g.areaM2;
    const fIn = recKg * pistonAcc(g, omega, th);
    const fPis = fGas - fIn;
    const beta = Math.asin(k * Math.sin(th));
    const fRod = fPis / Math.cos(beta);
    gasPk = Math.max(gasPk, fGas);
    if (fRod > comp) { comp = fRod; cDeg = d; }
    if (-fRod > tens) { tens = -fRod; tDeg = d; }
    pin = Math.max(pin, Math.abs(fRod));
  }
  const A = EST.rodAreaMm2 * 1e-6;
  const E = EST.rodE_GPa * 1e9;
  const buck = (Math.PI ** 2 * E * EST.rodI_mm4 * 1e-12) / g.lM ** 2;
  return {
    tensionN: tens, tensionDeg: tDeg, compressionN: comp, compressionDeg: cDeg, gasPeakN: gasPk, inertiaTdcN: recKg * g.rM * omega * omega * (1 + k),
    sigmaTensMPa: tens / A / 1e6, sigmaCompMPa: comp / A / 1e6, bucklingN: buck, strainUe: (Math.max(tens, comp) / A / E) * 1e6, crankPinN: pin,
  };
}

// ===================== 05 INJEÇÃO E AFR =====================
const flowOf = (id: string | undefined, k: "bico" | "bomba") => slotPart(id, k).flow ?? 1;
export function injectionAt(b: BikeModel, s: Setup, rpm: number, load = 1) {
  const e = engine(b, s);
  const fuelKey = e.eth ? "etanol" : "gasolina";
  const rho = FUEL_DENSITY[s.fuel];
  const m = mixtureAt(s, rpm, e.rpmPeak);
  const kW = crankW(b, s, rpm, load) / 1000;
  // demanda (g/s) = P·BSFC × fome extra do conjunto (m.need): kit maior puxa mais ar que a linha entrega
  const bsfc = BSFC[s.fuel] * 1000; // g/kWh
  const demandGs = (kW * bsfc) / 3600 * Math.max(1, m.need);
  const demandCcMin = (demandGs / rho) * 60;
  const pumpLh = EST.pumpLh * flowOf(s.slots.bomba, "bomba");
  const pumpCcMin = (pumpLh * 1000) / 60;
  // pressão de linha cai quando a bomba não acompanha a vazão pedida (Q ∝ √ΔP no bico)
  const railBar = demandCcMin > pumpCcMin ? EST.railBar * (pumpCcMin / demandCcMin) ** 2 : EST.railBar;
  const injCcMin = EST.injFlowCcMin * flowOf(s.slots.bico, "bico") * Math.sqrt(railBar / 3);
  const cycleMs = 120000 / Math.max(1, rpm);
  const fuelPerCycleCc = demandCcMin / (rpm / 2);
  const pulseMs = (fuelPerCycleCc / injCcMin) * 60000 + EST.injDeadMs;
  const duty = (pulseMs / cycleMs) * 100;
  const deliveredCcMin = Math.min(demandCcMin, injCcMin * Math.max(0, (cycleMs - EST.injDeadMs) / cycleMs), pumpCcMin);
  const lph = (kW * bsfc) / (1000 * rho) ;
  return {
    fuel: FUEL[fuelKey].label, afrStoich: FUEL[fuelKey].afr, rpm, cycleMs, pulseMs, duty, deadMs: EST.injDeadMs, railBar, injCcMin, pumpCcMin, demandCcMin, deliveredCcMin,
    lambda: mixState(b, s, rpm, e.rpmPeak).lambda_mix, lph, saturated: duty >= 100, high: duty > 85, pressureCollapse: railBar < EST.railBar * 0.95,
  };
}

// ===================== 03 EMBREAGEM =====================
/** Potência de deslize P = T_transmitido · |ω_motor − ω_câmbio| (W). Torque e potência separados. */
export function clutchSlipW(transNm: number, omegaEngine: number, omegaGearbox: number) {
  return Math.abs(transNm) * Math.abs(omegaEngine - omegaGearbox);
}
/** Balanço térmico dos discos: m·c·dT/dt = P_slip − hA·(T − T_óleo). */
export function clutchTempStep(tC: number, slipW: number, dt: number, oilC = 90, kgMul = 1) {
  const mc = EST.clutchKg * kgMul * EST.clutchCp;
  return tC + ((slipW - EST.clutchHA * (tC - oilC)) / mc) * dt;
}
export const clutchThermalCapJ = (kgMul = 1) => EST.clutchKg * kgMul * EST.clutchCp * (EST.clutchLimC - EST.clutchStartC);

// ===================== 04 ESCAPE =====================
export function exhaustFlow(b: BikeModel, s: Setup, rpm: number, load = 1) {
  const sp = exhaustSpec(exhaustId(s));
  const g = geoOf(b, s);
  const cyc = cycleAt(b, s, rpm, load);
  const mDot = ((cyc.airMg + cyc.fuelMg) * 1e-6 * rpm) / 120; // kg/s
  const tGasK = 850 + 273; // EGT no coletor em plena carga (estimado)
  const rho = P_ATM_PA / (R_AIR * tGasK);
  const area = (Math.PI * (sp.d / 1000) ** 2) / 4;
  const vMean = mDot / (rho * area);
  const vPeak = vMean * 3; // pulso único por 2 voltas: pico ≈ 3× a média (estimado)
  // contrapressão: ΔP = K·½ρv², K = restrição do silencioso/catalisador
  const kLoss = 1 + sp.restr * 12;
  const backPa = kLoss * 0.5 * rho * vMean * vMean * 6;
  const pumpJ = backPa * g.vdM3; // trabalho de bombeamento extra por ciclo
  const pumpW = (pumpJ * rpm) / 120;
  const a = Math.sqrt(1.35 * R_AIR * tGasK);
  const tunedRpm = (a * 60) / (4 * (sp.L / 1000)) / 1.85; // 1/4 de onda com ângulo de escape ≈ 1,85 fator (estimado)
  return { d: sp.d, L: sp.L, restr: sp.restr, mDotGs: mDot * 1000, rho, area, vMean, vPeak, backKPa: backPa / 1000, pumpJ, pumpW, pumpCv: pumpW / CV_W, sound: a, tunedRpm, curveMul: exhaustShape(b, s, rpm, engine(b, s).rpmPeak) };
}

// ===================== 07 TÉRMICO E DILATAÇÃO =====================
/** Crescimento da coroa em direção à válvula (mm): ΔL = α·L·ΔT. */
export const crownGrowthMm = (pistonC: number) => EST.pistonAlpha * EST.compHeightMm * (pistonC - 20);
/** Alongamento elástico da biela sob tração (mm): δ = F·L/(E·A). */
export const rodStretchMm = (tensionN: number, rodMm: number = EST.rodMm) => ((tensionN * rodMm) / (EST.rodE_GPa * 1e3 * EST.rodAreaMm2));

// ===================== 09 TREM DE VÁLVULAS =====================
/** Força de mola necessária (N) para segurar a válvula a um rpm, dado o rpm de flutuação calibrado. */
export function valveTrain(floatRpm: number, rpm: number) {
  const mEff = 0.085; // válvula + prato + 1/3 da mola + balancim reduzido (estimado)
  const liftM = 0.0075, durDeg = 240;
  const aAt = (r: number) => { const wCam = omegaOf(r) / 2; const t = (durDeg / 2 / 360) * (2 * Math.PI) / wCam; return (8 * liftM) / (t * t); };
  const springN = mEff * aAt(floatRpm); // mola que exatamente segura no rpm de flutuação
  const needN = mEff * aAt(rpm);
  return { mEff, liftMm: liftM * 1000, accMs2: aAt(rpm), springN, needN, margin: springN / needN, floats: needN > springN };
}


/**
 * Folga pistão-válvula geométrica (BUG 04). Varre o virabrequim no cruzamento (PMS de troca):
 * gap(θ) = h0 + x_pistão(θ) − lift(θ)·(1 + loft), com h0 tal que min gap estático = clearance0.
 * lift: perfil 1−cos de duração 240° e 7,5 mm (ESTIMADO); admissão abre 20° APMS, escape fecha 20° DPMS.
 * loft = needN/springN − 1 quando a mola não segura (valveTrain): a válvula passa do came por inércia.
 */
export function valveGap(g: Geo, clearance0Mm: number, rpm: number, floatRpm: number) {
  const vt = valveTrain(floatRpm, rpm);
  const L = vt.liftMm, dur = 240, ivo = -20, evc = 20;
  const lift = (d: number, open: number) => (d < open || d > open + dur ? 0 : (L / 2) * (1 - Math.cos((2 * Math.PI * (d - open)) / dur)));
  const rows: { deg: number; x: number; li: number; le: number }[] = [];
  for (let d = -60; d <= 60; d += 0.5) rows.push({ deg: d, x: pistonX(g, d * DEG) * 1000, li: lift(d, ivo), le: lift(d, evc - dur) });
  const loft = Math.max(0, vt.needN / vt.springN - 1);
  const minOf = (k: number) => rows.reduce((w, r) => { const gi = r.x - r.li * k, ge = r.x - r.le * k; const v = Math.min(gi, ge); return v < w.v ? { v, deg: r.deg, valve: gi <= ge ? "admissão" : "escape" } : w; }, { v: Infinity, deg: 0, valve: "admissão" });
  const st = minOf(1), dy = minOf(1 + loft);
  const h0 = clearance0Mm - st.v;
  const minMm = h0 + dy.v;
  return { minMm, deg: dy.deg, valve: dy.valve, loft, liftMm: L, collision: minMm < 0, margin: vt.margin };
}

/** Biela: cada critério independente com sua origem; o status final é o pior (BUG 02). */
export type RodCheck = { crit: string; loadN: number; capN: number; margin: number; origem: string; status: Status };
export function rodChecks(rl: RodLoad, ratedN: number, ratedCompN: number): { checks: RodCheck[]; status: Status } {
  const A = EST.rodAreaMm2;
  const mk = (crit: string, loadN: number, capN: number, origem: string, fail: Status): RodCheck => ({ crit, loadN, capN, margin: capN / Math.max(1, loadN), origem, status: loadN > capN ? fail : loadN > capN * 0.85 ? "WARNING" : "PASS" });
  const checks = [
    mk("limite cadastrado da peça (tração)", rl.tensionN, ratedN, "catálogo do jogo, sem certificado do fabricante (ESTIMADO); é o limite que quebra na corrida", "FAILURE"),
    mk("limite cadastrado da peça (compressão/flambagem)", rl.compressionN, ratedCompN, "min(escoamento·A, Euler) escalado pela biela instalada; quebra na corrida", "FAILURE"),
    mk("escoamento do material (tração)", rl.tensionN, EST.rodYieldMPa * A, `σ_y ${EST.rodYieldMPa} MPa × A ${A} mm² (ESTIMADO): deformação permanente`, "OVERLOAD"),
    mk("ruptura do material (tração)", rl.tensionN, EST.rodUtsMPa * A, `σ_u ${EST.rodUtsMPa} MPa × A (ESTIMADO)`, "FAILURE"),
    mk("flambagem de Euler", rl.compressionN, rl.bucklingN, `π²·E·I/L², E ${EST.rodE_GPa} GPa, I ${EST.rodI_mm4} mm⁴ (ESTIMADO)`, "FAILURE"),
  ];
  const sa = (rl.tensionN + rl.compressionN) / 2 / A, sm = (rl.tensionN - rl.compressionN) / 2 / A;
  const goodman = sa / EST.rodFatigueMPa + Math.max(0, sm) / EST.rodUtsMPa;
  checks.push({ crit: "fadiga (Goodman, 10⁷ ciclos)", loadN: goodman, capN: 1, margin: 1 / Math.max(1e-6, goodman), origem: `σa/Se + σm/σu, Se ${EST.rodFatigueMPa} MPa (ESTIMADO, sem curva S-N medida)`, status: goodman > 1 ? "OVERLOAD" : "NOT_VALIDATED" });
  const rank: Status[] = ["PASS", "NOT_VALIDATED", "INSUFFICIENT_DATA", "WARNING", "OVERLOAD", "FAILURE"];
  const status = checks.reduce<Status>((w, c) => (rank.indexOf(c.status) > rank.indexOf(w) ? c.status : w), "PASS");
  return { checks, status };
}

// ===================== 10 TRANSMISSÃO =====================
/** Cadeia da corrida (physics.drivetrain): relação total = primária × marcha × coroa/pinhão do manual; nenhuma relação genérica. */
export function transmission(b: BikeModel, s: Setup) {
  const e = engine(b, s), d = drivetrain(b, s);
  const T = torqueNm(b, s, e.rpmPeak);
  return d.totals.map((total, i) => {
    const kmh = d.vCutKmh[i]!;
    const wheelNm = T * total * ETA;
    return { gear: i + 1, gearRatio: d.gears[i] ?? null, primary: d.primary, total, origem: d.origem, kmhAtLimit: kmh, gameKmh: kmh, wheelNm, wheelN: wheelNm / d.rDynM, rDyn: d.rDynM };
  });
}

// ===================== 11 DINÂMICA VEICULAR =====================
export function vehicleAt(b: BikeModel, s: Setup, vMs: number, driveN: number, fuelL = b.tank) {
  const m = stats(b, s, fuelL).kg + (s.riderKg ?? RIDER_KG);
  const g = 9.81;
  const tire = tireOf(s);
  const drag = 0.5 * 1.2 * EST.cd * EST.frontalM2 * vMs * vMs;
  const roll = tire.crr * m * g;
  // transferência longitudinal: ΔN = m·a·h/L, resolvida de forma implícita (a depende de N_traseiro)
  let a = 0, nRear = m * g * EST.rearStaticShare, Fx = driveN;
  for (let i = 0; i < 6; i++) {
    nRear = m * g * EST.rearStaticShare + (m * a * EST.cgHeightM) / EST.wheelbaseM;
    nRear = Math.min(m * g, nRear);
    Fx = Math.min(driveN, EST.mu * tire.grip * nRear);
    a = (Fx - drag - roll) / m;
  }
  return { m, drag, roll, nRear, nFront: m * g - nRear, traction: EST.mu * tire.grip * nRear, Fx, slipLimited: driveN > Fx, a, wheelie: nRear >= m * g };
}

// ===================== AUDITORIA =====================
interface Line { mod: string; status: Status; txt: string }
export type AuditLim = { rodLimitN: number; rodCompLimitN: number; clearance0Mm?: number; floatRpm?: number };
export function overhaulAudit(b: BikeModel, s: Setup, lim?: AuditLim) {
  const out: Line[] = [];
  const add = (mod: string, status: Status, txt: string) => out.push({ mod, status, txt });
  const e = engine(b, s);
  const g = geoOf(b, s);
  const tc = torqueCurve(b, s);
  // 01
  const worst = tc.rows.reduce((a, r) => Math.max(a, Math.abs(r.Nm * omegaOf(r.rpm) - r.W)), 0);
  add("01 Torque/Potência", worst < 1e-6 ? "PASS" : "FAILURE", `T = P/ω em toda a faixa (erro máx ${worst.toExponential(1)} W). Pico ${rr(tc.peakPower.cv, 2)} cv @ ${tc.peakPower.rpm} rpm → ${rr(tc.torqueAtPeakPowerNm, 2)} N·m; torque máx ${rr(tc.peakTorque.Nm, 2)} N·m @ ${tc.peakTorque.rpm} rpm. Roda (×${ETA}, uma vez só): ${rr(tc.peakPower.wheelCv, 2)} cv CALCULADO, não medido em dinamômetro.`);
  const dTab = (tc.tableTorqueNm - tc.peakTorque.Nm) / tc.peakTorque.Nm;
  add("01 Torque/Potência", Math.abs(dTab) > 0.03 ? "WARNING" : "PASS", `Torque da ficha escalado (stats) ${rr(tc.tableTorqueNm, 2)} N·m vs curva P/ω ${rr(tc.peakTorque.Nm, 2)} N·m (${rr(dTab * 100)}%). A curva P/ω é a fonte usada na física.`);
  // 06 + 02
  const recKg = 0.18 * (g.boreMm / 57.3) ** 2;
  for (const rpm of [6000, e.rpmPeak, e.rpmLimit]) {
    const c = cycleAt(b, s, rpm, 1);
    const rl = rodLoads(g, c, rpm, recKg);
    add("06 Combustão", "NOT_VALIDATED", `${rpm} rpm: VE ${rr(veAt(b, s, rpm) * 100)}% · ar ${rr(c.airMg)} mg · comb. ${rr(c.fuelMg, 2)} mg · lambda_mix ${rr(c.lambda, 3)} (AFR_actual ${rr(c.afr, 2)}, AFR_stoich ${rr(c.afr / c.lambda, 1)}) · Q ${rr(c.qJ)} J · P_comp ${rr(c.pCompBar)} bar · P_max ${rr(c.pMaxBar)} bar a ${rr(c.thPeakDeg)}° APMS · IMEP ${rr(c.imepBar, 2)} bar. Sem curva de pressão medida para comparar.`);
    const rated = lim ?? { rodLimitN: 9500, rodCompLimitN: Math.min(EST.rodYieldMPa * EST.rodAreaMm2, Math.PI ** 2 * EST.rodE_GPa * 1e3 * EST.rodI_mm4 / EST.rodMm ** 2) };
    const rc = rodChecks(rl, rated.rodLimitN, rated.rodCompLimitN);
    add("02 Biela", rc.status, `${rpm} rpm · ` + rc.checks.map((c) => `[${c.status}] ${c.crit}: ${c.crit.startsWith("fadiga") ? `índice ${rr(c.loadN, 3)} de 1` : `${Math.round(c.loadN)} N de ${Math.round(c.capN)} N`} (margem ×${rr(c.margin, 2)}; ${c.origem})`).join(" · "));
    add("02 Biela", rc.status === "PASS" ? "PASS" : rc.status, `${rpm} rpm: tração máx ${Math.round(rl.tensionN)} N a ${rl.tensionDeg}° (${rr(rl.sigmaTensMPa)} MPa) · compressão máx ${Math.round(rl.compressionN)} N a ${rl.compressionDeg}° (${rr(rl.sigmaCompMPa)} MPa) · flambagem Euler ${Math.round(rl.bucklingN)} N · deformação ${rr(rl.strainUe)} µε. Escoamento ${EST.rodYieldMPa} MPa ESTIMADO.`);
  }
  // 05
  const inj = injectionAt(b, s, e.rpmLimit);
  add("05 Injeção", inj.saturated ? "OVERLOAD" : inj.high ? "WARNING" : "PASS", `${inj.fuel}, AFR_stoich ${inj.afrStoich} · lambda_mix ${rr(inj.lambda, 3)} · AFR_actual ${rr(inj.afrStoich * inj.lambda, 2)} · AFR_requested ${rr(inj.afrStoich * LAMBDA_TARGET, 2)}. ${e.rpmLimit} rpm: ciclo ${rr(inj.cycleMs, 2)} ms · pulso ${rr(inj.pulseMs, 2)} ms (morto ${inj.deadMs}) · duty ${rr(inj.duty)}% · linha ${rr(inj.railBar, 2)} bar · bico ${Math.round(inj.injCcMin)} cc/min · bomba ${Math.round(inj.pumpCcMin)} cc/min · demanda ${Math.round(inj.demandCcMin)} cc/min · consumo ${rr(inj.lph, 2)} L/h.${inj.pressureCollapse ? " PRESSÃO CAIU: bomba não acompanha." : ""}`);
  add("05 Injeção", "INSUFFICIENT_DATA", `Vazão do bico (${EST.injFlowCcMin} cc/min), tempo morto e vazão da bomba são ESTIMADOS: sem ficha medida do fabricante.`);
  // 03
  add("03 Embreagem", "PASS", `Checagem dimensional: |T_motor| ≤ T_cap (N·m) e P_deslize = T·|ω_m − ω_c| (W). Capacidade térmica ${Math.round(clutchThermalCapJ())} J (m ${EST.clutchKg} kg · c ${EST.clutchCp} J/kg·K · ${EST.clutchStartC}→${EST.clutchLimC} °C, ESTIMADO).`);
  // 04
  const ex = exhaustFlow(b, s, e.rpmPeak);
  add("04 Escape", "NOT_VALIDATED", `Ø ${ex.d} mm × ${ex.L} mm: ṁ ${rr(ex.mDotGs, 2)} g/s · ρ ${rr(ex.rho, 3)} kg/m³ · v média ${rr(ex.vMean)} m/s (pico ~${rr(ex.vPeak)}) · contrapressão ${rr(ex.backKPa, 2)} kPa · bombeamento ${rr(ex.pumpW)} W (${rr(ex.pumpCv, 2)} cv, já contido na curva exhaust.ts — não é subtraído de novo) · sintonia 1/4 onda ≈ ${Math.round(ex.tunedRpm)} rpm.`);
  // 09
  if (lim?.clearance0Mm != null) for (const rpm of [6000, e.rpmPeak, e.rpmLimit]) {
    const vg = valveGap(g, lim.clearance0Mm, rpm, lim.floatRpm ?? 10300);
    add("09 Folga pistão-válvula", vg.collision ? "FAILURE" : vg.minMm < 0.3 ? "WARNING" : "PASS", `${rpm} rpm: menor folga ${rr(vg.minMm, 2)} mm a ${vg.deg}° do PMS (válvula de ${vg.valve}) · estática ${rr(lim.clearance0Mm, 2)} mm · loft da válvula ${rr(vg.loft * 100, 1)}% (margem da mola ×${rr(vg.margin, 2)})${vg.collision ? " · COLISÃO MECÂNICA: a válvula bate no pistão" : ""}. Perfil do came e geometria da câmara ESTIMADOS. Folga sem dilatação; a corrida soma dilatação da coroa e esticamento da biela.`);
  }
  const vt = valveTrain(lim?.floatRpm ?? 10300, e.rpmLimit);
  add("09 Válvulas", vt.floats ? "OVERLOAD" : "PASS", `${e.rpmLimit} rpm: aceleração ${Math.round(vt.accMs2)} m/s² · força exigida ${Math.round(vt.needN)} N · mola ${Math.round(vt.springN)} N · margem ×${rr(vt.margin, 2)}. Massa efetiva e perfil do came ESTIMADOS.`);
  // 10
  for (const t of transmission(b, s)) {
    add("10 Transmissão", t.origem === "MANUAL" ? "PASS" : "INSUFFICIENT_DATA", `${t.gear}ª: relação total ${rr(t.total, 3)} = ${t.primary != null ? rr(t.primary, 3) : "?"} × ${t.gearRatio != null ? rr(t.gearRatio, 3) : "?"} × ${s.rear}/${s.front} · r_din ${rr(t.rDyn, 4)} m → ${rr(t.kmhAtLimit)} km/h no corte (teórica) · roda ${rr(t.wheelNm)} N·m / ${Math.round(t.wheelN)} N.`);
  }
  add("10 Transmissão", "NOT_VALIDATED", `Relações do manual do fabricante (engine_catalog); raio dinâmico = raio estático × fator de rolagem (ESTIMADO, não medido); η ${ETA} (ESTIMADO, registry drivetrain.eta_total).`);
  // 11
  const t1 = transmission(b, s)[0]!;
  const vd = vehicleAt(b, s, 3, t1.wheelN);
  add("11 Dinâmica", vd.slipLimited ? "WARNING" : "PASS", `1ª a 3 m/s: força na roda ${Math.round(t1.wheelN)} N · tração ${Math.round(vd.traction)} N (N traseiro ${Math.round(vd.nRear)} N com transferência ${Math.round(vd.nRear - vd.m * 9.81 * EST.rearStaticShare)} N) · arrasto ${rr(vd.drag)} N · rolagem ${rr(vd.roll)} N · a = ${rr(vd.a, 2)} m/s²${vd.slipLimited ? " · pneu patina" : ""}${vd.wheelie ? " · empina" : ""}.`);
  add("11 Dinâmica", "NOT_VALIDATED", "O passo da corrida (step) ainda usa peso total × aderência e ETA; esta transferência de carga é auditoria de referência, não muda o resultado da corrida.");
  return out;
}

export function overhaulTxt(b: BikeModel, s: Setup, lim?: AuditLim) {
  const L = ["", "================ FÍSICA ACOPLADA 2.0 · AUDITORIA POR MÓDULO ================", "Status: PASS · WARNING · OVERLOAD · FAILURE · INSUFFICIENT_DATA · NOT_VALIDATED"];
  L.push(`Parâmetros ESTIMADOS (sem medição): ${Object.entries(EST).map(([k, v]) => `${k}=${Array.isArray(v) ? v.map((x) => rr(x, 3)).join("/") : v}`).join(" · ")}`);
  for (const l of overhaulAudit(b, s, lim)) L.push(`[${l.status}] ${l.mod}: ${l.txt}`);
  return L.join("\n");
}
