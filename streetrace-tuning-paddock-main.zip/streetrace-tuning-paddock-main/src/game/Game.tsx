import { useEffect, useState, useCallback, useRef, type PointerEvent as RPointerEvent } from "react";
import { IMG, preloadImages, radio } from "./assets";
import { getPlayer, setLedgerScene, usePlayer } from "./store";
import { preloadReport, pushLive } from "./preload-report";
import { bikeModel } from "./physics";
import { applyNexusOverrides } from "./nexus-update/registry";
import { RegisterScreen } from "./screens/Register";
import { StoreScreen } from "./screens/Store";
import { GarageScreen } from "./screens/Garage";
import { FucarScreen } from "./screens/Fucar";
import { PecasScreen } from "./screens/Pecas";
import { OficinaScreen } from "./screens/Oficina";
import { RaceScreen } from "./screens/Race";
import { DinoScreen } from "./screens/Dino";
import { MapaScreen } from "./screens/Mapa";
import { JobLayer } from "./ui/Caller";
import { EquipCheckOverlay } from "./ui/EquipCheckOverlay";
import { Missions } from "./ui/Missions";
import { ChatButton } from "./social/Chat";
import { HallFama } from "./ui/HallFama";
import hallArt from "@/assets/hall_fama.png.asset.json";
import { inTutorial, TUTORIAL_LOCK } from "./missions";
import { MISSION_SCENES } from "./missions";
import { uiClick } from "./ui-sound";
import { BUSY_MSG, isBusy, notify } from "./jobrun";
import type { Difficulty } from "./offline";
import type { OnlineRace } from "./mmr/online-race";
import { Header } from "./ui/Header";
import { Loading, type LoadCheck } from "./ui/Loading";
import { applyUpdate, isCriticalPending, startUpdateWatch, useUpdatePending } from "./anticheat/update-watch";

/** Duração da análise do RealGear Anticheat (uma vez por sessão). */
export const ANTICHEAT_S = 2.5;
/** Sem tempo fixo: a tela abre assim que as imagens e fontes estão prontas. */
export const PRELOAD_BASE_S = 0;
const AC_KEY = "realgear-ac-ok";
import { SCENE_ASSETS, NEXT_SCENES } from "./scene-assets";
import { prefetchImages } from "./image-preload";

export type Scene = "register" | "store" | "pecas" | "garage" | "fucar" | "inventario" | "oficina" | "dino" | "race" | "mapa";
export interface Nav {
  go: (s: Scene, opts?: { distance?: number; diff?: Difficulty; online?: OnlineRace; bololo?: boolean }) => void;
}

/** Scenes inside the player's garage: the only place the radio plays. */
const GARAGE_SCENES: Scene[] = ["garage", "fucar", "inventario"];
export const musicPlaysIn = (s: Scene) => GARAGE_SCENES.includes(s) || s === "mapa";

export function Game() {
  const player = usePlayer();
  const [ready, setReady] = useState(false);
  const [scene, setScene] = useState<Scene>("register");
  const [loading, setLoading] = useState<string | null>("Carregando");
  const [distance, setDistance] = useState(500);
  const [diff, setDiff] = useState<Difficulty>("facil");
  const [, setRecords] = useState(false);
  const [hall, setHall] = useState(false);
  const [online, setOnline] = useState<OnlineRace | null>(null);
  const [bololo, setBololo] = useState(false);
  const [loadError, setLoadError] = useState(false);
  const [mountedRequest, setMountedRequest] = useState(0);
  const request = useRef(0);
  const retryLoad = useRef<() => void>(() => {});

  useState(() => { applyNexusOverrides(); return 0; });
  // soft tick on every menu button tap
  useEffect(() => {
    const onDown = (e: PointerEvent) => {
      if ((e.target as HTMLElement | null)?.closest("button,[role=button],a")) uiClick();
    };
    window.addEventListener("pointerdown", onDown);
    return () => window.removeEventListener("pointerdown", onDown);
  }, []);

  useEffect(() => () => radio.pause(), []);

  // RealGear Anticheat: build novo no servidor → preload "Atualização detectada" e recarga automática (nunca no meio da corrida/dino)
  const update = useUpdatePending();
  const [updating, setUpdating] = useState(false);
  useEffect(() => { startUpdateWatch(); }, []);
  useEffect(() => {
    if (!update || updating) return;
    void applyUpdate(scene, () => { radio.pause(); setUpdating(true); });
  }, [update, scene, updating]);

  const tapRef = useRef(0);
  const bootVerified = useRef(false);
  useEffect(() => { try { if (sessionStorage.getItem(AC_KEY) === "1") bootVerified.current = true; } catch { /* sem storage */ } }, []);
  const bootStart = useRef(typeof performance !== "undefined" ? performance.now() : 0);
  const [verified, setVerified] = useState(false);
  const [checks, setChecks] = useState<LoadCheck[]>([]);
  const goStart = useRef(0);
  const go = useCallback<Nav["go"]>(async (s, opts) => {
    if ((s === "race" || s === "dino" || s === "oficina") && isBusy()) return notify(BUSY_MSG);
    if ((s === "race" || s === "dino") && isCriticalPending()) return notify("Atualização obrigatória em andamento");
    const id = ++request.current;
    goStart.current = performance.now();
    retryLoad.current = () => { void go(s, opts); };
    setLoadError(false);
    setLoading(s === "race" ? "Preparando pista" : "Carregando");
    const base: LoadCheck[] = s === "race"
      ? [{ label: "Imagens e poses das motos", done: false }, { label: "Física da pista", done: false }, { label: "Conferência final", done: false }]
      : [{ label: "Imagens da tela", done: false }, { label: "Conferência final", done: false }];
    setChecks(base);
    const mark = (i: number, extra?: string) => setChecks((c) => c.map((x, j) => (j === i ? { ...x, done: true, ...(extra ? { detail: extra } : {}) } : x)));
    try {
      if (s === "race" && opts?.distance) {
        const pl = getPlayer();
        if (pl?.activeBike) {
          try { pushLive(preloadReport(pl.name, bikeModel(pl.activeBike), pl.setup, opts.distance, pl.fuelL), { bike: bikeModel(pl.activeBike), setup: pl.setup }); } catch (err) { console.warn("preload report", err); }
        }
      }
      await preloadImages(SCENE_ASSETS[s], (d, t) => { if (request.current === id) setChecks((c) => c.map((x, j) => (j === 0 ? { ...x, detail: `${d}/${t}` } : x))); });
      if (request.current !== id) return;
      mark(0);
      if (s === "race") mark(1);
      // conferência: toda imagem da cena precisa estar decodificada antes de montar (sem sprite tardio nem teleporte)
      await preloadImages(SCENE_ASSETS[s]);
      // fontes prontas antes de abrir: sem troca de layout com a tela já visível
      try { await Promise.race([document.fonts?.ready, new Promise((r) => setTimeout(r, 1500))]); } catch { /* sem API de fontes */ }
      if (request.current !== id) return;
      mark(base.length - 1);
      if (opts?.distance) setDistance(opts.distance);
      if (opts?.diff) setDiff(opts.diff);
      setOnline(opts?.online ?? null);
      setBololo(!!opts?.bololo);
      setRecords(false);
      setHall(false);
      setScene(s);
      setLedgerScene(s);
      setReady(true);
      setMountedRequest(id);
      // antecipa em segundo plano as telas prováveis a seguir (não bloqueia a cena atual)
      prefetchImages((NEXT_SCENES[s as keyof typeof NEXT_SCENES] ?? []).flatMap((n) => [...SCENE_ASSETS[n]]));
      if (musicPlaysIn(s)) void radio.start();
      else radio.pause();
    } catch {
      if (request.current === id) setLoadError(true);
    }
  }, []);

  useEffect(() => {
    void go("mapa");
    return () => { request.current++; };
  }, [go]);

  // Keep the shield over the newly committed scene until layout and its first paint are ready.
  useEffect(() => {
    if (!mountedRequest) return;
    let next = 0;
    let timer = 0;
    const frame = requestAnimationFrame(() => {
      next = requestAnimationFrame(() => {
        if (request.current !== mountedRequest) return;
        const baseWait = Math.max(0, PRELOAD_BASE_S * 1000 - (performance.now() - goStart.current));
        if (bootVerified.current) { timer = window.setTimeout(() => { if (request.current === mountedRequest) setLoading(null); }, baseWait); return; }
        // RealGear Anticheat: análise de 4 s só na primeira carga da sessão; depois todo preload é só conferência visual
        const wait = Math.max(baseWait - 900, ANTICHEAT_S * 1000 - (performance.now() - bootStart.current));
        timer = window.setTimeout(() => {
          setVerified(true);
          timer = window.setTimeout(() => {
            bootVerified.current = true;
            try { sessionStorage.setItem(AC_KEY, "1"); } catch { /* sem storage */ }
            setVerified(false);
            if (request.current === mountedRequest) setLoading(null);
          }, 900);
        }, wait);
      });
    });
    return () => { cancelAnimationFrame(frame); cancelAnimationFrame(next); window.clearTimeout(timer); };
  }, [mountedRequest]);

  const showHeader = player && scene !== "register" && scene !== "race" && scene !== "dino";

    const back: Scene | null =
    scene === "dino" ? "oficina"
    : ["fucar", "inventario"].includes(scene) ? "mapa"
    : ["store", "pecas", "oficina", "garage"].includes(scene) ? "mapa"
    : null;

  const onDoubleBack = (e: RPointerEvent) => {
    if (loading) return;
    if (!back) return;
    if ((e.target as HTMLElement).closest("button,input,select,textarea,a,[role=slider],[data-no-back]")) return;
    const now = e.timeStamp;
    if (now - tapRef.current < 320) { tapRef.current = 0; go(back); } else tapRef.current = now;
  };

  return (
    <div
      onPointerUp={onDoubleBack}
      className="relative h-dvh max-h-dvh w-full max-w-[calc(100dvh*9/16)] overflow-hidden bg-background shadow-2xl">
      {ready && (
        <div key={scene} inert={!!loading} className="absolute inset-0">
          {scene === "register" && <RegisterScreen go={go} />}
          {scene === "store" && <StoreScreen go={go} />}
          {scene === "pecas" && <PecasScreen go={go} />}
          {scene === "garage" && <GarageScreen go={go} />}
          {scene === "fucar" && <FucarScreen go={go} />}
          {scene === "inventario" && <FucarScreen go={go} mode="pecas" />}
          {scene === "oficina" && <OficinaScreen go={go} />}
          {scene === "dino" && <DinoScreen go={go} />}
          {scene === "race" && <RaceScreen go={go} distance={distance} diff={diff} online={online} bololo={bololo} />}
          {scene === "mapa" && <MapaScreen go={go} />}
        </div>
      )}
      {showHeader && scene !== "oficina" && <Header shop={scene === "store" || scene === "pecas"} scene={scene} />}
      {showHeader && MISSION_SCENES.includes(scene) && scene !== "garage" && (
        <button onClick={() => (player && inTutorial(player) ? notify(TUTORIAL_LOCK) : setHall(true))} aria-label="Liderança" className="absolute right-5 top-[298px] z-30 flex w-[4.25rem] overflow-visible flex-col items-center transition active:scale-90">
          <img src={hallArt.url} alt="" className="h-10 w-10 object-contain drop-shadow-lg" draggable={false} />
          <span className="-mt-0.5 font-display text-[8px] tracking-[0.12em] drop-shadow-[0_1px_2px_rgb(0_0_0/0.9)]">LIDERANÇA</span>
        </button>
      )}
      {hall && <HallFama onClose={() => setHall(false)} />}
      <EquipCheckOverlay />
      {player && scene !== "register" && <JobLayer showCalls={scene !== "race" && scene !== "dino"} />}
      {showHeader && MISSION_SCENES.includes(scene) && <ChatButton />}
      {showHeader && MISSION_SCENES.includes(scene) && <Missions go={go} />}
      {updating && <Loading label="Atualizando" updating />}
      {!updating && loading && <Loading label={loading} failed={loadError} verified={verified} checks={checks} analyzing={!bootVerified.current} onRetry={() => retryLoad.current()} />}
    </div>
  );
}
