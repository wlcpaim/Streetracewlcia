import { ARCHIVED_BIKE_ART } from "@/game/complegame/bike-sprites";
import "@/game/assets";
import { describe, expect, it } from "vitest";
import { laneBottomPct, spriteBox, scaleBox, spriteWidthPct, geoOf, REF_WHEELBASE_PCT, SPRITE_PCT } from "./race-lanes";
import { SPRITE_CAL } from "./sprite-calibration";
import { BIKE_ART, bikeScale } from "./assets";

const POSES = ["foot", "g1", "crouch", "tuck"] as const;
const wbPx = (src: string, w: number) => { const g = geoOf(src), b = spriteBox(g, w); return b.wPx * (g.A - g.B); };
const tireLine = (src: string, w: number) => { const b = spriteBox(geoOf(src), w); return -(b.groundPx - b.refGroundPx) + b.groundPx; };

describe("calibração real por sprite", () => {
  it("toda pose de toda moto tem calibração própria medida", () => {
    for (const a of Object.values(ARCHIVED_BIKE_ART)) for (const p of POSES) expect(SPRITE_CAL.has(a[p])).toBe(true);
  });
  it("1. todas as motos e o sprite especial têm o mesmo entre-eixos na tela", () => {
    for (const src of SPRITE_CAL.keys()) expect(wbPx(src, 1000)).toBeCloseTo((REF_WHEELBASE_PCT / 100) * 1000, 6);
  });
  it("2. nenhuma deformação: altura = largura × H/W do PNG", () => {
    for (const [src, c] of SPRITE_CAL) { const b = spriteBox(geoOf(src), 777); expect(b.hPx / b.wPx).toBeCloseTo(c.imageHeight / c.imageWidth, 9); }
  });
  it("3. as 4 posturas da mesma moto ficam dentro de 0,3% de largura", () => {
    for (const a of Object.values(ARCHIVED_BIKE_ART)) {
      const w = POSES.map((p) => spriteBox(geoOf(a[p]), 1000).pct);
      expect(Math.max(...w) / Math.min(...w)).toBeLessThan(1.003);
    }
  });
  it("4. pneus no asfalto: linha do pneu fica no mesmo ponto em todas as imagens", () => {
    const ref = tireLine([...SPRITE_CAL.keys()][0]!, 1000);
    for (const src of SPRITE_CAL.keys()) expect(tireLine(src, 1000)).toBeCloseTo(ref, 6);
  });
  it("5. faixas retas: todas as faixas no mesmo solo, sem escala", () => {
    for (const [l, b] of [[-1, 10], [0, 10], [1 / 7, 13], [4 / 7, 22], [1, 31], [3, 31]] as const) expect(laneBottomPct(l)).toBeCloseTo(b, 6);
    expect(spriteBox.length).toBe(2); // spriteBox não recebe faixa nem Y
  });
  it("6. o sprite largo (boss 1667×911) não herda a geometria genérica", () => {
    const boss = [...SPRITE_CAL.values()].find((c) => c.name === "boss_cg_twister")!;
    const src = [...SPRITE_CAL].find(([, c]) => c === boss)![0];
    expect(spriteBox(geoOf(src), 1000).pct).toBeLessThan(SPRITE_PCT - 4);
  });
  it("7. jogador e adversário da mesma moto usam a mesma caixa", () => {
    const a = ARCHIVED_BIKE_ART["factor150"]!;
    expect(spriteBox(geoOf(a.g1), 900)).toEqual(spriteBox(geoOf(a.g1), 900));
    expect(spriteWidthPct(geoOf(a.g1))).toBeCloseTo(spriteWidthPct(geoOf(ARCHIVED_BIKE_ART["titan160"]!.g1)), 1);
  });
  it("8. responsividade: percentual igual em 360, 450 e 1920 px", () => {
    for (const src of SPRITE_CAL.keys()) {
      const p = [360, 450, 1920].map((w) => spriteBox(geoOf(src), w));
      expect(new Set(p.map((x) => x.pct)).size).toBe(1);
      expect(p[0]!.wPx / 360).toBeCloseTo(p[2]!.wPx / 1920, 9);
    }
  });
  it("9. Bolinha no tamanho original: mesma caixa sem escala", () => {
    const g = geoOf(ARCHIVED_BIKE_ART["cg125"]!.g1);
    expect(bikeScale("cg125")).toBe(1);
    expect(scaleBox(spriteBox(g, 1000), bikeScale("cg125"))).toEqual(spriteBox(g, 1000));
  });
});
