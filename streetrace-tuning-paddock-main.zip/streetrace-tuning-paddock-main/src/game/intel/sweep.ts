// Wikipedia StreetRace — Teste Geral: o cérebro varre cada peça, comando, taxa e combustível
// em cada moto e pista com o mesmo step() da corrida e a revisão física (physicsReview), e grava
// o resultado como TXT no feed "Ao Vivo". Somente leitura: não altera a física.
import { BIKES, runTest } from "../admin-lab";
import { STOCK_SETUP, type Setup } from "../physics";
import { CAM_LABEL, PARTS_CATALOG, SLOTS, TAXAS, type Cam, type Slot } from "../parts";
import { TRACKS } from "../records";
import { physicsReview, UPDATES } from "./changelog";
import type { LiveReport } from "../preload-report";

export type Variation = { group: string; label: string; setup: Setup };

/** Todas as variações: cada peça de cada slot, cada comando, cada taxa, cada combustível. */
export function variations(): Variation[] {
  const v: Variation[] = [{ group: "base", label: "Original", setup: STOCK_SETUP }];
  for (const slot of SLOTS) for (const p of PARTS_CATALOG.filter((p) => (p.kind as string) === slot && p.id !== `${slot}-original`))
    v.push({ group: `peça:${slot}`, label: `${p.brand} ${p.name}`, setup: { ...STOCK_SETUP, slots: { ...STOCK_SETUP.slots, [slot as Slot]: p.id } } });
  for (const cam of Object.keys(CAM_LABEL) as Cam[]) if (cam !== "original") v.push({ group: "comando", label: CAM_LABEL[cam], setup: { ...STOCK_SETUP, cam } });
  for (const t of TAXAS) v.push({ group: "taxa", label: `CR ${t.taxa}`, setup: { ...STOCK_SETUP, compression: t.taxa } });
  v.push({ group: "combustível", label: "Etanol", setup: { ...STOCK_SETUP, fuel: "etanol" as Setup["fuel"] } });
  return v;
}

const f = (n: number | null | undefined, d = 3) => (n == null || !Number.isFinite(n) ? "—" : n.toFixed(d));

/** Roda tudo e gera o relatório do cérebro. Determinístico (mesmas entradas, mesmo TXT). */
export function generalSweep(): { report: LiveReport; runs: number; fails: number } {
  const vs = variations();
  const L: string[] = ["WIKIPEDIA STREETRACE — TESTE GERAL (coração e cérebro do sistema)", `Variações: ${vs.length} × motos: ${BIKES.length} × pistas: ${TRACKS.length}`, `Atualizações registradas: ${UPDATES.map((u) => u.id).join(", ")}`, ""];
  let runs = 0, fails = 0, worstErr = 0;
  for (const b of BIKES) {
    L.push("=".repeat(78), `MOTO: ${b.name}`, "=".repeat(78));
    for (const v of vs) {
      const chk = physicsReview(v.setup, b.id);
      const bad = chk.filter((c) => c.status !== "PASS");
      worstErr = Math.max(worstErr, ...chk.map((c) => (Number.isFinite(c.errPct) ? c.errPct : 0)));
      const times = TRACKS.map((t) => {
        const r = runTest(b, v.setup, t.m, { id: `${b.id}-${v.label}-${t.id}`, group: v.group, label: v.label, track: t.id }, false);
        runs++;
        const broke = r.breakdown ? ` QUEBROU(${r.breakdown.cause} @${f(r.breakdown.atM, 0)}m ${f(r.breakdown.rpm, 0)}rpm)` : r.result.stalled ? " PANE SECA" : "";
        if (broke) fails++;
        return `${t.id}: ${f(r.result.finishS)}s ${f(r.result.vmaxKmh, 1)}km/h${broke}`;
      });
      L.push(`[${v.group}] ${v.label}`, `   ${times.join(" | ")}`,
        `   física: ${chk.length - bad.length}/${chk.length} PASS${bad.length ? " · " + bad.map((c) => `${c.id}=${c.status} (erro ${f(c.errPct)}%)`).join(", ") : ""}`);
    }
  }
  L.push("", "RESUMO", `Corridas simuladas: ${runs}`, `Quebras/pane: ${fails}`, `Maior erro de cálculo físico: ${f(worstErr)}%`,
    "Valores marcados ESTIMADO na auditoria continuam sem medição real; nenhuma variação foi declarada validada.");
  const report: LiveReport = { id: `geral-${Date.now()}`, at: new Date().toISOString(), pilot: "Wikipedia", bike: "Teste geral", distance: 0, status: `${runs} corridas · ${fails} quebras`, txt: L.join("\n") };
  return { report, runs, fails };
}
