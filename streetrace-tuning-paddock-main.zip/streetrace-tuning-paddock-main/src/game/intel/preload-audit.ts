// Lê um relatório TXT de preload (gerado no jogo ou colado) e audita os números entre si, sem rodar o jogo.
import { CV_KW, K_RPM, KGF_NM } from "./powertrain";
import type { Finding } from "./audit";

export type ParsedPreload = { piloto?: string | undefined; moto?: string | undefined; pista?: number | undefined; cv?: number | undefined; rpmPico?: number | undefined; corte?: number | undefined; kgf?: number | undefined; nm?: number | undefined; massa?: number | undefined; eta?: number | undefined; duties: { rpm: number; duty: number; afr: number }[]; combustivel?: string | undefined; tempo?: number | undefined; vmax?: number | undefined; gasto?: number | undefined };

const num = (s?: string) => (s == null ? undefined : Number(s.replace(",", ".")));
export function parsePreload(txt: string): ParsedPreload {
  const g = (re: RegExp) => re.exec(txt);
  const hp = g(/RESULTADO:\s*hp\s*=\s*([\d.]+)\s*cv\s*@\s*(\d+)\s*rpm\s*\|\s*corte\s*(\d+)/);
  const tq = g(/torque[^\n]*=\s*([\d.]+)\s*kgf·m\s*=\s*([\d.]+)\s*N·m/);
  const ms = g(/piloto\s*\d+\s*=\s*([\d.]+)\s*kg/);
  const head = g(/PILOTO:\s*([^|]+)\|\s*MOTO:\s*([^|]+)\|\s*PISTA:\s*([\d.]+)/);
  const fuel = g(/Tanque:\s*[\d.]+\s*L\s*\((\w+)\)/);
  const end = g(/CHEGADA:\s*([\d.]+)\s*s\s*\|\s*vmax\s*([\d.]+)[^|]*\|[^|]*\|\s*gasto\s*([\d.]+)/);
  const duties = [...txt.matchAll(/(\d{4,5})\s*rpm:[^\n]*duty\s*([\d.]+)%\s*\|\s*AFR\s*([\d.]+)/g)].map((m) => ({ rpm: Number(m[1]), duty: Number(m[2]), afr: Number(m[3]) }));
  return { piloto: head?.[1]?.trim(), moto: head?.[2]?.trim(), pista: num(head?.[3]), cv: num(hp?.[1]), rpmPico: num(hp?.[2]), corte: num(hp?.[3]), kgf: num(tq?.[1]), nm: num(tq?.[2]), massa: num(ms?.[1]), duties, combustivel: fuel?.[1], tempo: num(end?.[1]), vmax: num(end?.[2]), gasto: num(end?.[3]) };
}

const base = { code: "", test: "", files: ["src/game/preload-report.ts", "src/game/physics.ts"], keep: ["resultado das corridas"] };
export function auditPreload(p: ParsedPreload): Finding[] {
  const F: Finding[] = [];
  if (p.cv && p.rpmPico && p.nm) {
    const kw = p.cv * CV_KW, exp = (kw * K_RPM) / p.rpmPico, d = p.nm - exp;
    F.push({ ...base, id: "RP-01", pass: Math.abs(d) / exp < 0.03, sev: "média", func: "stats() / relatório", title: "Torque sem RPM associado: possível incompatibilidade simultânea",
      found: `${p.cv} cv @ ${p.rpmPico} rpm com ${p.nm} N·m`, expected: `${p.cv} × 0,73549875 = ${kw.toFixed(3)} kW → T = ${kw.toFixed(3)} × 9549,3 / ${p.rpmPico} = ${exp.toFixed(2)} N·m`,
      formula: "T = P(kW) × 60000/(2π·rpm)", diffAbs: d, diffPct: (100 * d) / exp, cause: "Se forem simultâneos, há incompatibilidade. Um torque máximo em outro RPM não pode ser comparado ao pico de potência. O TXT antigo não informa o RPM do torque; é preciso investigar, não concluir quebra física.",
      code: "physics.ts stats()", test: "Recalcular T a partir de P e rpm.", fix: "Mostrar o torque com o rpm em que ocorre, derivado da curva." });
    if (p.kgf) { const dk = Math.abs(p.kgf * KGF_NM - p.nm); F.push({ ...base, id: "RP-02", pass: dk < 0.06, sev: "baixa", func: "relatório", title: "Conversão kgf·m ↔ N·m", found: `${p.kgf} kgf·m ↔ ${p.nm} N·m`, expected: `${(p.kgf * KGF_NM).toFixed(2)} N·m`, formula: "1 kgf·m = 9,80665 N·m", diffAbs: dk, diffPct: null, cause: "—", fix: "Nenhuma." }); }
  }
  const over = p.duties.filter((x) => x.duty > 100);
  if (p.duties.length) F.push({ ...base, id: "RP-03", pass: !over.length, sev: "alta", func: "fuelChain()", title: "Duty cycle acima de 100%", found: over.map((x) => `${x.rpm}: ${x.duty}%`).join(" · ") || "≤100%", expected: "≤ 100% (bico travado aberto = limite)", formula: "duty = tempo aberto / tempo do ciclo", diffAbs: over.length ? Math.max(...over.map((x) => x.duty)) - 100 : 0, diffPct: null, cause: "O número é demanda/capacidade, não duty físico: o sistema opera saturado.", fix: "Limitar a 100% e mostrar a falta em % separada." });
  const st = p.combustivel === "etanol" ? 9.0 : 14.7;
  const rich = p.duties.filter((x) => x.duty > 100 && x.afr < st);
  if (p.duties.length) F.push({ ...base, id: "RP-04", pass: !rich.length, sev: "alta", func: "afrAt()", title: "FALTA de combustível com AFR rico", found: rich.map((x) => `${x.rpm}: AFR ${x.afr} (λ ${(x.afr / st).toFixed(3)})`).join(" · ") || "coerente", expected: `falta real ⇒ AFR > ${st} (λ > 1)`, formula: "λ = AFR / AFR_esteq", diffAbs: null, diffPct: null, cause: "O relatório diz FALTA enquanto o AFR mostrado ainda é rico: o diagnóstico usa o alvo λ 0,88, não o estequiométrico.", fix: "Classificar por λ: <0,88 rico, 0,88–1 abaixo do alvo de potência, >1 pobre." });
  if (p.cv && p.rpmPico) { const cv = p.cv; F.push({ ...base, id: "RP-05", pass: true, sev: "info", func: "relatório", title: "CV na roda (cenários, não medição)", found: `motor ${cv} cv`, expected: [0.95, 0.9, 0.85].map((e) => `η ${e}: ${(cv * e).toFixed(2)} cv`).join(" · "), formula: "P_roda = P_motor × η", diffAbs: null, diffPct: null, cause: "SIMULAÇÃO DE CENÁRIO — nenhum dinamômetro real; pressupõe embreagem acoplada.", fix: "Calibrar η com dinamômetro de rolo." }); }
  if (p.tempo && p.gasto && p.cv) { const maxL = (p.cv * CV_KW * (p.combustivel === "etanol" ? 0.61 : 0.42)) / (p.combustivel === "etanol" ? 0.79 : 0.74) / 3600 * p.tempo; F.push({ ...base, id: "RP-06", pass: p.gasto <= maxL * 1.01, sev: "média", func: "fuelFlow()", title: "Consumo compatível com potência e tempo", found: `${p.gasto} L em ${p.tempo} s`, expected: `≤ ${maxL.toFixed(3)} L`, formula: "L = P × BSFC / ρ / 3600 × t", diffAbs: p.gasto - maxL, diffPct: null, cause: "—", fix: "Nenhuma." }); }
  return F;
}
