// Engenharia Inteligente: perguntas técnicas respondidas com os dados do código e da telemetria da corrida.
// Cada resposta diz a origem (MEDIDO/CALCULADO/ESTIMADO) e, quando falta dado, diz exatamente qual.
import { ETA, PARTS_CATALOG_FREE, type Setup } from "./qa-deps";
import { RIDER_KG, FUEL_DENSITY, stats, type BikeModel } from "../physics";
import { fuelChain } from "../rootcause";
import { runTest, type RunResult } from "../admin-lab";
import { powertrain, type Origem } from "./powertrain";

export type Answer = { q: string; a: string; origem: Origem; passos: string[]; falta?: string };
const n = (x: number | null | undefined, d = 2) => (x == null || !Number.isFinite(x) ? "—" : x.toFixed(d));
const NAO = "NÃO É POSSÍVEL CALCULAR COM OS DADOS ATUAIS.";

function race(b: BikeModel, s: Setup, m = 402.34, log = false) {
  return runTest(b, s, m, { id: "qa", group: "qa", label: "qa", track: `${m} m` }, log, 0.05, 2000);
}

/** Controlled experiments: one change at a time, same track, same seed rules. */
export function experiments(b: BikeModel, s: Setup, m = 402.34) {
  const base = race(b, s, m).result.finishS;
  const bico = PARTS_CATALOG_FREE.filter((p) => p.kind === "bico" && (p.flow ?? 1) > ((PARTS_CATALOG_FREE.find((x) => x.id === s.slots.bico)?.flow) ?? 1)).sort((a, z) => (a.flow ?? 1) - (z.flow ?? 1))[0];
  const tries: [string, Setup][] = [
    ["coroa +2 dentes", { ...s, rear: s.rear + 2 }],
    ["coroa −2 dentes", { ...s, rear: s.rear - 2 }],
    ["pinhão −1 dente", { ...s, front: s.front - 1 }],
    ["pneu −4 psi", { ...s, psi: s.psi - 4 }],
    ...(bico ? [[`bico ${bico.name}`, { ...s, slots: { ...s.slots, bico: bico.id } }] as [string, Setup]] : []),
  ];
  return { base, rows: tries.map(([label, x]) => { const t = race(b, x, m).result.finishS; return { label, t, delta: t != null && base != null ? t - base : null }; }) };
}

export function answers(b: BikeModel, s: Setup, m = 402.34): { run: RunResult; list: Answer[] } {
  const pt = powertrain(b, s), run = race(b, s, m, true), log = run.engineLog ?? [];
  const L: Answer[] = [];
  const mx = pt.motor.cvMax, nm = pt.motor.nmMax;
  L.push({ q: "Quantos CV o motor produz?", a: `${n(mx.v)} cv a ${mx.rpm} rpm (base de ficha ${pt.motor.cvBase.v} cv).`, origem: "CALCULADO", passos: ["P(rpm) = engine().hp × powerShape × mixFactor × exhaustShape", `máximo da varredura 3000–${run.engine.rpmLimit} rpm de 50 em 50 = ${n(mx.v)} cv @ ${mx.rpm}`] });
  L.push({ q: "Quantos CV chegam efetivamente à roda?", a: `Calculado: ${n(pt.roda.cvRoda.v)} cv (η ${ETA}). Medido: ${NAO}`, origem: "CALCULADO", passos: [`P_roda = min(P_motor, T_cap×ω) × ${ETA} = ${n(pt.roda.cvRoda.v)} cv`, ...pt.roda.cenarios.map((c) => `cenário η ${c.eta}: ${n(c.cv)} cv (SIMULAÇÃO DE CENÁRIO)`)], falta: "Para medir: dinamômetro de rolo com leitura de força e rpm do rolo." });
  L.push({ q: "Quantos CV são perdidos na transmissão?", a: `${n(pt.roda.perdaCv.v)} cv (${n(pt.roda.perdaPct.v, 1)}%).`, origem: "CALCULADO", passos: [`perda = ${n(mx.v)} − ${n(pt.roda.cvRoda.v)}`, `perda% = 100 × (1 − ${ETA})`], falta: "Divisão entre primária, câmbio e corrente: não modelada (η único)." });
  L.push({ q: "Em qual RPM o motor entrega sua potência máxima?", a: `${mx.rpm} rpm; torque máximo ${n(nm.v)} N·m a ${nm.rpm} rpm.`, origem: "CALCULADO", passos: ["argmax P(rpm) e argmax T(rpm) = P/ω na curva"] });
  const g = pt.gears.filter((x) => x.forcaN != null);
  if (g.length) {
    const best = g.reduce((a, x) => ((x.forcaN ?? 0) > (a.forcaN ?? 0) ? x : a));
    L.push({ q: "Qual marcha entrega maior força na roda?", a: `${best.marcha}ª: ${n(best.forcaN, 0)} N no torque máximo.`, origem: "ESTIMADO", passos: g.map((x) => `${x.marcha}ª: N_total ${n(x.relacaoTotal, 2)} · T_roda = ${n(nm.v)}→emb ${n(Math.min(nm.v, pt.embreagemNm))} × ${n(x.relacaoTotal, 2)} × ${ETA} = ${n(x.nmRoda, 1)} N·m · F = T/r(${n(pt.raioPneu.v, 3)} m) = ${n(x.forcaN, 0)} N`), falta: "Raio dinâmico real (estimado pelo raio estático da medida do pneu)." });
    L.push({ q: "Quanto torque chega à roda em cada marcha?", a: g.map((x) => `${x.marcha}ª ${n(x.nmRoda, 0)} N·m`).join(" · "), origem: "ESTIMADO", passos: ["N_total = ω_motor no corte × r / v_marcha(gearSpeeds)", "T_roda = T_embreagem × N_total × η"], falta: "Relação primária e de cada marcha separadas não existem nos dados; usada a relação total." });
  }
  L.push({ q: "Quanto tempo o pneu realmente patinou?", a: `${n(run.result.spinS, 2)} s na corrida de ${m} m.`, origem: "CALCULADO", passos: ["soma de DT (1/240 s) enquanto força na roda > tração"], falta: "Slip ratio (velocidade da roda) não é calculado: só o tempo acima do limite." });
  L.push({ q: "Quanto tempo a embreagem realmente patinou?", a: `${n(run.result.slipS, 2)} s.`, origem: "CALCULADO", passos: ["soma de DT enquanto T_motor > capacidade (P > clutchNm × ω)"], falta: "Diferença de rpm motor/câmbio não é registrada." });
  const slipPts = log.filter((p) => p.slip > 0);
  const lostKj = slipPts.reduce((a, p) => a + (p.hp / Math.max(0.01, 1 - p.slip)) * p.slip * 0.7355 * 0.05, 0);
  L.push({ q: "Quanto torque foi perdido durante a patinagem?", a: slipPts.length ? `Torque excedente requer torque motor antes do acoplamento em cada passo. Energia estimada não equivale a torque: ≈ ${n(lostKj, 2)} kJ.` : "Nenhuma patinagem de embreagem nesta corrida.", origem: "ESTIMADO", passos: ["E_perdida ≈ Σ P_motor × slip × Δt", "P_motor = hp_log / (1 − slip)"] });
  const peakFc = fuelChain(b, s, mx.rpm);
  const fr = { comb: Math.max(0, peakFc.dutyPct - 100), tracao: (run.result.spinS / Math.max(0.01, run.result.finishS ?? 1)) * 100, emb: (run.result.slipS / Math.max(0.01, run.result.finishS ?? 1)) * 100 };
  const lim = Object.entries({ "combustível (bico/bomba)": fr.comb, "tração do pneu": fr.tracao, "embreagem": fr.emb }).sort((a, z) => z[1] - a[1])[0];
  L.push({ q: "O motor está limitado por combustível, escape, admissão, temperatura ou transmissão?", a: (lim?.[1] ?? 0) > 0.5 ? `Hipótese entre os indicadores disponíveis: ${lim?.[0]}.` : "Nenhum limitador relevante detectado.", origem: "CALCULADO", passos: [`falta de combustível no pico: ${n(fr.comb, 1)}% (demanda/capacidade ${n(peakFc.dutyPct, 1)}%)`, `tempo patinando pneu: ${n(fr.tracao, 1)}% da corrida`, `tempo patinando embreagem: ${n(fr.emb, 1)}%`], falta: "Temperatura real (EGT/cabeçote) não existe: o jogo só tem acumulador de calor do log de fluxo." });
  const ex = experiments(b, s, m);
  const bestEx = ex.rows.filter((r) => r.delta != null).sort((a, z) => (a.delta ?? 0) - (z.delta ?? 0))[0];
  L.push({ q: "Qual alteração teria maior efeito na aceleração?", a: bestEx ? `${bestEx.label}: diferença ${n(bestEx.delta, 3)} s em ${m} m entre os ensaios disponíveis (não prova causal definitiva).` : NAO, origem: "CALCULADO", passos: [`base ${n(ex.base, 3)} s`, ...ex.rows.map((r) => `${r.label}: ${n(r.t, 3)} s (${r.delta != null && r.delta >= 0 ? "+" : ""}${n(r.delta, 3)})`)] });
  const mass = stats(b, s, b.tank).kg + (s.riderKg ?? RIDER_KG);
  const vEnd = (log.at(-1)?.kmh ?? 0) / 3.6;
  const ke = 0.5 * mass * vEnd * vEnd / 1000;
  const wWheel = log.reduce((a, p) => a + p.hp * 0.7355 * ETA * 0.05, 0);
  L.push({ q: "O resultado da corrida é compatível com a potência, massa e relações?", a: ke <= wWheel ? `Verificação parcial por amostras: energia cinética final ${n(ke, 1)} kJ ≤ trabalho na roda ${n(wWheel, 1)} kJ (balanço integral de energia ainda não instrumentado).` : `INCOMPATÍVEL: energia cinética ${n(ke, 1)} kJ > trabalho na roda ${n(wWheel, 1)} kJ.`, origem: "CALCULADO", passos: [`m = ${n(mass, 1)} kg (moto+tanque ${FUEL_DENSITY[s.fuel]} kg/L+piloto)`, `Ec = ½ m v² com v final ${n(vEnd * 3.6, 1)} km/h`, "W_roda ≈ Σ P_motor(log) × η × Δt"] });
  return { run, list: L };
}
