// Auditoria matemática: roda as funções reais com o setup escolhido e compara com equações físicas independentes.
// Somente leitura: nenhuma fórmula, parâmetro ou resultado do jogo é alterado aqui.
import { ETA, FUEL_DENSITY, RIDER_KG, STOCK_SETUP, afrAt, drivetrain, engine, exhaustShape, fuelFlow, gearSpeeds, mixtureAt, stats, stress, tireOf, type BikeModel, type Setup } from "../physics";
import { fuelChain } from "../rootcause";
import { runTest } from "../admin-lab";
import { partById, PARTS_CATALOG } from "../parts";
import { KGF_NM, cvToKw, powertrain, torqueFromPower, curve, clutchCap } from "./powertrain";

export type Sev = "alta" | "média" | "baixa" | "info";
export type Finding = {
  id: string; pass: boolean; sev: Sev; func: string; title: string;
  found: string; expected: string; formula: string; diffAbs: number | null; diffPct: number | null;
  cause: string; code: string; test: string; fix: string; files: string[]; keep: string[];
};

const n = (x: number, d = 2) => (Number.isFinite(x) ? x.toFixed(d) : "—");
const pctDiff = (a: number, b: number) => (b ? (100 * (a - b)) / b : null);

export function auditSetup(b: BikeModel, s: Setup): Finding[] {
  const F: Finding[] = [];
  const add = (f: Finding) => F.push(f);
  const e = engine(b, s), st = stats(b, s), pt = powertrain(b, s);
  const eth = e.eth;

  // 1. Torque de stats() vs torque da curva real (P = T·ω)
  const nmStats = st.torque * KGF_NM, tk = pt.motor.nmMax, tAtPeak = torqueFromPower(cvToKw(pt.motor.cvMax.v), pt.motor.cvMax.rpm);
  const d1 = nmStats - tk.v;
  add({ id: "PT-01", pass: Math.abs(d1) / tk.v < 0.03, sev: Math.abs(d1) / tk.v > 0.06 ? "alta" : "média", func: "stats()", title: "Torque exibido vs torque da curva de potência",
    found: `stats(): ${n(nmStats, 2)} N·m (${n(st.torque, 2)} kgf·m), sem rpm associado`, expected: `máx da curva: ${n(tk.v, 2)} N·m a ${tk.rpm} rpm; no pico de potência (${n(pt.motor.cvMax.v)} cv a ${pt.motor.cvMax.rpm} rpm): ${n(tAtPeak, 2)} N·m`,
    formula: "T(N·m) = P(kW) × 60000 / (2π × rpm) ≈ P × 9549,3 / rpm", diffAbs: d1, diffPct: pctDiff(nmStats, tk.v),
    cause: "stats() escala o torque da ficha pela razão de potência (torque_base × hp/hp_base). O relatório mostra esse número ao lado do pico de potência como se fossem do mesmo rpm.",
    code: "physics.ts stats(): const torque = torqueBase * (e.hp / hpBase)", test: "Comparar stats().torque×9,80665 com max(P(rpm)/ω) da curve(); diferença < 3%.",
    fix: "Derivar o torque exibido da própria curva (P/ω) e sempre mostrar o rpm em que ele ocorre.", files: ["src/game/physics.ts", "src/game/preload-report.ts"], keep: ["resultado das corridas (step() usa P, não stats().torque)"] });

  // 2. Ficha base: o par cv/torque do fabricante é coerente com a forma da curva?
  if (s === STOCK_SETUP || JSON.stringify(s) === JSON.stringify(STOCK_SETUP)) {
    const c = curve(b, s, 50), at = c.reduce((a, p) => (Math.abs(p.rpm - b.rpmTorque) < Math.abs(a.rpm - b.rpmTorque) ? p : a), c[0] ?? { rpm: 0, nmMotor: 0 });
    const ficha = (eth ? b.torqueEth : b.torqueGas) * KGF_NM;
    add({ id: "PT-02", pass: Math.abs(at.nmMotor - ficha) / ficha < 0.05, sev: "média", func: "powerShape()", title: "Forma da curva vs torque da ficha no rpm de torque máximo",
      found: `curva a ${at.rpm} rpm: ${n(at.nmMotor)} N·m; máximo da curva em ${tk.rpm} rpm`, expected: `ficha: ${n(ficha)} N·m a ${b.rpmTorque} rpm (máximo nesse rpm)`, formula: "T(rpm) = hp × powerShape(rpm) × 735,5 / ω", diffAbs: at.nmMotor - ficha, diffPct: pctDiff(at.nmMotor, ficha),
      cause: "powerShape() é uma parábola em torno do pico de potência; não é ajustada para pôr o torque máximo no rpm da ficha.", code: "physics.ts powerShape()", test: "Curva de fábrica: argmax(T) ≈ rpmTorque e T(rpmTorque) ≈ ficha ±5%.",
      fix: "Ajustar powerShape para dois pontos de ficha (cv@rpmPeak e N·m@rpmTorque) e conferir com dinamômetro real.", files: ["src/game/physics.ts"], keep: ["stock vs stock empata", "pico de potência no rpmPeak"] });
  }

  // 3. Eficiência e perdas
  const c = curve(b, s);
  const bad = c.find((p) => p.cvRoda > p.cvMotor + 1e-9);
  add({ id: "TR-01", pass: ETA > 0 && ETA <= 1 && !bad, sev: "alta", func: "step() ETA", title: "Eficiência da transmissão dentro de 0–100% e CV roda ≤ CV motor",
    found: `ETA = ${ETA} (perda ${n(100 * (1 - ETA), 1)}%); ${bad ? `roda > motor a ${bad.rpm} rpm` : "roda ≤ motor em toda a curva"}`, expected: "0 < η ≤ 1; P_roda ≤ P_motor", formula: "P_roda = P_motor × η; perda% = 100(1−η)", diffAbs: null, diffPct: null,
    cause: "—", code: "physics.ts const ETA", test: "Varrer curve(): cvRoda ≤ cvMotor.", fix: "Nenhuma. Pendência: η é um número único (registry drivetrain.eta_total, faixa documentada); separar primária, câmbio e corrente exige medição por estágio.", files: ["src/game/physics.ts", "src/game/physics-registry/constants.ts"], keep: ["ETA = drivetrain.eta_total"] });

  // 4. Coroa/pinhão alteram a relação
  const g0 = gearSpeeds(b, s), g1 = gearSpeeds(b, { ...s, rear: s.rear + 4 }), dt0 = drivetrain(b, s);
  // recálculo independente: v = ω_corte · r_din / (primária × marcha × coroa/pinhão)
  const wLim = (e.rpmLimit * 2 * Math.PI) / 60;
  const indep = dt0.gears.map((ig, i) => (ig != null && dt0.primary != null ? ((wLim * dt0.rDynM) / (dt0.primary * ig * (s.rear / s.front))) * 3.6 : g0[i]!));
  const allSlower = g0.every((v, i) => (g1[i] ?? Infinity) < v), match = g0.every((v, i) => Math.abs(v - indep[i]!) < 1e-6);
  add({ id: "TR-02", pass: allSlower && match && dt0.origem === "MANUAL", sev: "alta", func: "drivetrain() / gearSpeeds()", title: "Coroa e pinhão mudam a velocidade de TODAS as marchas pela relação total",
    found: `1ª com ${s.front}×${s.rear}: ${n((g0[0] ?? 0), 1)} km/h; com coroa +4: ${n((g1[0] ?? 0), 1)} km/h; relações ${dt0.origem === "MANUAL" ? "do manual" : "PENDENTES"}`, expected: "coroa maior → velocidade menor em todas as marchas, força maior", formula: "v_k = (corte·2π/60)·r_din / (i_prim · i_k · coroa/pinhão) · 3,6", diffAbs: (g1[0] ?? 0) - (g0[0] ?? 0), diffPct: pctDiff((g1[0] ?? 0), (g0[0] ?? 0)),
    cause: "—", code: "physics.ts drivetrainCalc()", test: "gearSpeeds com rear+4 < original em todas as marchas; recálculo independente igual.", fix: "Nenhuma.", files: ["src/game/physics.ts"], keep: [] });

  // 5. "Duty cycle" > 100%
  const fc = [6000, 7000, 8000, e.rpmLimit].map((r) => fuelChain(b, s, r));
  const over = fc.filter((x) => x.dutyPct > 100);
  add({ id: "AL-01", pass: over.length === 0, sev: over.length ? "alta" : "info", func: "fuelChain()", title: "Duty cycle do bico acima de 100%",
    found: over.length ? over.map((x) => `${x.rpm} rpm: ${n(x.dutyPct, 1)}%`).join(" · ") : `máx ${n(Math.max(...fc.map((x) => x.dutyPct)), 1)}%`, expected: "duty físico ≤ 100%; acima de ~85% o bico já está no limite", formula: "dutyPct = need / supply × 100 (razão demanda/oferta, não tempo de abertura)", diffAbs: over.length ? Math.max(...over.map((x) => x.dutyPct)) - 100 : 0, diffPct: null,
    cause: "O número é a razão entre combustível pedido e entregue. Um bico real não passa de 100%: ele trava aberto e a mistura empobrece.", code: "rootcause.ts fuelChain(): dutyPct", test: "dutyPct ≤ 100 sempre; quando need > supply, marcar 'bico saturado' e mostrar a falta em %.",
    fix: "Renomear para 'demanda/capacidade' ou limitar duty a 100% e expor a falta separada.", files: ["src/game/rootcause.ts", "src/game/preload-report.ts"], keep: ["lógica de causa raiz"] });

  // 6. AFR/lambda vs diagnóstico de mistura pobre
  const stoich = eth ? 9.0 : 14.7;
  const rows = [6000, 7000, 8000, e.rpmLimit].map((r) => ({ r, afr: afrAt(b, s, r, e.rpmPeak), lean: mixtureAt(s, r, e.rpmPeak).lean }));
  const contra = rows.filter((x) => x.lean > 0 && x.afr / stoich < 1);
  add({ id: "AL-02", pass: contra.length === 0, sev: "alta", func: "afrAt() / stress()", title: "Mistura marcada como POBRE com lambda ainda rica",
    found: contra.length ? contra.map((x) => `${x.r} rpm: AFR ${n(x.afr)} λ=${n(x.afr / stoich, 3)}`).join(" · ") : "sem contradição", expected: `pobre em relação ao estequiométrico com λ > 1 (AFR > ${stoich} no ${eth ? "etanol" : "gasolina"}); alvo de potência λ≈0,88`, formula: "λ = AFR / AFR_esteq; AFR = esteq × 0,88 × need / supply", diffAbs: null, diffPct: null,
    cause: "lean = need − supply mede o afastamento do alvo λ 0,88, não do estequiométrico. Mesmo rica (λ 0,9) o jogo soma risco de 'pistão derretido por mistura pobre'.", code: "physics.ts mixtureAt() + stress() (lean)", test: "Distinguir afastamento do alvo de potência de mistura pobre estequiométrica; validar risco com dados térmicos.",
    fix: "Usar λ para o diagnóstico: perda de potência entre λ 0,88 e 1,0; risco térmico depende de carga, tempo, combustível e temperatura; exigir calibração, não escolher um corte universal.", files: ["src/game/physics.ts", "src/game/rootcause.ts"], keep: ["perda de potência quando falta combustível"] });

  // 7. Embreagem
  const cap = clutchCap(s), maxT = Math.max(...c.map((p) => p.nmMotor));
  add({ id: "EM-01", pass: true, sev: "info", func: "step() embreagem", title: "Capacidade da embreagem em N·m (não em potência)",
    found: `torque máx ${n(maxT)} N·m · capacidade ${cap} N·m → ${maxT > cap ? "patina" : "acopla"}`, expected: "cap = clutchNm × ω comparada com P equivale a comparar T com clutchNm", formula: "P_cap = T_cap × ω  ⇔  T_motor > T_cap", diffAbs: maxT - cap, diffPct: null,
    cause: "—", code: "physics.ts step(): cap = clutchNm(s) * omega", test: "Torque motor < cap → slip 0.", fix: "Nenhuma. Pendência: a patinagem não registra a diferença de rpm motor/câmbio.", files: ["src/game/physics.ts"], keep: [] });

  // 8. Pneu: patinagem sem slip ratio
  const tire = tireOf(s);
  add({ id: "PN-01", pass: false, sev: "média", func: "step() tração", title: "Pneu patina sem cálculo de slip ratio",
    found: `tração = 0,62×m×g×1,05×grip(${n(tire.grip, 3)}); patinando entrega fixo ×0,85`, expected: "força = μ(slip)×N, com slip = (v_roda − v)/v", formula: "κ = (ω_roda×r − v)/v; μ(κ) curva de pneu", diffAbs: null, diffPct: null,
    cause: "O modelo é liga/desliga: acima do limite, cai para 85% sem velocidade da roda.", code: "physics.ts step(): st.spin, SPIN_GRIP", test: "Instrumentar ω_roda e verificar κ > 0 durante st.spin.",
    fix: "Adicionar velocidade angular da roda e curva μ(κ) simples (pico ~10% de slip).", files: ["src/game/physics.ts"], keep: ["determinismo", "stock vs stock empata"] });

  // 9. Massa
  const dry = st.kg, total = dry + RIDER_KG + b.tank * FUEL_DENSITY[s.fuel];
  add({ id: "MA-01", pass: Math.abs(stats(b, s, b.tank).kg - (dry + b.tank * FUEL_DENSITY[s.fuel])) < 0.11, sev: "média", func: "stats()", title: "Massa decomposta (seco + peças + combustível + piloto)",
    found: `seco+peças ${n(dry, 1)} · tanque cheio ${n(b.tank * FUEL_DENSITY[s.fuel], 2)} kg · piloto ${RIDER_KG} = ${n(total, 1)} kg`, expected: "soma das partes = massa usada em step()", formula: "m = seco + Σpeças + L×ρ + piloto", diffAbs: null, diffPct: null,
    cause: "—", code: "physics.ts dryKg(), stats()", test: "stats(b,s,L).kg = stats(b,s).kg + L×ρ.", fix: "Nenhuma.", files: [], keep: [] });

  // 10. Risco válido
  const sr = stress(b, s);
  add({ id: "ST-01", pass: Number.isFinite(sr.risk) && sr.risk >= 0 && sr.risk <= 0.85, sev: "alta", func: "stress()", title: "Índice de risco matematicamente válido",
    found: `risco ${n(sr.risk * 100, 1)}% · soma ${n(sr.value, 1)}`, expected: "0 ≤ risco ≤ 85%, finito", formula: "risco = min(0,85, max(0, soma−10)×0,012×desgaste)", diffAbs: null, diffPct: null,
    cause: "—", code: "physics.ts stress()", test: "Bateria de cenários: risco sempre finito em [0, 0,85].", fix: "Nenhuma.", files: [], keep: [] });

  // 11. Escape normalizado
  const xs = exhaustShape(b, s, e.rpmPeak, e.rpmPeak);
  add({ id: "ES-01", pass: Math.abs(xs - 1) < 1e-9, sev: "média", func: "exhaust.ts", title: "Forma do escape vale 1 no pico (sem contar duas vezes)",
    found: `exhaustShape(pico) = ${n(xs, 4)}`, expected: "1,0000: o ganho do escape já entra em engine().hp", formula: "shape = exhaustMul(rpm)/exhaustMul(pico)", diffAbs: xs - 1, diffPct: null,
    cause: "—", code: "physics.ts exhaustShape()", test: "exhaustShape(pico) = 1.", fix: "Nenhuma.", files: [], keep: [] });

  // 12. Corrida: consumo, patinagem, determinismo
  const r1 = runTest(b, s, 402.34, { id: "audit", group: "audit", label: "audit", track: "1/4" }, false);
  const r2 = runTest(b, s, 402.34, { id: "audit", group: "audit", label: "audit", track: "1/4" }, false);
  const tSec = r1.result.finishS ?? 0;
  const maxL = fuelFlow(s.fuel, pt.motor.cvMax.v * 735.5) * e.fuelMul * tSec;
  add({ id: "CO-01", pass: tSec > 0 && r1.result.fuelUsedL <= maxL * 1.05 && r1.result.fuelUsedL > 0, sev: "média", func: "step() consumo", title: "Consumo compatível com potência × tempo",
    found: `gasto ${n(r1.result.fuelUsedL, 4)} L em ${n(tSec, 2)} s`, expected: `≤ ${n(maxL, 4)} L (potência máxima o tempo todo)`, formula: "L/s = P(kW) × BSFC / ρ / 3600", diffAbs: r1.result.fuelUsedL - maxL, diffPct: null,
    cause: "—", code: "physics.ts fuelFlow()", test: "fuelUsed ≤ teto teórico.", fix: "Nenhuma.", files: [], keep: [] });
  add({ id: "DT-01", pass: JSON.stringify(r1.result) === JSON.stringify(r2.result), sev: "alta", func: "step()", title: "Resultado reproduzível com as mesmas condições",
    found: `${n(r1.result.finishS ?? NaN, 3)} s / ${n(r2.result.finishS ?? NaN, 3)} s`, expected: "idêntico", formula: "sim de passo fixo DT = 1/240 s", diffAbs: null, diffPct: null,
    cause: "—", code: "physics.ts step()", test: "Duas rodadas idênticas.", fix: "Nenhuma.", files: [], keep: [] });
  return F;
}

/** Parts intelligence: each catalog part's effects classified as physical mechanism vs bare multiplier. */
const PHYS: Record<string, string> = { flow: "vazão (fluxo de combustível)", need: "demanda de combustível por deslocamento", clutchNm: "capacidade de torque N·m", grip: "coeficiente de aderência", crr: "coeficiente de rolamento", kg: "massa", rpm: "limite de giro", oilLife: "vida do óleo (km)", cavas: "folga pistão-válvula" };
const ARB: Record<string, string> = { hp: "cv somados sem geometria", hpMul: "multiplicador de potência sem geometria", stress: "carga de risco tabelada", relief: "alívio de risco tabelado" };
export function partsIntel() {
  return PARTS_CATALOG.map((p) => {
    const rec = p as unknown as Record<string, unknown>;
    const fisico = Object.keys(PHYS).filter((k) => rec[k] != null).map((k) => `${PHYS[k]}: ${String(rec[k])}`);
    const arbit = Object.keys(ARB).filter((k) => rec[k] != null && rec[k] !== 1 && rec[k] !== 0).map((k) => `${ARB[k]}: ${String(rec[k])}`);
    const cc = /(\d{3})\s*cc/.exec(p.name)?.[1], bore = /Ø\s*([\d,]+)\s*mm/.exec(`${p.name} ${p.spec}`)?.[1];
    const geo = cc || bore ? `${bore ? `Ø ${bore} mm` : ""}${cc ? ` ${cc} cc` : ""}`.trim() : null;
    return { id: p.id, slot: p.kind, nome: `${p.brand} ${p.name}`, geo, fisico, arbitrario: arbit, pendente: [p.kind === "pistao" || p.kind === "biela" ? "material, massa e limite térmico não cadastrados" : "", p.kind === "escape" ? "diâmetro/comprimento vêm de exhaust.ts" : ""].filter(Boolean), ok: arbit.length === 0 };
  });
}

export const auditPart = (id: string) => partById(id);

/** Lovable-ready improvement prompt for a finding. */
export function promptFor(f: Finding, bikeName: string) {
  return [
    `StreetRace · correção de física · ${f.id} — ${f.title}`,
    "",
    `1. Problema: ${f.cause}`,
    `2. Onde: ${f.code} (função ${f.func}).`,
    `3. Fórmula/valor atual: ${f.found}`,
    `4. Esperado / abordagem: ${f.expected}. Fórmula de referência: ${f.formula}. Correção sugerida: ${f.fix}`,
    `5. Arquivos para analisar: ${f.files.join(", ") || "—"}.`,
    `6. Preservar: ${["simulação determinística (DT fixo)", "stock vs stock empata", ...f.keep].join("; ")}.`,
    `7. Como testar: ${f.test} Rodar bunx vitest run e a bateria do /WikiStreetrace.`,
    `8. Resultado esperado: o achado ${f.id} passa a APROVADO na auditoria da ${bikeName} sem quebrar os outros testes.`,
    "Antes de mudar, mostre fórmula antiga, fórmula proposta, efeito esperado nos tempos e testes antes/depois. Não aplique sem minha aprovação.",
  ].join("\n");
}
