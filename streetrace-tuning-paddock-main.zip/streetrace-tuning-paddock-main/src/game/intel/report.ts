import { powertrain } from './powertrain';
import type { BikeModel, Setup } from '../physics';
export function transmissionTxt(b: BikeModel, s: Setup) {
 const p=powertrain(b,s), f=(n:number)=>n.toFixed(3);
 return ['','POTÊNCIA E TRANSMISSÃO — AUDITORIA SOMENTE LEITURA',
 `Base cadastrada: ${f(p.motor.cvBase.v)} CV [ESTIMADO; sem medição anexada]`,
 `Motor nominal: ${f(p.motor.cvCalculado.v)} CV [CALCULADO]`,
 `Motor máximo na varredura: ${f(p.motor.cvMax.v)} CV @ ${p.motor.cvMax.rpm} RPM [CALCULADO]`,
 `Torque máximo da curva: ${f(p.motor.nmMax.v)} N·m @ ${p.motor.nmMax.rpm} RPM [CALCULADO]`,
 `T = CV × 0.73549875 × 60000 / (2π × RPM)`,
 `Roda no RPM de potência máxima: ${f(p.roda.cvRoda.v)} CV [CALCULADO, não medido]`,
 `P_roda = min(P_motor, capacidade_embreagem × ω) × η(${p.roda.eta.v})`,
 `Perda total: ${f(p.roda.perdaCv.v)} CV / ${f(p.roda.perdaPct.v)}%; embreagem limitada a ${p.embreagemNm} N·m`,
 'η é um parâmetro agregado do jogo, não medição nem eficiência universal. Não somar perdas novamente.',
 'CV medido na roda: NÃO É POSSÍVEL CALCULAR COM OS DADOS ATUAIS. Falta dinamômetro real.',
 ...p.gears.map(g=>`${g.marcha}ª: relação total ${g.relacaoTotal?.toFixed(3)??'PENDENTE'}; RPM roda no corte ${g.rpmRodaNoCorte?.toFixed(1)??'PENDENTE'}; torque roda ${g.nmRoda?.toFixed(2)??'PENDENTE'} N·m; força ${g.forcaN?.toFixed(2)??'PENDENTE'} N [ESTIMADO: raio estático]`),
 'Primária/marcha separadas, raio dinâmico, slip de roda e RPM do câmbio: PENDENTES.',
 'CURVAS (plena carga): RPM | CV motor | CV roda | N·m motor | N·m embreagem',
 ...p.curve.map(c=>`${c.rpm} | ${f(c.cvMotor)} | ${f(c.cvRoda)} | ${f(c.nmMotor)} | ${f(c.nmEmbreagem)}`),
 'SIMULAÇÃO DE CENÁRIO (embreagem acoplada; não medição):',
 ...p.roda.cenarios.map(c=>`η ${c.eta}: ${f(c.cv)} CV roda; perda ${f(c.perdaCv)} CV`),
 'PERGUNTAS E RESPOSTAS MATEMÁTICAS',
 `Quantos CV? Motor calculado ${f(p.motor.cvMax.v)}; roda calculada ${f(p.roda.cvRoda.v)}.`,
 `Onde está o máximo de torque? ${p.motor.nmMax.rpm} RPM; potência e torque máximos não são simultâneos por definição.`,
 'Quanto patinou? Consulte o diário; diferença de RPM e slip ratio não instrumentados.',
 'Temperatura real, pressão e vazão absoluta? NÃO É POSSÍVEL CALCULAR COM OS DADOS ATUAIS.',
 ].join('\n');
}
