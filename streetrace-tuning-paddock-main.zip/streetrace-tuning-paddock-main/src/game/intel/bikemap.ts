// Mapeamento da Moto — somente leitura. Cada módulo descreve uma parte real do jogo,
// as fórmulas que o código usa e os números calculados pelas próprias funções de physics.ts.
// Nada aqui muda a corrida; o que o jogo não calcula fica marcado como NAO_CALCULADO_NA_CORRIDA.
import { ETA, FUEL_DENSITY, RIDER_KG, SPIN_GRIP, STOCK_PSI, drivetrain, engine, gearSpeeds, stats, tireOf, type BikeModel, type Setup } from "../physics";
import { tireRadius } from "./powertrain";

export type Origem = "CALCULADO" | "JOGO" | "ESTIMADO" | "NAO_CALCULADO_NA_CORRIDA";
export type Calc = { nome: string; formula: string; conta: string; valor: string; origem: Origem };
export type Modulo = { id: string; eixo: "A" | "B" | "C" | "A↔B" | "Pista"; titulo: string; texto: string; liga: string; fonte: string; calculos: Calc[] };

const G = 9.81, RHO = 1.2, CDA = 0.27, PITCH = 0.0127;
const f = (n: number, d = 2) => n.toLocaleString("pt-BR", { maximumFractionDigits: d, minimumFractionDigits: d });

export function bikeMap(b: BikeModel, s: Setup, fuelL = b.tank): Modulo[] {
  const e = engine(b, s), st = stats(b, s, fuelL), tire = tireOf(s), gs = gearSpeeds(b, s);
  const m = st.kg + (s.riderKg ?? RIDER_KG);
  const w = (e.rpmLimit * 2 * Math.PI) / 60;
  const iF = s.rear / s.front;
  const rp = PITCH / (2 * Math.sin(Math.PI / s.front)), rc = PITCH / (2 * Math.sin(Math.PI / s.rear));
  const rB = drivetrain(b, s).rDynM; // raio dinâmico do pneu montado (o mesmo da corrida)
  const v1 = (gs[0] ?? 0) / 3.6, vTop = (gs[gs.length - 1] ?? 0) / 3.6;
  const wWheel = vTop / rB, nWheel = (wWheel * 60) / (2 * Math.PI), nPinhao = nWheel * iF;
  const vChain = (s.front * PITCH * nPinhao) / 60;
  const Pw = e.hp * 735.5, Pwheel = Pw * ETA;
  const trac = 0.62 * m * G * 1.05 * tire.grip;
  const F1 = Pwheel / Math.max(v1, 1);
  const roll = tire.crr * m * G, drag100 = 0.5 * RHO * CDA * (100 / 3.6) ** 2;
  const fuelKg = fuelL * FUEL_DENSITY[s.fuel];
  return [
    { id: "motor", eixo: "C", titulo: "Motor (eixo C · virabrequim)", fonte: "physics.engine(), physics.stats()",
      texto: "Gera a potência. Pistão empurra a biela, que gira o virabrequim. O jogo calcula potência máxima, rpm de pico e corte a partir das peças instaladas.",
      liga: "Virabrequim → engrenagem primária → embreagem.",
      calculos: [
        { nome: "Potência", formula: "P = cv × 735,5", conta: `${f(e.hp, 1)} × 735,5`, valor: `${f(Pw, 0)} W`, origem: "CALCULADO" },
        { nome: "Velocidade angular no corte", formula: "ω = 2π·n/60", conta: `2π × ${e.rpmLimit} / 60`, valor: `${f(w, 1)} rad/s`, origem: "CALCULADO" },
        { nome: "Torque no corte", formula: "T = P/ω", conta: `${f(Pw, 0)} / ${f(w, 1)}`, valor: `${f(Pw / w, 2)} N·m`, origem: "CALCULADO" },
        { nome: "Pico / corte", formula: "engine()", conta: "peças + comando + taxa + amaciamento", valor: `${e.rpmPeak} / ${e.rpmLimit} rpm`, origem: "JOGO" },
      ] },
    { id: "embreagem", eixo: "C", titulo: "Embreagem", fonte: "physics.step() clutchNm",
      texto: "Acopla motor e câmbio. Se o torque passar da capacidade dos discos, ela patina e o excesso não chega à roda.",
      liga: "Campana (primária) → discos → eixo primário do câmbio.",
      calculos: [{ nome: "Potência que passa", formula: "P_máx = T_embreagem × ω ; patina = 1 − P_máx/P", conta: "T_embreagem da peça × ω do instante", valor: "por passo da corrida", origem: "CALCULADO" }] },
    { id: "cambio", eixo: "C", titulo: "Câmbio (marchas)", fonte: "physics.gearSpeeds()",
      texto: "O jogo não guarda as relações internas de cada marcha; usa a velocidade de cada marcha no corte, corrigida pela relação final.",
      liga: "Eixo primário → par de engrenagens da marcha → eixo secundário (pinhão).",
      calculos: [
        { nome: "Velocidade por marcha", formula: "v = (corte·2π/60)·r_din / (primária × marcha × coroa/pinhão)", conta: `relação ${s.front}×${s.rear}`, valor: gs.map((g) => f(g, 0)).join(" / ") + " km/h", origem: "CALCULADO" },
        { nome: "Relações internas reais", formula: "i = dentes conduzida/motora", conta: "sem dado de fábrica", valor: "DADO NÃO IDENTIFICADO", origem: "NAO_CALCULADO_NA_CORRIDA" },
      ] },
    { id: "corrente", eixo: "A↔B", titulo: "Pinhão, corrente 428 e coroa (C → B)", fonte: "Setup.front/rear, gearSpeeds()",
      texto: "Liga o motor à roda traseira. O pinhão gira junto com o eixo secundário; a corrente puxa a coroa, que gira com a roda.",
      liga: "Eixo secundário → pinhão → corrente 428 → coroa → coxins → cubo traseiro.",
      calculos: [
        { nome: "Relação final", formula: "i = Z_coroa / Z_pinhão", conta: `${s.rear} / ${s.front}`, valor: f(iF, 3), origem: "CALCULADO" },
        { nome: "Raio primitivo do pinhão", formula: "r = p / (2·sen(π/Z))", conta: `12,7 mm / (2·sen(π/${s.front}))`, valor: `${f(rp * 1000, 1)} mm`, origem: "CALCULADO" },
        { nome: "Raio primitivo da coroa", formula: "r = p / (2·sen(π/Z))", conta: `12,7 mm / (2·sen(π/${s.rear}))`, valor: `${f(rc * 1000, 1)} mm`, origem: "CALCULADO" },
        { nome: "Rotação do pinhão na final", formula: "n_pinhão = n_roda × i", conta: `${f(nWheel, 0)} × ${f(iF, 3)}`, valor: `${f(nPinhao, 0)} rpm`, origem: "CALCULADO" },
        { nome: "Velocidade da corrente", formula: "v = Z·p·n/60", conta: `${s.front} × 0,0127 × ${f(nPinhao, 0)} / 60`, valor: `${f(vChain, 1)} m/s`, origem: "CALCULADO" },
        { nome: "Rendimento da transmissão", formula: "P_roda = P × η", conta: `${f(Pw, 0)} × ${ETA}`, valor: `${f(Pwheel, 0)} W`, origem: "JOGO" },
      ] },
    { id: "rodaB", eixo: "B", titulo: "Roda traseira (eixo B)", fonte: "intel/powertrain.tireRadius(), physics.step()",
      texto: "Recebe o torque da coroa pelos coxins, cubo e aro, e empurra o asfalto pelo pneu. Na corrida a força vem da potência dividida pela velocidade.",
      liga: "Coroa → coxins → cubo → raios/aro → pneu → asfalto. Eixo preso na balança.",
      calculos: [
        { nome: "Raio do pneu traseiro", formula: "r = aro/2 + largura × perfil", conta: b.tires.split("·").pop()!.trim(), valor: `${f(rB, 4)} m`, origem: "ESTIMADO" },
        { nome: "Rotação da roda na final", formula: "n = v/(2πr)×60", conta: `${f(vTop, 1)} m/s ÷ ${f(rB, 3)} m`, valor: `${f(nWheel, 0)} rpm`, origem: "CALCULADO" },
        { nome: "Força na roda (1ª, no corte)", formula: "F = P·η / max(v, 1)", conta: `${f(Pwheel, 0)} / ${f(Math.max(v1, 1), 2)}`, valor: `${f(F1, 0)} N`, origem: "CALCULADO" },
        { nome: "Massa girante", formula: "a = F/(m × 1,06)", conta: "6% somado à massa", valor: "fator 1,06", origem: "JOGO" },
      ] },
    { id: "pneu", eixo: "B", titulo: "Pneu (borracha)", fonte: "physics.tireOf()",
      texto: "A calibragem e o desgaste mudam a aderência e o rolamento. Menos pressão: mais aderência e mais rolamento.",
      liga: "Aro → talão → carcaça → banda de rodagem → asfalto.",
      calculos: [
        { nome: "Aderência", formula: "grip = composto × (1 + (28 − psi)×0,008) × (1 − 0,18×desgaste)", conta: `psi ${s.psi}, desgaste ${f((s.tireWear ?? 0) * 100, 0)}%`, valor: f(tire.grip, 4), origem: "CALCULADO" },
        { nome: "Coef. de rolamento", formula: "crr(v) = 0,015 × composto × δ/δrec × [1 + 0,6·(v/33,3)²·(δ/δrec)^1,5] (parado)", conta: `${s.psi} psi · rec ${STOCK_PSI}`, valor: f(tire.crr, 5), origem: "CALCULADO" },
      ] },
    { id: "rodaA", eixo: "A", titulo: "Roda dianteira (eixo A)", fonte: "physics.step() (só no peso total)",
      texto: "Roda livre, sem tração. Na corrida ela não tem cálculo próprio: entra só no peso e no rolamento total.",
      liga: "Chassi → mesa → garfo/bengalas → eixo dianteiro → cubo → aro → pneu.",
      calculos: [{ nome: "Carga e empinada", formula: "N_A = N_A,estático − m·a·h/L", conta: "altura do CG e entre-eixos sem dado", valor: "DADO NÃO IDENTIFICADO", origem: "NAO_CALCULADO_NA_CORRIDA" }] },
    { id: "chassi", eixo: "A↔B", titulo: "Chassi, balança e massa", fonte: "physics.stats()",
      texto: "Une eixo A, motor e eixo B. A massa total (moto + combustível + piloto) entra na aceleração e na tração.",
      liga: "Espiga → quadro → pivô da balança → eixo B.",
      calculos: [
        { nome: "Combustível", formula: "m = L × densidade", conta: `${f(fuelL, 1)} × ${FUEL_DENSITY[s.fuel]}`, valor: `${f(fuelKg, 1)} kg`, origem: "CALCULADO" },
        { nome: "Massa total", formula: "m = moto + combustível + piloto", conta: `${f(st.kg, 1)} + ${s.riderKg ?? RIDER_KG}`, valor: `${f(m, 1)} kg`, origem: "CALCULADO" },
        { nome: "Centro de massa", formula: "—", conta: "fixo no jogo", valor: "NÃO MUDA COM AS PEÇAS", origem: "NAO_CALCULADO_NA_CORRIDA" },
      ] },
    { id: "asfalto", eixo: "Pista", titulo: "Pista e asfalto (contato com o pneu)", fonte: "physics.step()",
      texto: "Onde a moto se apoia. O asfalto devolve no máximo a força de tração; passou disso o pneu patina e entrega só 85%. Ar e rolamento freiam a moto.",
      liga: "Pneu traseiro e dianteiro → mancha de contato → asfalto. Ar contra piloto e carenagem.",
      calculos: [
        { nome: "Limite de tração", formula: "F_tração = 0,62 × m × g × 1,05 × grip", conta: `0,62 × ${f(m, 1)} × 9,81 × 1,05 × ${f(tire.grip, 3)}`, valor: `${f(trac, 0)} N`, origem: "CALCULADO" },
        { nome: "Patina na 1ª?", formula: "F_roda > F_tração", conta: `${f(F1, 0)} > ${f(trac, 0)}`, valor: F1 > trac ? `SIM → ${f(trac * SPIN_GRIP, 0)} N (×${SPIN_GRIP})` : "NÃO", origem: "CALCULADO" },
        { nome: "Rolamento", formula: "F = crr × m × g", conta: `${f(tire.crr, 4)} × ${f(m, 1)} × 9,81`, valor: `${f(roll, 1)} N`, origem: "CALCULADO" },
        { nome: "Arrasto a 100 km/h", formula: "F = ½ρ·CdA·v²", conta: `0,5 × 1,2 × 0,27 × 27,78²`, valor: `${f(drag100, 1)} N`, origem: "CALCULADO" },
        { nome: "Aceleração", formula: "a = (F − arrasto − rolamento)/(m × 1,06)", conta: "a cada passo da corrida", valor: "por passo", origem: "CALCULADO" },
        { nome: "Temperatura / tipo de asfalto", formula: "—", conta: "não existe no jogo", valor: "NÃO IMPLEMENTADO", origem: "NAO_CALCULADO_NA_CORRIDA" },
      ] },
  ];
}
