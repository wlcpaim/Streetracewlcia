import { cloudStore } from "@/game/cloud/cloud-store";
// Wikipedia (pt) como base conceitual: REST page/summary + busca do MediaWiki, com cache, origem e data.
// Não é fonte de valores de preparação; serve para conceitos e para cruzar com as fórmulas do jogo.
export type WikiArticle = { query: string; title: string; url: string; extract: string; revisedAt: string | null; fetchedAt: string; cat: string; sistemas: string[]; conceitos: string[] };
export type WikiTopic = { q: string; cat: string; sistemas: string[] };

export const TOPICS: WikiTopic[] = [
  { q: "Motor de combustão interna", cat: "Motor", sistemas: ["engine()"] },
  { q: "Ciclo de Otto", cat: "Motor", sistemas: ["engine()"] },
  { q: "Motor de quatro tempos", cat: "Motor", sistemas: ["engine()"] },
  { q: "Cilindrada", cat: "Motor", sistemas: ["ccOf()", "exhaust.ts"] },
  { q: "Taxa de compressão", cat: "Motor", sistemas: ["engine()", "stress()"] },
  { q: "Torque", cat: "Potência", sistemas: ["stats()", "powertrain"] },
  { q: "Potência", cat: "Potência", sistemas: ["engine()", "powertrain"] },
  { q: "Mistura ar-combustível", cat: "Alimentação", sistemas: ["mixtureAt()", "afrAt()"] },
  { q: "Injeção eletrônica", cat: "Alimentação", sistemas: ["fuelChain()"] },
  { q: "Bico injetor", cat: "Alimentação", sistemas: ["fuelChain()"] },
  { q: "Corpo de borboleta", cat: "Alimentação", sistemas: ["mixtureAt()"] },
  { q: "Sonda lambda", cat: "Alimentação", sistemas: ["afrAt()"] },
  { q: "Cabeçote", cat: "Motor", sistemas: ["engine()"] },
  { q: "Comando de válvulas", cat: "Motor", sistemas: ["CAM_FX"] },
  { q: "Pistão", cat: "Motor", sistemas: ["stress()"] },
  { q: "Biela", cat: "Motor", sistemas: ["stress()"] },
  { q: "Virabrequim", cat: "Motor", sistemas: ["stress()"] },
  { q: "Escapamento", cat: "Escape", sistemas: ["exhaust.ts"] },
  { q: "Embreagem", cat: "Transmissão", sistemas: ["step() embreagem"] },
  { q: "Transmissão mecânica", cat: "Transmissão", sistemas: ["gearSpeeds()", "ETA"] },
  { q: "Corrente de transmissão", cat: "Transmissão", sistemas: ["ETA"] },
  { q: "Pneu", cat: "Chassi", sistemas: ["tireOf()"] },
  { q: "Resistência ao rolamento", cat: "Chassi", sistemas: ["tireOf() crr"] },
  { q: "Arrasto aerodinâmico", cat: "Chassi", sistemas: ["step() CDA"] },
  { q: "Inércia", cat: "Chassi", sistemas: ["step() massa"] },
  { q: "Suspensão", cat: "Chassi", sistemas: ["tração 0,62"] },
  { q: "Etanol", cat: "Combustível", sistemas: ["BSFC", "FUEL_DENSITY"] },
  { q: "Gasolina", cat: "Combustível", sistemas: ["BSFC", "FUEL_DENSITY"] },
  { q: "Lubrificação", cat: "Desgaste", sistemas: ["engine() óleo"] },
  { q: "Detonação", cat: "Motor", sistemas: ["stress()", "timingOpt"] },
];

const KEY = "streetrace-intel-wiki-v1";
const MAX_AGE_MS = 30 * 24 * 3600 * 1000;
const KEYWORDS = /(potência|torque|rotação|rpm|pressão|temperatura|volume|massa|força|atrito|relação|eficiência|combust|ar\b|vazão|compress|velocidade|energia|calor|aderência|desgaste)/i;

export function readCache(): WikiArticle[] {
  if (typeof cloudStore === "undefined") return [];
  try { const v = JSON.parse(cloudStore.getItem(KEY) ?? "[]"); return Array.isArray(v) ? v : []; } catch { return []; }
}
function writeCache(list: WikiArticle[]) {
  if (typeof cloudStore !== "undefined") cloudStore.setItem(KEY, JSON.stringify(list));
}
/** Sentences that carry a physical quantity or relation. */
export function concepts(extract: string) {
  return extract.split(/(?<=[.;])\s+/).filter((s) => KEYWORDS.test(s)).slice(0, 6);
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
async function getJson(url: string, tries = 3): Promise<unknown> {
  for (let i = 0; i < tries; i++) {
    const r = await fetch(url, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(12000) });
    if (r.status === 429 || r.status >= 500) { await sleep(800 * 2 ** i); continue; }
    if (r.status === 404) return null;
    if (!r.ok) throw new Error(`Wikipedia respondeu ${r.status}`);
    return r.json();
  }
  throw new Error("Wikipedia limitou as consultas (429). Tente de novo em alguns segundos.");
}

/** MediaWiki search: best matching article titles. */
export async function search(q: string, limit = 6): Promise<{ title: string; snippet: string }[]> {
  const u = `https://pt.wikipedia.org/w/api.php?action=query&list=search&format=json&origin=*&srlimit=${limit}&srsearch=${encodeURIComponent(q)}`;
  const j = (await getJson(u)) as { query?: { search?: { title: string; snippet: string }[] } } | null;
  return (j?.query?.search ?? []).map((x) => ({ title: x.title, snippet: x.snippet.replace(/<[^>]+>/g, "") }));
}

type Summary = { title: string; extract?: string; timestamp?: string; content_urls?: { desktop?: { page?: string } }; type?: string };
async function summary(title: string) {
  return (await getJson(`https://pt.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title.replace(/ /g, "_"))}`)) as Summary | null;
}

/** Fetch (or reuse fresh cache) one topic: summary by title, falling back to search's first hit. */
export async function fetchTopic(t: WikiTopic, force = false): Promise<WikiArticle> {
  const cache = readCache();
  const hit = cache.find((a) => a.query === t.q);
  if (hit && !force && Date.now() - Date.parse(hit.fetchedAt) < MAX_AGE_MS) return hit;
  let s = await summary(t.q);
  if (!s || s.type === "disambiguation" || !s.extract) {
    const first = (await search(t.q, 1))[0];
    s = first ? await summary(first.title) : null;
  }
  if (!s?.extract) throw new Error(`Nenhum artigo encontrado para "${t.q}"`);
  const a: WikiArticle = { query: t.q, title: s.title, url: s.content_urls?.desktop?.page ?? `https://pt.wikipedia.org/wiki/${encodeURIComponent(s.title)}`, extract: s.extract, revisedAt: s.timestamp ?? null, fetchedAt: new Date().toISOString(), cat: t.cat, sistemas: t.sistemas, conceitos: concepts(s.extract) };
  writeCache([a, ...cache.filter((x) => x.query !== t.q)]);
  return a;
}

/** Fetch every topic sequentially (polite pacing); errors are reported per topic, never invented. */
export async function fetchAll(onEach: (q: string, ok: boolean, err?: string) => void, force = false) {
  for (const t of TOPICS) {
    try { const fresh = !readCache().some((a) => a.query === t.q) || force; await fetchTopic(t, force); onEach(t.q, true); if (fresh) await sleep(350); }
    catch (e) { onEach(t.q, false, e instanceof Error ? e.message : String(e)); }
  }
}
