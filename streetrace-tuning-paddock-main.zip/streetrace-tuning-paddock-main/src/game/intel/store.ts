import { cloudStore } from "@/game/cloud/cloud-store";
// Conhecimento persistente da auditoria (neste aparelho): histórico, status dos bugs e propostas aguardando aprovação.
export type BugStatus = "Novo" | "Em análise" | "Correção proposta" | "Em teste" | "Aprovado" | "Reprovado";
export const BUG_STATUS: BugStatus[] = ["Novo", "Em análise", "Correção proposta", "Em teste", "Aprovado", "Reprovado"];
export type AuditRun = { at: string; bike: string; score: number; passed: number; failed: number; failedIds: string[] };
export type IntelState = { history: AuditRun[]; status: Record<string, BugStatus>; notes: Record<string, string> };

const KEY = "streetrace-intel-v1";
export function readIntel(): IntelState {
  const empty: IntelState = { history: [], status: {}, notes: {} };
  if (typeof cloudStore === "undefined") return empty;
  try {
    const raw = JSON.parse(cloudStore.getItem(KEY) ?? "{}");
    if (!raw || typeof raw !== "object") return empty;
    return { history: Array.isArray(raw.history) ? raw.history.filter((h: AuditRun) => h && typeof h.at === "string" && Number.isFinite(h.score)) : [], status: raw.status && typeof raw.status === "object" ? raw.status : {}, notes: raw.notes && typeof raw.notes === "object" ? raw.notes : {} };
  } catch { return empty; }
}
export function writeIntel(s: IntelState) {
  if (typeof cloudStore !== "undefined") cloudStore.setItem(KEY, JSON.stringify({ ...s, history: s.history.slice(0, 100) }));
}
export const score = (passed: number, total: number) => (total ? Math.round((100 * passed) / total) : 0);
