import { useMemo, useState } from "react";
import { STOCK_SETUP, TITAN_160, FACTOR_150, BIKE_MODELS } from "../physics";
import { bikeMap } from "./bikemap";

const BIKES = BIKE_MODELS;

export function BikeMapTab() {
  const [bi, setBi] = useState(0);
  const mods = useMemo(() => bikeMap(BIKES[bi]!, STOCK_SETUP), [bi]);
  const [open, setOpen] = useState(mods[0]!.id);
  const mod = mods.find((m) => m.id === open) ?? mods[0]!;
  return (
    <div className="space-y-3">
      <div className="rounded-xl bg-secondary p-3 text-xs">
        <div className="font-display text-sm">Mapeamento da moto · somente leitura</div>
        <pre className="mt-2 overflow-x-auto font-mono text-[11px] leading-4">{`[A dianteira] ── chassi ── [C motor/câmbio] ── corrente ── [B traseira]
      \\______________ pneu × ASFALTO ______________/`}</pre>
        <div className="mt-2 flex gap-1">
          {BIKES.map((b, i) => <button key={b.id} onClick={() => setBi(i)} className={`h-8 rounded-lg px-3 ${i === bi ? "bg-primary text-primary-foreground" : "bg-background"}`}>{b.name}</button>)}
        </div>
      </div>
      <nav className="flex flex-wrap gap-1">
        {mods.map((m) => <button key={m.id} onClick={() => setOpen(m.id)} className={`h-8 rounded-lg px-2 text-xs ${m.id === mod.id ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>{m.eixo} · {m.titulo.split(" (")[0]}</button>)}
      </nav>
      <section className="space-y-2 rounded-xl bg-secondary p-3">
        <h2 className="font-display text-lg">{mod.titulo}</h2>
        <p className="text-sm">{mod.texto}</p>
        <p className="text-xs text-muted-foreground"><b>Conexão:</b> {mod.liga}</p>
        <p className="text-[11px] text-muted-foreground">Fonte no jogo: {mod.fonte}</p>
        <div className="space-y-2">
          {mod.calculos.map((c) => (
            <div key={c.nome} className="rounded-lg bg-background p-2 text-xs">
              <div className="flex justify-between gap-2"><b>{c.nome}</b><span className="text-[10px] text-muted-foreground">{c.origem}</span></div>
              <div className="font-mono">{c.formula}</div>
              <div className="font-mono text-muted-foreground">{c.conta}</div>
              <div className="font-mono font-bold">= {c.valor}</div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
