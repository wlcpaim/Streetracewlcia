// Potência e transmissão: CV no motor vs CV na roda, torque em cada ponto da cadeia e força na roda por marcha.
// Lê as funções reais (engine, powerShape, mixFactor, exhaustShape, gearSpeeds, ETA) — não é um segundo motor físico.
import { ETA, drivetrain, engine, rearTireRadiusM, exhaustShape, mixFactor, powerShape, stats, type BikeModel, type Setup } from "../physics";
import { clutchCapNm, slotPart } from "../parts";

export type Origem = "MEDIDO" | "CALCULADO" | "ESTIMADO" | "PENDENTE";
export const CV_KW = 0.73549875;
/** 60000 / 2π: N·m × rpm / K = W·1000 → kW. (9550 é o arredondamento usual.) */
export const K_RPM = 60000 / (2 * Math.PI);
export const KGF_NM = 9.80665;

export const cvToKw = (cv: number) => cv * CV_KW;
export const kwToCv = (kw: number) => kw / CV_KW;
export const torqueFromPower = (kw: number, rpm: number) => (rpm > 0 ? (kw * K_RPM) / rpm : NaN);
export const powerFromTorque = (nm: number, rpm: number) => (nm * rpm) / K_RPM;
export const wheelPower = (engineCv: number, eta: number) => {
  if (!Number.isFinite(eta) || eta < 0 || eta > 1) throw new RangeError("Eficiência deve estar entre 0 e 1");
  return engineCv * eta;
};
export const lossPct = (eta: number) => { wheelPower(1, eta); return 100 * (1 - eta); };

/** Raio estático estimado do pneu traseiro ("100/80-18" ou diagonal "2.75-18"): a mesma medida que a corrida usa. */
export const tireRadius = (spec: string) => rearTireRadiusM(spec);

export const clutchCap = (s: Setup) => clutchCapNm(s);

export type CurvePoint = { rpm: number; cvMotor: number; kwMotor: number; nmMotor: number; nmEmbreagem: number; cvRoda: number; patina: boolean };

/** Curva do motor com a mesma forma do step(): hp × powerShape × mixFactor × exhaustShape; embreagem capa em clutchNm×ω; roda = × ETA. */
export function curve(b: BikeModel, s: Setup, step = 250): CurvePoint[] {
  if (!(step > 0) || !Number.isFinite(step)) throw new RangeError("Passo de RPM inválido");
  const e = engine(b, s), cap = clutchCap(s), out: CurvePoint[] = [];
  for (let rpm = 3000; rpm <= e.rpmLimit; rpm += step) {
    const shape = powerShape(rpm, e.rpmPeak, b, s) * mixFactor(s, rpm, e.rpmPeak) * exhaustShape(b, s, rpm, e.rpmPeak);
    const cv = e.hp * shape, kw = cvToKw(cv), nm = torqueFromPower(kw, rpm);
    const nmC = Math.min(nm, cap);
    out.push({ rpm, cvMotor: cv, kwMotor: kw, nmMotor: nm, nmEmbreagem: nmC, cvRoda: kwToCv(powerFromTorque(nmC, rpm)) * ETA, patina: nm > cap });
  }
  return out;
}

export type GearRow = { marcha: number; vMaxKmh: number; relacaoTotal: number | null; rpmRodaNoCorte: number | null; nmRoda: number | null; forcaN: number | null };

/** Tudo de potência e transmissão de um setup, cada número com sua origem. */
export function powertrain(b: BikeModel, s: Setup) {
  const e = engine(b, s), st = stats(b, s), c = curve(b, s, 50);
  const first = c[0];
  if (!first) throw new RangeError("Curva indisponível: corte abaixo de 3000 RPM");
  const pk = c.reduce((a, p) => (p.cvMotor > a.cvMotor ? p : a), first);
  const tk = c.reduce((a, p) => (p.nmMotor > a.nmMotor ? p : a), first);
  const d = drivetrain(b, s), r = d.rDynM;
  // mesma cadeia da corrida: i_total = primária × marcha × coroa/pinhão; v no corte = ω·r_din/i
  const gears: GearRow[] = d.totals.map((N, i) => {
    const nmRoda = tk.nmEmbreagem * N * ETA;
    return { marcha: i + 1, vMaxKmh: d.vCutKmh[i]!, relacaoTotal: N, rpmRodaNoCorte: e.rpmLimit / N, nmRoda, forcaN: nmRoda / r };
  });
  const cvRoda = pk.cvRoda;
  return {
    motor: {
      cvBase: { v: e.eth ? b.hpEth : b.hpGas, o: "ESTIMADO" as Origem, nota: "valor cadastrado da ficha; fonte e medição original não anexadas" },
      cvCalculado: { v: e.hp, o: "CALCULADO" as Origem, nota: "engine().hp no pico nominal" },
      cvMax: { v: pk.cvMotor, rpm: pk.rpm, o: "CALCULADO" as Origem, nota: "máximo da curva real do step()" },
      nmMax: { v: tk.nmMotor, rpm: tk.rpm, o: "CALCULADO" as Origem, nota: "T = P×60000/(2π×rpm) sobre a curva" },
      nmStats: { v: st.torque * KGF_NM, o: "CALCULADO" as Origem, nota: "stats(): torque_base × hp/hp_base (sem rpm associado)" },
    },
    roda: {
      eta: { v: ETA, o: "CALCULADO" as Origem, nota: "constante ETA do physics.ts: única perda modelada (primária+câmbio+corrente juntos)" },
      cvRoda: { v: cvRoda, o: "CALCULADO" as Origem, nota: "P_roda = min(P_motor, T_cap × ω) × ETA no RPM de potência máxima; estimativa física com η tabelado" },
      cvRodaMedido: { v: null, o: "PENDENTE" as Origem, nota: "nenhum dinamômetro de rolo real registrado" },
      perdaCv: { v: pk.cvMotor - cvRoda, o: "CALCULADO" as Origem },
      perdaPct: { v: pk.cvMotor > 0 ? 100 * (1 - cvRoda / pk.cvMotor) : 0, o: "CALCULADO" as Origem },
      cenarios: [0.95, 0.9, 0.85].map((eta) => ({ eta, cv: wheelPower(pk.cvMotor, eta), perdaCv: pk.cvMotor * (1 - eta), o: "ESTIMADO" as Origem, nota: "SIMULAÇÃO DE CENÁRIO" })),
    },
    raioPneu: { v: r, o: "ESTIMADO" as Origem, nota: "raio dinâmico = raio estático do pneu montado × fator de rolagem (registry); não instrumentado" },
    relacaoPrimariaECambio: d.origem === "MANUAL"
      ? { v: { primaria: d.primary, marchas: d.gears, final: d.final }, o: "CALCULADO" as Origem, nota: `primária ${d.primary?.toFixed(3)} × marchas ${d.gears.map((g) => g?.toFixed(3)).join("/")} × final ${d.final.toFixed(3)} (${d.fonte})` }
      : { v: null, o: "PENDENTE" as Origem, nota: d.fonte },
    embreagemNm: clutchCap(s),
    gears,
    curve: c.filter((_, i) => i % 5 === 0),
  };
}
