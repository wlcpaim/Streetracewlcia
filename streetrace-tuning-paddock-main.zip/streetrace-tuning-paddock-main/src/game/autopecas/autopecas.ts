// AUTO PEÇAS — dossiê técnico de cada peça à venda na loja (fonte: shop-catalog.ts), com a física e as contas
// do próprio jogo (engine/stats/stress/gearSpeeds/exhaustMul). Somente leitura: monta um Setup de teste,
// nunca altera o Setup do jogador nem a corrida. Envio ao funil → RealGear → NEXUS → aprovado ou volta (Fix).
import { cloudStore } from "@/game/cloud/cloud-store";
import { BSFC, ETA, STOCK_SETUP, bikeModel, ccOf, drivetrain, engine, exhaustMul, gearSpeeds, stats, stress, type BikeModel, type Setup } from "../physics";
import { SLOTS, partById, type Part } from "../parts";
import { FICHA, runFunnel, type Estado, type Execucao, type Projeto } from "../realgear/funnel";
import { appendHistory } from "../realgear/history";
import { appendLayerLogs } from "../realgear/logs";
import { captureFailures, processFailure, readFix, saveFix } from "../realgear/fix/pipeline";
import { tireRadius } from "../intel/powertrain";
import { LHV_BY_FUEL } from "../physics-registry/constants";
import { dealerListing, shopListing, type ShopEntry } from "../shop-catalog";

export type Origem = "CALCULADO" | "JOGO" | "FICHA" | "ESTIMADO" | "DADO NÃO IDENTIFICADO" | "NÃO IMPLEMENTADO";
export type Calc = { nome: string; formula: string; conta: string; resultado: string; origem: Origem };
export type Dossie = {
  id: string; nome: string; grupo: string; marca: string; bikeId: string; bike: string;
  descricao: string; funcionamento: string; conexoes: string[]; fisica: string[]; calculos: Calc[];
  enviavel: boolean; motivoNaoEnviavel?: string | undefined; fonte: string[];
};

const n = (x: number, d = 2) => (Number.isFinite(x) ? x.toLocaleString("pt-BR", { maximumFractionDigits: d, minimumFractionDigits: 0 }) : "—");
const W_PER_CV = 735.49875;
/** stats().torque vem em kgf·m (ficha brasileira). */
const KGFM_NM = 9.80665;

/** Setup de teste: moto de fábrica + somente esta peça (kit completo leva o bundle que o mecânico monta). */
export function setupFor(e: ShopEntry): Setup {
  const s: Setup = structuredClone(STOCK_SETUP);
  const p = e.part;
  if (e.fuel?.comb) s.blend = { [e.fuel.comb]: 1 };
  if (!p) return s;
  if (p.kind === "kit") { s.front = p.front ?? s.front; s.rear = p.rear ?? s.rear; }
  else if (p.kind === "pinhao") s.front = p.front ?? s.front;
  else if (p.kind === "coroa") s.rear = p.rear ?? s.rear;
  else if (p.kind === "comando" && p.cam) s.cam = p.cam;
  else if ((SLOTS as string[]).includes(p.kind)) (s.slots as Record<string, string>)[p.kind] = p.id;
  if (p.bundle) {
    s.slots.bico = p.bundle.bico; s.cam = p.bundle.cam; s.front = p.bundle.front ?? s.front; s.rear = p.bundle.rear ?? s.rear;
    if (p.bundle.modulo) s.slots.modulo = p.bundle.modulo;
    if (p.bundle.molas) s.slots.molas = p.bundle.molas;
    if (p.bundle.bomba) s.slots.bomba = p.bundle.bomba;
    if (p.bundle.pistao) s.slots.pistao = p.bundle.pistao;
    if (p.bundle.biela) s.slots.biela = p.bundle.biela;
    if (p.bundle.services) s.services = [...s.services, ...p.bundle.services];
  }
  return s;
}

const CONEXOES: Record<string, string[]> = {
  moto: ["Moto completa de fábrica: motor (eixo C) gera torque, embreagem e câmbio reduzem, pinhão → corrente 428 → coroa levam à roda traseira (eixo B).", "Eixo A (roda dianteira) é livre e direcional; o chassi liga os três eixos e define a distribuição de peso.", "Pneu traseiro no asfalto: tração limitada por μ·N com transferência de carga na aceleração."],
  cilindro: ["Cilindro (camisa) parafusado no bloco, eixo C; o pistão desliza dentro dele com os anéis vedando a câmara.", "Pistão → pino → biela → moente do virabrequim: converte força do gás em torque (T = F·r·sen θ efetivo).", "Cabeçote fecha a câmara: volume da câmara + cilindrada definem a taxa de compressão.", "Kit leva bico (vazão), comando (abertura das válvulas), relação (redução final) e módulo (corte/mistura) ajustados juntos."],
  escape: ["Flange no duto de escape do cabeçote → curva primária → corpo/silencioso → ponteira.", "A onda de pressão do pulso de escape volta como depressão no cruzamento das válvulas e ajuda a esvaziar o cilindro.", "Diâmetro e comprimento são confrontados com a cilindrada × rpm em exhaust.ts."],
  modulo: ["Módulo (ECU) lê rotação (sensor de fase/roda fônica), borboleta (TPS), temperatura e sonda λ.", "Comanda o tempo de abertura do bico (mistura) e o ponto da centelha na bobina/vela.", "Define o corte de giro: limita a rotação máxima e, com ela, a velocidade em cada marcha."],
  kit: ["Pinhão no eixo secundário do câmbio (saída do eixo C) → corrente 428 → coroa no cubo da roda traseira (eixo B).", "Coroa presa ao cubo por coxins de borracha que amortecem os trancos de torque.", "Redução secundária multiplica o torque e divide a rotação que chega à roda."],
  pinhao: ["Pinhão estriado no eixo secundário (eixo C), engrena a corrente 428.", "Menos dentes = redução maior = mais força na roda e menos velocidade final."],
  coroa: ["Coroa parafusada no cubo traseiro (eixo B), recebe a corrente 428.", "Mais dentes = redução maior = mais força na roda e menos velocidade final."],
  combustivel: ["Tanque → bomba → linha → bico injetor → duto de admissão → câmara.", "Combustível entra na mistura do tanque (Setup.blend) e muda potência, demanda de vazão e consumo."],
  nitro: ["Garrafa N₂O → solenoide → injeção na admissão (sistema ainda não instalado no jogo)."],
};

/** Dossiê completo da peça montada na moto escolhida. */
export function dossier(e: ShopEntry, bikeId = e.bikeId ?? "titan160"): Dossie {
  const b: BikeModel = bikeModel(bikeId);
  const s0 = STOCK_SETUP, s1 = setupFor(e);
  const e0 = engine(b, s0), e1 = engine(b, s1), st0 = stats(b, s0), st1 = stats(b, s1), sr0 = stress(b, s0), sr1 = stress(b, s1);
  const p = e.part, kind = e.moto ? "moto" : e.fuel ? (e.fuel.nitro ? "nitro" : "combustivel") : p!.kind;
  const C: Calc[] = [];
  const fonte = ["src/game/physics.ts · engine()/stats()/stress()", "src/game/shop-catalog.ts · shopListing()"];
  const fic = FICHA[b.id];

  // Comuns: potência, torque, P = T·ω, peso, relação peso/potência, carga mecânica.
  C.push({ nome: "Potência no virabrequim", formula: "P = hp_base × Π(multiplicadores de cada peça)", conta: `fábrica ${n(st0.hp, 1)} cv → com a peça ${n(st1.hp, 1)} cv`, resultado: `${st1.hp - st0.hp >= 0 ? "+" : ""}${n(((st1.hp / st0.hp) - 1) * 100, 1)} %`, origem: "JOGO" });
  const Tnm = st1.torque * KGFM_NM;
  C.push({ nome: "Torque máximo", formula: "T = T_ficha × (P / P_ficha); 1 kgf·m = 9,80665 N·m", conta: `${n(st0.torque)} → ${n(st1.torque)} kgf·m = ${n(Tnm)} N·m`, resultado: `${n(Tnm)} N·m`, origem: "JOGO" });
  const w = (e1.rpmPeak * 2 * Math.PI) / 60;
  C.push({ nome: "Potência pelo torque (P = T·ω)", formula: "P[W] = T[N·m] × ω[rad/s], ω = 2π·rpm/60", conta: `${n(Tnm)} × ${n(w, 1)} = ${n(Tnm * w, 0)} W`, resultado: `${n((Tnm * w) / W_PER_CV, 1)} cv usando o torque máximo no rpm de pico de potência (indicativo: o torque cai no pico)`, origem: "ESTIMADO" });
  C.push({ nome: "Rotação de pico e corte", formula: "rpmPeak = ficha + comando + serviços; corte = módulo", conta: `pico ${e0.rpmPeak} → ${e1.rpmPeak} rpm · corte ${e0.rpmLimit} → ${e1.rpmLimit} rpm`, resultado: `${e1.rpmLimit} rpm`, origem: "JOGO" });
  C.push({ nome: "Relação peso/potência", formula: "kg/cv = massa seca / P", conta: `${n(st1.kg, 1)} / ${n(st1.hp, 1)}`, resultado: `${n(st1.kg / st1.hp, 2)} kg/cv`, origem: "CALCULADO" });
  C.push({ nome: "Carga mecânica (risco de quebra)", formula: "Σ esforço de peças/serviços − alívios", conta: `${n(sr0.value, 1)} → ${n(sr1.value, 1)} · risco ${n(sr1.risk * 100, 1)} %`, resultado: `${n(sr1.value, 1)} pontos`, origem: "JOGO" });

  if (kind === "cilindro" || p?.bundle) {
    const cc = ccOf(b, s1), S = (fic?.strokeMm ?? NaN) / 1000;
    const D = Math.sqrt((4 * cc * 1e-6) / (Math.PI * S));
    C.push({ nome: "Cilindrada", formula: "V = π·D²·S / 4", conta: `${b.cc} cc → ${n(cc, 1)} cc`, resultado: `${n(cc, 1)} cm³`, origem: "JOGO" });
    C.push({ nome: "Diâmetro implícito", formula: "D = √(4V / (π·S))", conta: `√(4 × ${n(cc * 1e-6, 7)} / (π × ${n(S, 4)}))`, resultado: `${n(D * 1000, 1)} mm`, origem: fic ? "CALCULADO" : "DADO NÃO IDENTIFICADO" });
    const vm = (2 * S * e1.rpmLimit) / 60;
    C.push({ nome: "Velocidade média do pistão no corte", formula: "v_m = 2·S·N / 60", conta: `2 × ${n(S, 4)} × ${e1.rpmLimit} / 60`, resultado: `${n(vm, 2)} m/s`, origem: fic ? "CALCULADO" : "DADO NÃO IDENTIFICADO" });
    C.push({ nome: "Aceleração do pistão (PMS)", formula: "a = ω²·r·(1 + r/l)", conta: "comprimento da biela l não consta na ficha", resultado: "DADO NÃO IDENTIFICADO", origem: "DADO NÃO IDENTIFICADO" });
    C.push({ nome: "Multiplicador do kit", formula: "P × hpMul", conta: `hpMul = ${p?.hpMul ?? 1}; demanda extra de combustível ${n((p?.need ?? 0) * 100, 0)} %`, resultado: `×${p?.hpMul ?? 1}`, origem: "JOGO" });
  }
  if (kind === "escape") {
    const m0 = exhaustMul(b, s0, e0.rpmPeak), m1 = exhaustMul(b, s1, e1.rpmPeak);
    C.push({ nome: "Fator do escape no pico", formula: "exhaustAt(geometria, cc, rpm) — diâmetro/comprimento × cilindrada × rpm", conta: `original ${n(m0, 4)} → ${n(m1, 4)}`, resultado: `×${n(m1, 4)}`, origem: "JOGO" });
    C.push({ nome: "Comprimento sintonizado (onda)", formula: "L ≈ (θ_esc/360) × 60·c / (2·N)", conta: "ângulo de abertura da válvula de escape e temperatura do gás não constam", resultado: "DADO NÃO IDENTIFICADO", origem: "DADO NÃO IDENTIFICADO" });
    fonte.push("src/game/exhaust.ts · exhaustAt()");
  }
  if (kind === "modulo") {
    C.push({ nome: "Corte de giro", formula: "rpmLimit = ficha + Δrpm do módulo (programável: mapa)", conta: `${e0.rpmLimit} → ${e1.rpmLimit} rpm`, resultado: `${e1.rpmLimit} rpm`, origem: "JOGO" });
    const vT0 = gearSpeeds(b, s0).at(-1) ?? 0, vT1 = gearSpeeds(b, s1).at(-1) ?? 0;
    C.push({ nome: "Velocidade final no corte (última marcha)", formula: "v = v_ficha × (corte/corte_ficha) × (relação ficha / relação)", conta: `${n(vT0, 1)} → ${n(vT1, 1)} km/h`, resultado: `${n(vT1, 1)} km/h`, origem: "JOGO" });
    C.push({ nome: "Mapa programável", formula: "P × (1 + 0,01·t − 0,0025·(t − t_ót)² + 0,0025·t_ót²)", conta: p?.prog ? "ativo: ponto t e mistura por faixa entram no engine()" : "módulo fixo: só Δrpm e hpMul", resultado: p?.prog ? "programável" : "fixo", origem: "JOGO" });
  }
  if (kind === "kit" || kind === "pinhao" || kind === "coroa" || p?.bundle) {
    const i0 = s0.rear / s0.front, i1 = s1.rear / s1.front;
    const r = tireRadius(b.tires) ?? NaN;
    C.push({ nome: "Redução secundária", formula: "i = Z_coroa / Z_pinhão", conta: `${s1.rear} / ${s1.front}`, resultado: `${n(i1, 3)} (fábrica ${n(i0, 3)})`, origem: "CALCULADO" });
    const F0 = (Tnm * i1 * ETA) / r;
    C.push({ nome: "Força na roda (secundária, sem câmbio)", formula: "F = T·i·η / r_pneu", conta: `${n(Tnm)} × ${n(i1, 3)} × ${ETA} / ${n(r, 4)}`, resultado: `${n(F0, 0)} N por unidade de relação do câmbio`, origem: "CALCULADO" });
    C.push({ nome: "Raio do pneu traseiro", formula: "r = (aro·25,4/2 + largura·perfil/100) / 1000", conta: b.tires, resultado: `${n(r, 4)} m`, origem: "CALCULADO" });
    const g = gearSpeeds(b, s1), dt1 = drivetrain(b, s1);
    C.push({ nome: "Velocidade por marcha no corte (teórica)", formula: "v_k = (corte·2π/60) · r_din / (i_prim · i_k · Z_coroa/Z_pinhão) · 3,6", conta: g.map((x, k) => `${k + 1}ª ${n(x, 0)}`).join(" · "), resultado: `${n(g.at(-1) ?? 0, 0)} km/h na última`, origem: "CALCULADO" });
    C.push({ nome: "Relações internas do câmbio", formula: "i_total_k = i_prim × i_k × Z_coroa/Z_pinhão", conta: dt1.primary != null ? `${n(dt1.primary, 3)} × [${dt1.gears.map((x) => (x != null ? n(x, 3) : "?")).join(" / ")}] × ${n(i1, 3)}` : "relações internas não documentadas", resultado: dt1.totals.map((x, k) => `${k + 1}ª ${n(x, 2)}`).join(" · "), origem: dt1.origem === "MANUAL" ? "FICHA" : "DADO NÃO IDENTIFICADO" });
  }
  if (kind === "combustivel" && e.fuel?.comb) {
    const lhv = (LHV_BY_FUEL as Record<string, number>)[e.fuel.comb];
    C.push({ nome: "Poder calorífico inferior", formula: "PCI (registry central)", conta: lhv ? `${n(lhv / 1e6, 2)} MJ/kg` : "não consta no registry central", resultado: lhv ? `${n(lhv / 1e6, 2)} MJ/kg` : "DADO NÃO IDENTIFICADO", origem: lhv ? "FICHA" : "DADO NÃO IDENTIFICADO" });
    C.push({ nome: "Potência com tanque 100 %", formula: "P × blendFx(mistura).hpMul", conta: `${n(st0.hp, 1)} → ${n(st1.hp, 1)} cv`, resultado: `×${n(st1.hp / st0.hp, 3)}`, origem: "JOGO" });
    C.push({ nome: "Consumo específico relativo", formula: "ṁ = P × BSFC × fuelMul", conta: `BSFC do jogo ${n(BSFC[s1.fuel], 2)} · fuelMul ${n(e0.fuelMul, 3)} → ${n(e1.fuelMul, 3)}`, resultado: `×${n(e1.fuelMul / e0.fuelMul, 3)} de vazão`, origem: "JOGO" });
    fonte.push("src/game/fuelmix.ts · blendFx()", "src/game/physics-registry/constants.ts");
  }
  if (kind === "moto") {
    const g = gearSpeeds(b, s1), r = tireRadius(b.tires) ?? NaN, i = s1.rear / s1.front, m = st1.kg + 75;
    C.push({ nome: "Cilindrada", formula: "V (ficha)", conta: `${b.cc} cc`, resultado: `${b.cc} cm³`, origem: "FICHA" });
    C.push({ nome: "Curso do pistão", formula: "S (catálogo de motores)", conta: fic ? `${fic.strokeMm} mm` : "não consta", resultado: fic ? `${fic.strokeMm} mm` : "DADO NÃO IDENTIFICADO", origem: fic ? "FICHA" : "DADO NÃO IDENTIFICADO" });
    C.push({ nome: "Redução secundária de fábrica", formula: "i = Z_coroa / Z_pinhão", conta: `${s1.rear} / ${s1.front}`, resultado: n(i, 3), origem: "CALCULADO" });
    C.push({ nome: "Raio do pneu traseiro", formula: "r = (aro·25,4/2 + largura·perfil/100) / 1000", conta: b.tires, resultado: `${n(r, 4)} m`, origem: "CALCULADO" });
    C.push({ nome: "Força na roda (secundária)", formula: "F = T·i·η / r", conta: `${n(Tnm)} × ${n(i, 3)} × ${ETA} / ${n(r, 4)}`, resultado: `${n((Tnm * i * ETA) / r, 0)} N por unidade de relação do câmbio`, origem: "CALCULADO" });
    C.push({ nome: "Velocidade por marcha no corte (teórica)", formula: "v_k = (corte·2π/60) · r_din / (i_prim · i_k · Z_coroa/Z_pinhão) · 3,6", conta: g.map((x, k) => `${k + 1}ª ${n(x, 0)}`).join(" · "), resultado: `${n(g.at(-1) ?? 0, 0)} km/h`, origem: "CALCULADO" });
    C.push({ nome: "Massa com piloto", formula: "m = massa da moto + piloto 75 kg", conta: `${n(st1.kg, 1)} + 75`, resultado: `${n(m, 1)} kg`, origem: "CALCULADO" });
    C.push({ nome: "Peso (força normal total)", formula: "N = m·g", conta: `${n(m, 1)} × 9,81`, resultado: `${n(m * 9.81, 0)} N`, origem: "CALCULADO" });
    const wLim = (e1.rpmLimit * 2 * Math.PI) / 60;
    const ik = g.map((v) => wLim / (v / 3.6 / r) / i);
    C.push({ nome: "Relações internas do câmbio (primária × marcha)", formula: "i_k = i_primária × i_marcha_k = (ω_motor no corte) / (v_k/r) / i_secundária", conta: `corte ${e1.rpmLimit} rpm · r ${n(r, 4)} m · i_sec ${n(i, 3)} → ${ik.map((x, k) => `${k + 1}ª ${n(x, 3)}`).join(" · ")}`, resultado: `${n(ik[0] ?? NaN, 3)} (1ª) a ${n(ik.at(-1) ?? NaN, 3)} (${ik.length}ª); valores efetivos do jogo, produto primária × marcha`, origem: "CALCULADO" });
    fonte.push("src/game/data/engine_catalog.ts", "src/game/intel/powertrain.ts · tireRadius()");
  }
  if (kind === "nitro") C.push({ nome: "Decomposição do N₂O", formula: "2 N₂O → 2 N₂ + O₂ (≈ 36 % de O₂ em massa)", conta: "nitro ainda não atua na física da corrida", resultado: "NÃO IMPLEMENTADO", origem: "NÃO IMPLEMENTADO" });

  const fisica = [
    "Combustão: energia química (PCI) → pressão na câmara → força no pistão.",
    "Biela-manivela: força linear vira torque no eixo C; P = T·ω.",
    "Transmissão: primária × câmbio × secundária (pinhão/coroa, corrente 428) com rendimento η = " + ETA + ".",
    "Roda/pneu (eixo B): F = T_roda / r; tração limitada por μ·N com transferência de carga (ground.ts).",
  ];
  const enviavel = kind !== "nitro";
  return {
    id: e.id, nome: e.nome, grupo: e.grupo, marca: p?.brand ?? "—", bikeId: b.id, bike: b.name,
    descricao: p ? `${p.name} · ${p.brand}${p.spec ? ` · ${p.spec}` : ""}` : e.nome,
    funcionamento: (CONEXOES[kind] ?? ["Peça de reposição original: restabelece a condição de fábrica do componente."])[0]!,
    conexoes: CONEXOES[kind] ?? ["Peça original no seu ponto de fábrica; não muda multiplicadores do engine()."],
    fisica, calculos: C, enviavel, motivoNaoEnviavel: enviavel ? undefined : "Nitro ainda não atua na física: não há o que o funil testar.", fonte,
  };
}

export const dossiers = (bikeId?: string) => shopListing().map((e) => dossier(e, bikeId));

// ---------- Exportação ----------
export const toJSON = (d: Dossie | Dossie[]) => JSON.stringify(d, null, 2);
export function toTXT(d: Dossie): string {
  return [`AUTO PEÇAS — ${d.nome}`, `Grupo: ${d.grupo} · Moto: ${d.bike}`, `Descrição: ${d.descricao}`, "", "FUNCIONAMENTO", d.funcionamento, "", "CONEXÕES NO MOTOR", ...d.conexoes.map((c) => `- ${c}`), "", "FÍSICA", ...d.fisica.map((c) => `- ${c}`), "", "CÁLCULOS",
    ...d.calculos.flatMap((c) => [`* ${c.nome} [${c.origem}]`, `  Fórmula: ${c.formula}`, `  Conta:   ${c.conta}`, `  Resultado: ${c.resultado}`]), "", "FONTES", ...d.fonte.map((f) => `- ${f}`)].join("\n");
}
export function toMD(d: Dossie): string {
  return [`# ${d.nome}`, `**${d.grupo}** · ${d.bike}`, "", d.descricao, "", "## Funcionamento", d.funcionamento, "", "## Conexões no motor", ...d.conexoes.map((c) => `- ${c}`), "", "## Física", ...d.fisica.map((c) => `- ${c}`), "", "## Cálculos", "| Grandeza | Fórmula | Conta | Resultado | Origem |", "|---|---|---|---|---|",
    ...d.calculos.map((c) => `| ${c.nome} | ${c.formula} | ${c.conta} | ${c.resultado} | ${c.origem} |`)].join("\n");
}
export function toCSV(ds: Dossie[]): string {
  const q = (s: string) => `"${s.replace(/"/g, '""')}"`;
  return ["peca;moto;grandeza;formula;conta;resultado;origem", ...ds.flatMap((d) => d.calculos.map((c) => [d.id, d.bikeId, c.nome, c.formula, c.conta, c.resultado, c.origem].map(q).join(";")))].join("\n");
}

// ---------- Funil → NEXUS → aprovado / Fix ----------
export const AP_KEY = "streetrace-autopecas-v1";
export type Etapa = "NO FUNIL" | "AGUARDANDO NEXUS" | "APROVADA NEXUS" | "REPROVADA NEXUS" | "REPROVADA NO FUNIL";
export type ApRec = { key: string; partId: string; nome: string; bikeId: string; at: string; runId: string; hash: string; estado: Estado; atual: number; motivo: string; failureIds: string[]; etapa: Etapa; nexus?: { at: string; aprovado: boolean; checks: { nome: string; pass: boolean; detalhe: string }[] } };
export const readAp = (): ApRec[] => { if (typeof cloudStore === "undefined") return []; try { const v = JSON.parse(cloudStore.getItem(AP_KEY) ?? "[]"); return Array.isArray(v) ? v : []; } catch { return []; } };
export const saveAp = (l: ApRec[]) => { try { cloudStore.setItem(AP_KEY, JSON.stringify(l)); } catch { /* cheio */ } return l; };

export function projectFor(e: ShopEntry, bikeId: string): Projeto {
  const b = bikeModel(bikeId);
  return { id: `autopeca-${e.id}-${b.id}`, versao: `loja-${e.id}`, nome: `Auto Peças · ${e.nome} · ${b.name}`, bike: b, setup: setupFor(e), aprovadoMecanico: true, origem: "Wikipedia StreetRace · Auto Peças (loja)" };
}

/** Pura (testável): roda o funil e devolve o registro; o efeito de gravar fica em sendToFunnel. */
export function evaluate(e: ShopEntry, bikeId: string, at: string): { rec: ApRec; x: Execucao; p: Projeto } {
  const p = projectFor(e, bikeId), x = runFunnel(p, at);
  const ok = x.estado === "REALGEAR VERIFIED";
  const rec: ApRec = { key: p.id, partId: e.id, nome: e.nome, bikeId: p.bike.id, at, runId: x.runId, hash: x.hash, estado: x.estado, atual: x.atual, motivo: ok ? "todas as 24 camadas aprovadas" : x.camadas[x.atual - 1]?.motivo ?? "", failureIds: [], etapa: ok ? "AGUARDANDO NEXUS" : "REPROVADA NO FUNIL" };
  return { rec, x, p };
}

export function sendToFunnel(e: ShopEntry, bikeId: string, at = new Date().toISOString()): ApRec {
  const { rec, x, p } = evaluate(e, bikeId, at);
  appendHistory(x); appendLayerLogs(p, x);
  const c = captureFailures(readFix(), p, x);
  saveFix(c.novos.reduce((st, f) => processFailure(st, f.failureId, x.at), c.st));
  rec.failureIds = c.novos.map((f) => f.failureId);
  saveAp([rec, ...readAp().filter((r) => r.key !== rec.key)]);
  return rec;
}

/** NEXUS: reexecuta o funil de forma independente com o mesmo instante e confere reprodutibilidade e camadas. */
export function nexusAudit(rec: ApRec, at: string): ApRec {
  const e = [...shopListing(), ...dealerListing()].find((x) => x.id === rec.partId);
  const checks: { nome: string; pass: boolean; detalhe: string }[] = [];
  if (!e) checks.push({ nome: "Peça ainda à venda na loja", pass: false, detalhe: rec.partId });
  else {
    const x = runFunnel(projectFor(e, rec.bikeId), rec.at);
    checks.push({ nome: "Peça ainda à venda na loja", pass: true, detalhe: e.nome });
    checks.push({ nome: "Funil reproduzível (mesmo hash)", pass: x.hash === rec.hash, detalhe: `${rec.hash} × ${x.hash}` });
    checks.push({ nome: "24 camadas aprovadas", pass: x.camadas.length > 0 && x.camadas.every((c) => c.conclusao === "APROVADA"), detalhe: `${x.camadas.filter((c) => c.conclusao === "APROVADA").length}/${x.camadas.length}` });
    checks.push({ nome: "Estado REALGEAR VERIFIED", pass: x.estado === "REALGEAR VERIFIED", detalhe: x.estado });
    const d = dossier(e, rec.bikeId);
    checks.push({ nome: "Dossiê com contas reais", pass: d.calculos.some((c) => c.origem === "CALCULADO" || c.origem === "JOGO"), detalhe: `${d.calculos.length} cálculos` });
  }
  const aprovado = checks.every((c) => c.pass);
  return { ...rec, nexus: { at, aprovado, checks }, etapa: aprovado ? "APROVADA NEXUS" : "REPROVADA NEXUS" };
}

export type Fonte = "loja" | "concessionaria";
/** Origem do registro: motos da concessionária têm id `moto-<bike>`; o resto vem da loja de peças. */
export const fonteOf = (r: Pick<ApRec, "partId">): Fonte => (dealerListing().some((x) => x.id === r.partId) ? "concessionaria" : "loja");
const byFonte = (l: ApRec[], f?: Fonte) => (f ? l.filter((r) => fonteOf(r) === f) : l);
export const approvedParts = (l: ApRec[], f?: Fonte) => byFonte(l, f).filter((r) => r.etapa === "APROVADA NEXUS");
export const failedParts = (l: ApRec[], f?: Fonte) => byFonte(l, f).filter((r) => r.etapa === "REPROVADA NO FUNIL" || r.etapa === "REPROVADA NEXUS");
export const pendingNexus = (l: ApRec[], f?: Fonte) => byFonte(l, f).filter((r) => r.etapa === "AGUARDANDO NEXUS");
export { partById };
export type { Part };
