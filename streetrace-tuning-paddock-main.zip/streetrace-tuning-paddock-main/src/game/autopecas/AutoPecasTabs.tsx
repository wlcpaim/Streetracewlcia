import { useEffect, useMemo, useRef, useState } from "react";
import { dealerListing, shopListing, type ShopEntry } from "../shop-catalog";
import { approvedParts, dossier, failedParts, pendingNexus, nexusAudit, type Fonte, readAp, saveAp, sendToFunnel, toCSV, toJSON, toMD, toTXT, dossiers, type ApRec } from "./autopecas";
import { analiseTXT, buildAnalise, readAnalise, saveAnalise, type Analise } from "./analise";
import { readFix, saveFix } from "../realgear/fix/pipeline";
import { nexusReview, readBug, resolve, saveBug, sync } from "../bugfix/bugfix";

const BIKES: [string, string][] = [["titan160", "Honda CG 160 Titan"], ["factor150", "Yamaha Factor 150"], ["titan150", "Honda CG 150 Titan ESD"], ["cg125", "Honda CG 125 Bolinha"]];
function download(text: string, name: string, type: string) {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = document.createElement("a"); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}
const useAp = () => {
  const [l, setL] = useState<ApRec[]>([]);
  useEffect(() => { setL(readAp()); const i = setInterval(() => setL(readAp()), 4000); return () => clearInterval(i); }, []);
  return [l, (x: ApRec[]) => setL(saveAp(x))] as const;
};
const Btn = (p: React.ButtonHTMLAttributes<HTMLButtonElement>) => <button {...p} className={`rounded-lg bg-secondary px-2.5 py-1 text-xs font-bold disabled:opacity-40 ${p.className ?? ""}`} />;
const Status = ({ r }: { r: ApRec }) => (
  <div className="rounded-xl border border-border bg-card p-3 text-sm">
    <div className="flex flex-wrap items-center justify-between gap-2"><b>{r.nome} · {r.bikeId}</b><span className="rounded bg-secondary px-2 py-0.5 text-xs font-bold">{r.etapa}</span></div>
    <p className="text-xs text-muted-foreground">Funil: {r.estado} · camada {r.atual} · {r.motivo} · hash {r.hash} · {new Date(r.at).toLocaleString("pt-BR")}</p>
    {r.nexus && <ul className="mt-1 space-y-0.5 text-xs">{r.nexus.checks.map((c) => <li key={c.nome}>{c.pass ? "✔" : "✘"} {c.nome} — {c.detalhe}</li>)}</ul>}
  </div>
);

/** WikiStreetrace · Auto Peças: as mesmas peças da loja, com dossiê técnico e envio ao funil. */
export function AutoPecasTab({ source = "loja" }: { source?: "loja" | "concessionaria" } = {}) {
  const list = useMemo<ShopEntry[]>(() => (source === "concessionaria" ? dealerListing() : shopListing()), [source]);
  const topRef = useRef<HTMLDivElement>(null);
  const [bulk, setBulk] = useState<string | null>(null);
  const [bike, setBike] = useState("titan160");
  const [sel, setSel] = useState(list[0]?.id ?? "");
  const [ap, setAp] = useAp();
  const entry = list.find((x) => x.id === sel);
  const d = useMemo(() => (entry ? dossier(entry, entry.bikeId ?? bike) : null), [entry, bike]);
  const groups = [...new Set(list.map((x) => x.grupo))];
  const rec = d && ap.find((r) => r.key === `autopeca-${d.id}-${d.bikeId}`);
  const send = () => { if (!entry || !d) return; sendToFunnel(entry, d.bikeId); setAp(readAp()); };
  const all = () => list.map((x) => dossier(x, x.bikeId ?? bike));
  const pick = (id: string) => { setSel(id); requestAnimationFrame(() => topRef.current?.scrollIntoView({ behavior: "smooth", block: "start" })); };
  const sendAll = () => {
    setBulk("Enviando…");
    setTimeout(() => {
      let ok = 0, bad = 0, skip = 0;
      for (const x of list) { const dd = dossier(x, x.bikeId ?? bike); if (!dd.enviavel) { skip++; continue; } const r = sendToFunnel(x, dd.bikeId); if (r.etapa === "AGUARDANDO NEXUS") ok++; else bad++; }
      setAp(readAp()); setBulk(`${ok} passaram no funil (aguardando NEXUS) · ${bad} reprovadas (foram para o Fix) · ${skip} não enviáveis`);
    }, 20);
  };
  return (
    <div ref={topRef} className="scroll-mt-28 space-y-3">
    <div className="flex flex-wrap items-center gap-2"><Btn onClick={sendAll} disabled={bulk === "Enviando…"} className="bg-primary text-primary-foreground">Enviar todos para o funil ({list.length})</Btn>{bulk && <span className="text-xs text-muted-foreground">{bulk}</span>}</div>
    <div className="grid gap-3 md:grid-cols-[260px_1fr]">
      <aside className="order-2 space-y-2 md:order-1">
        <select value={bike} onChange={(e) => setBike(e.target.value)} className="w-full rounded border border-input bg-background px-2 py-1 text-sm">{BIKES.map(([id, l]) => <option key={id} value={id}>{l}</option>)}</select>
        <p className="text-[11px] text-muted-foreground">{list.length} itens · lidos da loja agora (entrou na loja, aparece aqui).</p>
        <div className="flex flex-wrap gap-1">
          <Btn onClick={() => download(toJSON(all()), `${source}-${bike}.json`, "application/json")}>JSON</Btn>
          <Btn onClick={() => download(all().map(toTXT).join("\n\n" + "=".repeat(60) + "\n\n"), `${source}-${bike}.txt`, "text/plain")}>TXT</Btn>
          <Btn onClick={() => download(all().map(toMD).join("\n\n---\n\n"), `${source}-${bike}.md`, "text/markdown")}>MD</Btn>
          <Btn onClick={() => download(toCSV(all()), `${source}-${bike}.csv`, "text/csv")}>CSV</Btn>
        </div>
        <div className="max-h-[70vh] space-y-2 overflow-y-auto pr-1">
          {groups.map((g) => (
            <div key={g}>
              <div className="mb-1 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">{g}</div>
              {list.filter((x) => x.grupo === g).map((x) => <button key={x.id} onClick={() => pick(x.id)} className={`mb-1 block w-full rounded-lg px-2 py-1.5 text-left text-xs ${sel === x.id ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>{x.nome}</button>)}
            </div>
          ))}
        </div>
      </aside>
      {d && (
        <article className="order-1 space-y-3 rounded-xl md:order-2 border border-border bg-card p-4 text-sm">
          <header className="flex flex-wrap items-start justify-between gap-2">
            <div><h3 className="font-display text-xl">{d.nome}</h3><p className="text-xs text-muted-foreground">{d.descricao} · montada na {d.bike}</p></div>
            <div className="flex flex-wrap gap-1">
              <Btn onClick={() => download(toJSON(d), `${d.id}-${d.bikeId}.json`, "application/json")}>JSON</Btn>
              <Btn onClick={() => download(toTXT(d), `${d.id}-${d.bikeId}.txt`, "text/plain")}>TXT</Btn>
              <Btn onClick={() => download(toMD(d), `${d.id}-${d.bikeId}.md`, "text/markdown")}>MD</Btn>
              <Btn disabled={!d.enviavel} onClick={send} className="bg-primary text-primary-foreground">Enviar para o funil</Btn>
            </div>
          </header>
          {!d.enviavel && <p className="text-xs text-destructive">{d.motivoNaoEnviavel}</p>}
          {rec && <Status r={rec} />}
          <section><h4 className="font-bold">Como funciona</h4><p>{d.funcionamento}</p></section>
          <section><h4 className="font-bold">Conexões no motor</h4><ul className="list-disc pl-5">{d.conexoes.map((c) => <li key={c}>{c}</li>)}</ul></section>
          <section><h4 className="font-bold">Física envolvida</h4><ul className="list-disc pl-5">{d.fisica.map((c) => <li key={c}>{c}</li>)}</ul></section>
          <section>
            <h4 className="font-bold">Cálculos e fórmulas</h4>
            <div className="space-y-1.5">{d.calculos.map((c) => (
              <div key={c.nome} className="rounded-lg bg-secondary/60 p-2">
                <div className="flex flex-wrap justify-between gap-2"><b>{c.nome}</b><span className="text-[10px] font-bold">{c.origem}</span></div>
                <div className="font-mono text-xs">{c.formula}</div>
                <div className="text-xs text-muted-foreground">{c.conta}</div>
                <div className="text-xs font-bold">= {c.resultado}</div>
              </div>))}</div>
          </section>
          <p className="text-[10px] text-muted-foreground">Fontes: {d.fonte.join(" · ")}</p>
        </article>
      )}
    </div>
    </div>
  );
}

/** WikiStreetrace · Auto Peças Fix / Concessionária Fix: reprovados voltam para cá e seguem a mecânica do Bug Fix. */
export function AutoPecasFixTab({ source = "loja" }: { source?: Fonte } = {}) {
  const [ap, setAp] = useAp();
  const [bug, setBug] = useState(() => ({ items: [] as ReturnType<typeof readBug>["items"] }));
  useEffect(() => { setBug(saveBug(sync(readBug(), readFix()))); }, [ap]);
  const list = failedParts(ap, source);
  const fix = (r: ApRec) => {
    const at = new Date().toISOString();
    let b = sync(readBug(), readFix()), fx = readFix();
    for (const id of r.failureIds) { const o = resolve(b, fx, id, at); b = o.b; fx = o.fx; b = nexusReview(b, fx, id, at); }
    saveFix(fx); setBug(saveBug(b));
  };
  const resend = (r: ApRec) => { const e = [...shopListing(), ...dealerListing()].find((x) => x.id === r.partId); if (e) { sendToFunnel(e, r.bikeId); setAp(readAp()); } };
  if (!list.length) return <p className="text-sm text-muted-foreground">{source === "concessionaria" ? "Nenhuma moto da concessionária reprovada. Motos reprovadas no funil ou no NEXUS voltam para cá." : "Nenhuma peça reprovada. Peças reprovadas no funil ou no NEXUS voltam para cá."}</p>;
  return (
    <div className="space-y-2">
      {list.map((r) => (
        <div key={r.key} className="space-y-1">
          <Status r={r} />
          {r.failureIds.map((id) => { const it = bug.items.find((i) => i.failureId === id); return <p key={id} className="pl-3 text-xs">Falha {id}: {it ? `${it.etapa} · camada ${it.camada}${it.nota ? ` · ${it.nota}` : ""}` : "aguardando registro"}</p>; })}
          <div className="flex gap-1 pl-3">
            <Btn disabled={!r.failureIds.length} onClick={() => fix(r)}>Resolver (Fix Center → NEXUS)</Btn>
            <Btn onClick={() => resend(r)}>Reenviar ao funil</Btn>
          </div>
        </div>
      ))}
    </div>
  );
}

/** NEXUS · Auto Peças / Concessionária: auditoria final do que passou no funil e lista dos aprovados. */
export function NexusAutoPecas({ source = "loja" }: { source?: Fonte } = {}) {
  const [ap, setAp] = useAp();
  const pend = pendingNexus(ap, source), ok = approvedParts(ap, source);
  const item = source === "concessionaria" ? "moto" : "peça";
  const audit = (r: ApRec) => setAp(readAp().map((x) => (x.key === r.key ? nexusAudit(x, new Date().toISOString()) : x)));
  return (
    <div className="space-y-3">
      <div className="space-y-2">
        <h4 className="text-sm font-bold">Aguardando auditoria final</h4>
        {!pend.length && <p className="text-xs text-muted-foreground">Nenhuma {item} aprovada no funil esperando o NEXUS.</p>}
        {pend.map((r) => <div key={r.key} className="space-y-1"><Status r={r} /><Btn onClick={() => audit(r)} className="bg-primary text-primary-foreground">Auditar e decidir</Btn></div>)}
      </div>
      <div className="space-y-2">
        <h4 className="text-sm font-bold">{source === "concessionaria" ? "Concessionária aprovadas" : "Auto Peças aprovadas"}</h4>
        {!ok.length && <p className="text-xs text-muted-foreground">Nenhuma {item} aprovada ainda.</p>}
        {ok.map((r) => <Status key={r.key} r={r} />)}
      </div>
    </div>
  );
}

/** WikiStreetrace · Análise Geral: física completa citando motos, leis, peças e estado no funil/NEXUS. */
export function AnaliseGeralTab() {
  const [a, setA] = useState<Analise | null>(null);
  useEffect(() => setA(readAnalise()), []);
  const gen = () => setA(saveAnalise(buildAnalise()));
  return (
    <div className="space-y-3 text-sm">
      <div className="flex flex-wrap gap-1">
        <Btn onClick={gen} className="bg-primary text-primary-foreground">{a ? "Atualizar análise" : "Gerar análise geral"}</Btn>
        {a && <><Btn onClick={() => download(JSON.stringify(a, null, 2), "analise-geral.json", "application/json")}>JSON</Btn><Btn onClick={() => download(analiseTXT(a), "analise-geral.txt", "text/plain")}>TXT</Btn></>}
      </div>
      {!a && <p className="text-muted-foreground">Ainda não gerada.</p>}
      {a && (
        <>
          <p className="text-xs text-muted-foreground">Gerada em {new Date(a.at).toLocaleString("pt-BR")} · {a.contagem.pecas} dossiês · {a.contagem.calculos} cálculos · {a.contagem.naoIdentificados} dados não identificados · leis {a.contagem.leisPass}/{a.contagem.leisTotal} PASS · NEXUS {a.contagem.aprovadasNexus} aprovadas / {a.contagem.reprovadas} reprovadas / {a.contagem.aguardando} aguardando</p>
          <pre className="max-h-[70vh] overflow-auto whitespace-pre-wrap rounded-xl bg-secondary/60 p-3 text-xs">{analiseTXT(a)}</pre>
        </>
      )}
    </div>
  );
}
