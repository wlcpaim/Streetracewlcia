// ANÁLISE GERAL — relatório físico completo gerado depois do ciclo Auto Peças → funil → NEXUS.
// Somente leitura: cita cada moto, cada lei física revisada (physicsReview), cada peça da loja com suas contas e o
// estado de cada peça no funil/NEXUS. Nada aqui muda Setup nem corrida.
import { cloudStore } from "@/game/cloud/cloud-store";
import { BIKES } from "../admin-lab";
import { STOCK_SETUP, engine, gearSpeeds, stats, stress } from "../physics";
import { physicsReview } from "../intel/changelog";
import { dossiers, readAp, type ApRec, type Dossie } from "./autopecas";

export const ANALISE_KEY = "streetrace-analise-geral-v1";
export type Analise = {
  at: string;
  motos: { id: string; nome: string; hp: number; torque: number; kg: number; rpmPeak: number; rpmLimit: number; marchas: number[]; carga: number }[];
  leis: { moto: string; id: string; lei: string; formula: string; calc: number; ref: number; unidade: string; erroPct: number; status: string; nota: string }[];
  pecas: Dossie[];
  funil: ApRec[];
  contagem: { pecas: number; calculos: number; naoIdentificados: number; aprovadasNexus: number; reprovadas: number; aguardando: number; leisPass: number; leisTotal: number };
};

export function buildAnalise(at = new Date().toISOString(), funil: ApRec[] = readAp()): Analise {
  const motos = BIKES.map((b) => { const e = engine(b, STOCK_SETUP), s = stats(b, STOCK_SETUP); return { id: b.id, nome: b.name, hp: s.hp, torque: s.torque, kg: s.kg, rpmPeak: e.rpmPeak, rpmLimit: e.rpmLimit, marchas: gearSpeeds(b, STOCK_SETUP).map((v) => Math.round(v * 10) / 10), carga: stress(b, STOCK_SETUP).value }; });
  const leis = BIKES.flatMap((b) => physicsReview(STOCK_SETUP, b.id).map((c) => ({ moto: b.name, id: c.id, lei: c.law, formula: c.formula, calc: c.calc, ref: c.ref, unidade: c.unit, erroPct: c.errPct, status: c.status, nota: c.note })));
  const pecas = BIKES.flatMap((b) => dossiers(b.id).filter((d) => d.bikeId === b.id));
  const calcs = pecas.flatMap((d) => d.calculos);
  return {
    at, motos, leis, pecas, funil,
    contagem: {
      pecas: pecas.length, calculos: calcs.length, naoIdentificados: calcs.filter((c) => c.origem === "DADO NÃO IDENTIFICADO").length,
      aprovadasNexus: funil.filter((r) => r.etapa === "APROVADA NEXUS").length, reprovadas: funil.filter((r) => r.etapa.startsWith("REPROVADA")).length,
      aguardando: funil.filter((r) => r.etapa === "AGUARDANDO NEXUS").length, leisPass: leis.filter((l) => l.status === "PASS").length, leisTotal: leis.length,
    },
  };
}

export function analiseTXT(a: Analise): string {
  const L: string[] = [`ANÁLISE GERAL DE FÍSICA — StreetRace · ${a.at}`, "", "CONTAGEM",
    `Peças analisadas (por moto): ${a.contagem.pecas} · cálculos: ${a.contagem.calculos} · dados não identificados: ${a.contagem.naoIdentificados}`,
    `Leis físicas revisadas: ${a.contagem.leisPass}/${a.contagem.leisTotal} PASS`,
    `Funil/NEXUS: ${a.contagem.aprovadasNexus} aprovadas · ${a.contagem.reprovadas} reprovadas · ${a.contagem.aguardando} aguardando NEXUS`, "", "MOTOS (fábrica)"];
  for (const m of a.motos) L.push(`- ${m.nome}: ${m.hp} cv · ${m.torque} kgf·m · ${m.kg} kg · pico ${m.rpmPeak} rpm · corte ${m.rpmLimit} rpm · marchas ${m.marchas.join("/")} km/h · carga ${m.carga}`);
  L.push("", "LEIS FÍSICAS (recalculadas por rota independente)");
  for (const l of a.leis) L.push(`- [${l.status}] ${l.moto} · ${l.lei} · ${l.formula} · calc ${l.calc.toFixed(4)} × ref ${l.ref.toFixed(4)} ${l.unidade} · erro ${l.erroPct.toFixed(3)} % · ${l.nota}`);
  L.push("", "PEÇAS DA LOJA");
  for (const d of a.pecas) {
    L.push(`## ${d.nome} · ${d.bike} (${d.grupo})`, `  ${d.funcionamento}`);
    for (const c of d.calculos) L.push(`  * ${c.nome} [${c.origem}] ${c.formula} | ${c.conta} | ${c.resultado}`);
  }
  L.push("", "FUNIL E NEXUS");
  if (!a.funil.length) L.push("- Nenhuma peça enviada ao funil ainda.");
  for (const r of a.funil) L.push(`- ${r.nome} · ${r.bikeId} · ${r.etapa} · camada ${r.atual} · ${r.estado} · hash ${r.hash} · ${r.motivo}`);
  return L.join("\n");
}

export const readAnalise = (): Analise | null => { try { return JSON.parse(cloudStore.getItem(ANALISE_KEY) ?? "null"); } catch { return null; } };
export const saveAnalise = (a: Analise) => { try { cloudStore.setItem(ANALISE_KEY, JSON.stringify(a)); } catch { /* cheio */ } return a; };
