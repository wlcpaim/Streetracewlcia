// Fuel blends: four base fuels, a tank composition (Setup.blend fractions) and their effect on the engine.
// Effects are relative to the base fuel the bike model already uses (gasolina or etanol), so a pure tank
// of the base fuel stays neutral and stock vs stock still ties.
import type { Setup } from "./physics";
import { K } from "./physics-registry/constants";

export type Comb = "gasc" | "podium" | "etanol" | "metanol" | "nitrometano";
export const COMBS: Comb[] = ["gasc", "podium", "etanol", "metanol", "nitrometano"];
export type Blend = Partial<Record<Comb, number>>;

export const COMB_INFO: Record<Comb, { label: string; kmL: number; gain: string; octane: string }> = {
  gasc: { label: "Gasolina C", kmL: 15.0, gain: "100% · base", octane: "RON ~95" },
  podium: { label: "Gasolina Podium", kmL: 14.7, gain: "100–103%", octane: "RON ~102" },
  etanol: { label: "Álcool", kmL: 10.5, gain: "102–108%", octane: "RON ~110" },
  metanol: { label: "Metanol", kmL: 7.9, gain: "105–115%", octane: "RON ~114" },
  // nitrometano (CH3NO2): carrega o próprio oxigênio; km/L e ganho são estimativas de jogo
  nitrometano: { label: "Nitrometano", kmL: 3.0, gain: "115–130% (estimado)", octane: "—" },
};
/** Physical properties of each fuel, all from the constants registry (stoichiometric AFR, density, LHV, latent heat). */
export const FUEL_PROPS: Record<Comb, { afr: number; rho: number; lhv: number; hvap: number }> = {
  gasc: { afr: K("fuel.afr.gasolina_c_e27"), rho: K("fuel.rho.gasolina_c_e27"), lhv: K("fuel.lhv.gasolina_c_e27"), hvap: K("fuel.hvap.gasolina_c_e27") },
  podium: { afr: K("fuel.afr.gasolina_c_e27"), rho: K("fuel.rho.gasolina_c_e27"), lhv: K("fuel.lhv.gasolina_c_e27"), hvap: K("fuel.hvap.gasolina_c_e27") },
  etanol: { afr: K("fuel.afr.etanol_hidratado"), rho: K("fuel.rho.etanol_hidratado"), lhv: K("fuel.lhv.etanol_hidratado"), hvap: K("fuel.hvap.etanol_hidratado") },
  metanol: { afr: K("fuel.afr.metanol"), rho: K("fuel.rho.metanol"), lhv: K("fuel.lhv.metanol"), hvap: K("fuel.hvap.metanol") },
  nitrometano: { afr: K("fuel.afr.nitrometano"), rho: K("fuel.rho.nitrometano"), lhv: K("fuel.lhv.nitrometano"), hvap: K("fuel.hvap.nitrometano") },
};
/** Liters of fuel per kg of air at stoichiometric: 1 / (AFR · ρ). */
const litersPerKgAir = (k: Comb) => 1 / (FUEL_PROPS[k].afr * FUEL_PROPS[k].rho);
/** Fuel VOLUME the injector must deliver for the same air, vs Gasolina C: (1/AFR·ρ)_k / (1/AFR·ρ)_gasC. */
export const DEMAND: Record<Comb, number> = Object.fromEntries(COMBS.map((k) => [k, litersPerKgAir(k) / litersPerKgAir("gasc")])) as Record<Comb, number>;
/** Port evaporation share and its ceiling (ESTIMADO: no measured intake temperature). */
const EVAP_SHARE = 0.5, COOL_MAX_K = 40, T_INTAKE_K = 320;
/** Charge cooling: ΔT = share · h_vap / (AFR · cp_ar), air density rises by T/(T−ΔT). */
export const chargeCoolK = (k: Comb) => Math.min(COOL_MAX_K, (EVAP_SHARE * FUEL_PROPS[k].hvap) / (FUEL_PROPS[k].afr * K("air.cp")));
/** Energy released per kg of air at stoichiometric (J/kg_ar) = LHV / AFR. Nitromethane carries its own O2. */
export const energyPerAir = (k: Comb) => FUEL_PROPS[k].lhv / FUEL_PROPS[k].afr;

/** Tank composition; old saves without a blend are pure base fuel. */
export function blendOf(s: Pick<Setup, "fuel" | "blend">): Record<Comb, number> {
  const b = s.blend;
  const out = { gasc: 0, podium: 0, etanol: 0, metanol: 0, nitrometano: 0 };
  const sum = b ? COMBS.reduce((n, k) => n + (b[k] ?? 0), 0) : 0;
  if (!b || sum <= 0) {
    out[s.fuel === "etanol" ? "etanol" : "gasc"] = 1;
    return out;
  }
  for (const k of COMBS) out[k] = (b[k] ?? 0) / sum;
  return out;
}

/** Base fuel the physics model uses: álcool when most of the tank is alcohol. */
export const baseFuel = (b: Record<Comb, number>): Setup["fuel"] => (b.etanol + b.metanol + b.nitrometano >= 0.5 ? "etanol" : "gasolina");

/**
 * Absolute power index of each fuel vs Gasolina C at stoichiometric:
 * (LHV/AFR)_k / (LHV/AFR)_gasC × air density gain from charge cooling × knock headroom at the compression.
 * Knock headroom (octane) is the only game-calibrated term (ESTIMADO): alcohols accept more advance as compression rises.
 */
export function hpIndex(k: Comb, comp: number) {
  const c = Math.max(0, Math.min(1, (comp - 9.5) / 4)); // 9,5:1 → 0 · 13,5:1 → 1
  const dens = (T_INTAKE_K / (T_INTAKE_K - chargeCoolK(k))) / (T_INTAKE_K / (T_INTAKE_K - chargeCoolK("gasc")));
  const knock = k === "podium" ? 0.03 : k === "etanol" ? 0.06 : k === "metanol" ? 0.1 : 0;
  return (energyPerAir(k) / energyPerAir("gasc")) * dens * (1 + knock * c);
}

/**
 * Effect of the tank blend vs the pure base fuel:
 * hpMul (power), need (fuel volume the injectors must deliver), burn (volume consumption).
 * Bad blends lose power: metanol does not mix well with gasoline, and splitting the tank
 * between fuels makes the map wrong for every one of them.
 */
export function blendFx(s: Pick<Setup, "fuel" | "blend" | "compression">, flex: boolean) {
  const b = blendOf(s);
  const base: Comb = baseFuel(b) === "etanol" && flex ? "etanol" : "gasc";
  let H = 0;
  let D = 0;
  for (const k of COMBS) {
    H += b[k] * hpIndex(k, s.compression);
    D += b[k] * DEMAND[k];
  }
  const gas = b.gasc + b.podium;
  const alc = b.etanol + b.metanol + b.nitrometano;
  // phase separation (metanol x gasolina) and a map that fits nobody in a 50/50 tank
  // flex (sonda + central adaptativa) acerta qualquer mistura de gasolina com etanol: sem mapa errado nem mistura rica
  const flexOk = flex && b.metanol + b.nitrometano === 0;
  const penalty = 0.12 * (b.metanol + b.nitrometano) * gas * 4 * 0.5 + (flexOk ? 0 : 0.03 * 4 * gas * alc);
  const hpMul = (H / hpIndex(base, s.compression)) * (1 - Math.min(0.15, penalty));
  const rel = flexOk ? 1 : D / DEMAND[base];
  return { hpMul: flexOk ? 1 : hpMul, need: rel, burn: flexOk ? D / DEMAND[base] : rel, base, flexEth: flexOk ? b.etanol : null };
}

/** Pour `add` liters into a tank with `fuelL` liters of `s` blend; returns the new fractions and liters. */
export function pour(s: Pick<Setup, "fuel" | "blend">, fuelL: number, add: Blend) {
  const cur = blendOf(s);
  const liters: Record<Comb, number> = { gasc: 0, podium: 0, etanol: 0, metanol: 0, nitrometano: 0 };
  let total = 0;
  for (const k of COMBS) {
    liters[k] = cur[k] * fuelL + Math.max(0, add[k] ?? 0);
    total += liters[k];
  }
  const blend: Blend = {};
  for (const k of COMBS) if (liters[k] > 0) blend[k] = Math.round((liters[k] / total) * 10000) / 10000;
  return { blend, fuelL: Math.round(total * 1000) / 1000, fuel: total > 0 ? baseFuel(blendOf({ fuel: s.fuel, blend })) : s.fuel };
}

/** Pump fuel ids to blend component. */
export const pumpComb = (f: "gasolina" | "etanol" | "podium"): Comb => (f === "gasolina" ? "gasc" : f);

/** A break caused by the mixture (lean or rich) contaminates the tank: the workshop drains it. */
export const isMixBreak = (cause: string | null | undefined) => !!cause && /mistura/i.test(cause);
export function drainIfMixBreak<P extends { fuelL: number; setup: Setup }>(p: P, cause: string | null | undefined): P {
  if (!isMixBreak(cause)) return p;
  const { blend: _b, ...rest } = p.setup;
  void _b;
  return { ...p, fuelL: 0, setup: rest as Setup };
}
