import { cloudStore } from "@/game/cloud/cloud-store";
// Limpeza do histórico de auditorias (RealGear, Fix Center, Bug Fix, Wikipedia ao vivo, ponte Python).
// Não toca no save do jogador, nas aprovações da Auto Peças nem nos resultados da ENG IA: as mecânicas ficam iguais.
export const AUDIT_KEYS = [
  "streetrace-realgear-history-v1", "streetrace-realgear-intake-v1", "streetrace-realgear-layerlogs-v1",
  "streetrace-realgear-bridge-v1", "streetrace-realgear-fixcenter-v1", "streetrace-bugfix-v1",
  "streetrace-intel-v1", "streetrace-wiki-live",
] as const;
const RESET_FLAG = "streetrace-audit-reset-2026-11-10";

export function clearAuditHistory() {
  for (const k of AUDIT_KEYS) cloudStore.removeItem(k);
}

/** Roda uma única vez por navegador (limpeza pedida para começar do zero). */
export function clearAuditHistoryOnce() {
  if (typeof cloudStore === "undefined" || cloudStore.getItem(RESET_FLAG)) return;
  clearAuditHistory();
  cloudStore.setItem(RESET_FLAG, "1");
}
