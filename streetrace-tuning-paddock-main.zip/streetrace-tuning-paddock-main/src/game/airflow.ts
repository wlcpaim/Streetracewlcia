// Admissão física: ar atravessa o corpo de borboleta (orifício compressível), enche o coletor e entra pela válvula.
// O ganho de um TBI maior é a densidade do coletor que ele preserva no pico; o escape (ondas) vem de exhaust.ts.
import { K } from "./physics-registry/constants";
import { partById } from "./parts";
import type { Setup } from "./physics";

/** Constantes do modelo (ESTIMADO: sem bancada de fluxo deste motor). */
export const AIR = {
  T0: 300, // K, ar ambiente
  p0: 101325, // Pa
  cd: 0.8, // coeficiente de descarga da borboleta aberta
  ve: 0.9, // eficiência volumétrica de referência no pico
  // monocilíndrico: só aspira em ~240° de 720°, com pico senoidal → vazão de pico = média · (720/240) · π/2
  pulse: (720 / 240) * (Math.PI / 2),
};
const CHOKE = Math.pow(2 / (K("air.gamma") + 1), K("air.gamma") / (K("air.gamma") - 1)); // 0,528

/** Vazão mássica isentrópica por um orifício (kg/s) na razão de pressão pr = p_coletor/p0. */
export function orificeFlow(areaM2: number, pr: number) {
  const g = K("air.gamma"), R = K("air.R");
  const p = Math.max(pr, CHOKE);
  return AIR.cd * areaM2 * (AIR.p0 / Math.sqrt(R * AIR.T0)) * Math.sqrt(((2 * g) / (g - 1)) * (Math.pow(p, 2 / g) - Math.pow(p, (g + 1) / g)));
}

/** Diâmetro efetivo da borboleta (mm): peça montada, ou a original brocada pelo serviço. */
export function tbiBoreMm(s: Pick<Setup, "slots" | "services">) {
  const id = s.slots.tbi ?? "tbi-original";
  const m = /Ø\s*(\d+(?:[.,]\d+)?)/.exec(partById(id)?.name ?? "");
  let d = m ? Number(m[1]!.replace(",", ".")) : 28;
  if (id === "tbi-original") {
    if (s.services.includes("tbi-36")) d = 32;
    else if (s.services.includes("tbi-34")) d = 30;
  }
  return d;
}

/** Resolve p_coletor/p0 em que a borboleta passa a vazão de pico que o cilindro pede. */
export function manifoldRatio(boreMm: number, cc: number, rpm: number) {
  const A = (Math.PI * (boreMm / 1000) ** 2) / 4;
  const rho0 = AIR.p0 / (K("air.R") * AIR.T0);
  let lo = CHOKE, hi = 1;
  for (let i = 0; i < 50; i++) {
    const pr = (lo + hi) / 2;
    const demand = rho0 * Math.pow(pr, 1 / K("air.gamma")) * cc * 1e-6 * AIR.ve * (rpm / 120) * AIR.pulse;
    if (orificeFlow(A, pr) > demand) lo = pr;
    else hi = pr;
  }
  return lo;
}

/** Densidade do ar no coletor vs ambiente: ρ/ρ0 = pr^(1/γ) (expansão adiabática). */
export const chargeDensity = (boreMm: number, cc: number, rpm: number) => Math.pow(manifoldRatio(boreMm, cc, rpm), 1 / K("air.gamma"));

/** Ganho de ar do TBI montado vs a borboleta de fábrica Ø 28 mm, no mesmo motor e giro (fábrica = 1). */
export function tbiAirGain(s: Pick<Setup, "slots" | "services">, cc: number, rpm: number) {
  return chargeDensity(tbiBoreMm(s), cc, rpm) / chargeDensity(28, cc, rpm);
}

/** Relatório da cadeia de ar no giro: vazão média, pico, pressão do coletor, Mach na borboleta. */
export function airChain(s: Pick<Setup, "slots" | "services">, cc: number, rpm: number) {
  const d = tbiBoreMm(s), pr = manifoldRatio(d, cc, rpm);
  const rho0 = AIR.p0 / (K("air.R") * AIR.T0), rho = rho0 * Math.pow(pr, 1 / K("air.gamma"));
  const mean = rho * cc * 1e-6 * AIR.ve * (rpm / 120);
  const A = (Math.PI * (d / 1000) ** 2) / 4;
  const v = (mean * AIR.pulse) / (rho * A);
  const a = Math.sqrt(K("air.gamma") * K("air.R") * AIR.T0 * Math.pow(pr, (K("air.gamma") - 1) / K("air.gamma")));
  return { boreMm: d, rpm, cc, prManifold: pr, densityRatio: rho / rho0, meanKgS: mean, peakKgS: mean * AIR.pulse, mach: v / a, gain: tbiAirGain(s, cc, rpm) };
}
