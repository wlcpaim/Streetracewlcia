// Exhaust system: geometry + gas flow → power curve multiplier. No fixed hp per pipe.
// Values are balance knobs (EXHAUST_SPECS / EXH_K); physics.ts reads exhaustAt() for engine and dyno.

export interface ExhaustSpec {
  /** Internal pipe diameter (mm). */
  d: number;
  /** Total length header → outlet (mm): sets the pulse-tuned rpm. */
  L: number;
  /** Flow restriction 0..1 (silencer + catalyst + bends). */
  restr: number;
  /** Flow efficiency 0..1: how much of the pulse tuning the geometry actually delivers. */
  eff: number;
  /** Weight of the whole pipe (kg). */
  kg: number;
  silencer: boolean;
  cat: boolean;
  /** Initial simulation modifiers per rpm band (fraction). */
  low: number;
  mid: number;
  high: number;
  /** Throttle response (reserved for balance). */
  resp: number;
}

export const EXH_K = {
  /** Reference: 162,7 cc at 8.000 rpm wants a 30 mm pipe. */
  refCc: 162.7,
  refRpm: 8000,
  refD: 30,
  /** Gas too slow (oversized pipe): scavenging loss. */
  slowLoss: 0.1,
  /** Pumping loss from restriction × flow². */
  pump: 0.05,
  /** Max pulse-tuning gain and its rpm width. */
  tune: 0.03,
  tuneWidth: 1800,
  /** 850 mm pipe tunes at 8.000 rpm. */
  tuneL: 850,
};

export const EXHAUST_SPECS: Record<string, ExhaustSpec> = {
  "escape-original": { d: 25, L: 980, restr: 0.42, eff: 0.62, kg: 6.8, silencer: true, cat: true, low: 0, mid: 0, high: 0, resp: 0 },
  "escape-dore": { d: 32, L: 850, restr: 0.18, eff: 0.82, kg: 1.8, silencer: true, cat: false, low: -0.01, mid: 0.02, high: 0.03, resp: 0.01 },
  "escape-gemoto": { d: 30, L: 900, restr: 0.26, eff: 0.74, kg: 3.8, silencer: true, cat: false, low: 0, mid: 0.01, high: 0.015, resp: 0 },
  "escape-ponteira-abafada": { d: 28, L: 940, restr: 0.3, eff: 0.7, kg: 4.2, silencer: true, cat: false, low: 0.005, mid: 0.01, high: 0.005, resp: 0 },
  // Polimet Tork: tubo mais longo e fino → sintonia emerge em ~6.480 rpm (8000·850/1050), sem bônus de faixa.
  "escape-polimet-tork": { d: 27, L: 1050, restr: 0.28, eff: 0.76, kg: 4.4, silencer: true, cat: false, low: 0, mid: 0, high: 0, resp: 0 },
  // 12 escapes de rua: geometria própria de cada um (Ø, comprimento, restrição, peso)
  "escape-rua-viuva": { d: 30, L: 880, restr: 0.24, eff: 0.76, kg: 3.6, silencer: true, cat: false, low: 0.004, mid: 0.008, high: 0.006, resp: 0 },
  "escape-rua-chiadeira": { d: 31, L: 860, restr: 0.22, eff: 0.78, kg: 3.2, silencer: true, cat: false, low: 0.0, mid: 0.012, high: 0.012, resp: 0 },
  "escape-rua-ronco-grosso": { d: 29, L: 960, restr: 0.27, eff: 0.74, kg: 4.0, silencer: true, cat: false, low: 0.012, mid: 0.006, high: -0.004, resp: 0 },
  "escape-rua-garrafinha": { d: 28, L: 1000, restr: 0.25, eff: 0.75, kg: 3.9, silencer: true, cat: false, low: 0.016, mid: 0.004, high: -0.008, resp: 0 },
  "escape-rua-megafone": { d: 34, L: 780, restr: 0.15, eff: 0.86, kg: 2.6, silencer: true, cat: false, low: -0.022, mid: 0.01, high: 0.04, resp: 0 },
  "escape-rua-cano-reto": { d: 36, L: 740, restr: 0.08, eff: 0.7, kg: 1.6, silencer: true, cat: false, low: -0.04, mid: -0.005, high: 0.045, resp: 0 },
  "escape-rua-abelha": { d: 30, L: 900, restr: 0.2, eff: 0.8, kg: 2.9, silencer: true, cat: false, low: 0.002, mid: 0.014, high: 0.01, resp: 0 },
  "escape-rua-trovaozinho": { d: 32, L: 840, restr: 0.18, eff: 0.82, kg: 2.7, silencer: true, cat: false, low: -0.008, mid: 0.016, high: 0.022, resp: 0 },
  "escape-rua-bigode": { d: 27, L: 1080, restr: 0.26, eff: 0.78, kg: 4.3, silencer: true, cat: false, low: 0.02, mid: 0.0, high: -0.012, resp: 0 },
  "escape-rua-serrote": { d: 33, L: 800, restr: 0.17, eff: 0.84, kg: 2.4, silencer: true, cat: false, low: -0.015, mid: 0.012, high: 0.032, resp: 0 },
  "escape-rua-tubarao": { d: 35, L: 770, restr: 0.13, eff: 0.88, kg: 2.3, silencer: true, cat: false, low: -0.028, mid: 0.008, high: 0.048, resp: 0 },
  "escape-rua-caneta": { d: 26, L: 1120, restr: 0.3, eff: 0.72, kg: 4.6, silencer: true, cat: false, low: 0.024, mid: -0.004, high: -0.016, resp: 0 },
  "escape-ks": { d: 32, L: 820, restr: 0.2, eff: 0.8, kg: 3.2, silencer: true, cat: false, low: -0.015, mid: 0.015, high: 0.03, resp: 0.01 },
  "escape-inox-completo": { d: 33, L: 800, restr: 0.16, eff: 0.84, kg: 2.9, silencer: true, cat: false, low: -0.02, mid: 0.015, high: 0.035, resp: 0.01 },
  "escape-grs": { d: 35, L: 760, restr: 0.12, eff: 0.88, kg: 2.2, silencer: true, cat: false, low: -0.03, mid: 0.01, high: 0.05, resp: 0.02 },
};

export const exhaustSpec = (id: string | undefined) => EXHAUST_SPECS[id ?? ""] ?? EXHAUST_SPECS["escape-original"]!;

/** Gas flow demand vs the reference engine (cilindrada × rpm). */
const demand = (cc: number, rpm: number) => (cc / EXH_K.refCc) * (rpm / EXH_K.refRpm);
const bands = (rpm: number) => {
  const lo = rpm <= 5500 ? 1 : rpm < 7000 ? (7000 - rpm) / 1500 : 0;
  const hi = rpm >= 9000 ? 1 : rpm > 7500 ? (rpm - 7500) / 1500 : 0;
  return { lo, hi, mid: Math.max(0, 1 - lo - hi) };
};

/** Raw breathing efficiency of a pipe on an engine at an rpm (≈1). */
export function flowEff(x: ExhaustSpec, cc: number, rpm: number) {
  const q = demand(cc, rpm);
  const dIdeal = EXH_K.refD * Math.sqrt(q);
  const vRatio = (dIdeal / x.d) ** 2; // gas speed vs ideal
  const slow = vRatio < 1 ? EXH_K.slowLoss * (1 - vRatio) ** 2 * (rpm < 7000 ? 1.5 : 1) : 0;
  const pump = Math.min(0.35, x.restr * EXH_K.pump * q * q * (EXH_K.refD / x.d) ** 4);
  const tuned = EXH_K.refRpm * (EXH_K.tuneL / x.L);
  const tune = EXH_K.tune * x.eff * Math.exp(-(((rpm - tuned) / EXH_K.tuneWidth) ** 2));
  const b = bands(rpm);
  return (1 - slow - pump + tune) * (1 + b.lo * x.low + b.mid * x.mid + b.hi * x.high);
}

/** Power multiplier of the installed pipe vs the factory pipe on the factory engine (stock = 1). */
export function exhaustAt(id: string | undefined, cc: number, stockCc: number, rpm: number) {
  return flowEff(exhaustSpec(id), cc, rpm) / flowEff(exhaustSpec("escape-original"), stockCc, rpm);
}

/** Readable gas data for the pipe at an rpm. */
export function exhaustInfo(id: string | undefined, cc: number, rpm: number) {
  const x = exhaustSpec(id);
  const q = demand(cc, rpm);
  const dIdeal = EXH_K.refD * Math.sqrt(q);
  return { dIdeal, oversized: x.d > dIdeal * 1.08, undersized: x.d < dIdeal * 0.9, tunedRpm: EXH_K.refRpm * (EXH_K.tuneL / x.L) };
}
