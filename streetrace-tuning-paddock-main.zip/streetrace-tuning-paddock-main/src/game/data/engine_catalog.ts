/**
 * Catálogo técnico por fabricante/modelo/ano/versão. Cada grandeza tem valor, unidade (SI ou
 * declarada), fonte, data de consulta, confiança e origem. Sem evidência = DESCONHECIDO (valor null).
 * Fonte de geometria: src/game/data/biblia_2026.json (ficha do fabricante transcrita).
 */
import type { Origem } from "../physics-registry/constants";
export interface Param { valor: number | string | null; unidade: string; fonte: string; consulta: string; confianca: "alta" | "media" | "baixa" | "nenhuma"; origem: Origem }
const C = "2026-11-10";
const of = (valor: number | string, unidade: string, fonte = "biblia_2026.json (ficha do fabricante)"): Param => ({ valor, unidade, fonte, consulta: C, confianca: "alta", origem: "OFICIAL" });
const calc = (valor: number, unidade: string, formula: string): Param => ({ valor, unidade, fonte: formula, consulta: C, confianca: "alta", origem: "CALCULADO" });
const rod5 = (valor: number, unidade: string, fonte: string): Param => ({ valor, unidade, fonte, consulta: C, confianca: "media", origem: "MEDIDO" });
const unk = (unidade: string): Param => ({ valor: null, unidade, fonte: "sem documento", consulta: C, confianca: "nenhuma", origem: "DESCONHECIDO" });
const vd = (d: number, s: number) => Math.round((Math.PI / 4) * d * d * s / 100) / 10; // cm³

const F150 = "Ficha técnica Honda CG 150 Titan ESD 2004–2008 (fornecida pelo jogador)";
const F125 = "Ficha técnica Honda CG 125 1ª geração 1976–1982 (fornecida pelo jogador)";
const T150 = "Relações de transmissão Honda CG 150 Titan ESD carburada CDI 2004–2008 (dados OEM fornecidos pelo jogador; não usar CG 150 Sport)";
const T125 = "Relações de transmissão Honda CG 125 Bolinha 4 marchas (dados OEM fornecidos pelo jogador; não vale para versão 5 marchas)";
export interface EngineEntry { fabricante: string; modelo: string; ano: number | null; versao: string; configuracao: string; p: Record<string, Param> }
export const ENGINE_CATALOG: Record<string, EngineEntry> = {
  titan160: { fabricante: "Honda", modelo: "CG 160 Titan", ano: null, versao: "flex", configuracao: "monocilíndrico OHC 2 válvulas arrefecido a ar",
    p: { diametro: of(57.3, "mm"), curso: of(63.096, "mm"), cilindrada: calc(vd(57.3, 63.096), "cm³", "π/4·D²·S"), cilindros: of(1, "—"), valvulas: of(2, "—"),
      biela: rod5(104.5, "mm", "5 catálogos de reposição concordantes (OEM 13201-KRE-G00): Alto Giro, Moto Peças Center, TXK/Rota Brusca, TXK/Idyshop, Audax/Retífica Fronza — centro a centro 104,5 mm"), massaPistao: unk("kg"), taxaCompressao: of(9.5, "—", "Manual de Serviços Honda CG160 Fan ESDi / Titan EX (00X6B-KVSP-001), Especificações"), potencia: unk("cv"), torque: unk("N·m"), rpmPotencia: unk("rpm"), rpmTorque: unk("rpm"),
      pinoPistao: of(14.0, "mm", "Manual de Serviços Honda CG160 Fan ESDi / Titan EX (00X6B-KVSP-001), Especificações"), pressaoCombustivel: of("288–300", "kPa", "Manual de Serviços Honda CG160 Fan ESDi / Titan EX (00X6B-KVSP-001), Especificações"), marchaLenta: of(1400, "rpm", "Manual de Serviços Honda CG160 Fan ESDi / Titan EX (00X6B-KVSP-001), Especificações"),
      alimentacao: of("injeção eletrônica", "—"), combustivel: of("gasolina C / etanol hidratado", "—"), relacaoPrimaria: of("3,136 (69/22)", "—", "Manual de Serviços Honda CG160 Fan ESDi / Titan EX (00X6B-KVSP-001), Especificações"),
      relacoesCambio: of("1ª 2,785 (39/14) · 2ª 1,695 (39/23) · 3ª 1,300 (26/20) · 4ª 1,066 (32/30) · 5ª 0,916 (22/24)", "—", "Manual de Serviços Honda CG160 Fan ESDi / Titan EX (00X6B-KVSP-001), Especificações"), relacaoFinal: of("2,933 (44/15)", "—", "Manual de Serviços Honda CG160 Fan ESDi / Titan EX (00X6B-KVSP-001), Especificações"), limiteRpm: unk("rpm") } },
  factor150: { fabricante: "Yamaha", modelo: "Factor 150", ano: null, versao: "UBS flex", configuracao: "monocilíndrico SOHC 2 válvulas arrefecido a ar",
    p: { diametro: of(57.3, "mm"), curso: of(57.9, "mm"), cilindrada: calc(vd(57.3, 57.9), "cm³", "π/4·D²·S"), cilindros: of(1, "—"), valvulas: of(2, "—"),
      biela: unk("mm"), massaPistao: unk("kg"), taxaCompressao: of(9.6, "—", "Manual de Serviço Yamaha Factor YBR150 ED UBS BlueFlex (2RP-F8197-W2), Especificações do motor"), potencia: of(12.4, "cv", "Ficha técnica Yamaha Factor 150 UBS (concessionária Yamaha)"), torque: of(12.75, "N·m", "1,3 kgf·m × 9,80665 — " + "Ficha técnica Yamaha Factor 150 UBS (concessionária Yamaha)"), rpmPotencia: of(7500, "rpm", "Ficha técnica Yamaha Factor 150 UBS (concessionária Yamaha)"), rpmTorque: of(5500, "rpm", "Ficha técnica Yamaha Factor 150 UBS (concessionária Yamaha)"),
      pinoPistao: of(15.0, "mm", "Manual de Serviço Yamaha Factor YBR150 ED UBS BlueFlex (2RP-F8197-W2), Especificações do motor"), pressaoCombustivel: of("300–390", "kPa", "Manual de Serviço Yamaha Factor YBR150 ED UBS BlueFlex (2RP-F8197-W2), Especificações do motor"), marchaLenta: of(1400, "rpm", "Manual de Serviço Yamaha Factor YBR150 ED UBS BlueFlex (2RP-F8197-W2), Especificações do motor"),
      alimentacao: of("injeção eletrônica", "—"), combustivel: of("gasolina C / etanol hidratado", "—"), relacaoPrimaria: of("3,409 (75/22)", "—", "Manual de Serviço Yamaha Factor YBR150 ED UBS BlueFlex (2RP-F8197-W2), Especificações do motor"),
      relacoesCambio: of("1ª 2,714 (38/14) · 2ª 1,789 (34/19) · 3ª 1,318 (29/22) · 4ª 1,045 (23/22) · 5ª 0,875 (21/24)", "—", "Manual de Serviço Yamaha Factor YBR150 ED UBS BlueFlex (2RP-F8197-W2), Especificações do motor"), relacaoFinal: of("2,786 (39/14)", "—", "Manual de Serviço Yamaha Factor YBR150 ED UBS BlueFlex (2RP-F8197-W2), Especificações do motor"), limiteRpm: unk("rpm") } },
  titan150: { fabricante: "Honda", modelo: "CG 150 Titan ESD", ano: 2006, versao: "ESD 2004–2008 carburada", configuracao: "monocilíndrico OHC 2 válvulas arrefecido a ar",
    p: { diametro: of(57.3, "mm", F150), curso: of(57.8, "mm", F150), cilindrada: calc(vd(57.3, 57.8), "cm³", "π/4·D²·S"), cilindros: of(1, "—", F150), valvulas: of(2, "—", F150),
      biela: unk("mm"), massaPistao: unk("kg"), taxaCompressao: of(9.5, "—", F150), potencia: of(14.2, "cv", F150), torque: of(13.24, "N·m", "1,35 kgf·m × 9,80665 — " + F150), rpmPotencia: of(8000, "rpm", F150), rpmTorque: of(6500, "rpm", F150),
      alimentacao: of("carburador 22 mm a vácuo", "—", F150), combustivel: of("gasolina", "—", F150),
      relacaoPrimaria: of("3,350", "—", T150), relacoesCambio: of("1ª 2,785 · 2ª 1,789 · 3ª 1,350 · 4ª 1,090 · 5ª 0,937", "—", T150), relacaoFinal: of("2,687 (43/16)", "—", T150), limiteRpm: unk("rpm") } },
  cg125: { fabricante: "Honda", modelo: "CG 125 (1ª geração, Bolinha)", ano: 1979, versao: "1976–1982 kick, platinado 6V", configuracao: "monocilíndrico OHV 2 válvulas arrefecido a ar",
    p: { diametro: of(56.5, "mm", F125), curso: of(49.5, "mm", F125), cilindrada: calc(vd(56.5, 49.5), "cm³", "π/4·D²·S"), cilindros: of(1, "—", F125), valvulas: of(2, "—", F125),
      biela: unk("mm"), massaPistao: unk("kg"), taxaCompressao: of(9.0, "—", F125), potencia: of(11, "cv", F125), torque: of(9.22, "N·m", "0,94 kgf·m × 9,80665 — " + F125), rpmPotencia: of(9000, "rpm", F125), rpmTorque: of(7500, "rpm", F125),
      alimentacao: of("carburador Keihin 20 mm", "—", F125), combustivel: of("gasolina", "—", F125),
      relacaoPrimaria: of("4,055", "—", T125), relacoesCambio: of("1ª 2,769 · 2ª 1,722 · 3ª 1,272 · 4ª 1,000", "—", T125), relacaoFinal: of("2,533 (38/15)", "—", T125), limiteRpm: unk("rpm") } },
};
/** Curso por moto; nunca cai em valor universal. Sem ficha → null (bloqueia). */
export const strokeMmOf = (bikeId: string): number | null => { const v = ENGINE_CATALOG[bikeId]?.p["curso"]?.valor; return typeof v === "number" ? v : null; };
/** Biela (centro a centro, mm) por moto; sem documento → null (DESCONHECIDO). */
export const rodMmOf = (bikeId: string): number | null => { const v = ENGINE_CATALOG[bikeId]?.p["biela"]?.valor; return typeof v === "number" ? v : null; };
