/**
 * Usinagem livre por escrita: o jogador fala com o mecânico, ele mede e executa.
 * Tudo sai da geometria real do motor montado (mechlimits.buildOf / physicsAt) — sem sorteio.
 */
import { CAVA_STD_MM, CROWN_MM, CROWN_SAFE_MM, buildOf, machOf } from "./mechlimits";
import { ccOf, engine, type BikeModel, type Setup } from "./physics";
import { slotPart } from "./parts";
import { platformOf } from "./platform/platforms";
import { FRESA_FOLGA_MM, bordaAtropela, camLiftMm, cavaDiamOf, cavaVolumeCm3, valvesOf, type Valvulas } from "./sintonia";

/** Menor parede de coroa que a fresa deixa (abaixo disso atravessa o pistão). */
export const CROWN_MIN_MM = 0.8;
/** Rebaixo máximo do cabeçote antes de chegar na sede das válvulas. */
export const REBAIXO_MAX_MM = 6.0;
/** Fresa da cava = válvula instalada + folga radial; volume sai da área real das duas válvulas. */
const fresaOf = (b: BikeModel, s: Setup): Valvulas => { const v = valvesOf(b.id, s); return { adm: r2(v.adm + FRESA_FOLGA_MM), esc: r2(v.esc + FRESA_FOLGA_MM) }; };
const pocketCm3 = (b: BikeModel, s: Setup, dh: number) => cavaVolumeCm3(fresaOf(b, s), dh);
/** Altura máxima de solda antes da vela/face: câmara esférica (OHV) é mais funda que a pentroof (OHC). */
export function domeMaxMm(b: BikeModel, s: Setup) {
  const ohv = platformOf(b.id)?.motor.arquitetura === "OHV";
  return r2((ohv ? 6.0 : 5.0) - (s.mach?.rebaixoMm ?? 0) * 0.5);
}
export const PRICE = { cavaPorMm: 120, rebaixoPorMm: 260, minimo: 80 };

export interface Medidas {
  cc: number;
  boreMm: number;
  cavaMm: number;
  coroaMm: number;
  coroaLimC: number;
  rebaixoMm: number;
  taxa: number;
  folgaMm: number;
  folgaCorteMm: number;
  rpmCorte: number;
}

const r2 = (n: number) => Math.round(n * 100) / 100;

export function medidas(b: BikeModel, s: Setup): Medidas {
  const k = buildOf(b, s);
  const cavasPart = !!slotPart(s.slots.pistao, "pistao").cavas || s.services.includes("cavas-pistao");
  const m = machOf(s, cavasPart);
  const e = engine(b, s);
  const folgaCorte = k.clearance0 - 0.3 * (e.rpmLimit / 9000) ** 2 - Math.max(0, e.rpmLimit - k.floatRpm) * 0.004;
  return { cc: r2(ccOf(b, s)), boreMm: r2(k.boreMm), cavaMm: r2(m.cavaMm), coroaMm: m.crownMm, coroaLimC: m.pistonLimC, rebaixoMm: r2(s.mach?.rebaixoMm ?? 0), taxa: r2(s.compression), folgaMm: r2(k.clearance0), folgaCorteMm: r2(folgaCorte), rpmCorte: e.rpmLimit };
}

/** Nova taxa quando o volume da câmara muda dV (cm³): CR = (Vs + Vc) / Vc. */
export function taxaCom(b: BikeModel, s: Setup, dVcm3: number) {
  const vs = ccOf(b, s);
  const vc = vs / (s.compression - 1) + dVcm3;
  return r2((vs + vc) / vc);
}

/** Medidas de taxa da Preparação (mm totais na peça). */
/** Medida padrão de toda usinagem em mm (rebaixo, solda, cava e curso usam a mesma escala). */
export const MEDIDAS_MM = [0.3, 0.6, 0.9, 1.2, 1.5, 1.8, 2.1, 2.4, 2.7, 3.0, 4.0, 5.0, 6.0];
export const REBAIXO_OPCOES = MEDIDAS_MM;
export const DOME_OPCOES = MEDIDAS_MM;
export const CAVA_OPCOES = MEDIDAS_MM;
export const DOME_POR_MM = 300;
const areaCm2 = (b: BikeModel, s: Setup) => (Math.PI * (buildOf(b, s).boreMm / 10) ** 2) / 4;
/** Rebaixa o cabeçote até `alvo` mm no total: tira π·D²/4 × Δh da câmara da moto montada. */
export function taxarCabecote(b: BikeModel, s: Setup, alvo: number) {
  const atual = s.mach?.rebaixoMm ?? 0, dh = r2(alvo - atual);
  if (dh <= 0) return null;
  const vc = ccOf(b, s) / (s.compression - 1), dV = areaCm2(b, s) * dh / 10;
  if (dV >= vc * 0.9) return null; // a face do cabeçote encosta no pistão: não sobra câmara
  const setup: Setup = { ...s, mach: { ...s.mach, rebaixoMm: alvo }, compression: taxaCom(b, s, -dV) };
  return { setup, preco: Math.max(PRICE.minimo, Math.round(PRICE.rebaixoPorMm * dh)) };
}
/** Enche a cabeça do pistão com solda até `alvo` mm no total: o volume sobe para dentro da câmara. */
export function taxarPistao(b: BikeModel, s: Setup, alvo: number) {
  const atual = s.mach?.domeMm ?? 0, dh = alvo - atual;
  if (dh <= 0 || alvo > domeMaxMm(b, s)) return null;
  const vc = ccOf(b, s) / (s.compression - 1), dV = areaCm2(b, s) * dh / 10;
  if (dV >= vc * 0.9) return null; // não cabe na câmara
  const setup: Setup = { ...s, mach: { ...s.mach, domeMm: alvo }, compression: taxaCom(b, s, -dV) };
  return { setup, preco: Math.round(DOME_POR_MM * dh) };
}

/** Cava máxima que o pistão montado aguenta: coroa nunca abaixo de CROWN_SAFE_MM e as duas fresas cabem no Ø com 1 mm de parede de cada lado. */
export function cavaMaxMm(b: BikeModel, s: Setup) {
  const f = fresaOf(b, s), bore = buildOf(b, s).boreMm;
  if (Math.max(f.adm, f.esc) > bore - 2) return 0;
  return r2(CROWN_MM - CROWN_SAFE_MM);
}
/** Aprofunda a cava das válvulas até `alvo` mm no total: ganha folga válvula-pistão, abre volume na câmara (taxa cai) e afina a coroa. */
export function cavarValvulas(b: BikeModel, s: Setup, alvo: number) {
  const cavasPart = !!slotPart(s.slots.pistao, "pistao").cavas || s.services.includes("cavas-pistao");
  const atual = machOf(s, cavasPart).cavaMm, dh = r2(alvo - atual);
  if (dh <= 0 || alvo > cavaMaxMm(b, s)) return null;
  const fresa = fresaOf(b, s);
  // fresa nova mais larga refaz a parede lateral em toda a profundidade
  const old = cavaDiamOf(b.id, s), largura = atual > 0 ? cavaVolumeCm3({ adm: Math.max(0, fresa.adm ** 2 - old.adm ** 2) ** 0.5, esc: Math.max(0, fresa.esc ** 2 - old.esc ** 2) ** 0.5 }, atual) : 0;
  const setup: Setup = { ...s, mach: { ...s.mach, cavaMm: alvo, cavaDiam: fresa }, compression: taxaCom(b, s, pocketCm3(b, s, dh) + largura) };
  return { setup, preco: Math.max(PRICE.minimo, Math.round(PRICE.cavaPorMm * dh)), fresa };
}


/** Fala técnica do mecânico com os números reais da peça montada. */
export function laudoMedidas(b: BikeModel, s: Setup) {
  const md = medidas(b, s), v = valvesOf(b.id, s), f = fresaOf(b, s);
  return `Pistão Ø ${fmt(md.boreMm)} mm, válvulas ${fmt(v.adm)}/${fmt(v.esc)} mm, fresa ${fmt(f.adm)}/${fmt(f.esc)} mm, levante ${fmt(camLiftMm(s.cam))} mm. Folga parada ${fmt(md.folgaMm)} mm, no corte de ${md.rpmCorte.toLocaleString("pt-BR")} rpm: ${fmt(md.folgaCorteMm)} mm.${bordaAtropela(b.id, s) && (s.mach?.cavaMm ?? 0) > 0 ? " Atenção: válvula maior que a cava, a borda vai atropelar." : ""}`;
}

export interface Resposta {
  texto: string;
  /** Serviço a cobrar/aplicar; ausente = só conversa. */
  servico?: { nome: string; preco: number; setup: Setup };
}

const num = (t: string) => {
  const m = t.match(/(\d+(?:[.,]\d+)?)\s*(mm|milimetro|milímetro|decimo|décimo)?/);
  if (!m) return null;
  const v = parseFloat(m[1]!.replace(",", "."));
  return m[2] && /d[eé]cimo/.test(m[2]) ? v / 10 : v;
};

const fmt = (n: number) => n.toLocaleString("pt-BR", { maximumFractionDigits: 2 });

export function conversar(b: BikeModel, s: Setup, frase: string): Resposta {
  const t = frase.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const md = medidas(b, s);
  const pergunta = /\?|quanto|qual|mede|medida|tem|falta|resta/.test(t) && !/\b(pode|faz|abre|cava|rebaix|tira|usina)\w*\b.*\d/.test(t);
  const v = num(t);

  if (/cava|coroa|cabeca do pistao|pistao/.test(t)) {
    const resta = r2(md.coroaMm - CROWN_MIN_MM);
    if (pergunta || v === null) {
      return { texto: `Passei o paquímetro: coroa de ${fmt(CROWN_MM)} mm, cava atual ${fmt(md.cavaMm)} mm, sobra ${fmt(md.coroaMm)} mm de parede. A fresa ainda entra ${fmt(Math.max(0, resta))} mm antes de atravessar; abaixo de ${fmt(CROWN_SAFE_MM)} mm a coroa perde resistência ao calor (limite hoje ${md.coroaLimC} °C). Folga válvula-pistão parada ${fmt(md.folgaMm)} mm, no corte ${fmt(md.folgaCorteMm)} mm.` };
    }
    if (v <= 0) return { texto: "Fala quantos milímetros quer cavar." };
    if (v > resta) return { texto: `Não dá: ${fmt(v)} mm atravessa o pistão. Sobram ${fmt(md.coroaMm)} mm e preciso deixar ${fmt(CROWN_MIN_MM)} mm de parede, então o máximo é ${fmt(Math.max(0, resta))} mm.` };
    const cava = r2(md.cavaMm + v);
    const ns: Setup = { ...s, mach: { ...s.mach, cavaMm: cava, cavaDiam: fresaOf(b, s) }, compression: taxaCom(b, s, pocketCm3(b, s, v)) };
    const after = medidas(b, ns);
    const aviso = after.coroaMm < CROWN_SAFE_MM ? ` Atenção: coroa com ${fmt(after.coroaMm)} mm, o alumínio agora cede a ${after.coroaLimC} °C.` : "";
    return {
      texto: `Cavei ${fmt(v)} mm: cava ${fmt(md.cavaMm)} → ${fmt(cava)} mm, coroa ${fmt(md.coroaMm)} → ${fmt(after.coroaMm)} mm. Folga parada ${fmt(md.folgaMm)} → ${fmt(after.folgaMm)} mm, no corte ${fmt(after.folgaCorteMm)} mm. Fresa ${fmt(fresaOf(b, s).adm)}/${fmt(fresaOf(b, s).esc)} mm, câmara ganhou ${fmt(pocketCm3(b, s, v))} cm³: taxa ${fmt(md.taxa)} → ${fmt(after.taxa)}:1.${aviso}`,
      servico: { nome: `Cavar pistão +${fmt(v)} mm`, preco: Math.max(PRICE.minimo, Math.round(PRICE.cavaPorMm * v)), setup: ns },
    };
  }

  if (/cabecote|rebaix|faceia|planific/.test(t)) {
    const resta = r2(REBAIXO_MAX_MM - md.rebaixoMm);
    const area = (Math.PI * (md.boreMm / 10) ** 2) / 4;
    if (pergunta || v === null) {
      return { texto: `Cabeçote rebaixado ${fmt(md.rebaixoMm)} mm; ainda dá ${fmt(resta)} mm antes da sede. Cada 0,1 mm tira ${fmt(area * 0.01)} cm³ da câmara e 0,1 mm de folga válvula-pistão. Taxa hoje ${fmt(md.taxa)}:1, folga parada ${fmt(md.folgaMm)} mm.` };
    }
    if (v <= 0) return { texto: "Fala quantos milímetros quer tirar do cabeçote." };
    if (v > resta) return { texto: `Não dá: o máximo que ainda sai são ${fmt(resta)} mm, depois disso chega na sede das válvulas.` };
    const ns: Setup = { ...s, mach: { ...s.mach, rebaixoMm: r2(md.rebaixoMm + v) }, compression: taxaCom(b, s, -area * v / 10) };
    const after = medidas(b, ns);
    const aviso = after.folgaCorteMm < 0 ? ` Cuidado: no corte (${after.rpmCorte} rpm) a válvula já encosta no pistão (${fmt(after.folgaCorteMm)} mm).` : "";
    return {
      texto: `Tirei ${fmt(v)} mm do cabeçote: câmara perdeu ${fmt(area * v / 10)} cm³, taxa ${fmt(md.taxa)} → ${fmt(after.taxa)}:1. Folga parada ${fmt(md.folgaMm)} → ${fmt(after.folgaMm)} mm.${aviso}`,
      servico: { nome: `Rebaixar cabeçote ${fmt(v)} mm`, preco: Math.max(PRICE.minimo, Math.round(PRICE.rebaixoPorMm * v)), setup: ns },
    };
  }

  if (/taxa|compress/.test(t)) return { texto: `Taxa ${fmt(md.taxa)}:1 com ${fmt(md.cc)} cc (Ø ${fmt(md.boreMm)} mm). Câmara de ${fmt(md.cc / (md.taxa - 1))} cm³.` };
  if (/folga|valvula/.test(t)) return { texto: `Folga válvula-pistão: ${fmt(md.folgaMm)} mm parada, ${fmt(md.folgaCorteMm)} mm no corte de ${md.rpmCorte} rpm. Abaixo de 0 a válvula bate.` };

  const conta = calcular(frase);
  if (conta) return { texto: conta };
  return { texto: "" };
}

/** Conta direta (ex.: "quanto é 70x5"): resolve na hora, sem depender da IA. */
export function calcular(frase: string): string | null {
  const e = frase.toLowerCase().replace(/quanto\s*(e|é)|calcula|resultado|de|\?|=/g, " ").replace(/,/g, ".").replace(/[x×]/g, "*").replace(/÷/g, "/").replace(/\^/g, "**").trim();
  if (!/^[\d.\s+\-*/()]+$/.test(e) || !/\d\s*(\*\*|[+\-*/])\s*[\d(]/.test(e)) return null;
  try {
    const v = Function(`"use strict";return (${e})`)() as number;
    if (!Number.isFinite(v)) return null;
    return `${e.replace(/\*\*/g, "^").replace(/\*/g, "×").replace(/\s+/g, " ")} = ${fmt(Math.round(v * 1e6) / 1e6)}`;
  } catch { return null; }
}

export { CAVA_STD_MM };

/** Assentamento de válvula: afunda a sede (mm). A válvula fica mais longe do pistão (+folga) e a câmara cresce (taxa cai). */
export const ASSENTO_OPCOES = [0.2, 0.4, 0.6] as const;
export function assentarValvulas(b: BikeModel, s: Setup, alvo: number) {
  const atual = s.mach?.assentoMm ?? 0, dh = r2(alvo - atual);
  if (dh <= 0) return null;
  const v = valvesOf(b.id, s);
  const setup: Setup = { ...s, mach: { ...s.mach, assentoMm: alvo }, compression: taxaCom(b, s, cavaVolumeCm3(v, dh)) };
  return { setup, preco: Math.max(PRICE.minimo, Math.round(PRICE.cavaPorMm * dh)) };
}
