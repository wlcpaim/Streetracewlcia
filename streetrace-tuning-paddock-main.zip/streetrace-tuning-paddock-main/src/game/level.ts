// Level-up perks: every XP gain goes through gainXp() so cash bonus, card limit and delivery speed stay consistent.
import { addXp, xpToNext } from "./trampo";
import { creditLimit, earn } from "./credit";
import type { Player } from "./store";

/** Cash bonus for reaching `level`: R$ 500 base, +3% compounded per level (level 2 = 500 +3%). */
export const levelBonus = (level: number) => Math.round(500 * Math.pow(1.03, Math.max(0, level - 1)));
/** Card limit grows 2.5% per level gained. */
export const CREDIT_PER_LEVEL = 0.025;
/** Delivery/ride time multiplier: −1% per level. */
export const tripMul = (level: number) => Math.pow(0.99, Math.max(0, level - 1));

export function gainXp(pl: Player, gained: number): { player: Player; ups: number; bonus: number } {
  const lv = addXp(pl.level, pl.xp ?? 0, gained);
  const ups = lv.level - pl.level;
  let bonus = 0;
  for (let l = pl.level + 1; l <= lv.level; l++) bonus += levelBonus(l);
  const base: Player = { ...pl, level: lv.level, xp: lv.xp, maxXp: Math.max(peakXp(pl), totalXp(lv.level, lv.xp)), ...(ups > 0 ? { creditLimit: Math.round(creditLimit(pl) * Math.pow(1 + CREDIT_PER_LEVEL, ups) * 100) / 100 } : {}) };
  return { player: bonus ? earn(base, bonus) : base, ups, bonus };
}

/** XP total acumulado: todos os níveis já fechados + XP do nível atual. */
export function totalXp(level: number, xp: number) {
  let t = xp;
  for (let l = 1; l < level; l++) t += xpToNext(l);
  return t;
}
/** Converte XP total em nível + XP do nível (inverso de totalXp). */
export const fromTotalXp = (total: number) => addXp(1, 0, Math.max(0, total));
/** Maior XP total já obtido pelo jogador. */
export const peakXp = (pl: Pick<Player, "level" | "xp" | "maxXp">) => Math.max(pl.maxXp ?? 0, totalXp(pl.level, pl.xp ?? 0));
/** Abandonar corrida custa 10% do XP máximo já obtido (pode regredir de nível). */
export const QUIT_PENALTY = 0.1;
export function quitPenalty(pl: Pick<Player, "level" | "xp" | "maxXp">) {
  const loss = Math.round(peakXp(pl) * QUIT_PENALTY);
  const after = fromTotalXp(totalXp(pl.level, pl.xp ?? 0) - loss);
  return { loss, level: after.level, xp: after.xp };
}
