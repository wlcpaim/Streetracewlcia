// COMPLEGAME · sprites arquivados das motos (piloto em moto e moto sozinha).
// Fora do STARTGAME até os novos sprites chegarem; nada foi apagado do CDN.
// Para reativar uma moto, copie o conjunto dela de volta para BIKE_ART em src/game/assets.ts.
export type BikeSpriteSet = { solo: string; brand: string; foot: string; g1: string; crouch: string; tuck: string };
export const ARCHIVED_BIKE_ART: Record<string, BikeSpriteSet> = {};
/** Imagens avulsas arquivadas (vitrines antigas e poses só-piloto). */
export const ARCHIVED_BIKE_IMG: Record<string, string> = {};
