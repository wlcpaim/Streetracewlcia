import { serviceById, type Setup } from "./physics";
import type { Slot } from "./parts";

/** Peça dona de cada serviço de usinagem. A preparação é gravada na peça: sai com ela e volta com ela. */
const SERVICE_OWNER: Record<string, Slot> = {
  "alivio-biela": "biela", "biela-forjada": "biela",
  "pino-2": "vira", "pino-4": "vira", "alivio-volante": "vira", balanceamento: "vira",
  "tbi-34": "tbi", "tbi-36": "tbi", coletor: "tbi", "limpeza-bico": "bico",
  "emb-esportivo": "embreagem",
};
const GROUP_OWNER: Partial<Record<string, Slot>> = { cilindro: "cilindro", pistao: "pistao", escape: "escape", embreagem: "embreagem" };
/** Slot que carrega a usinagem do serviço (null = cabeçote/comando, que têm estoque próprio). */
export function serviceOwner(id: string): Slot | null {
  if (SERVICE_OWNER[id]) return SERVICE_OWNER[id]!;
  if (/^pino-\d+$/.test(id)) return "vira"; // todo curso fica gravado no virabrequim
  const g = serviceById(id)?.group;
  return g ? GROUP_OWNER[g] ?? null : null;
}
const isFactory = (id: string | undefined) => !id || id.endsWith("-original");

/** Serviços gravados numa peça solta (id da peça → serviços). Inclui o curso legado (viraStroke). */
export function prepOfPart(s: Setup, id: string): string[] {
  const own = s.partPrep?.[id];
  if (own) return own;
  const legacy = s.viraStroke?.[id];
  return legacy ? [legacy] : [];
}

/** Machining belongs to the installed component, never its replacement: the leaving piece keeps its signature. */
export function swapSlot(s: Setup, slot: Slot, id: string): Setup {
  if (s.slots[slot] === id) return s;
  const { mach: m0, ...rest } = s;
  const old = s.slots[slot];
  const leaving = s.services.filter((x) => serviceOwner(x) === slot);
  const partPrep = { ...(s.partPrep ?? {}) };
  const partMach = { ...(s.partMach ?? {}) };
  let viraStroke = s.viraStroke ? { ...s.viraStroke } : undefined;
  if (old && !isFactory(old)) {
    if (leaving.length) partPrep[old] = leaving; else delete partPrep[old];
    if (viraStroke) delete viraStroke[old];
    if (slot === "pistao") { if (m0?.cavaMm !== undefined) partMach[old] = { cavaMm: m0.cavaMm, ...(m0.cavaDiam ? { cavaDiam: m0.cavaDiam } : {}) } as never; else delete partMach[old]; }
  }
  const back = prepOfPart(s, id);
  if (viraStroke && viraStroke[id]) delete viraStroke[id];
  delete partPrep[id];
  const services = [...s.services.filter((x) => serviceOwner(x) !== slot), ...back.filter((x) => !!serviceById(x))];
  let mach = m0;
  if (slot === "pistao") {
    const cava = partMach[id]?.cavaMm, cavaDiam = (partMach[id] as { cavaDiam?: { adm: number; esc: number } } | undefined)?.cavaDiam; delete partMach[id];
    const next = { ...(m0?.rebaixoMm !== undefined ? { rebaixoMm: m0.rebaixoMm } : {}), ...(cava !== undefined ? { cavaMm: cava, ...(cavaDiam ? { cavaDiam } : {}) } : {}) };
    mach = Object.keys(next).length ? next : undefined;
  }
  if (viraStroke && !Object.keys(viraStroke).length) viraStroke = undefined;
  return {
    ...rest, ...(mach ? { mach } : {}), ...(viraStroke ? { viraStroke } : {}),
    ...(Object.keys(partPrep).length ? { partPrep } : {}), ...(Object.keys(partMach).length ? { partMach } : {}),
    slots: { ...s.slots, [slot]: id }, services,
  };
}

/** Texto curto da assinatura gravada na peça solta (vazio se não tem preparação). */
export function prepLabel(s: Setup, id: string): string {
  const names = prepOfPart(s, id).map((x) => serviceById(x)?.name).filter(Boolean);
  const cava = s.partMach?.[id]?.cavaMm;
  if (cava !== undefined) names.push(`cava ${cava} mm`);
  return names.length ? ` · preparada: ${names.join(", ")}` : "";
}
/** Valor de mão de obra gravado na peça (R$ dos serviços feitos nela). */
export const prepValue = (s: Setup, id: string) => prepOfPart(s, id).reduce((n, x) => n + (serviceById(x)?.price ?? 0), 0);
