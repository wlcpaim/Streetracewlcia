// Hall da Fama: só jogadores reais, lido de partidas 1x1 calculadas no servidor. Temporada = mês corrente (UTC), reinicia sozinha.
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { seasonStart, type HallRow } from "./season";

const In = z.object({ board: z.enum(["competitivo", "casual", "recordes"]), scope: z.enum(["temporada", "geral"]), distance: z.number().optional() });

export const hallOfFame = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => In.parse(d))
  .handler(async ({ data }): Promise<{ season: string; rows: HallRow[] }> => {
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    const start = seasonStart(new Date());
    const season = start.toISOString().slice(0, 7);
    let q = db.from("x1_matches").select("a_player,b_player,a_user,b_user,a_name,b_name,a_time,b_time,result_a,mode,distance,a_top,b_top,created_at").eq("status" as never, "ok" as never).limit(5000);
    if (data.scope === "temporada") q = q.gte("created_at", start.toISOString());
    if (data.board === "casual") q = q.eq("mode", "casual");
    if (data.board === "competitivo") q = q.eq("mode", "ranked");
    if (data.board === "recordes" && data.distance) q = q.eq("distance", data.distance);
    const { data: ms0 } = await q;
    // Só jogadores reais: descarta partidas de contas que não existem mais (ex.: contas de teste apagadas).
    const pids = [...new Set((ms0 ?? []).flatMap((m) => [m.a_player, m.b_player]))];
    const { data: alive } = pids.length ? await db.from("players").select("id").in("id", pids) : { data: [] as { id: string }[] };
    const ok = new Set((alive ?? []).map((x) => x.id));
    const ms = (ms0 ?? []).filter((m) => ok.has(m.a_player) && ok.has(m.b_player));
    const sides = ms.flatMap((m) => [
      { user: m.a_user, name: m.a_name, time: m.a_time, top: m.a_top, s: m.result_a },
      { user: m.b_user, name: m.b_name, time: m.b_time, top: m.b_top, s: 1 - m.result_a },
    ]);
    const by = new Map<string, HallRow>();
    for (const x of sides) {
      const r = by.get(x.user) ?? { name: x.name, wins: 0, losses: 0, matches: 0, value: data.board === "recordes" ? Infinity : 0 };
      r.name = x.name; r.matches++; if (x.s === 1) r.wins++; if (x.s === 0) r.losses++;
      if (data.board === "recordes" && x.time != null && x.time < r.value) { r.value = x.time; r.top = x.top; }
      by.set(x.user, r);
    }
    if (data.board === "competitivo") {
      const ids = [...by.keys()];
      if (data.scope === "geral") {
        const { data: mm } = await db.from("player_mmr").select("user_id,mmr,matches").eq("category", "ranked_1x1").in("user_id", ids.length ? ids : ["00000000-0000-0000-0000-000000000000"]);
        for (const m of mm ?? []) { const r = by.get(m.user_id); if (r) { r.value = m.matches >= 10 ? m.mmr : 0; r.calibrating = m.matches < 10; } }
      } else {
        const { data: h } = await db.from("mmr_history").select("user_id,delta").eq("category", "ranked_1x1").gte("created_at", start.toISOString());
        for (const x of h ?? []) { const r = by.get(x.user_id); if (r) r.value += x.delta; }
      }
    }
    let rows = [...by.values()];
    if (data.board === "recordes") rows = rows.filter((r) => Number.isFinite(r.value)).sort((a, b) => a.value - b.value);
    else if (data.board === "casual") rows.sort((a, b) => b.wins - a.wins || a.losses - b.losses);
    else rows.sort((a, b) => Number(!!a.calibrating) - Number(!!b.calibrating) || b.value - a.value || b.wins - a.wins);
    return { season, rows: rows.slice(0, 50) };
  });
