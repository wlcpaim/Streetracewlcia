/** Temporada mensal: começa no dia 1 às 00:00 UTC; o Geral nunca reinicia. */
export const seasonStart = (d: Date) => new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1));
export interface HallRow { name: string; wins: number; losses: number; matches: number; value: number; top?: number; calibrating?: boolean }
