// Visual-only randomness for race lanes and evasive moves (never touches physics/results).
// Every draw is a fair 50/50 between sides and every maneuver gets its own reaction,
// lateral distance and lean speed, so the race never repeats the same visual pattern.
export type Rand = () => number;

/** Fair coin: true/false with exactly 50% each. */
export const coin = (r: Rand) => r() < 0.5;

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

/** 1x1 start: same spacing as Bololo — two neighbouring Bololo lines (1/3 apart, small jitter); 50% the player starts on top. */
export function startLanes(r: Rand): { m: number; o: number } {
  const k = Math.floor(r() * 7); // pair of neighbouring lines out of 8
  const low = k / 7, high = (k + 1) / 7;
  return coin(r) ? { m: high, o: low } : { m: low, o: high };
}

/** Bololo start: 4 distinct lanes in a random order, each with a small jitter that keeps them ≥ 0.25 apart. */
export function startGrid4(r: Rand): number[] {
  // 4 riders on alternate operable lines of the 8 (one empty line between them = 10 m)
  const off = r() < 0.5 ? 0 : 1;
  const base = [0, 2, 4, 6].map((k) => (k + off) / 7);
  for (let i = base.length - 1; i > 0; i--) {
    const j = Math.floor(r() * (i + 1));
    [base[i], base[j]] = [base[j]!, base[i]!];
  }
  return base;
}

export interface Maneuver {
  /** reaction time (s) used to anticipate the closing speed */
  react: number;
  /** lateral distance away from the leader (lanes) */
  offset: number;
  /** lean stiffness multiplier */
  gain: number;
  /** max lateral speed multiplier */
  vmax: number;
}

/** A fresh style per evasive move. */
export function rollManeuver(r: Rand): Maneuver {
  return { react: lerp(0.45, 1.0, r()), offset: (r() < 0.5 ? 1 : 2) / 7, gain: lerp(0.7, 1.35, r()), vmax: lerp(0.8, 1.25, r()) };
}

/** Target lane to evade a leader at `lead`: fair 50/50 up/down; only forced to one side when the other leaves the road. */
export function evadeLane(lead: number, m: Maneuver, r: Rand): number {
  const up = lead + m.offset, dn = lead - m.offset;
  const okUp = up <= 1 + 1e-9, okDn = dn >= -1e-9;
  if (okUp && okDn) return coin(r) ? up : dn;
  if (okUp) return up;
  if (okDn) return dn;
  return lead >= 0.5 ? lead - 1 / 7 : lead + 1 / 7;
}
