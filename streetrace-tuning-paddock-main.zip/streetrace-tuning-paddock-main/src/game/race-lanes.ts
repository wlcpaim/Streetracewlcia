// Race lane placement. Bikes keep one fixed on-screen wheelbase in every lane and pose;
// changing lane only shifts the bike up/down on the same asphalt (no fake perspective, no Y/lane scale).
import { calOf, type SpriteCal } from "./sprite-calibration";

export const SPRITE_PCT = 60;
export const LANE_BOTTOM_PCT = 10; // front lane (0)
/** Breathing step: 3% per neighbouring line (7 gaps between the 8 operable lines); only moves the bike up, never scales it. */
export const LANE_STEP_PCT = 21;

export function laneBottomPct(lane: number): number {
  const l = Math.max(0, Math.min(1, lane));
  return LANE_BOTTOM_PCT + LANE_STEP_PCT * l;
}

/** Sprite geometry as fractions of its own image: rear/front tire contact centre (B/A, of width), ground line (of height), H/W. */
export type SpriteGeo = { B: number; A: number; ground: number; aspect: number };
/** Reference: the normalized 1536×1200 race art (wheel centres 0.201/0.819, asphalt 0.951). */
export const REF_GEO: SpriteGeo = { B: 0.201, A: 0.819, ground: 0.951, aspect: 1200 / 1536 };
/** Common on-screen distance between the two wheel centres, % of the scene width. */
export const REF_WHEELBASE_PCT = SPRITE_PCT * (REF_GEO.A - REF_GEO.B);

export const geoFromCal = (c: SpriteCal): SpriteGeo => ({ B: c.rearAxleX / c.imageWidth, A: c.frontAxleX / c.imageWidth, ground: c.groundLineY / c.imageHeight, aspect: c.imageHeight / c.imageWidth });
/** Calibrated geometry of a race image; an uncalibrated image falls back to the reference (and fails the coverage test). */
export const geoOf = (src: string): SpriteGeo => { const c = calOf(src); return c ? geoFromCal(c) : REF_GEO; };

/** largura_renderizada = distância_visual_referência / distância_normalizada_entre_eixos. */
export function spriteWidthPct(geo: { B: number; A: number }): number {
  return REF_WHEELBASE_PCT / (geo.A - geo.B);
}

/** One scale for every sprite: width from the wheelbase, height from the PNG aspect, tires on the lane line. */
export function spriteBox(geo: SpriteGeo, sceneW: number) {
  const pct = spriteWidthPct(geo), wPx = (sceneW * pct) / 100;
  const refW = (sceneW * SPRITE_PCT) / 100;
  return { pct, wPx, hPx: wPx * geo.aspect, mid: (geo.A + geo.B) / 2, groundPx: (1 - geo.ground) * geo.aspect * wPx, refGroundPx: (1 - REF_GEO.ground) * REF_GEO.aspect * refW };
}
export type SpriteBox = ReturnType<typeof spriteBox>;
/** Applies a model's display scale (BIKE_SCALE) to a measured box: everything shrinks together, so the tire stays on the lane line. */
export function scaleBox(bx: SpriteBox, scale: number): SpriteBox {
  if (scale === 1) return bx;
  return { ...bx, pct: bx.pct * scale, wPx: bx.wPx * scale, hPx: bx.hPx * scale, groundPx: bx.groundPx * scale };
}
