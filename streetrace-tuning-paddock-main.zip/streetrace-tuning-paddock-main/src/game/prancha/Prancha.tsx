import { useMemo, useRef, useState } from "react";
import { usePlayer } from "../store";
import { bikeModel, engine } from "../physics";
import { buildBoard, NC, type Comp, type Flow } from "./board";

const FLOWS: { f: Flow; label: string }[] = [
  { f: "forca", label: "Transmissão de força" }, { f: "movimento", label: "Movimento mecânico" }, { f: "oleo", label: "Óleo" },
  { f: "combustivel", label: "Combustível" }, { f: "ar", label: "Ar / gases" }, { f: "eletrico", label: "Elétrico" }, { f: "calor", label: "Calor" },
];
const col = (f: Flow) => `var(--flow-${f})`;
const cx = (c: Comp) => c.x + c.w / 2, cy = (c: Comp) => c.y + c.h / 2;

/** Bloco modular estilo Technic: corpo, face de profundidade e furos de encaixe. */
function Brick({ c, on, dim, pick }: { c: Comp; on: boolean; dim: boolean; pick: () => void }) {
  const round = c.id.startsWith("roda");
  const holes = Math.max(1, Math.min(8, Math.floor(c.w / 22)));
  return (
    <g onClick={pick} style={{ cursor: "pointer", opacity: dim ? 0.25 : 1 }}>
      {round ? (
        <>
          <circle cx={cx(c)} cy={cy(c)} r={c.w / 2} fill="var(--board-ink)" opacity={0.85} />
          <circle cx={cx(c)} cy={cy(c)} r={c.w / 2 - 28} fill="var(--board-part)" stroke="var(--board-part-edge)" strokeWidth={3} />
          {Array.from({ length: 10 }, (_, i) => { const a = (i * Math.PI) / 5; return <circle key={i} cx={cx(c) + Math.cos(a) * (c.w / 2 - 60)} cy={cy(c) + Math.sin(a) * (c.w / 2 - 60)} r={8} fill="var(--board-bg)" stroke="var(--board-part-edge)" />; })}
          <circle cx={cx(c)} cy={cy(c)} r={18} fill="var(--board-bg)" stroke="var(--board-part-edge)" strokeWidth={3} />
        </>
      ) : (
        <>
          <rect x={c.x + 6} y={c.y - 6} width={c.w} height={c.h} rx={4} fill="var(--board-part-edge)" opacity={0.35} />
          <rect x={c.x} y={c.y} width={c.w} height={c.h} rx={4} fill="var(--board-part)" stroke={on ? "var(--board-sel)" : "var(--board-part-edge)"} strokeWidth={on ? 4 : 1.5} />
          {c.h >= 18 && Array.from({ length: holes }, (_, i) => <circle key={i} cx={c.x + ((i + 0.5) * c.w) / holes} cy={c.y + Math.min(c.h / 2, 11)} r={Math.min(5, c.h / 5)} fill="var(--board-bg)" stroke="var(--board-part-edge)" />)}
        </>
      )}
      {round && on && <circle cx={cx(c)} cy={cy(c)} r={c.w / 2 + 4} fill="none" stroke="var(--board-sel)" strokeWidth={5} />}
    </g>
  );
}

export function Prancha() {
  const pl = usePlayer();
  const svgRef = useRef<SVGSVGElement>(null);
  const [sel, setSel] = useState<string | null>(null);
  const [hide, setHide] = useState<Set<Flow>>(new Set());
  const b = bikeModel(pl?.activeBike);
  const e = pl ? engine(b, pl.setup) : null;
  const [rpm, setRpm] = useState<number | null>(null);
  const board = useMemo(() => (pl ? buildBoard(b, pl.setup, rpm ?? undefined) : null), [pl, b, rpm]);
  if (!pl || !board || !e) return <p className="p-6 text-sm text-muted-foreground">Entre na sua conta e escolha uma moto para gerar a prancha.</p>;
  const by = new Map(board.comps.map((c) => [c.id, c]));
  const cur = sel ? by.get(sel) : undefined;
  const near = new Set(cur ? [cur.id, ...cur.conecta, ...board.links.filter((l) => l.a === cur.id || l.b === cur.id).flatMap((l) => [l.a, l.b])] : []);
  // chamadas: metade esquerda/direita, empilhadas na ordem vertical
  const sorted = [...board.comps].sort((a, z) => cy(a) - cy(z));
  const left = sorted.filter((c) => cx(c) < 960), right = sorted.filter((c) => cx(c) >= 960);
  const slot = (list: Comp[], i: number) => 130 + (i * 900) / Math.max(1, list.length - 1 || 1);
  const r = board.resumo;
  const f1 = (n: number, d = 1) => n.toLocaleString("pt-BR", { maximumFractionDigits: d, minimumFractionDigits: d });

  const exportPng = () => {
    const svg = svgRef.current; if (!svg) return;
    const css = getComputedStyle(document.documentElement);
    let xml = new XMLSerializer().serializeToString(svg);
    xml = xml.replace(/var\((--[\w-]+)\)/g, (_, v: string) => css.getPropertyValue(v).trim() || "#888");
    const img = new Image();
    img.onload = () => {
      const cv = document.createElement("canvas"); cv.width = 1920; cv.height = 1080;
      cv.getContext("2d")!.drawImage(img, 0, 0, 1920, 1080);
      const a = document.createElement("a"); a.download = `prancha-${b.id}.png`; a.href = cv.toDataURL("image/png"); a.click();
    };
    img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(xml);
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-3 text-sm">
        <strong>{r.moto}</strong>
        <label className="flex items-center gap-2">Rotação analisada
          <input type="range" min={1400} max={e.rpmLimit} step={100} value={board.rpm} onChange={(ev) => setRpm(Number(ev.target.value))} />
          <span className="tabular-nums">{board.rpm} rpm</span>
        </label>
        <button onClick={exportPng} className="rounded-md bg-primary px-3 py-1 text-xs font-bold text-primary-foreground">Baixar PNG 1920×1080</button>
      </div>
      <div className="flex flex-wrap gap-2 text-xs">
        {FLOWS.map((x) => (
          <button key={x.f} onClick={() => setHide((h) => { const n = new Set(h); if (n.has(x.f)) n.delete(x.f); else n.add(x.f); return n; })} className="flex items-center gap-1 rounded border border-border px-2 py-0.5" style={{ opacity: hide.has(x.f) ? 0.4 : 1 }}>
            <span className="inline-block h-1 w-5" style={{ background: col(x.f) }} />{x.label}
          </button>
        ))}
      </div>
      <div className="grid gap-3 lg:grid-cols-[1fr_340px]">
        <svg ref={svgRef} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 1080" className="w-full rounded-lg border border-border" style={{ background: "var(--board-bg)", fontFamily: "monospace" }}>
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M40 0H0V40" fill="none" stroke="var(--board-grid)" strokeWidth="1" /></pattern>
            {FLOWS.map((x) => <marker key={x.f} id={`ar-${x.f}`} viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0 0L10 5L0 10z" fill={col(x.f)} /></marker>)}
          </defs>
          <rect width="1920" height="1080" fill="var(--board-bg)" />
          <rect width="1920" height="1080" fill="url(#grid)" />
          <text x="960" y="40" textAnchor="middle" fontSize="26" fontWeight="bold" fill="var(--board-ink)">PRANCHA TÉCNICA — {r.moto.toUpperCase()}</text>
          <text x="960" y="70" textAnchor="middle" fontSize="16" fill="var(--board-ink)">Vd {f1(r.cc)} cm³ · D {f1(r.D, 2)} mm · S {f1(r.S, 3)} mm · l {f1(r.l)} mm · ε {f1(r.cr, 2)}:1 · {f1(r.hp)} cv @ {r.rpmPeak} · corte {r.rpmLimit} rpm · final {f1(r.final, 3)} · análise @ {board.rpm} rpm</text>
          {board.comps.filter((c) => c.id.startsWith("roda")).map((c) => <Brick key={c.id} c={c} on={sel === c.id} dim={!!cur && !near.has(c.id)} pick={() => setSel(c.id)} />)}
          {board.comps.filter((c) => !c.id.startsWith("roda")).map((c) => <Brick key={c.id} c={c} on={sel === c.id} dim={!!cur && !near.has(c.id)} pick={() => setSel(c.id)} />)}
          {board.links.filter((l) => !hide.has(l.f)).map((l, i) => {
            const a = by.get(l.a), z = by.get(l.b); if (!a || !z) return null;
            const hot = !cur || l.a === cur.id || l.b === cur.id;
            return <line key={i} x1={cx(a)} y1={cy(a)} x2={cx(z)} y2={cy(z)} stroke={col(l.f)} strokeWidth={hot ? 4 : 2} opacity={hot ? 0.95 : 0.15} strokeDasharray={l.f === "ar" ? "8 5" : l.f === "eletrico" ? "3 4" : undefined} markerEnd={`url(#ar-${l.f})`} />;
          })}
          {[left, right].map((list, side) => list.map((c, i) => {
            const ty = slot(list, i), tx = side === 0 ? 20 : 1600;
            const first = c.dados.find((d) => d.v !== NC) ?? c.dados[0];
            const dim = !!cur && !near.has(c.id);
            return (
              <g key={c.id} onClick={() => setSel(c.id)} style={{ cursor: "pointer", opacity: dim ? 0.3 : 1 }}>
                <line x1={side === 0 ? tx + 300 : tx} y1={ty} x2={cx(c)} y2={cy(c)} stroke="var(--board-ink)" strokeWidth={1} opacity={0.55} />
                <circle cx={cx(c)} cy={cy(c)} r={4} fill="var(--board-ink)" />
                <rect x={tx} y={ty - 16} width={300} height={34} rx={3} fill="var(--board-bg)" stroke={sel === c.id ? "var(--board-sel)" : "var(--board-part-edge)"} strokeWidth={sel === c.id ? 3 : 1} />
                <text x={tx + 6} y={ty - 2} fontSize="13" fontWeight="bold" fill="var(--board-ink)">{c.nome.toUpperCase()}</text>
                <text x={tx + 6} y={ty + 13} fontSize="11" fill="var(--board-ink)">{first ? `${first.k}: ${first.v}`.slice(0, 46) : ""}</text>
              </g>
            );
          }))}
        </svg>
        <aside className="max-h-[80vh] overflow-auto rounded-lg border border-border bg-card p-3 text-sm">
          {!cur ? <p className="text-muted-foreground">Toque numa peça para abrir a ficha técnica.</p> : (
            <div className="space-y-3">
              <div><p className="text-xs uppercase text-muted-foreground">{cur.grupo}</p><h3 className="text-lg font-bold">{cur.nome}</h3>{cur.peca && <p className="text-xs">{cur.peca}</p>}</div>
              <p><b>Função:</b> {cur.funcao}<br /><b>Posição:</b> {cur.posicao}</p>
              <table className="w-full text-xs"><tbody>{cur.dados.map((d, i) => (
                <tr key={i} className="border-t border-border"><td className="py-1 pr-2">{d.k}</td><td className="py-1 font-mono">{d.v}</td><td className="py-1 text-[10px] text-muted-foreground">{d.o}</td></tr>
              ))}</tbody></table>
              {cur.formulas.length > 0 && <div><b>Fórmulas e cálculos</b>{cur.formulas.map((fm, i) => <div key={i} className="mt-1 rounded bg-muted p-2 font-mono text-xs"><div>{fm.nome}</div><div>{fm.expr}</div><div>= {fm.resultado}</div></div>)}</div>}
              <div><b>Conectado a:</b><div className="mt-1 flex flex-wrap gap-1">{cur.conecta.map((id) => <button key={id} onClick={() => setSel(id)} className="rounded border border-border px-1.5 py-0.5 text-xs">{by.get(id)?.nome ?? id}</button>)}</div></div>
              <p className="text-xs"><b>Estado:</b> {pl.broken ? "motor quebrado" : "em funcionamento"}</p>
              <button onClick={() => setSel(null)} className="text-xs underline">Fechar</button>
            </div>
          )}
        </aside>
      </div>
      <p className="text-xs text-muted-foreground">Origem de cada valor: FICHA (manual do fabricante), PEÇA INSTALADA, CALCULADO (mesmas fórmulas da corrida), ESTIMADO (constante de engenharia do jogo) ou NÃO CADASTRADO. Esquema em vista lateral; posições aproximadas, não em escala.</p>
    </div>
  );
}
