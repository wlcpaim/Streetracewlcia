/**
 * Prancha técnica: monta a lista de componentes da moto ativa a partir das MESMAS funções do jogo
 * (geoOf, buildOf, engine, stats, catalogRatios, ENGINE_CATALOG, slots). Leitura apenas — nunca altera Setup.
 * Valor sem fonte = "NÃO CADASTRADO"; valores de EST/estimativas são marcados ESTIMADO.
 */
import type { BikeModel, Setup } from "../physics";
import { engine, stats, catalogRatios, rearTireRadiusM, pinOffsetMm } from "../physics";
import { geoOf, EST } from "../enginephys";
import { buildOf } from "../mechlimits";
import { slotPart, type Slot } from "../parts";
import { ENGINE_CATALOG } from "../data/engine_catalog";

export type Origem = "FICHA" | "CALCULADO" | "PEÇA INSTALADA" | "ESTIMADO" | "NÃO CADASTRADO";
export interface Val { k: string; v: string; o: Origem }
export interface Formula { nome: string; expr: string; resultado: string }
export type Flow = "forca" | "movimento" | "oleo" | "combustivel" | "ar" | "eletrico" | "calor";
export interface Comp {
  id: string; nome: string; grupo: string;
  x: number; y: number; w: number; h: number; // retângulo no viewBox 1920×1080
  peca?: string; // nome da peça instalada
  dados: Val[]; formulas: Formula[]; conecta: string[]; funcao: string; posicao: string;
}
export interface Link { a: string; b: string; f: Flow }

export const NC = "NÃO CADASTRADO";
const f = (n: number, d = 1) => n.toLocaleString("pt-BR", { maximumFractionDigits: d, minimumFractionDigits: d });
const nc = (k: string): Val => ({ k, v: NC, o: "NÃO CADASTRADO" });
const ficha = (bikeId: string, key: string, label: string): Val => {
  const p = ENGINE_CATALOG[bikeId]?.p[key];
  if (!p || p.valor == null) return nc(label);
  return { k: label, v: `${typeof p.valor === "number" ? f(p.valor, 3).replace(/,?0+$/, "") : p.valor} ${p.unidade === "—" ? "" : p.unidade}`.trim(), o: "FICHA" };
};
const partVal = (s: Setup, slot: Slot): { nome: string; v: Val } => {
  const p = slotPart(s.slots[slot], slot);
  const nome = `${p.name}${p.brand ? ` · ${p.brand}` : ""}${p.spec ? ` · ${p.spec}` : ""}`;
  return { nome, v: { k: "Peça instalada", v: nome, o: "PEÇA INSTALADA" } };
};

export function buildBoard(b: BikeModel, s: Setup, rpm?: number) {
  const g = geoOf(b, s), bd = buildOf(b, s), e = engine(b, s), st = stats(b, s);
  const N = rpm ?? e.rpmPeak, w = (2 * Math.PI * N) / 60;
  const vm = (2 * (g.strokeMm / 1000) * N) / 60;
  const lam = g.rM / g.lM;
  const aMax = g.rM * w * w * (1 + lam);
  const Fin = bd.recKg * aMax;
  const torqueNm = st.torque * 9.80665;
  const kW = e.hp * 0.7355;
  const ratios = catalogRatios(b.id);
  const final = s.rear / s.front;
  const rT = rearTireRadiusM(b.tires);
  const pin = pinOffsetMm(s);
  const cyl = partVal(s, "cilindro"), pis = partVal(s, "pistao"), rod = partVal(s, "biela"), vira = partVal(s, "vira");
  const geoO = (o: string): Origem => (o === "CATALOGO" ? "FICHA" : "ESTIMADO");
  const C: Comp[] = [];
  const add = (c: Comp) => C.push(c);

  // ---------- MOTOR ----------
  add({ id: "cabecote", nome: "Cabeçote", grupo: "Motor", x: 880, y: 360, w: 170, h: 70, funcao: "Fecha a câmara, aloja válvulas, comando e velas.", posicao: "Topo do cilindro", conecta: ["cilindro", "comando", "valv-adm", "valv-esc", "camara", "vela", "coletor", "escape"],
    dados: [{ k: "Taxa de compressão", v: `${f(s.compression, 2)}:1`, o: "PEÇA INSTALADA" }, ficha(b.id, "valvulas", "Válvulas"), { k: "Rebaixo", v: `${f(s.mach?.rebaixoMm ?? 0, 2)} mm`, o: "PEÇA INSTALADA" }, nc("Massa"), nc("Material")],
    formulas: [{ nome: "Volume da câmara", expr: "Vc = Vd / (ε − 1)", resultado: `${f(g.vcM3 * 1e6, 2)} cm³` }] });
  add({ id: "cilindro", nome: "Cilindro", grupo: "Motor", x: 890, y: 430, w: 150, h: 90, peca: cyl.nome, funcao: "Guia o pistão e conduz calor às aletas.", posicao: "Sobre o cárter", conecta: ["cabecote", "pistao", "aneis"],
    dados: [cyl.v, { k: "Diâmetro (D)", v: `${f(g.boreMm, 2)} mm`, o: "CALCULADO" }, { k: "Cilindrada", v: `${f(g.cc, 1)} cm³`, o: "CALCULADO" }, { k: "Parede", v: `${f(bd.wallMm, 1)} mm`, o: "ESTIMADO" }, nc("Massa"), nc("Material")],
    formulas: [{ nome: "Diâmetro", expr: "D = √(4·Vd / (π·S))", resultado: `${f(g.boreMm, 2)} mm` }, { nome: "Área do pistão", expr: "A = π·D²/4", resultado: `${f(g.areaM2 * 1e4, 2)} cm²` }] });
  add({ id: "pistao", nome: "Pistão", grupo: "Motor", x: 915, y: 470, w: 100, h: 40, peca: pis.nome, funcao: "Converte a pressão da combustão em força linear.", posicao: "Dentro do cilindro", conecta: ["pino", "aneis", "cilindro", "camara"],
    dados: [pis.v, { k: "Diâmetro", v: `${f(g.boreMm, 2)} mm`, o: "CALCULADO" }, { k: "Massa alternativa (pistão+pino+anéis)", v: `${f(bd.recKg * 1000, 0)} g`, o: "ESTIMADO" }, { k: "Coroa restante", v: `${f(bd.crownMm, 2)} mm`, o: "CALCULADO" }, { k: "Limite térmico da coroa", v: `${bd.pistonLimC} °C`, o: "ESTIMADO" }, nc("Material")],
    formulas: [{ nome: "Velocidade média", expr: "vm = 2·S·N/60", resultado: `${f(vm, 2)} m/s @ ${N} rpm` }, { nome: "Aceleração máx. (PMS)", expr: "a = r·ω²·(1 + r/l)", resultado: `${f(aMax, 0)} m/s²` }, { nome: "Força de inércia", expr: "F = m·a", resultado: `${f(Fin, 0)} N (massa ESTIMADA)` }] });
  add({ id: "aneis", nome: "Anéis", grupo: "Motor", x: 1020, y: 470, w: 50, h: 22, funcao: "Vedam a câmara e raspam o óleo da camisa.", posicao: "Canaletas do pistão", conecta: ["pistao", "cilindro"], dados: [nc("Massa"), nc("Material"), nc("Altura"), nc("Folga entre pontas")], formulas: [] });
  add({ id: "pino", nome: "Pino do pistão", grupo: "Motor", x: 945, y: 515, w: 40, h: 20, funcao: "Articula pistão e biela.", posicao: "Olhal menor da biela", conecta: ["pistao", "biela"], dados: [ficha(b.id, "pinoPistao", "Diâmetro"), nc("Massa"), nc("Material")], formulas: [] });
  add({ id: "biela", nome: "Biela", grupo: "Motor", x: 945, y: 535, w: 40, h: 75, peca: rod.nome, funcao: "Transforma movimento linear em rotativo.", posicao: "Entre pino e moente", conecta: ["pino", "vira"],
    dados: [rod.v, { k: "Centro a centro (l)", v: `${f(g.rodMm, 1)} mm`, o: geoO(g.rodOrigem) }, { k: "λ = r/l", v: f(lam, 3), o: "CALCULADO" }, { k: "Limite de compressão", v: `${f(bd.rodCompLimitN, 0)} N`, o: "ESTIMADO" }, { k: "Seção / E / σy", v: `${EST.rodAreaMm2} mm² · ${EST.rodE_GPa} GPa · ${EST.rodYieldMPa} MPa`, o: "ESTIMADO" }, nc("Massa")],
    formulas: [{ nome: "Flambagem de Euler", expr: "Fcr = π²·E·I / l²", resultado: `${f((Math.PI ** 2 * EST.rodE_GPa * 1e3 * EST.rodI_mm4) / g.rodMm ** 2, 0)} N` }, { nome: "Tração por inércia", expr: "F = m·r·ω²·(1+λ)", resultado: `${f(Fin, 0)} N` }] });
  add({ id: "vira", nome: "Virabrequim", grupo: "Motor", x: 905, y: 610, w: 120, h: 60, peca: vira.nome, funcao: "Converte o empuxo da biela em torque e acumula inércia.", posicao: "Centro do cárter", conecta: ["biela", "rolamentos-motor", "primaria", "corrente-comando", "bomba-oleo"],
    dados: [vira.v, { k: "Curso (S)", v: `${f(g.strokeMm, 3)} mm`, o: geoO(g.strokeOrigem) }, { k: "Pino cursado", v: `+${pin} mm`, o: "PEÇA INSTALADA" }, { k: "Rotação analisada", v: `${N} rpm`, o: "CALCULADO" }, { k: "Torque no eixo", v: `${f(torqueNm, 2)} N·m`, o: "CALCULADO" }, nc("Massa"), nc("Momento de inércia")],
    formulas: [{ nome: "Raio da manivela", expr: "r = S/2", resultado: `${f(g.strokeMm / 2, 3)} mm` }, { nome: "Velocidade angular", expr: "ω = 2π·N/60", resultado: `${f(w, 1)} rad/s` }, { nome: "Potência", expr: "P = T·ω", resultado: `${f(kW, 2)} kW (${f(e.hp, 1)} cv no pico)` }] });
  add({ id: "rolamentos-motor", nome: "Rolamentos do virabrequim", grupo: "Motor", x: 1030, y: 625, w: 50, h: 30, funcao: "Apoiam o virabrequim no cárter.", posicao: "Mancais do cárter", conecta: ["vira"], dados: [nc("Referência"), nc("Massa"), nc("Carga dinâmica C")], formulas: [] });
  add({ id: "comando", nome: "Comando de válvulas", grupo: "Motor", x: 900, y: 330, w: 130, h: 28, funcao: "Abre as válvulas sincronizado a 1/2 da rotação do virabrequim.", posicao: "Cabeçote (OHC)", conecta: ["cabecote", "corrente-comando", "valv-adm", "valv-esc", "molas"],
    dados: [{ k: "Perfil", v: s.cam, o: "PEÇA INSTALADA" }, { k: "Pico de potência", v: `${e.rpmPeak} rpm`, o: "CALCULADO" }, { k: "Flutuação de válvula", v: `${bd.floatRpm} rpm`, o: "ESTIMADO" }, nc("Levante"), nc("Duração")],
    formulas: [{ nome: "Rotação do comando", expr: "Ncam = N/2", resultado: `${N / 2} rpm` }] });
  add({ id: "valv-adm", nome: "Válvula de admissão", grupo: "Motor", x: 860, y: 395, w: 30, h: 50, funcao: "Libera a mistura para a câmara.", posicao: "Cabeçote, lado admissão", conecta: ["comando", "molas", "coletor", "camara"], dados: [nc("Diâmetro"), nc("Massa"), nc("Material")], formulas: [] });
  add({ id: "valv-esc", nome: "Válvula de escape", grupo: "Motor", x: 1040, y: 395, w: 30, h: 50, funcao: "Libera os gases queimados.", posicao: "Cabeçote, lado escape", conecta: ["comando", "molas", "escape", "camara"], dados: [nc("Diâmetro"), nc("Massa"), nc("Material")], formulas: [] });
  const mol = partVal(s, "molas");
  add({ id: "molas", nome: "Molas de válvula", grupo: "Motor", x: 1060, y: 345, w: 40, h: 40, peca: mol.nome, funcao: "Mantêm o tucho em contato com o came.", posicao: "Sobre as válvulas", conecta: ["valv-adm", "valv-esc", "comando"], dados: [mol.v, { k: "Folga válvula-pistão", v: `${f(bd.clearance0, 2)} mm`, o: "ESTIMADO" }, nc("Constante k"), nc("Pré-carga")], formulas: [] });
  add({ id: "corrente-comando", nome: "Corrente de comando", grupo: "Motor", x: 1080, y: 390, w: 22, h: 230, funcao: "Sincroniza virabrequim e comando (2:1).", posicao: "Lateral do cilindro", conecta: ["vira", "comando"], dados: [nc("Passo"), nc("Elos")], formulas: [{ nome: "Relação", expr: "i = 2:1", resultado: "fixa" }] });
  const emb = partVal(s, "embreagem");
  add({ id: "embreagem", nome: "Embreagem", grupo: "Motor", x: 1050, y: 640, w: 80, h: 80, peca: emb.nome, funcao: "Acopla o motor ao câmbio por atrito.", posicao: "Lado direito, árvore primária", conecta: ["primaria", "cambio"],
    dados: [emb.v, { k: "Capacidade de torque", v: `${f(bd.clutchNm, 1)} N·m`, o: "ESTIMADO" }, { k: "Capacidade térmica", v: `${f(bd.clutchCapJ / 1000, 1)} kJ`, o: "ESTIMADO" }, nc("Nº de discos"), nc("Massa")],
    formulas: [{ nome: "Potência de deslize", expr: "Ps = T·Δω", resultado: "calculada a cada passo na corrida" }] });
  add({ id: "primaria", nome: "Transmissão primária", grupo: "Transmissão", x: 1020, y: 680, w: 40, h: 40, funcao: "Reduz a rotação do virabrequim para a embreagem.", posicao: "Virabrequim → campana", conecta: ["vira", "embreagem"], dados: [ficha(b.id, "relacaoPrimaria", "Relação primária")], formulas: [] });
  add({ id: "cambio", nome: "Câmbio (eixos primário e secundário)", grupo: "Transmissão", x: 860, y: 680, w: 150, h: 60, funcao: "Seleciona a relação de cada marcha.", posicao: "Atrás do virabrequim", conecta: ["embreagem", "pinhao"],
    dados: [ficha(b.id, "relacoesCambio", "Relações"), { k: "Limite de torque", v: `${f(bd.gearLimitNm, 0)} N·m`, o: "ESTIMADO" }, nc("Massa")],
    formulas: ratios ? ratios.gears.map((r, i) => ({ nome: `${i + 1}ª total`, expr: `i = prim × marcha × final = ${f(ratios.prim, 3)}×${f(r, 3)}×${f(final, 3)}`, resultado: f(ratios.prim * r * final, 2) })) : [] });
  add({ id: "bomba-oleo", nome: "Bomba de óleo", grupo: "Lubrificação", x: 960, y: 700, w: 50, h: 30, funcao: "Pressuriza o óleo para mancais e cabeçote.", posicao: "Fundo do cárter", conecta: ["vira", "cabecote"], dados: [{ k: "Óleo", v: partVal(s, "oleo").nome, o: "PEÇA INSTALADA" }, nc("Vazão"), nc("Pressão")], formulas: [] });

  // ---------- ALIMENTAÇÃO ----------
  add({ id: "filtro", nome: "Filtro de ar", grupo: "Alimentação", x: 650, y: 380, w: 110, h: 70, funcao: "Filtra o ar admitido.", posicao: "Sob o banco", conecta: ["tbi"], dados: [{ k: "Configuração", v: s.airFilter, o: "PEÇA INSTALADA" }, nc("Área filtrante")], formulas: [] });
  const tbi = partVal(s, "tbi");
  add({ id: "tbi", nome: "Corpo de borboleta", grupo: "Alimentação", x: 765, y: 395, w: 50, h: 40, peca: tbi.nome, funcao: "Dosa a vazão de ar.", posicao: "Entre filtro e coletor", conecta: ["filtro", "coletor", "injetor", "ecu"], dados: [tbi.v, nc("Diâmetro da borboleta")], formulas: [] });
  const bico = partVal(s, "bico");
  add({ id: "injetor", nome: "Injetor", grupo: "Alimentação", x: 790, y: 360, w: 25, h: 35, peca: bico.nome, funcao: "Pulveriza combustível conforme o pulso da ECU.", posicao: "Corpo de borboleta", conecta: ["tbi", "bomba-comb", "ecu"], dados: [bico.v, ficha(b.id, "pressaoCombustivel", "Pressão de linha"), nc("Vazão")], formulas: [] });
  add({ id: "coletor", nome: "Coletor de admissão", grupo: "Alimentação", x: 815, y: 400, w: 45, h: 30, funcao: "Leva a mistura ao cabeçote.", posicao: "TBI → cabeçote", conecta: ["tbi", "valv-adm", "cabecote"], dados: [nc("Comprimento"), nc("Diâmetro")], formulas: [] });
  const bomba = partVal(s, "bomba");
  add({ id: "bomba-comb", nome: "Bomba de combustível / tanque", grupo: "Alimentação", x: 760, y: 250, w: 200, h: 70, peca: bomba.nome, funcao: "Armazena e pressuriza o combustível.", posicao: "Tanque", conecta: ["injetor"], dados: [bomba.v, { k: "Tanque", v: `${f(b.tank, 1)} L`, o: "FICHA" }, { k: "Combustível", v: s.fuel, o: "PEÇA INSTALADA" }], formulas: [] });
  add({ id: "camara", nome: "Câmara de combustão", grupo: "Combustão", x: 920, y: 440, w: 90, h: 25, funcao: "Onde a mistura queima e gera pressão.", posicao: "Entre cabeçote e pistão", conecta: ["cabecote", "pistao", "vela", "valv-adm", "valv-esc"],
    dados: [{ k: "Volume Vc", v: `${f(g.vcM3 * 1e6, 2)} cm³`, o: "CALCULADO" }, { k: "Taxa", v: `${f(s.compression, 2)}:1`, o: "PEÇA INSTALADA" }, { k: "Avanço base", v: `${EST.sparkBtdc}° APMS`, o: "ESTIMADO" }],
    formulas: [{ nome: "Cilindrada", expr: "Vd = π/4·D²·S", resultado: `${f(g.cc, 1)} cm³` }, { nome: "Taxa", expr: "ε = (Vd+Vc)/Vc", resultado: f((g.vdM3 + g.vcM3) / g.vcM3, 2) }] });
  const vela = partVal(s, "vela");
  add({ id: "vela", nome: "Vela", grupo: "Ignição", x: 955, y: 305, w: 25, h: 25, peca: vela.nome, funcao: "Gera a centelha.", posicao: "Centro do cabeçote", conecta: ["camara", "ecu"], dados: [vela.v, { k: "Cabo", v: partVal(s, "cabo").nome, o: "PEÇA INSTALADA" }], formulas: [] });
  const esc = partVal(s, "escape");
  add({ id: "escape", nome: "Escape", grupo: "Alimentação", x: 1100, y: 470, w: 380, h: 50, peca: esc.nome, funcao: "Retira os gases e sintoniza a onda de pressão.", posicao: "Cabeçote → traseira", conecta: ["valv-esc", "cabecote"], dados: [esc.v, nc("Comprimento"), nc("Diâmetro")], formulas: [] });

  // ---------- TRANSMISSÃO FINAL ----------
  add({ id: "pinhao", nome: "Pinhão", grupo: "Transmissão", x: 830, y: 740, w: 40, h: 40, funcao: "Saída do câmbio para a corrente.", posicao: "Eixo secundário", conecta: ["cambio", "corrente"], dados: [{ k: "Dentes", v: `${s.front}`, o: "PEÇA INSTALADA" }], formulas: [] });
  add({ id: "corrente", nome: "Corrente", grupo: "Transmissão", x: 600, y: 745, w: 230, h: 18, funcao: "Transmite torque do pinhão à coroa.", posicao: "Lado esquerdo", conecta: ["pinhao", "coroa"], dados: [nc("Passo"), nc("Elos")], formulas: [] });
  add({ id: "coroa", nome: "Coroa", grupo: "Transmissão", x: 520, y: 700, w: 80, h: 80, funcao: "Recebe a corrente e gira a roda traseira.", posicao: "Cubo traseiro", conecta: ["corrente", "roda-tras"],
    dados: [{ k: "Dentes", v: `${s.rear}`, o: "PEÇA INSTALADA" }, ficha(b.id, "relacaoFinal", "Relação final de fábrica")], formulas: [{ nome: "Relação final", expr: "i = Z coroa / Z pinhão", resultado: f(final, 3) }] });

  // ---------- CICLÍSTICA ----------
  add({ id: "quadro", nome: "Quadro", grupo: "Ciclística", x: 760, y: 330, w: 520, h: 20, funcao: "Estrutura que liga todos os conjuntos.", posicao: "Central", conecta: ["direcao", "balanca", "cilindro"], dados: [{ k: "Peso seco da moto", v: `${b.dryWeight} kg`, o: "FICHA" }, nc("Massa do quadro"), nc("Material")], formulas: [] });
  add({ id: "direcao", nome: "Direção", grupo: "Ciclística", x: 1290, y: 300, w: 40, h: 60, funcao: "Eixo de giro do garfo.", posicao: "Caixa de direção", conecta: ["quadro", "garfo"], dados: [nc("Cáster"), nc("Trail"), nc("Rolamentos")], formulas: [] });
  const susp = partVal(s, "susp");
  add({ id: "garfo", nome: "Suspensão dianteira", grupo: "Ciclística", x: 1310, y: 360, w: 35, h: 300, peca: susp.nome, funcao: "Absorve impactos na dianteira.", posicao: "Garfo telescópico", conecta: ["direcao", "roda-diant"], dados: [susp.v, nc("Curso")], formulas: [] });
  add({ id: "balanca", nome: "Balança", grupo: "Ciclística", x: 560, y: 690, w: 320, h: 22, funcao: "Liga o eixo traseiro ao quadro.", posicao: "Pivô atrás do motor", conecta: ["quadro", "roda-tras", "amort"], dados: [nc("Comprimento"), nc("Massa")], formulas: [] });
  add({ id: "amort", nome: "Amortecedor traseiro", grupo: "Ciclística", x: 640, y: 450, w: 30, h: 240, funcao: "Controla o movimento da balança.", posicao: "Quadro ↔ balança", conecta: ["quadro", "balanca"], dados: [nc("Curso"), nc("Constante k")], formulas: [] });
  const pneu = partVal(s, "pneu"), roda = partVal(s, "roda");
  add({ id: "roda-tras", nome: "Roda e pneu traseiros", grupo: "Ciclística", x: 400, y: 570, w: 320, h: 320, peca: `${roda.nome} / ${pneu.nome}`, funcao: "Transforma torque em força de tração.", posicao: "Eixo traseiro", conecta: ["coroa", "balanca", "freio-tras"],
    dados: [roda.v, { k: "Pneu", v: pneu.nome, o: "PEÇA INSTALADA" }, { k: "Medidas", v: b.tires, o: "FICHA" }, rT ? { k: "Raio geométrico", v: `${f(rT * 1000, 0)} mm`, o: "CALCULADO" } : nc("Raio"), { k: "Desgaste", v: `${f((s.tireWear ?? 0) * 100, 0)} %`, o: "PEÇA INSTALADA" }],
    formulas: rT ? [{ nome: "Velocidade", expr: "v = N·2π·r / (60·i_total)", resultado: ratios ? `${f((e.rpmLimit * 2 * Math.PI * rT * 3.6) / (60 * ratios.prim * ratios.gears[ratios.gears.length - 1]! * final), 0)} km/h no corte em ${ratios.gears.length}ª` : NC }, { nome: "Força na roda (1ª)", expr: "F = T·i_total / r", resultado: ratios ? `${f((torqueNm * ratios.prim * ratios.gears[0]! * final) / rT, 0)} N` : NC }] : [] });
  add({ id: "roda-diant", nome: "Roda e pneu dianteiros", grupo: "Ciclística", x: 1200, y: 570, w: 320, h: 320, funcao: "Apoio e direção.", posicao: "Eixo dianteiro", conecta: ["garfo", "freio-diant"], dados: [{ k: "Medidas", v: b.tires, o: "FICHA" }, nc("Massa")], formulas: [] });
  add({ id: "freio-diant", nome: "Freio dianteiro (disco + pinça)", grupo: "Ciclística", x: 1320, y: 690, w: 80, h: 60, funcao: "Converte energia cinética em calor.", posicao: "Cubo dianteiro", conecta: ["roda-diant"], dados: [nc("Diâmetro do disco"), nc("Pistões da pinça")], formulas: [{ nome: "Energia", expr: "E = ½·m·v²", resultado: "depende da velocidade" }] });
  add({ id: "freio-tras", nome: "Freio traseiro", grupo: "Ciclística", x: 470, y: 690, w: 50, h: 50, funcao: "Frenagem traseira.", posicao: "Cubo traseiro", conecta: ["roda-tras"], dados: [nc("Tipo"), nc("Diâmetro")], formulas: [] });

  // ---------- ELÉTRICA ----------
  const mod = partVal(s, "modulo"), bat = partVal(s, "bateria");
  add({ id: "ecu", nome: "ECU / módulo", grupo: "Elétrica", x: 700, y: 290, w: 60, h: 40, peca: mod.nome, funcao: "Calcula injeção e ignição.", posicao: "Sob o banco", conecta: ["injetor", "vela", "tbi", "bateria", "sensores"], dados: [mod.v, { k: "Corte de giro", v: `${e.rpmLimit} rpm`, o: "CALCULADO" }, { k: "Programável", v: bd.prog ? "sim" : "não", o: "PEÇA INSTALADA" }], formulas: [] });
  add({ id: "bateria", nome: "Bateria", grupo: "Elétrica", x: 640, y: 300, w: 55, h: 40, peca: bat.nome, funcao: "Alimenta ECU, bomba e partida.", posicao: "Lateral", conecta: ["ecu"], dados: [bat.v, nc("Capacidade")], formulas: [] });
  add({ id: "sensores", nome: "Sensores (TPS, MAP, temp., O2)", grupo: "Elétrica", x: 820, y: 435, w: 40, h: 25, funcao: "Informam a ECU.", posicao: "TBI / cabeçote / escape", conecta: ["ecu"], dados: [{ k: "Malha fechada", v: s.ecu?.closed ? "ativa" : "não", o: "PEÇA INSTALADA" }, nc("Modelos")], formulas: [] });
  add({ id: "arrefecimento", nome: "Arrefecimento", grupo: "Complementar", x: 1045, y: 430, w: 40, h: 40, funcao: "Dissipa calor do cilindro.", posicao: "Aletas", conecta: ["cilindro", "cabecote"], dados: [{ k: "Tipo", v: b.cooling, o: "FICHA" }], formulas: [{ nome: "Calor", expr: "Q = h·A·ΔT", resultado: NC + " (h e A)" }] });

  const L: Link[] = [
    ["camara", "pistao", "forca"], ["pistao", "pino", "forca"], ["pino", "biela", "forca"], ["biela", "vira", "forca"], ["vira", "primaria", "forca"], ["primaria", "embreagem", "forca"], ["embreagem", "cambio", "forca"], ["cambio", "pinhao", "forca"], ["pinhao", "corrente", "forca"], ["corrente", "coroa", "forca"], ["coroa", "roda-tras", "forca"],
    ["vira", "corrente-comando", "movimento"], ["corrente-comando", "comando", "movimento"], ["comando", "valv-adm", "movimento"], ["comando", "valv-esc", "movimento"], ["garfo", "roda-diant", "movimento"], ["balanca", "roda-tras", "movimento"], ["amort", "balanca", "movimento"],
    ["bomba-oleo", "vira", "oleo"], ["bomba-oleo", "cabecote", "oleo"],
    ["bomba-comb", "injetor", "combustivel"], ["injetor", "coletor", "combustivel"],
    ["filtro", "tbi", "ar"], ["tbi", "coletor", "ar"], ["coletor", "valv-adm", "ar"], ["valv-esc", "escape", "ar"],
    ["bateria", "ecu", "eletrico"], ["ecu", "injetor", "eletrico"], ["ecu", "vela", "eletrico"], ["sensores", "ecu", "eletrico"],
    ["camara", "cabecote", "calor"], ["cilindro", "arrefecimento", "calor"], ["embreagem", "cambio", "calor"],
  ].map(([a, b2, fl]) => ({ a: a!, b: b2!, f: fl as Flow }));
  return { comps: C, links: L, rpm: N, resumo: { moto: b.name, cc: g.cc, D: g.boreMm, S: g.strokeMm, l: g.rodMm, cr: s.compression, hp: e.hp, rpmPeak: e.rpmPeak, rpmLimit: e.rpmLimit, torqueNm, final } };
}
export type Board = ReturnType<typeof buildBoard>;
