const TRACK_ORDER = [201.16, 402.33, 804.67, 1609.34, 6437.38];
// Offline races: the computer rides a real Titan 160 build per level (parts change its hp), fixed and deterministic.
import { kitPlan, type Stage } from "./kits/preparado";
import { simulate, STOCK_SETUP, stockSetupOf, TITAN_160, FACTOR_150, TITAN_150, CG_125, type BikeModel, type Setup } from "./physics";

export type Difficulty = "iniciante" | "facil" | "medio" | "dificil" | "chefe";

const build = (slots: Partial<Setup["slots"]>, o: Partial<Setup> = {}): Setup => ({ ...STOCK_SETUP, ...o, slots: { ...STOCK_SETUP.slots, ...slots } });

/** Computer bike per level (Titan): Fácil kit 190 + Dore ~19 cv, Médio 205 + Dore + Athlon ~24 cv, Difícil 220 cursado + Athlon ~30 cv. */
export const OPP_SETUP: Record<"facil" | "medio" | "dificil", Setup> = {
  facil: build({ cilindro: "cilindro-4mm", escape: "escape-dore", bico: "bico-170", modulo: "modulo-pnp-race" }, { cam: "mb60", services: ["polimento"] }),
  medio: build(
    { embreagem: "embreagem-kit-vesrah", cilindro: "cilindro-205", pistao: "pistao-forjado", escape: "escape-dore", modulo: "modulo-athlon", bico: "bico-racing", molas: "molas-duplas", tbi: "tbi-34", bomba: "bomba-alta" },
    { fuel: "etanol", compression: 12, cam: "ma69", services: ["dutos", "dutos-escape", "valv-maiores", "cavas-pistao", "pino-2", "biela-forjada", "polimento"], ecu: { ...STOCK_SETUP.ecu, timing: 3.5, trim: 5, launch: 8200 } },
  ),
  dificil: build(
    { embreagem: "embreagem-campana", pneu: "pneu-sport", cilindro: "cilindro-220", pistao: "pistao-forjado", escape: "escape-dore", modulo: "modulo-athlon", bico: "bico-racing", bomba: "bomba-alta", molas: "molas-duplas", tbi: "tbi-36", vela: "vela-racing", cabo: "cabo-nology" },
    {
      fuel: "etanol", compression: 13.5, cam: "a75", airFilter: "sem",
      services: ["pino-4", "biela-forjada", "parede-grossa", "dutos", "dutos-escape", "valv-33", "valv-3ang", "polimento", "cavas-pistao", "alivio-volante", "alivio-pistao", "coletor", "tbi-36", "lev-adm-05", "lev-esc-05", "cruzamento", "rebaixar-cabecote"],
      ecu: { ...STOCK_SETUP.ecu, timing: 4, trim: 14, launch: 8800 },
    },
  ),
};

/** Níveis pelo desempenho real da moto original de fábrica (potência ÷ peso): Factor < CG 125 < CG 160 < CG 150. */
export const DIFFICULTY: Record<Difficulty, { label: string; prize: number; setup: Setup }> = {
  iniciante: { label: "Iniciante", prize: 15, setup: STOCK_SETUP },
  facil: { label: "Fácil", prize: 30, setup: STOCK_SETUP },
  medio: { label: "Médio", prize: 75, setup: STOCK_SETUP },
  dificil: { label: "Difícil", prize: 375, setup: STOCK_SETUP },
  chefe: { label: "Líder", prize: 0, setup: OPP_SETUP.dificil },
};

/** Carreira chefe 1: Tião da Twister, CG Bolinha azul (motor Twister 2006, carburador Falcon, escape GRS). Upgrades every track. */
/** Player level that unlocks the chefe (tutorial must also be done). */
export const BOSS_LEVEL = 5;
export const BOSS = { name: "Tião da Twister", bike: "CG Bolinha Twister", final: 25000 };
export const BOSS_SETUP: Setup[] = [
  build({ escape: "escape-grs", vela: "vela-iridium", cabo: "cabo-ibooster" }, { airFilter: "sem" }),
  build({ escape: "escape-grs", vela: "vela-iridium", cabo: "cabo-ibooster", bico: "bico-150" }, { airFilter: "sem" }),
  build({ escape: "escape-grs", vela: "vela-racing", cabo: "cabo-nology", bico: "bico-150", cilindro: "cilindro-4mm", pistao: "pistao-forjado" }, { airFilter: "sem" }),
  build({ escape: "escape-grs", vela: "vela-racing", cabo: "cabo-nology", bico: "bico-150", cilindro: "cilindro-4mm", pistao: "pistao-forjado", modulo: "modulo-infinitum" }, { airFilter: "sem" }),
  OPP_SETUP.dificil,
];
/** Médio: kit 4MM completo + Dore com relação e psi próprios de cada pista. */
const KIT4_OPP = build({ cilindro: "cilindro-4mm", pistao: "pistao-forjado", biela: "biela-txk-racing", vira: "vira-ww3", bico: "bico-170", modulo: "modulo-remap", escape: "escape-dore", embreagem: "embreagem-discos" }, { cam: "ma66", services: ["pino-2"] });
const MEDIO_TRACK: [number, number, number][] = [[17, 46, 24], [14, 38, 20], [17, 46, 20], [15, 36, 32], [17, 40, 36]];
export const MEDIO_SETUP: Setup[] = MEDIO_TRACK.map(([front, rear, psi]) => ({ ...KIT4_OPP, front, rear, psi }));
/** Fácil: peças avulsas seguras da loja, progredindo por pista, nunca o kit 4MM completo. */
const FACIL_PARTS: Setup[] = [
  build({ escape: "escape-dore" }),
  build({ escape: "escape-dore", bico: "bico-170", embreagem: "embreagem-discos" }),
  build({ escape: "escape-dore", bico: "bico-170", embreagem: "embreagem-discos" }, { cam: "ma66" }),
  build({ escape: "escape-dore", bico: "bico-170", embreagem: "embreagem-discos", cilindro: "cilindro-4mm" }, { cam: "ma66" }),
  build({ escape: "escape-dore", bico: "bico-170", embreagem: "embreagem-discos", cilindro: "cilindro-4mm", modulo: "modulo-remap" }, { cam: "ma66" }),
];
// 1/4 e 1/2 recalculadas depois que o câmbio passou a sair do manual (relação mais longa vence com a 1ª real mais curta)
const FACIL_TRACK: [number, number, number][] = [[14, 48, 36], [17, 36, 20], [17, 36, 20], [14, 34, 36], [17, 40, 36]];
export const FACIL_SETUP: Setup[] = FACIL_PARTS.map((s, i) => { const [front, rear, psi] = FACIL_TRACK[i]!; return { ...s, front, rear, psi }; });
/** Médio e Difícil também usam relação e psi acertados por pista (pinhão, coroa, psi). */
export const TRACK_GEAR: Record<"dificil", [number, number, number][]> = {
  dificil: [[18, 34, 20], [18, 34, 20], [18, 34, 20], [18, 34, 20], [18, 34, 20]],
};
/** Opponent build for a level and track (chefe upgrades per track). */
export function oppSetup(d: Difficulty, distance: number): Setup {
  const i = Math.max(0, TRACK_ORDER.findIndex((m) => Math.abs(m - distance) < 0.5));
  if (d === "facil" || d === "medio" || d === "dificil") return kitOpp(d, distance);
  if (d !== "chefe") return stockSetupOf(OPP_BIKE[d].id); // moto 100% original de fábrica (relação final da própria moto)
  return BOSS_SETUP[i]!;
}

/** Street race prize: base at 1/8 mile, ×1.5 per longer track. */
export function racePrize(d: Difficulty, distance: number) {
  const i = Math.max(0, TRACK_ORDER.findIndex((m) => Math.abs(m - distance) < 0.5));
  return Math.round(DIFFICULTY[d].prize * Math.pow(1.5, i));
}

/** Difficulty follows engine power: Fácil is always the original red Factor 150 (weakest stock), higher levels ride stronger Titan builds. */
export const OPP_BIKE: Record<Difficulty, BikeModel> = { iniciante: FACTOR_150, facil: CG_125, medio: TITAN_160, dificil: TITAN_150, chefe: TITAN_160 };

/** Kit 4MM por nível do computador: Fácil = Stage 1, Médio = Stage 2, Difícil = Stage 3. */
export const LEVEL_STAGE: Record<"facil" | "medio" | "dificil", Stage> = { facil: 1, medio: 2, dificil: 3 };
const FRONTS = [13, 14, 15, 16, 17, 18];
const REARS = [28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48];
const kitCache = new Map<string, Setup>();
/** Kit do nível com a relação (pinhão × coroa) que faz o menor tempo naquela pista, escolhida pela própria física. */
export function kitOpp(d: "facil" | "medio" | "dificil", distance: number): Setup {
  const k = `${d}:${distance}`;
  const hit = kitCache.get(k); if (hit) return hit;
  const bike = OPP_BIKE[d], plan = kitPlan(bike.id, LEVEL_STAGE[d]);
  const base = plan ? plan.setup : stockSetupOf(bike.id);
  let best = base, bestT = simulate(bike, base, distance, bike.tank).finishT ?? Infinity;
  for (const front of FRONTS) for (const rear of REARS) {
    const s = { ...base, front, rear };
    const t = simulate(bike, s, distance, bike.tank).finishT ?? Infinity;
    if (t < bestT - 1e-9) { bestT = t; best = s; }
  }
  kitCache.set(k, best);
  return best;
}

const cache = new Map<string, number>();
/** Computer finish time (s) for a level and distance, from its real build on a full tank. */
export function oppTime(d: Difficulty, distance: number) {
  const k = `${d}:${distance}`;
  if (!cache.has(k)) cache.set(k, Math.round(simulate(OPP_BIKE[d], oppSetup(d, distance), distance, OPP_BIKE[d].tank).finishT! * 1000) / 1000);
  return cache.get(k)!;
}
