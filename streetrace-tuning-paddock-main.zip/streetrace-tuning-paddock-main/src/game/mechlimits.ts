/**
 * Limites físicos do motor — quebra determinística, sem probabilidade.
 * A cada passo da simulação (DT = 1/240 s) o motor calcula força, pressão, temperatura,
 * folga e energia; quando uma grandeza passa do limite do material instalado, o motor quebra
 * NAQUELE instante e o laudo diz o número que estourou.
 */
import { CAM_FX, clutchCapNm, slotPart } from "./parts";
import { bordaAtropela, camLiftMm } from "./sintonia";
import { SERVICES, ccOf, engine, exhaustShape, gearSpeeds, mixFactor, mixtureAt, newSim, powerShape, stalled, step, timingOptimum, mapTiming, SERVITEC_ID, valveFloatRpm, type BikeModel, type Setup, type SimState } from "./physics";
import { newRodFatigue, rodFatigueOf, rodFatigueStep, type RodEstado, type RodFatigueState } from "./rodfatigue/rod-fatigue";
import { overhaulTxt, valveGap, EST, clutchSlipW, clutchTempStep, clutchThermalCapJ, crownGrowthMm, cycleAt, geoOf, rodLoads, rodStretchMm, type Cycle, type RodLoad } from "./enginephys";

const P_ATM = 1.013; // bar
const POLY = 1.33; // expoente politrópico da compressão
const COMB_RATIO = 3.4; // pressão de pico / pressão de compressão em plena carga
export const T_WARM = 200; // °C coroa do pistão no início (motor aquecido)
export const TAU_S = 4; // constante de tempo térmica da coroa
export const LIM = {
  pistonC: 480, // alumínio perde a resistência: coroa fura/derrete
  linerMPa: 90, // tensão circunferencial que trinca a camisa
  knock: 1, // dano acumulado de detonação
  clearanceMm: 0, // válvula encosta no pistão
};

export interface MechTelemetry {
  /** Pressão de compressão (bar) e de pico de combustão (bar). */
  pCompBar: number;
  pMaxBar: number;
  /** Força do gás sobre o pistão (N). */
  gasN: number;
  /** Força de inércia que estica a biela no PMS (N) e o limite da biela instalada. */
  rodN: number;
  rodLimitN: number;
  /** Fadiga da biela (só bielas com parâmetros em rod-fatigue.ts). */
  rodEstado?: RodEstado; rodUsoPct?: number; rodFadigaPct?: number; rodOverS?: number; rodOverCycles?: number; rodMaxRpm?: number; rodTensDeg?: number;
  /** Aceleração do pistão no PMS em g. */
  pistonG: number;
  /** Velocidade média do pistão (m/s). */
  vpm: number;
  /** Temperatura da coroa (°C) e de equilíbrio naquele regime. */
  pistonC: number;
  pistonEqC: number;
  /** Intensidade de detonação (0 = queima limpa) e dano acumulado (1 = fura). */
  knock: number;
  knockDmg: number;
  /** Rotação em que a mola perde a válvula, e folga válvula-pistão (mm). */
  floatRpm: number;
  clearanceMm: number;
  /** Tensão na parede do cilindro (MPa) e limite. */
  linerMPa: number;
  /** Energia dissipada na embreagem (J) e capacidade. */
  clutchJ: number;
  clutchCapJ: number;
  /** Torque no virabrequim (N·m) e choque no engate da última troca. */
  crankNm: number;
  shiftShockNm: number;
  /** Mistura: >0 pobre. */
  lean: number;
  /** Ângulo do pico de pressão depois do PMS (°), compressão máxima na biela (N) e temperatura dos discos (°C). */
  pPeakDeg?: number;
  rodCompN?: number;
  rodCompLimitN?: number;
  clutchC?: number;
  slipW?: number;
  /** Carga do passo (0..1) e força máxima no moente do virabrequim no ciclo (N). */
  load?: number;
  crankPinN?: number;
}
export interface MechBreak {
  cause: string;
  /** Frase com o número exato que estourou. */
  fisica: string;
  t: number;
  x: number;
  rpm: number;
  gear: number;
  kmh: number;
  tel: MechTelemetry;
  /** Biela: ruptura por sobrecarga instantânea ou por fadiga acumulada. */
  rodModo?: "SOBRECARGA" | "FADIGA";
}

/** Coroa do pistão: espessura de fábrica e mínima que ainda conduz o calor sem perder resistência. */
export const CROWN_MM = 5.5;
export const CROWN_SAFE_MM = 2.2;
/** Cava de fábrica dos pistões com cavas (mm). */
export const CAVA_STD_MM = 1.5;
/** Cava total e coroa restante; coroa abaixo do mínimo perde 40 °C de limite por mm faltante. */
export function machOf(s: Setup, cavasPart: boolean) {
  const cavaMm = s.mach?.cavaMm ?? (cavasPart ? CAVA_STD_MM : 0);
  const crownMm = Math.round((CROWN_MM - cavaMm) * 100) / 100;
  const pistonLimC = Math.round(LIM.pistonC - Math.max(0, CROWN_SAFE_MM - crownMm) * 40);
  return { cavaMm, crownMm, pistonLimC };
}

/** Giro máximo da biela de fábrica por moto (rpm): acima dele a inércia rompe a biela. */
export const FACTORY_ROD_RPM: Record<string, number> = { cg125: 11500, titan150: 9500, titan160: 9500, factor150: 9500 };
const svcList = (s: Setup) => s.services.map((id) => SERVICES.find((v) => v.id === id)).filter((x): x is NonNullable<typeof x> => !!x);
const fixOf = (s: Setup, slot: "biela" | "molas" | "embreagem", cause: string) => (slotPart(s.slots[slot], slot).fix ?? {})[cause] ?? 0;

/** Constantes da montagem: geometria, materiais e folgas (não mudam durante a corrida). */
export function buildOf(b: BikeModel, s: Setup) {
  // curso, biela e diâmetro do modelo (catálogo; fallback ESTIMADO em geoOf)
  const geo = geoOf(b, s);
  const { cc, boreMm, areaM2 } = geo;
  const pis = slotPart(s.slots.pistao, "pistao");
  const cyl = slotPart(s.slots.cilindro, "cilindro");
  const list = svcList(s);
  const has = (id: string) => s.services.includes(id);
  // massa alternativa: pistão + pino + anéis cresce com a área; forjado é ~8% mais leve
  const recKg = 0.18 * (boreMm / 57.3) ** 2 * (pis.id.includes("forjado") ? 0.92 : 1);
  // limite de ficha vale só para a biela ORIGINAL; bielas avulsas têm o próprio limite (9500 N + reforço)
  const rodPart = slotPart(s.slots.biela, "biela");
  // biela com giro declarado: força inercial ∝ ω², então o limite escala por (rpm_peça / rpm_fábrica)² sobre a biela de fábrica da moto
  // giro de referência da biela montada: o limite é a tração real (rodLoads) naquele giro, com o pistão montado → quebra só acima dele
  const rodRefRpm = rodPart.factory ? FACTORY_ROD_RPM[b.id] ?? 9500 : rodPart.rodRpm ?? 9500;
  const rodBase = Math.ceil(rodLoads(geo, cycleAt(b, s, rodRefRpm, 1, 0, 0), rodRefRpm, recKg).tensionN) + 1;
  const rodLimitN = rodBase + fixOf(s, "biela", "Biela quebrada") * 160;
  const cam = CAM_FX[s.cam] ?? CAM_FX.original;
  const liftSvc = list.filter((x) => x.needsCavas).length;
  const floatRpm = valveFloatRpm(s);
  const cavas = !!pis.cavas || list.some((x) => x.cavas) || (s.mach?.cavaMm ?? 0) > 0;
  const m = machOf(s, cavas);
  // levante real do comando montado contra a folga de fábrica (comando original ≈ 5,0 mm)
  const liftExtra = Math.max(0, camLiftMm(s.cam) - 5.0) * 0.12;
  let clearance0 = 1.1 - liftSvc * 0.5 - cam.risk * 0.03 - liftExtra + m.cavaMm - (s.mach?.rebaixoMm ?? 0) - (s.mach?.domeMm ?? 0) + (s.mach?.assentoMm ?? 0) + (slotPart(s.slots.molas, "molas").valveRecessMm ?? 0);
  // válvula maior que a cava: a borda bate na lateral do rebaixo, profundidade não salva
  if (m.cavaMm > 0 && bordaAtropela(b.id, s)) clearance0 = Math.min(clearance0, -0.4);
  const pistonLimC = m.pistonLimC;
  const wallMm = cyl.factory ? 5 : cyl.id === "cilindro-220" ? (has("parede-grossa") ? 4 : 2) : cyl.id === "cilindro-205" ? (has("parede-grossa") ? 4.5 : 3) : 4;
  const clutchNm = clutchCapNm(s);
  // massa térmica dos discos cresce com a capacidade (mais discos); capacidade = m·c·(T_lim − T_ini)
  const clutchKgMul = (clutchNm / 22) * (1 + fixOf(s, "embreagem", "Embreagem queimada") * 0.03);
  const clutchCapJ = clutchThermalCapJ(clutchKgMul);
  const gearLimitNm = 48 + fixOf(s, "embreagem", "Câmbio espanado") * 3;
  const eth = s.fuel === "etanol" && b.flex;
  const crLimit = eth ? 12 : 11;
  const prog = !!slotPart(s.slots.modulo, "modulo").prog;
  const mt = mapTiming(b, s);
  const timingOver = mt != null && (prog || s.slots.modulo === SERVITEC_ID) ? Math.max(0, mt - timingOptimum(b, s)) : 0;
  const honed = !cyl.stress || has("brunimento");
  // compressão: o menor entre escoamento da seção e flambagem de Euler (escala com a biela instalada)
  const rodCompLimitN = Math.min(EST.rodYieldMPa * EST.rodAreaMm2, Math.PI ** 2 * EST.rodE_GPa * 1e3 * EST.rodI_mm4 / geo.rodMm ** 2) * ((rodLimitN - rodBase + 9500) / 9500);
  const timingAdv = prog ? s.ecu.timing : 0;
  return { cc, boreMm, areaM2, recKg, rodLimitN, rodCompLimitN, clutchKgMul, clutchNm, timingAdv, geo, cyc: new Map<string, { c: Cycle; r: RodLoad }>(), floatRpm, cavas, clearance0, pistonLimC, crownMm: m.crownMm, wallMm, clutchCapJ, gearLimitNm, crLimit, prog, timingOver, honed, leanCut: prog && !!s.ecu.leanCut, rodFatigue: rodFatigueOf(b.id, s.slots.biela) };
}
export type Build = ReturnType<typeof buildOf>;
export { valveFloatRpm };

export interface MechState {
  clutchC?: number;
  pistonC: number;
  knockDmg: number;
  clutchJ: number;
  gear: number;
  tel: MechTelemetry | null;
  rod?: RodFatigueState;
}
export const newMech = (): MechState => ({ clutchC: EST.clutchStartC, pistonC: T_WARM, knockDmg: 0, clutchJ: 0, gear: 1, tel: null, rod: newRodFatigue() });

/** Carga do motor girando solto no limitador (sem tração; corte de ignição alterna) — ESTIMADO. */
export const FREE_REV_LOAD = 0.3;
/** Duração da pré-largada (s): 4 s lenta · 4 s progressão até o giro máximo · 2 s cortando giro. */
export const PRELAUNCH_S = 10;
export const PRELAUNCH_IDLE_S = 4;
export const PRELAUNCH_RAMP_S = 4;
/** Mantido por compatibilidade: o giro de largada agora é o corte de cada motor (launchRpm). */
export const LAUNCH_RPM = 7000;
export const PRELAUNCH_REV_S = PRELAUNCH_RAMP_S;
export type PreLaunchPhase = "lenta" | "subida" | "limitador";
/**
 * Curva única da pré-largada de 10 s (painel, som e calor usam a mesma):
 * 0–4 s lenta · 4–8 s progressão (smoothstep) até o giro máximo · 8–10 s no corte; aos 10 s solta a embreagem de uma vez.
 */
export function preLaunchAt(t: number, idle: number, _lim: number, launchAt: number): { rpm: number; load: number; phase: PreLaunchPhase } {
  if (t < PRELAUNCH_IDLE_S) return { rpm: idle, load: 0.05, phase: "lenta" };
  const k = (t - PRELAUNCH_IDLE_S) / PRELAUNCH_RAMP_S;
  if (k >= 1) return { rpm: launchAt, load: FREE_REV_LOAD, phase: "limitador" };
  return { rpm: idle + (launchAt - idle) * (k * k * (3 - 2 * k)), load: FREE_REV_LOAD * (0.3 + 0.7 * k), phase: "subida" };
}

/**
 * Pré-largada de 10 s pela curva preLaunchAt().
 * Integra a mesma EDO térmica da coroa (dT/dt = (T_eq − T)/τ) de mechStep(), deterministicamente.
 */
export function preLaunchHeat(ms: MechState, b: BikeModel, s: Setup, k: Build, launchAt: number, idle = 1300, dt = 1 / 60) {
  const lim = engine(b, s).rpmLimit;
  for (let t = 0; t < PRELAUNCH_S; t += dt) {
    const { rpm, load } = preLaunchAt(t, idle, lim, launchAt);
    const ph = physicsAt(b, s, k, rpm, load, ms.pistonC);
    ms.pistonC += ((ph.eqC - ms.pistonC) / TAU_S) * dt;
    ms.knockDmg += (ph.knock * dt) / 3;
  }
  return ms;
}

/** Grandezas físicas num regime (rpm, carga) — usado no passo da corrida e nos relatórios. */
export function physicsAt(b: BikeModel, s: Setup, k: Build, rpm: number, load: number, pistonC: number) {
  const e = engine(b, s);
  const omega = (rpm * 2 * Math.PI) / 60;
  const lean = mixtureAt(s, rpm, e.rpmPeak).lean;
  const tHigh = k.prog ? Math.max(0, (s.ecu.tHigh ?? 0) - 1.5) : 0;
  const tLow = k.prog ? Math.max(0, (s.ecu.tLow ?? 0) - 0.5) : 0;
  const bandOver = rpm >= 8000 ? tHigh : rpm <= 6000 ? tLow : 0;
  // ESTIMADO: índice de detonação (sem modelo de autoignição validado)
  const knock = load * (Math.max(0, s.compression - k.crLimit) * 0.5 + (k.timingOver + bandOver) * 0.12 + Math.max(0, lean) * 0.8 * Math.max(0, s.compression - 10));
  // ciclo termodinâmico (Wiebe + politrópica) e forças na biela em 720°, memorizados por regime
  const key = `${Math.round(rpm / 50)}|${Math.round(load * 10)}|${Math.round(knock * 50)}`;
  let cr = k.cyc.get(key);
  if (!cr) {
    const c = cycleAt(b, s, rpm, load, knock, k.timingAdv);
    cr = { c, r: rodLoads(k.geo, c, rpm, k.recKg) };
    k.cyc.set(key, cr);
  }
  const pComp = cr.c.pCompBar;
  const pMax = cr.c.pMaxBar;
  const gasN = cr.r.gasPeakN;
  const rodN = cr.r.tensionN;
  const accel = k.geo.rM * omega * omega * (1 + k.geo.rM / k.geo.lM);
  const linerMPa = (pMax * 0.1 * k.boreMm) / (2 * k.wallMm);
  const leanHeat = Math.max(0, lean) * 1800 * (k.leanCut ? 0.4 : 1);
  const eqC = 260 + load * (60 + (k.cc / 162.7 - 1) * 120 + leanHeat + knock * 150 + (k.honed ? 0 : 40) + Math.max(0, s.compression - 9.5) * 8);
  // folga dinâmica: coroa dilata (α·L·ΔT), biela estica (F·L/E·A) e mancal/pino absorvem 0,05 mm sob tração (estimado)
  // + geometria: menor distância pistão-válvula no cruzamento com loft da válvula quando a mola não segura
  const gk = `vg${Math.round(rpm / 50)}`;
  let vg = k.cyc.get(gk) as unknown as ReturnType<typeof valveGap> | undefined;
  if (!vg) { vg = valveGap(k.geo, k.clearance0, rpm, k.floatRpm); k.cyc.set(gk, vg as never); }
  const clearance = vg.minMm - crownGrowthMm(pistonC) - rodStretchMm(rodN, k.geo.rodMm) - 0.05;
  const shape = powerShape(rpm, e.rpmPeak, b, s) * mixFactor(s, rpm, e.rpmPeak) * exhaustShape(b, s, rpm, e.rpmPeak);
  const crankNm = omega > 0 ? (e.hp * 735.5 * shape * load) / omega : 0;
  return { rodTensDeg: cr.r.tensionDeg, crankPinN: cr.r.crankPinN, omega, rodN, rodCompN: cr.r.compressionN, pPeakDeg: cr.c.thPeakDeg, pistonG: accel / 9.81, vpm: (2 * (k.geo.strokeMm / 1000) * rpm) / 60, lean, knock, pComp, pMax, gasN, linerMPa, eqC, clearance, crankNm, pistonC };
}

const r1 = (n: number) => Math.round(n * 10) / 10;

/**
 * Carga real do motor no passo: seca/troca = 0,1 (marcha lenta sem tração); limitador cortando = carga de giro solto;
 * fora disso, o acelerador efetivo do piloto (st.thr, que cai no alívio de empinada/patinagem). Sem st.thr (rolo do dino) = plena.
 */
export const loadOf = (st: SimState) => (st.dry || st.shiftT > 0 ? 0.1 : st.limiter ? FREE_REV_LOAD : Math.max(0.1, st.thr ?? 1));

/**
 * Um passo físico. Chame logo depois de step(); devolve a quebra se algum limite estourou.
 */
export function mechStep(ms: MechState, st: SimState, b: BikeModel, s: Setup, k: Build, dt: number): MechBreak | null {
  if (st.finishT !== null) return null;
  const load = loadOf(st);
  const ph = physicsAt(b, s, k, st.rpm, load, ms.pistonC);
  ms.pistonC += ((ph.eqC - ms.pistonC) / TAU_S) * dt;
  ms.knockDmg += (ph.knock * dt) / 3;
  const omega = ph.omega;
  // deslize: P = T_transmitido·|ω_motor − ω_câmbio|; ω_câmbio vem da velocidade da roda na marcha
  const gTop = (gearSpeeds(b, s)[st.gear - 1] ?? 100) / 3.6;
  const omegaGb = (st.v / gTop) * ((engine(b, s).rpmLimit * 2 * Math.PI) / 60);
  const slipW = st.shiftT > 0 || omega <= omegaGb ? 0 : clutchSlipW(Math.min(ph.crankNm, k.clutchNm), omega, omegaGb);
  ms.clutchJ += slipW * dt;
  ms.clutchC = clutchTempStep(ms.clutchC ?? EST.clutchStartC, slipW, dt, 90, k.clutchKgMul);
  let shock = 0;
  if (st.gear !== ms.gear) {
    const qs = k.prog ? (s.ecu.qsGear?.[ms.gear - 1] || s.ecu.qs || 220) : 220;
    shock = ph.crankNm * (120 / qs);
    ms.gear = st.gear;
  }
  const tel: MechTelemetry = {
    pCompBar: r1(ph.pComp), pMaxBar: r1(ph.pMax), gasN: Math.round(ph.gasN), rodN: Math.round(ph.rodN), rodLimitN: k.rodLimitN, pistonG: Math.round(ph.pistonG), vpm: r1(ph.vpm),
    pistonC: Math.round(ms.pistonC), pistonEqC: Math.round(ph.eqC), knock: Math.round(ph.knock * 100) / 100, knockDmg: Math.round(ms.knockDmg * 100) / 100,
    floatRpm: Math.round(k.floatRpm), clearanceMm: Math.round(ph.clearance * 100) / 100, linerMPa: r1(ph.linerMPa), clutchJ: Math.round(ms.clutchJ), clutchCapJ: Math.round(k.clutchCapJ),
    crankNm: r1(ph.crankNm), shiftShockNm: r1(shock), lean: Math.round(ph.lean * 1000) / 1000,
    pPeakDeg: r1(ph.pPeakDeg), rodCompN: Math.round(ph.rodCompN), rodCompLimitN: Math.round(k.rodCompLimitN), clutchC: Math.round(ms.clutchC), slipW: Math.round(slipW),
    load, crankPinN: Math.round(ph.crankPinN),
  };
  ms.tel = tel;
  const at = (cause: string, fisica: string): MechBreak => ({ cause, fisica, t: st.t, x: st.x, rpm: Math.round(st.rpm), gear: st.gear, kmh: r1(st.v * 3.6), tel });
  if (k.rodFatigue) {
    const f = (ms.rod ??= newRodFatigue());
    const modo = rodFatigueStep(f, k.rodFatigue, st.rpm, ph.rodN, k.rodLimitN, dt);
    Object.assign(tel, { rodEstado: f.estado, rodUsoPct: Math.round((ph.rodN / k.rodLimitN) * 1000) / 10, rodFadigaPct: Math.round(f.dano * 1000) / 10, rodOverS: Math.round(f.overS * 1000) / 1000, rodOverCycles: Math.round(f.overCycles), rodMaxRpm: Math.round(f.maxRpm), rodTensDeg: ph.rodTensDeg });
    if (modo === "SOBRECARGA") return { ...at("Biela quebrada", `Sobrecarga instantânea: tração de ${tel.rodN} N a ${Math.round(st.rpm)} rpm passou ${k.rodFatigue.razaoRuptura}× a referência de ${k.rodLimitN} N (${k.rodFatigue.refRpm} rpm); ruptura sem depender de fadiga (fadiga no instante ${tel.rodFadigaPct}%).`), rodModo: modo };
    if (modo === "FADIGA") return { ...at("Biela quebrada", `Fadiga acumulada: vida esgotada (100%) após ${tel.rodOverCycles} ciclos de tração acima de ${k.rodLimitN} N em ${tel.rodOverS} s acima de ${k.rodFatigue.refRpm} rpm; último ciclo ${tel.rodN} N (${tel.rodUsoPct}% da referência). Miner D = Σ n/N, N = ${k.rodFatigue.n0}·x^-${k.rodFatigue.m}.`), rodModo: modo };
  } else if (ph.rodN > k.rodLimitN) return at("Biela quebrada", `Inércia de ${tel.rodN} N esticou a biela no PMS a ${Math.round(st.rpm)} rpm (${tel.pistonG} g no pistão); a biela instalada aguenta ${k.rodLimitN} N.`);
  if (ph.rodCompN > k.rodCompLimitN) return at("Biela quebrada", `Compressão de ${tel.rodCompN} N na biela (pico de ${tel.pMaxBar} bar a ${tel.pPeakDeg}° APMS); a biela instalada aguenta ${tel.rodCompLimitN} N em compressão/flambagem.`);
  if (ph.clearance < LIM.clearanceMm) return at("Válvula atropelada", `Folga válvula-pistão chegou a ${tel.clearanceMm} mm a ${Math.round(st.rpm)} rpm (mola solta a válvula a partir de ${tel.floatRpm} rpm${k.cavas ? "" : ", pistão sem cavas"}).`);
  if (ph.linerMPa > LIM.linerMPa) return at("Cilindro trincado", `Pico de ${tel.pMaxBar} bar gerou ${tel.linerMPa} MPa na parede de ${k.wallMm} mm do cilindro; a camisa trinca acima de ${LIM.linerMPa} MPa.`);
  if (ms.pistonC > k.pistonLimC) return at(ph.lean > 0.02 ? "Pistão derretido · mistura pobre" : ph.knock > 0.05 ? "Pistão furado" : k.honed ? "Pistão travou no cilindro" : "Anéis quebrados", `Coroa do pistão chegou a ${tel.pistonC} °C (equilíbrio ${tel.pistonEqC} °C; mistura ${ph.lean > 0 ? `${Math.round(ph.lean * 100)}% pobre` : "ok"}, detonação ${tel.knock}); o alumínio cede acima de ${k.pistonLimC} °C${k.crownMm < CROWN_SAFE_MM ? ` (coroa usinada com só ${k.crownMm} mm)` : ""}.`);
  if (ms.knockDmg >= LIM.knock) return at("Pistão furado", `Detonação contínua (intensidade ${tel.knock}) com pico de ${tel.pMaxBar} bar martelou a coroa até o dano chegar a 100%.`);
  if ((ms.clutchC ?? 0) > EST.clutchLimC) return at("Embreagem queimada", `Discos chegaram a ${tel.clutchC} °C dissipando ${tel.slipW} W no deslize (${tel.clutchJ} J no total); o material de atrito vitrifica acima de ${EST.clutchLimC} °C.`);
  if (ms.clutchJ > k.clutchCapJ) return at("Embreagem queimada", `Embreagem patinando dissipou ${tel.clutchJ} J; os discos aguentam ${tel.clutchCapJ} J.`);
  if (shock > k.gearLimitNm) return at("Câmbio espanado", `Engate da ${st.gear}ª com choque de ${tel.shiftShockNm} N·m (corte curto do quickshifter); os dentes aguentam ${k.gearLimitNm} N·m.`);
  return null;
}

/** Roda a corrida inteira sem adversário e devolve onde (e por que) o motor quebra, ou null. */
export function physicalBreak(b: BikeModel, s: Setup, distance: number, fuelL = b.tank): (MechBreak & { at: number }) | null {
  const work = physicalBreakSteps(b, s, distance, fuelL);
  let next = work.next();
  while (!next.done) next = work.next();
  return next.value;
}

export function* physicalBreakSteps(b: BikeModel, s: Setup, distance: number, fuelL = b.tank): Generator<void, (MechBreak & { at: number }) | null> {
  const st = newSim(fuelL);
  const ms = newMech();
  const k = buildOf(b, s);
  while (st.finishT === null && !stalled(st) && st.t < 900) {
    step(st, b, s, 1 / 240, distance);
    const br = mechStep(ms, st, b, s, k, 1 / 240);
    if (br) return { ...br, at: br.x };
    yield;
  }
  return null;
}

/** Seção TXT do relatório ao vivo: as contas de força, pressão, calor e folga, e o veredito físico. */
export function mechTxt(b: BikeModel, s: Setup, distance: number, fuelL = b.tank): string {
  const work = mechTxtSteps(b, s, distance, fuelL);
  let next = work.next();
  while (!next.done) next = work.next();
  return next.value;
}

export function* mechTxtSteps(b: BikeModel, s: Setup, distance: number, fuelL = b.tank): Generator<void, string> {
  const k = buildOf(b, s);
  const e = engine(b, s);
  const L: string[] = ["", "================ FÍSICA DO MOTOR · LIMITES DOS MATERIAIS (sem probabilidade) ================"];
  L.push(`Geometria: Ø ${r1(k.boreMm)} mm × curso ${k.geo.strokeMm} mm [${k.geo.strokeOrigem}] · biela ${k.geo.rodMm} mm [${k.geo.rodOrigem}] · rod_ratio (r/l) = ${(k.geo.strokeMm / 2 / k.geo.rodMm).toFixed(4)} · ${Math.round(k.cc * 10) / 10} cc`);
  L.push(`Área do pistão A = π·D²/4 = ${(k.areaM2 * 1e4).toFixed(3)} cm² · massa alternativa m = ${(k.recKg * 1000).toFixed(0)} g`);
  L.push(`Compressão P_comp = ${P_ATM}·${s.compression}^${POLY} = ${r1(P_ATM * s.compression ** POLY)} bar · limite antidetonante do combustível: ${k.crLimit}:1`);
  L.push(`Limites instalados: biela ${k.rodLimitN} N · mola solta a válvula em ${Math.round(k.floatRpm)} rpm · folga estática ${k.clearance0.toFixed(2)} mm${k.cavas ? " (com cavas)" : ""} · parede ${k.wallMm} mm (≤ ${LIM.linerMPa} MPa) · embreagem ${Math.round(k.clutchCapJ)} J · coroa ${k.crownMm} mm ≤ ${k.pistonLimC} °C`);
  L.push("", "rpm     | F_inércia = m·r·ω²·(1+rod_ratio) | g pistão | Vpm m/s | P_max bar | F_gás N | σ parede MPa | folga mm | detonação | T equilíbrio coroa");
  for (const rpm of [6000, e.rpmPeak, e.rpmLimit]) {
    const ph = physicsAt(b, s, k, rpm, 1, T_WARM);
    L.push(`${String(Math.round(rpm)).padEnd(7)} | ${String(Math.round(ph.rodN)).padStart(6)} N de ${k.rodLimitN} N      | ${String(Math.round(ph.pistonG)).padStart(6)} | ${r1(ph.vpm).toString().padStart(7)} | ${r1(ph.pMax).toString().padStart(9)} | ${String(Math.round(ph.gasN)).padStart(7)} | ${r1(ph.linerMPa).toString().padStart(12)} | ${ph.clearance.toFixed(2).padStart(8)} | ${ph.knock.toFixed(2).padStart(9)} | ${Math.round(ph.eqC)} °C${ph.lean > 0.01 ? ` (mistura ${Math.round(ph.lean * 100)}% pobre)` : ""}`);
  }
  L.push("", "Calor da coroa: dT/dt = (T_eq − T)/τ, τ = " + TAU_S + " s, partindo de " + T_WARM + " °C. Dano de detonação: dD/dt = intensidade/3 s.");
  const br = yield* physicalBreakSteps(b, s, distance, fuelL);
  L.push(overhaulTxt(b, s, { rodLimitN: k.rodLimitN, rodCompLimitN: k.rodCompLimitN, clearance0Mm: k.clearance0, floatRpm: k.floatRpm }));
  // verificação no corte: uma folga negativa ou carga acima do limite nunca some do veredito final
  const cut = physicsAt(b, s, k, e.rpmLimit, 1, T_WARM);
  const over: string[] = [];
  if (cut.clearance < LIM.clearanceMm) over.push(`[COLISÃO MECÂNICA] folga pistão-válvula ${cut.clearance.toFixed(2)} mm no corte de ${e.rpmLimit} rpm`);
  if (cut.rodN > k.rodLimitN) over.push(`[FAILURE] biela em tração ${Math.round(cut.rodN)} N > ${k.rodLimitN} N no corte`);
  if (cut.rodCompN > k.rodCompLimitN) over.push(`[FAILURE] biela em compressão ${Math.round(cut.rodCompN)} N > ${Math.round(k.rodCompLimitN)} N no corte`);
  if (cut.linerMPa > LIM.linerMPa) over.push(`[FAILURE] parede do cilindro ${r1(cut.linerMPa)} MPa > ${LIM.linerMPa} MPa no corte`);
  if (fuelL <= 0) L.push("[TESTE NÃO EXECUTADO POR FALTA DE COMBUSTÍVEL] tanque vazio: nenhum limite foi exercitado; nada é aprovado.");
  if (over.length) L.push("Verificação no regime de corte (independe de a corrida chegar lá):", ...over.map((x) => "  " + x));
  L.push(fuelL <= 0 ? "" : br ? `[QUEBRA FÍSICA] ${br.cause} aos ${Math.round(br.x)} m, ${br.t.toFixed(2)} s, ${br.gear}ª a ${br.rpm} rpm: ${br.fisica}` : over.length ? `[NÃO APROVADO] a corrida de ${distance} m não quebrou, mas o motor excede limites no corte (acima).` : `[OK] Nenhum limite físico é ultrapassado nos ${distance} m (corrida sem adversário).`);
  return L.join("\n");
}

/**
 * Dinamômetro: varre o giro na ordem real da puxada (rpmAt(t)) com carga plena e roda o mesmo mechStep()
 * da corrida. Embreagem travada no rolo (sem deslize), marcha fixa. Quebra só se um limite físico estourar.
 */
export function benchBreak(b: BikeModel, s: Setup, rpmAt: (tS: number) => number, sweepS: number, dt = 1 / 240): (MechBreak & { frac: number }) | null {
  const work = benchBreakSteps(b, s, rpmAt, sweepS, dt);
  let next = work.next();
  while (!next.done) next = work.next();
  return next.value;
}

export function* benchBreakSteps(b: BikeModel, s: Setup, rpmAt: (tS: number) => number, sweepS: number, dt = 1 / 240): Generator<void, (MechBreak & { frac: number }) | null> {
  const k = buildOf(b, s);
  const ms = newMech();
  const st = newSim(b.tank);
  st.v = 1e6; // rolo acoplado: ω_câmbio ≥ ω_motor, P_deslize = 0
  const r0 = rpmAt(0), r1x = rpmAt(sweepS);
  for (let t = 0; t <= sweepS; t += dt) {
    st.t = t;
    st.rpm = rpmAt(t);
    const br = mechStep(ms, st, b, s, k, dt);
    if (br) return { ...br, frac: (st.rpm - r0) / Math.max(1, r1x - r0) };
    yield;
  }
  return null;
}

/** Carga de cruzeiro de entrega (fração da plena carga) — PARÂMETRO CALIBRADO DO JOGO. */
export const STREET_LOAD = 0.6;
/**
 * Entrega na rua: regime permanente (dT/dt = 0 → T_coroa = T_eq) de 3000 rpm até o corte em carga de cruzeiro.
 * Sem sorteio: quebra só quando força, folga, tensão ou temperatura de equilíbrio passam do limite instalado.
 */
export function streetBreak(b: BikeModel, s: Setup): { cause: string; fisica: string; rpm: number } | null {
  const k = buildOf(b, s);
  const lim = engine(b, s).rpmLimit;
  for (let rpm = 3000; rpm <= lim; rpm += 250) {
    let T = T_WARM;
    for (let i = 0; i < 8; i++) T = physicsAt(b, s, k, rpm, STREET_LOAD, T).eqC; // ponto fixo térmico
    const ph = physicsAt(b, s, k, rpm, STREET_LOAD, T);
    const r = Math.round(rpm);
    if (ph.rodN > k.rodLimitN * (k.rodFatigue?.razaoRuptura ?? 1)) return { cause: "Biela quebrada", rpm: r, fisica: `Inércia de ${Math.round(ph.rodN)} N a ${r} rpm; a biela aguenta ${k.rodLimitN} N.` };
    if (ph.rodCompN > k.rodCompLimitN) return { cause: "Biela quebrada", rpm: r, fisica: `Compressão de ${Math.round(ph.rodCompN)} N a ${r} rpm; limite ${Math.round(k.rodCompLimitN)} N.` };
    if (ph.clearance < LIM.clearanceMm) return { cause: "Válvula atropelada", rpm: r, fisica: `Folga válvula-pistão ${ph.clearance.toFixed(2)} mm a ${r} rpm.` };
    if (ph.linerMPa > LIM.linerMPa) return { cause: "Cilindro trincado", rpm: r, fisica: `${r1(ph.linerMPa)} MPa na parede de ${k.wallMm} mm; limite ${LIM.linerMPa} MPa.` };
    if (T > k.pistonLimC) return { cause: ph.lean > 0.02 ? "Pistão derretido · mistura pobre" : ph.knock > 0.05 ? "Pistão furado" : k.honed ? "Pistão travou no cilindro" : "Anéis quebrados", rpm: r, fisica: `Coroa em equilíbrio a ${Math.round(T)} °C a ${r} rpm em cruzeiro; o alumínio cede acima de ${k.pistonLimC} °C.` };
    if (ph.knock > 0 && ph.knock * 3600 / 3 >= LIM.knock * 60) return { cause: "Pistão furado", rpm: r, fisica: `Detonação contínua (intensidade ${ph.knock.toFixed(2)}) a ${r} rpm em cruzeiro acumula 100% de dano na coroa.` };
  }
  return null;
}
