// Live economy pegged to the real USD/BRL rate. Prices in the catalog are the base at BASE_USD;
// each part passes a share of the dollar move to the counter price (imports 100%, national parts less).
import { cloudStore } from "@/game/cloud/cloud-store";
import type { Part } from "./parts";

export const BASE_USD = 5.4;
const KEY = "streetrace-usd-v1";
type Quote = { bid: number; pct: number; high: number; low: number; t: number };

let live: Quote | null = null;
const subs = new Set<() => void>();

if (typeof window !== "undefined") {
  try {
    const c = JSON.parse(cloudStore.getItem(KEY) || "null");
    if (c && typeof c.bid === "number") live = c;
  } catch {
    /* ignore */
  }
}

/** Fetch the real commercial dollar (AwesomeAPI) at most once every 5 min. */
export async function refreshUsd() {
  if (typeof window === "undefined") return;
  if (live && Date.now() - live.t < 300000) return;
  try {
    let q: Quote | null = null;
    try {
      const j = (await (await fetch("https://economia.awesomeapi.com.br/json/last/USD-BRL")).json()).USDBRL;
      if (j && +j.bid > 0) q = { bid: +j.bid, pct: +j.pctChange, high: +j.high, low: +j.low, t: Date.now() };
    } catch {
      /* try backup */
    }
    if (!q) {
      const j = await (await fetch("https://open.er-api.com/v6/latest/USD")).json();
      const bid = +j?.rates?.BRL;
      if (!(bid > 0)) return;
      const pct = live ? ((bid - live.bid) / live.bid) * 100 : 0;
      q = { bid, pct, high: Math.max(bid, live?.high ?? bid), low: Math.min(bid, live?.low ?? bid), t: Date.now() };
    }
    live = q;
    cloudStore.setItem(KEY, JSON.stringify(live));
    subs.forEach((f) => f());
  } catch {
    /* offline: keep last quote */
  }
}
export const onUsd = (f: () => void) => (subs.add(f), () => subs.delete(f));

/** Current rate: last real quote with a small per-minute trading drift; base when never fetched. */
export function usdRate(now = Date.now()) {
  if (!live) return BASE_USD;
  const m = now / 60000;
  const drift = Math.sin(m / 7.3) * 0.002 + Math.sin(m / 1.9) * 0.0008;
  return Math.round(live.bid * (1 + drift) * 10000) / 10000;
}
export const usdQuote = () => live;

const IMPORT_BRANDS = ["Athlon Racing", "Fueltech", "FuelTech", "Bosch", "Motobatt", "DID", "NGK", "Motul", "Pirelli", "RIK", "Andreani", "Hyperpro", "Marchesini", "Barnett", "EBC", "Hot Rods", "Kibbel", "Vesrah", "YSS", "Yuasa", "Skyrich", "Shido", "Mobil", "Nology", "Brisk", "Stedi", "Racing Line"];
/** Share of the dollar move passed to the price (0..1). */
export function usdShare(x: Pick<Part, "brand" | "spec" | "factory">) {
  if (IMPORT_BRANDS.includes(x.brand) || /forjad/i.test(x.spec)) return 1;
  if (x.factory || x.brand === "Honda") return 0.6;
  return 0.4;
}

/** Counter price now (R$, cents). Equals the catalog price at BASE_USD. */
export function priceNow(x: Part, _rate?: number) {
  // preço fixo de tabela: não há mais taxa de balcão nem variação pelo dólar
  return x.price ? Math.round(x.price * 100) / 100 : 0;
}

/** Fuel follows oil priced in dollar: ~half of the pump price moves with the rate. */
export const fuelUsdMul = (_rate?: number) => 1; // combustível com preço fixo

export function news(rate = usdRate()) {
  const d = (rate / BASE_USD - 1) * 100;
  const pct = live?.pct ?? 0;
  const out: string[] = [];
  if (pct > 0.3) out.push("Dólar opera em alta hoje: importados sobem na AutoStreet.");
  else if (pct < -0.3) out.push("Dólar recua no pregão: boa janela pra comprar módulo e bicos importados.");
  else out.push("Dólar de lado no pregão: preços estáveis nas lojas.");
  if (d > 3) out.push("Câmbio acima da média: kits forjados e corrente DID com reajuste.");
  if (d < -3) out.push("Real valorizado: peças importadas abaixo da tabela.");
  out.push(d > 0 ? "Petróleo em dólar pressiona a gasolina nas bombas." : "Gasolina alivia com o câmbio mais baixo.");
  out.push("Peças nacionais repassam só parte da variação do dólar.");
  return out;
}
