// Chat da Bancada: o mecânico comenta cada serviço e a puxada do dinamômetro.
// A conversa fica guardada na sessão para não sumir ao ir no rolo e voltar.
export interface Note { de: "mec"; texto: string; key?: string }

type Listener<T> = (fn: (m: T[]) => T[]) => void;
let saved: unknown[] | null = null;
let listener: Listener<unknown> | null = null;
const MAX = 60;

/** Aplica uma mensagem: com key, substitui a anterior da mesma key (sem flood). */
export function applyNote<T extends { key?: string }>(list: T[], n: T): T[] {
  const base = n.key ? list.filter((x) => x.key !== n.key) : list;
  return [...base, n].slice(-MAX);
}

export function mechSay(texto: string, key?: string) {
  if (!texto) return;
  const n: Note = { de: "mec", texto, ...(key ? { key } : {}) };
  if (listener) listener((m) => applyNote(m as Note[], n));
  else if (saved) saved = applyNote(saved as Note[], n);
  else saved = [n];
}

export function bindBench<T>(set: Listener<T>, initial: () => T[]): { start: T[]; save: (m: T[]) => void; unbind: () => void } {
  listener = set as Listener<unknown>;
  const start = (saved as T[] | null) ?? initial();
  return { start, save: (m) => { saved = m; }, unbind: () => { if (listener === (set as Listener<unknown>)) listener = null; } };
}
