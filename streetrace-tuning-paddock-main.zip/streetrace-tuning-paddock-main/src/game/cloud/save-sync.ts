// Compatibilidade: a nuvem agora é a única fonte (cloud-store.ts). Estas funções só repassam.
import { cloudState, onCloudStore, startCloudStore } from "./cloud-store";

export type SaveKind = "player" | "eng";
export const cloudStatus = () => { const s = cloudState(); return { status: s.status, userId: s.userId }; };
export const onCloud = onCloudStore;
/** Gravações já sobem pelo cloudStore; mantido para chamadas antigas. */
export function pushLater(_kind: SaveKind) { /* nada */ }
export function startCloudSync(_onPulled: (kinds: SaveKind[]) => void) { startCloudStore(); }
