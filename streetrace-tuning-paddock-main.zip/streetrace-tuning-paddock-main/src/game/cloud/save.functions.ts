// Única porta de gravação do save do piloto: valida posse e transição no servidor (save-guard).
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { checkSave } from "./save-guard";

export const savePlayer = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { playerId: string; data: unknown }) => {
    if (!d || typeof d.playerId !== "string" || !/^[0-9a-f-]{36}$/i.test(d.playerId)) throw new Error("jogador inválido");
    if (JSON.stringify(d.data ?? null).length > 2_000_000) throw new Error("save grande demais");
    return d;
  })
  .handler(async ({ data, context }) => {
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    const { data: own } = await db.from("players").select("id").eq("id", data.playerId).eq("user_id", context.userId).maybeSingle();
    if (!own) return { ok: false as const, motivo: "jogador não é seu", data: null };
    const kind = `player:${data.playerId}`;
    const { data: row } = await db.from("game_saves").select("data,updated_at").eq("user_id", context.userId).eq("kind", kind).maybeSingle();
    if (data.data === null) return { ok: false as const, motivo: "apagar save não é permitido", data: row?.data ?? null };
    const elapsed = row ? (Date.now() - new Date(row.updated_at).getTime()) / 1000 : 0;
    const v = checkSave((row?.data ?? null) as never, data.data as never, elapsed);
    if (!v.ok) return { ok: false as const, motivo: v.motivo, data: row?.data ?? null };
    const { error } = await db.from("game_saves").upsert({ user_id: context.userId, kind, data: data.data as never, updated_at: new Date().toISOString() });
    if (error) throw new Error("falha ao gravar");
    return { ok: true as const, motivo: null, data: null };
  });
