import { Fragment, useEffect, useSyncExternalStore, type ReactNode } from "react";
import { activePlayer, cloudState, isEntering, setEntering, onCloudStore, setPlayerSaver, startCloudStore } from "./cloud-store";
import { savePlayer } from "./save.functions";

setPlayerSaver(savePlayer);
import { createPlayer, getPlayer, loadSave, setPlayer } from "../store";
import { Loading } from "../ui/Loading";
import { Landing } from "@/components/landing/Landing";
import { startPresence } from "../social/presence";
import { StandingGate } from "../support/StandingGate";

let snap = cloudState();
// snapshot sempre calculado na hora (cacheado por campos) para não perder mudanças anteriores à inscrição
let snapEnt = false;
const getSnap = () => {
  const n = cloudState(); const ent = isEntering();
  if (n.status !== snap.status || n.userId !== snap.userId || n.playerId !== snap.playerId || n.authResolved !== snap.authResolved || ent !== snapEnt) { snap = n; snapEnt = ent; }
  return snap;
};
const sub = (f: () => void) => onCloudStore(f);

/** Preload: só decide entre jogo e landing depois de checar a sessão e carregar o jogador. */
export function CloudGate({ children }: { children: ReactNode }) {
  const st = useSyncExternalStore(sub, getSnap, () => snap);
  useEffect(() => { startCloudStore(); }, []);
  useEffect(() => {
    if (!st.ready || !st.playerId) return;
    loadSave();
    const row = activePlayer();
    // jogador novo começa do zero; nome do save acompanha o nome único do banco
    if (!getPlayer() && row) createPlayer(row.name);
    else if (row && getPlayer()!.name !== row.name) setPlayer((p) => ({ ...p, name: row.name }));
  }, [st.ready, st.userId, st.playerId]);
  useEffect(() => (st.userId && st.playerId ? startPresence(st.playerId) : undefined), [st.userId, st.playerId]);

  if (!st.authResolved || st.status === "carregando") return <Loading label="Verificando sessão" />;
  if (st.userId && st.status === "erro" && !st.ready) return <Loading label="Erro ao falar com a nuvem" />;
  if (st.userId && st.playerId) { if (isEntering()) setTimeout(() => setEntering(false), 0); }
  if (st.userId && st.playerId) return <Fragment key={st.playerId}><StandingGate playerId={st.playerId}>{children}</StandingGate></Fragment>;
  if (st.userId) return <Loading label="Carregando jogador" />;
  if (isEntering()) return <Loading label="Entrando" />;
  return <Landing />;
}
