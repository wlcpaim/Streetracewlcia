// Orquestração no servidor (Lovable Cloud). Toda escrita passa por aqui com o cliente de serviço;
// o navegador só lê. Relatórios recebidos são dados, nunca instruções.
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { bikeModel } from "../physics";
import { runFunnel, stockProject } from "../realgear/funnel";
import { captureFailures, processFailure } from "../realgear/fix/pipeline";
import { emptyFix } from "../realgear/fix/contracts";
import { codeVersion, investigate } from "../realgear/fix/investigator";
import type { FailureEvent, PythonInvestigation } from "../realgear/fix/contracts";
import { shaOf } from "../realgear/sha256";
import { CLOUD_CONTRACT, COND, compare, investigateDivergence, runKeyOf, specOf, tsCompute, type PyResponse, type SpecId, type TsResult } from "./crossaudit";

type Json = Parameters<typeof JSON.stringify>[0];
const db = () => supabaseAdmin;

export async function logEvent(runId: string | null, module: string, step: string, message: string, data?: Json) {
  await db().from("pipeline_events").insert({ run_id: runId, module, step, message, data: (data ?? null) as never });
}
export async function beat(module: string, version: string, error?: string) {
  const { data } = await db().from("service_heartbeats").select("runs").eq("module", module).maybeSingle();
  const now = new Date().toISOString();
  await db().from("service_heartbeats").upsert(error
    ? { module, version, last_error: error.slice(0, 500), last_error_at: now, runs: data?.runs ?? 0, updated_at: now }
    : { module, version, last_ok_at: now, runs: (data?.runs ?? 0) + 1, updated_at: now });
}

/** Fluxo 1→3: Wikipedia fornece a ficha → RealGear calcula → job para o Python. Idempotente por run_key. */
export async function startRun(specId: SpecId) {
  const cv = codeVersion(), spec = specOf(specId), runKey = runKeyOf(specId, spec, COND, cv);
  const existing = await db().from("cloud_runs").select("id,status").eq("run_key", runKey).maybeSingle();
  if (existing.data) { await logEvent(existing.data.id, "Orquestrador", "IDEMPOTÊNCIA", "Mesma ficha, condição e versão de código: execução existente reaproveitada, nada duplicado."); return { runId: existing.data.id, duplicate: true, status: existing.data.status }; }

  await beat("Wikipedia StreetRace", "funnel.FICHA/motoSpec");
  const ts: TsResult = tsCompute(spec, COND);
  await beat("RealGear", "realgear.axles/1.0.0");

  // RealGear: funil de 24 camadas da moto original (as motos reais), com Fix Center + Repair Sandbox existentes.
  let funnel: Json = null, fixState = emptyFix();
  if (specId !== "referencia") {
    const p = stockProject(bikeModel(specId)), at = new Date().toISOString(), x = runFunnel(p, at);
    const c = captureFailures(fixState, p, x);
    fixState = c.novos.reduce((st, f) => processFailure(st, f.failureId, at), c.st);
    funnel = { runId: x.runId, estado: x.estado, parouNaCamada: x.atual, motivo: x.camadas[x.atual - 1]?.motivo ?? null, hash: x.hash };
  }

  const ins = await db().from("cloud_runs").insert({
    run_key: runKey, kind: "axles", bike_id: specId, spec_hash: shaOf(spec), code_version: cv, contract: CLOUD_CONTRACT,
    input: { spec, cond: COND } as never, ts_result: ts as never, funnel: funnel as never, status: "AGUARDANDO_PYTHON",
  }).select("id").single();
  if (ins.error) {
    if (ins.error.code === "23505") { const again = await db().from("cloud_runs").select("id,status").eq("run_key", runKey).single(); return { runId: again.data!.id, duplicate: true, status: again.data!.status }; }
    throw new Error(`falha ao gravar execução: ${ins.error.message}`);
  }
  const runId = ins.data.id;
  await logEvent(runId, "Wikipedia StreetRace", "DADOS", `Ficha ${spec.nome} entregue (${spec.referencia ? "REFERÊNCIA SINTÉTICA — não é moto real" : spec.fonteVersao}).`, { specHash: shaOf(spec) });
  await logEvent(runId, "RealGear", "CÁLCULO", ts.ok ? "12 métricas calculadas em SI." : `${ts.erro}: ${ts.pendentes.join(", ")}`, { batteries: ts.batteries });

  for (const f of fixState.failures) {
    const inv = fixState.validations.filter((x) => x.failureId === f.failureId);
    const r = await db().from("cloud_failures").upsert({
      failure_key: f.failureId, run_id: runId, origin: "RealGear · funil 24 camadas", severity: f.conclusao === "REPROVADA" ? "ALTA" : "MÉDIA",
      summary: `${f.bikeName} · camada ${f.camada.n} ${f.conclusao}: ${f.teste.nome}`, evidence: { teste: f.teste, formula: f.formula, ausentes: f.ausentes, codeVersion: f.codeVersion } as never,
      status: fixState.status[f.failureId] ?? "RECEBIDA",
      fix_report: { investigacoes: fixState.investigations.filter((x) => x.failureId === f.failureId), diagnosticos: fixState.diagnoses.filter((x) => x.failureId === f.failureId), patches: fixState.patches.filter((x) => x.failureId === f.failureId).map((p) => ({ patchId: p.patchId, arquivo: p.arquivo, linha: p.linha, diff: p.diff, patchHash: p.patchHash })) } as never,
      sandbox_report: { validacoes: inv, nota: "Sandbox via overrides do runFunnel; corrida e código principal inalterados. Integração exige aprovação técnica." } as never,
    }, { onConflict: "failure_key", ignoreDuplicates: true });
    if (!r.error) await logEvent(runId, "Central de Falhas", "FALHA", `${f.failureId} registrada (${f.camada.nome}); Fix Center → Sandbox: ${fixState.status[f.failureId]}.`);
  }
  if (fixState.failures.length) { await beat("Fix Center", "realgear.fix/1"); await beat("Repair Sandbox", "runFunnel overrides"); }

  await db().from("python_jobs").insert({ run_id: runId, kind: "axles", payload: { schema: CLOUD_CONTRACT, spec, cond: COND } as never });
  // Cada falha do funil também vai para o investigador Python, que lê o código real por conta própria.
  for (const f of fixState.failures) await db().from("python_jobs").insert({ run_id: runId, kind: "investigate", payload: { schema: CLOUD_CONTRACT, event: f } as never });
  await logEvent(runId, "Orquestrador", "FILA", `${1 + fixState.failures.length} job(s) para o Python Investigator (cálculo SI${fixState.failures.length ? " + investigação de código" : ""}).`);
  return { runId, duplicate: false, status: "AGUARDANDO_PYTHON" };
}

export async function claimJob(worker: string) {
  const { data, error } = await db().rpc("claim_python_job", { _worker: worker });
  if (error) throw new Error(error.message);
  const job = (data as { id: string; run_id: string; payload: unknown; attempts: number; kind?: string }[] | null)?.[0];
  if (!job) return null;
  await logEvent(job.run_id, "Python Investigator", "RESERVA", `Job ${job.kind ?? "axles"} reservado por ${worker} (tentativa ${job.attempts}).`);
  return { jobId: job.id, runId: job.run_id, kind: job.kind ?? "axles", payload: job.payload };
}

const RANK = ["FALHA DE EXECUÇÃO", "DIVERGÊNCIA", "BLOQUEADO", "INCONCLUSIVO", "APROVADO"];
/** Fecha a execução só quando TODOS os jobs terminaram; o pior resultado manda. */
async function settleRun(runId: string) {
  const jobs = await db().from("python_jobs").select("status,result").eq("run_id", runId);
  const list = jobs.data ?? [];
  if (!list.length || list.some((j) => j.status !== "CONCLUIDO" && j.status !== "FALHOU")) return null;
  const sts = list.map((j) => (j.status === "FALHOU" ? "FALHA DE EXECUÇÃO" : String((j.result as { _status?: string } | null)?._status ?? "FALHA DE EXECUÇÃO")));
  const status = RANK.find((r) => sts.includes(r)) ?? "FALHA DE EXECUÇÃO";
  const reason = list.map((j) => (j.result as { _reason?: string } | null)?._reason ?? j.status).join(" | ").slice(0, 900);
  await db().from("cloud_runs").update({ status, status_reason: reason, completed_at: new Date().toISOString() }).eq("id", runId).is("completed_at", null);
  return status;
}

/** Fluxo 4→12: compara, envia divergência à Central de Falhas, Fix Center investiga, Sandbox reproduz. */
export async function submitResult(jobId: string, worker: string, response: PyResponse & { investigacao?: unknown }) {
  const job = await db().from("python_jobs").select("id,run_id,status,worker_id,kind,payload").eq("id", jobId).maybeSingle();
  if (!job.data) return { http: 404, body: { error: "job inexistente" } };
  if (job.data.status !== "EM_EXECUCAO" || job.data.worker_id !== worker) return { http: 409, body: { error: `job em estado ${job.data.status}; resultado recusado (sem duplicar nem sobrescrever)` } };
  // Trava otimista: só um envio passa de EM_EXECUCAO → FINALIZANDO. Se cair no meio, recover_stale_jobs() devolve à fila.
  const lock = await db().from("python_jobs").update({ status: "FINALIZANDO", locked_at: new Date().toISOString() }).eq("id", jobId).eq("status", "EM_EXECUCAO").eq("worker_id", worker).select("id");
  if (!lock.data?.length) return { http: 409, body: { error: "resultado concorrente já em gravação; recusado" } };
  const runId = job.data.run_id;
  const out = job.data.kind === "investigate" ? await settleInvestigation(runId, job.data.payload as unknown as { event: FailureEvent }, response) : await settleAxles(runId, response);
  await db().from("python_jobs").update({ status: "CONCLUIDO", result: { ...response, _status: out.status, _reason: out.reason } as never, finished_at: new Date().toISOString() }).eq("id", jobId).eq("status", "FINALIZANDO");
  const final = await settleRun(runId);
  if (final) await logEvent(runId, "Orquestrador", "CONCLUSÃO", `Todos os jobs concluídos; execução ${final}.`);
  return { http: 200, body: { status: out.status, reason: out.reason, run: final ?? "AGUARDANDO OUTROS JOBS" } };
}

async function settleAxles(runId: string, response: PyResponse) {
  const run = await db().from("cloud_runs").select("id,bike_id,input,ts_result").eq("id", runId).single();
  const ts = run.data!.ts_result as unknown as TsResult, input = run.data!.input as unknown as { cond: typeof COND };
  const cmp = compare(ts, response);
  await beat("Python Investigator", String(response.schema ?? "?"), response.erro ?? undefined);
  await logEvent(runId, "Python Investigator", "RESULTADO", response.erro ? `Python: ${response.erro}` : "Python recalculou de forma independente.");
  if (cmp.rows.length) {
    const w = await db().from("cross_audits").upsert(cmp.rows.map((r) => ({ run_id: runId, metric: r.metric, unit: r.unit, method: r.method, ts_value: r.ts, py_value: r.py, abs_diff: r.abs, rel_diff: r.rel, tolerance: r.tolerance, tolerance_basis: "rel 1e-9 (double, < 30 operações) + piso abs 1e-12", status: r.status })), { onConflict: "run_id,metric" });
    if (w.error) throw new Error(`falha ao gravar auditoria cruzada: ${w.error.message}`);
  }
  await beat("Auditoria Cruzada", "streetrace.cloud/1.0.0");
  await logEvent(runId, "Auditoria Cruzada", cmp.status, cmp.reason);
  if (cmp.status === "DIVERGÊNCIA" || cmp.status === "FALHA DE EXECUÇÃO" || cmp.status === "BLOQUEADO") {
    const key = `XAUD-${shaOf({ runId, cmp: cmp.rows.filter((r) => r.status !== "APROVADO"), reason: cmp.reason }).slice(0, 12)}`;
    const inv = cmp.rows.length ? investigateDivergence(specOf(run.data!.bike_id as never), input.cond, ts, cmp.rows) : null;
    await db().from("cloud_failures").upsert({
      failure_key: key, run_id: runId, origin: "Auditoria Cruzada TS × Python", severity: cmp.status === "DIVERGÊNCIA" ? "CRÍTICA" : "ALTA", summary: cmp.reason,
      evidence: { rows: cmp.rows.filter((r) => r.status !== "APROVADO"), python: response } as never,
      status: inv ? (inv.sandbox.reproduzido ? "AGUARDANDO APROVAÇÃO TÉCNICA" : "REINVESTIGAR") : "DADOS INSUFICIENTES",
      fix_report: (inv?.fix ?? null) as never, sandbox_report: (inv?.sandbox ?? null) as never,
    }, { onConflict: "failure_key", ignoreDuplicates: true });
    await logEvent(runId, "Central de Falhas", "FALHA", `${key} registrada.`);
    if (inv) { await logEvent(runId, "Fix Center", "CAUSA RAIZ", inv.fix.causaRaiz.map((a) => `${a.metric}: ${a.culpado}`).join("; ")); await logEvent(runId, "Repair Sandbox", "REPRODUÇÃO", inv.sandbox.mensagem); await beat("Fix Center", "realgear.fix/1"); await beat("Repair Sandbox", "isolado"); }
  }
  return { status: cmp.status, reason: `eixos: ${cmp.reason}` };
}

/** Investigação de código: o Python leu o código real; comparamos com o espelho TS (mesmas regras). */
async function settleInvestigation(runId: string, payload: { event: FailureEvent }, response: PyResponse & { investigacao?: unknown }) {
  const ev = payload.event, py = response.investigacao as PythonInvestigation | undefined;
  if (response.schema !== "realgear.fix/1.0.0" || !py || typeof py !== "object" || py.failureId !== ev.failureId) {
    await logEvent(runId, "Python Investigator", "BLOQUEADO", "investigação com contrato inválido ou de outra falha");
    return { status: "BLOQUEADO", reason: `investigação ${ev.failureId}: contrato inválido` };
  }
  const ts = investigate(ev);
  const same = py.arquivo === ts.arquivo && py.linha === ts.linha && py.determinado === ts.determinado && JSON.stringify(py.correcao) === JSON.stringify(ts.correcao);
  const status = !same ? "DIVERGÊNCIA" : py.determinado ? "APROVADO" : "INCONCLUSIVO";
  const reason = `investigação ${ev.failureId}: ${!same ? `Python (${py.arquivo}:${py.linha}) ≠ TS (${ts.arquivo}:${ts.linha})` : py.determinado ? `Python e TS apontam ${py.arquivo}:${py.linha}` : `causa indeterminada; faltando ${py.faltando.join(", ")}`}`;
  await beat("Python Investigator", "realgear.fix/1.0.0");
  await logEvent(runId, "Python Investigator", status, reason, { python: { arquivo: py.arquivo, linha: py.linha, correcao: py.correcao }, ts: { arquivo: ts.arquivo, linha: ts.linha, correcao: ts.correcao } } as never);
  if (!same) await db().from("cloud_failures").upsert({ failure_key: `XINV-${shaOf({ f: ev.failureId, py: py.linha, ts: ts.linha }).slice(0, 12)}`, run_id: runId, origin: "Investigação Python × espelho TS", severity: "ALTA", summary: reason, evidence: { python: py, ts } as never, status: "REINVESTIGAR" }, { onConflict: "failure_key", ignoreDuplicates: true });
  return { status, reason };
}

export async function failJob(jobId: string, worker: string, error: string) {
  const job = await db().from("python_jobs").select("id,run_id,status,worker_id,attempts").eq("id", jobId).maybeSingle();
  if (!job.data || job.data.status !== "EM_EXECUCAO" || job.data.worker_id !== worker) return { http: 409, body: { error: "job não reservado por este worker" } };
  const final = job.data.attempts >= 3;
  await db().from("python_jobs").update({ status: final ? "FALHOU" : "PENDENTE", error: error.slice(0, 500), locked_at: null }).eq("id", jobId).eq("status", "EM_EXECUCAO");
  await beat("Python Investigator", "?", error);
  await logEvent(job.data.run_id, "Python Investigator", "ERRO", `${error.slice(0, 200)} · ${final ? "3 tentativas: FALHA DE EXECUÇÃO" : "volta para a fila"}`);
  if (final) await settleRun(job.data.run_id);
  return { http: 200, body: { requeued: !final } };
}

export async function pingDb() {
  const t0 = Date.now();
  const { error } = await db().from("service_heartbeats").select("module", { count: "exact", head: true });
  if (error) { await beat("Banco de dados", "postgres", error.message); return { ok: false, ms: Date.now() - t0, error: error.message }; }
  await beat("Backend", CLOUD_CONTRACT); await beat("Banco de dados", "postgres");
  return { ok: true, ms: Date.now() - t0 };
}

export async function recoverJobs() {
  const { data, error } = await db().rpc("recover_stale_jobs");
  if (error) throw new Error(error.message);
  return Number(data ?? 0);
}
