// Funções de servidor chamadas pela interface (RealGear → aba Nuvem). Escrita só via servidor.
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { SPEC_IDS } from "./crossaudit";

export const startCrossAudit = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ specId: z.enum(SPEC_IDS as [string, ...string[]]) }).parse(d) as { specId: (typeof SPEC_IDS)[number] })
  .handler(async ({ data }) => {
    const { startRun } = await import("./cloud.server");
    return startRun(data.specId as never);
  });

export const connectivityPing = createServerFn({ method: "GET" }).handler(async () => {
  const { pingDb } = await import("./cloud.server");
  return pingDb();
});
