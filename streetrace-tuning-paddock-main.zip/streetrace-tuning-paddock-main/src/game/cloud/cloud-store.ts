// Armazenamento do jogo 100% na nuvem (tabela game_saves, uma linha por usuário e chave).
// O save do piloto é por JOGADOR (kind "player:<uuid>"); demais chaves (som, ENG, ajustes) são da conta.
// Ao entrar, hydrate() baixa tudo, garante um jogador (players) e escolhe o ativo (account_state).
// authResolved só fica true depois que a sessão foi checada e, se houver conta, o jogador carregado:
// o CloudGate usa isso para nunca mostrar a landing a quem está logado.
import { supabase } from "@/integrations/supabase/client";

const SAVE_KEY = "streetrace-save-v1";
const LEGACY: Record<string, string> = { eng: "streetrace-eng-v1" };
const KIND_OF: Record<string, string> = { "streetrace-eng-v1": "eng" };

export interface PlayerRow { id: string; name: string; tag: string; created_at: string }

const mem = new Map<string, string>();
const playerSaves = new Map<string, string>();
const timers = new Map<string, ReturnType<typeof setTimeout>>();
let uid: string | null = null;
let pid: string | null = null;
let players: PlayerRow[] = [];
let authResolved = false;
let status: "offline" | "carregando" | "sincronizando" | "salvo" | "erro" = "offline";
let pending = 0;
type Saver = (a: { data: { playerId: string; data: unknown } }) => Promise<{ ok: boolean; motivo: string | null; data: unknown }>;
let savePlayer: Saver | null = null;
/** Registrado pelo CloudGate (evita ciclo de imports com o servidor). */
export const setPlayerSaver = (f: Saver) => { savePlayer = f; };
/** Último motivo de recusa do servidor (save restaurado ao último válido). */
export let rejected: string | null = null;
const subs = new Set<() => void>();
const emit = () => subs.forEach((f) => f());
const setStatus = (s: typeof status) => { status = s; emit(); };
/** Login em andamento: o CloudGate mostra o preload em vez da landing até a sessão abrir. */
let entering = false;
export const setEntering = (v: boolean) => { entering = v; try { if (v) sessionStorage.setItem("sr-entering", "1"); else sessionStorage.removeItem("sr-entering"); } catch { /* */ } emit(); };
export const isEntering = () => { if (entering) return true; try { return sessionStorage.getItem("sr-entering") === "1"; } catch { return false; } };
export const cloudState = () => ({ status, userId: uid, playerId: pid, authResolved, ready: status !== "offline" && status !== "carregando" });
export const onCloudStore = (f: () => void) => { subs.add(f); return () => { subs.delete(f); }; };
export const activePlayerId = () => pid;
export const myPlayers = () => players;
export const activePlayer = () => players.find((p) => p.id === pid) ?? null;

const kindOf = (key: string) => key === SAVE_KEY ? (pid ? `player:${pid}` : null) : (KIND_OF[key] ?? key);
function encode(key: string, raw: string) {
  if (key === SAVE_KEY || KIND_OF[key]) { try { return JSON.parse(raw); } catch { /* texto */ } }
  return { v: raw };
}

async function flush(key: string) {
  timers.delete(key);
  const kind = kindOf(key);
  if (!uid || !kind) return;
  pending++; setStatus("sincronizando");
  const raw = mem.get(key);
  if (key === SAVE_KEY && pid) {
    if (!savePlayer) { pending--; setStatus("erro"); return; }
    // save do piloto: só o servidor grava, depois de validar posse, saldo e compras
    let ok = false;
    try {
      const r = await savePlayer({ data: { playerId: pid, data: raw === undefined ? null : encode(key, raw) } });
      ok = r.ok;
      if (!r.ok && r.data) { const back = JSON.stringify(r.data); mem.set(SAVE_KEY, back); playerSaves.set(pid, back); rejected = r.motivo; window.location.reload(); }
    } catch { /* rede */ }
    pending--;
    setStatus(ok ? (pending ? "sincronizando" : "salvo") : "erro");
    return;
  }
  const { error } = raw === undefined
    ? await supabase.from("game_saves").delete().eq("user_id", uid).eq("kind", kind)
    : await supabase.from("game_saves").upsert({ user_id: uid, kind, data: encode(key, raw), updated_at: new Date().toISOString() });
  pending--;
  setStatus(error ? "erro" : pending ? "sincronizando" : "salvo");
}
const schedule = (key: string) => {
  if (!uid) return;
  clearTimeout(timers.get(key));
  timers.set(key, setTimeout(() => void flush(key), 600));
};

/** Envia já o que estiver pendente (ex.: antes de entrar na fila do 1x1, que corre com o save salvo). */
export async function flushNow() {
  const keys = [...timers.keys()];
  for (const k of keys) clearTimeout(timers.get(k));
  await Promise.all(keys.map((k) => flush(k)));
}

export const cloudStore = {
  getItem: (k: string): string | null => mem.get(k) ?? null,
  setItem: (k: string, v: string) => { mem.set(k, String(v)); if (k === SAVE_KEY && pid) playerSaves.set(pid, String(v)); schedule(k); },
  removeItem: (k: string) => { mem.delete(k); if (k === SAVE_KEY && pid) playerSaves.delete(pid); schedule(k); },
  key: (i: number) => [...mem.keys()][i] ?? null,
  get length() { return mem.size; },
  clear: () => { for (const k of [...mem.keys()]) cloudStore.removeItem(k); },
};

const cleanName = (s: string) => s.replace(/[^\p{L}\p{N} ._-]/gu, "").trim().slice(0, 16) || "Piloto";

/** Cria jogador no banco (nome único garantido por índice UNIQUE + função transacional). */
export async function createPlayerRow(name: string): Promise<PlayerRow> {
  const { data, error } = await supabase.rpc("create_player", { _name: name });
  if (error) throw new Error(/existe|23505/.test(error.message + error.code) ? "Esse nome já existe." : /limite/.test(error.message) ? "Limite de 5 jogadores por conta." : "Não foi possível criar o jogador.");
  const row = data as unknown as PlayerRow;
  players = [...players, row];
  emit();
  return row;
}

async function loadPlayers(id: string) {
  const [{ data: ps, error }, { data: st }] = await Promise.all([
    supabase.from("players").select("id,name,tag,created_at").eq("user_id", id).order("created_at"),
    supabase.from("account_state").select("active_player_id").eq("user_id", id).maybeSingle(),
  ]);
  if (error) throw error;
  players = ps ?? [];
  if (!players.length) {
    const { data: u } = await supabase.auth.getUser();
    const meta = u.user?.user_metadata as { display_name?: string } | undefined;
    const base = cleanName(meta?.display_name || u.user?.email?.split("@")[0] || "Piloto");
    let made: PlayerRow | null = null;
    for (let i = 0; i < 6 && !made; i++) {
      const nm = i === 0 ? base : `${base.slice(0, 11)}_${Math.floor(1000 + Math.random() * 9000)}`;
      try { made = await createPlayerRow(nm); } catch (e) { if (!/existe/.test((e as Error).message)) throw e; }
    }
    if (!made) throw new Error("sem nome livre");
    players = [made];
    return made.id;
  }
  const act = st?.active_player_id && players.some((p) => p.id === st.active_player_id) ? st.active_player_id : players[0]!.id;
  return act;
}

/** Baixa tudo do usuário e carrega o jogador ativo. */
let inflight: { id: string | null; p: Promise<void> } | null = null;
export function hydrate(id: string | null): Promise<void> {
  if (id === uid && authResolved) return Promise.resolve();
  if (inflight && inflight.id === id) return inflight.p;
  const p = doHydrate(id).finally(() => { if (inflight?.p === p) inflight = null; });
  inflight = { id, p };
  return p;
}
async function doHydrate(id: string | null) {
  uid = id; pid = null; players = []; mem.clear(); playerSaves.clear();
  if (!id) { authResolved = true; setStatus("offline"); return; }
  authResolved = false;
  setStatus("carregando");
  const { data, error } = await supabase.from("game_saves").select("kind,data").eq("user_id", id);
  if (error || uid !== id) { if (uid === id) { authResolved = true; setStatus("erro"); } return; }
  let legacy: string | null = null;
  for (const r of data ?? []) {
    if (r.kind.startsWith("player:")) { playerSaves.set(r.kind.slice(7), JSON.stringify(r.data)); continue; }
    if (r.kind === "player") { legacy = JSON.stringify(r.data); continue; }
    const key = LEGACY[r.kind] ?? r.kind;
    const d = r.data as { v?: unknown } | null;
    mem.set(key, !LEGACY[r.kind] && d && typeof d === "object" && typeof d.v === "string" ? d.v : JSON.stringify(r.data));
  }
  try { pid = await loadPlayers(id); } catch { if (uid === id) { authResolved = true; setStatus("erro"); } return; }
  if (uid !== id) return;
  // save antigo (uma conta = um piloto) passa para o primeiro jogador, uma única vez
  if (legacy && !playerSaves.size && pid) { playerSaves.set(pid, legacy); mem.set(SAVE_KEY, legacy); await flush(SAVE_KEY); }
  const own = pid ? playerSaves.get(pid) : undefined;
  if (own !== undefined) mem.set(SAVE_KEY, own);
  try {
    const ls = globalThis.localStorage;
    if (ls) for (let i = ls.length - 1; i >= 0; i--) { const k = ls.key(i); if (k?.startsWith("streetrace-")) ls.removeItem(k); }
  } catch { /* sem acesso */ }
  authResolved = true;
  setStatus("salvo");
}

/** Troca o jogador ativo: grava o save atual, aponta no banco e troca o espelho do save. */
export async function switchPlayer(next: string) {
  if (!uid || next === pid || !players.some((p) => p.id === next)) return;
  if (timers.has(SAVE_KEY)) { clearTimeout(timers.get(SAVE_KEY)); await flush(SAVE_KEY); }
  const { error } = await supabase.rpc("set_active_player", { _pid: next });
  if (error) throw new Error("Não foi possível trocar de jogador.");
  pid = next;
  const s = playerSaves.get(next);
  if (s !== undefined) mem.set(SAVE_KEY, s); else mem.delete(SAVE_KEY);
  emit();
}

export async function renamePlayerRow(id: string, name: string) {
  const { error } = await supabase.rpc("rename_player", { _pid: id, _name: name });
  if (error) throw new Error(/existe|23505/.test(error.message + error.code) ? "Esse nome já existe." : "Nome inválido.");
  players = players.map((p) => p.id === id ? { ...p, name: name.trim() } : p);
  emit();
}

let started = false;
export function startCloudStore() {
  if (started || typeof window === "undefined") return; started = true;
  const verify = async (id: string | null) => {
    if (id) {
      try {
        const { checkTokenSession } = await import("../auth/token.functions");
        const r = await checkTokenSession();
        if (r.expires_at) localStorage.setItem("realgear-access-expires", r.expires_at);
        else localStorage.removeItem("realgear-access-expires");
      } catch { await supabase.auth.signOut(); return; }
    }
    await hydrate(id);
  };
  // INITIAL_SESSION sempre dispara uma vez com a sessão já restaurada: é a única decisão inicial.
  supabase.auth.onAuthStateChange((ev, session) => {
    if (ev === "SIGNED_IN" || ev === "SIGNED_OUT" || ev === "INITIAL_SESSION") setTimeout(() => {
      const expires = Date.parse(localStorage.getItem("realgear-access-expires") ?? "");
      if (session && Number.isFinite(expires) && expires <= Date.now()) { void supabase.auth.signOut(); return; }
      void verify(session?.user.id ?? null);
    }, 0);
  });
  setInterval(() => {
    const expires = Date.parse(localStorage.getItem("realgear-access-expires") ?? "");
    if (uid && Number.isFinite(expires) && expires <= Date.now()) {
      localStorage.removeItem("realgear-access-token");
      localStorage.removeItem("realgear-access-expires");
      void supabase.auth.signOut();
    }
  }, 1000);
  setInterval(() => { if (uid) void verify(uid); }, 30000);
}
