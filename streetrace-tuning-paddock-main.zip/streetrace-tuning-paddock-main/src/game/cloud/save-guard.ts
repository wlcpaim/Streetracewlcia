// Validação autoritativa do save do piloto: o servidor compara o save novo com o último aceito
// e recusa dinheiro criado do nada, motos/peças não liberadas ou não pagas. Pura e determinística.
import { CHALLENGES, GOALS, MISSIONS } from "../missions";
import { levelBonus } from "../level";
import { partById } from "../parts";
import { BIKE_MODELS, factoryGear } from "../physics";
import { bikeReleased, partReleased } from "../startgame";
import { START_MONEY } from "../store";
import { fitsBike } from "../ignition";
/** Mesma fração de garage.ts (sem importar: ciclo store/garage). */
const RESALE_SHARE = 0.8;

type Save = { activeBike?: string | null; money?: number; creditDebt?: number; bikes?: string[]; parts?: string[]; level?: number; missions?: string[]; setup?: { slots?: Record<string, string>; front?: number; rear?: number } } | null;

/** Teto de ganho por segundo real (corrida, entregas, diárias) e folga fixa por gravação. */
export const EARN_PER_SEC = 120;
export const EARN_BUFFER = 3000;
/** Preço pode cair com o dólar; exige ao menos esta fração do preço de tabela. */
export const MIN_PRICE_SHARE = 0.5;
// calculados na hora da checagem: este módulo entra num ciclo de imports com store/cloud-store
const bikePrice = (id: string) => BIKE_MODELS.find((b) => b.id === id)?.price ?? 0;
const onceCash = (id: string) => [...MISSIONS, ...GOALS, ...CHALLENGES].find((m) => m.id === id)?.cash ?? 0;

const count = (xs: string[] = []) => xs.reduce((m, x) => m.set(x, (m.get(x) ?? 0) + 1), new Map<string, number>());
const net = (s: Save) => (Number(s?.money) || 0) - (Number(s?.creditDebt) || 0);

export type Verdict = { ok: true } | { ok: false; motivo: string };

export function checkSave(prev: Save, next: Save, elapsedS: number): Verdict {
  if (!next || typeof next !== "object") return { ok: false, motivo: "save inválido" };
  const money = Number(next.money);
  if (!Number.isFinite(money) || money < -0.01) return { ok: false, motivo: "saldo inválido" };
  if (!Number.isFinite(Number(next.creditDebt ?? 0)) || Number(next.creditDebt ?? 0) < -0.01) return { ok: false, motivo: "fatura inválida" };
  const base: Save = prev ?? { money: START_MONEY, creditDebt: 0, bikes: [], parts: [], level: 1, missions: [] };

  let spend = 0;
  const pb = count(base.bikes);
  for (const [id, n] of count(next.bikes)) {
    const add = n - (pb.get(id) ?? 0);
    if (add <= 0) continue;
    if (!bikeReleased(id)) return { ok: false, motivo: `moto não liberada: ${id}` };
    spend += add * bikePrice(id);
  }
  // moto vendida à concessionária: credita até 80% da tabela
  let resale = 0;
  const nb = count(next.bikes);
  for (const [id, n] of pb) resale += Math.max(0, n - (nb.get(id) ?? 0)) * bikePrice(id) * RESALE_SHARE;
  // a moto nova vem com o pinhão e a coroa de fábrica dela (sem custo extra)
  const newGear = new Set<string>();
  for (const [id, n] of count(next.bikes)) if (n > (pb.get(id) ?? 0)) { const g = factoryGear(id); newGear.add(`pinhao-${g.front}`); newGear.add(`coroa-${g.rear}`); }
  const pp = count(base.parts);
  const mounted = new Set([...Object.values(base.setup?.slots ?? {}), ...(base.setup?.front ? [`pinhao-${base.setup.front}`, `coroa-${base.setup.rear}`] : [])]);
  for (const [id, n] of count(next.parts)) {
    const add = n - (pp.get(id) ?? 0);
    if (add <= 0) continue;
    const part = partById(id);
    if (!part) return { ok: false, motivo: `peça inexistente: ${id}` };
    if (part.factory || newGear.has(id) && add === 1 || mounted.has(id) || /^(pinhao|coroa)-/.test(id) && (pp.has(id) || mounted.has(id))) continue;
    if (!partReleased(id)) return { ok: false, motivo: `peça não liberada: ${id}` };
    spend += add * part.price;
  }

  const mod = next.setup?.slots?.["modulo"] ? partById(next.setup.slots["modulo"]) : null;
  if (mod && next.activeBike && !fitsBike(mod, next.activeBike)) return { ok: false, motivo: `módulo incompatível com a moto: ${mod.id}` };

  const had = new Set(base.missions ?? []);
  let bonus = 0;
  for (const id of new Set(next.missions ?? [])) if (!had.has(id)) bonus += onceCash(id);
  for (let l = (base.level ?? 1) + 1; l <= (next.level ?? 1); l++) bonus += levelBonus(l);

  const allowance = EARN_PER_SEC * Math.max(0, elapsedS) + EARN_BUFFER + bonus + resale;
  if (net(next) - net(base) > allowance - spend * MIN_PRICE_SHARE + 0.01) return { ok: false, motivo: "saldo acima do possível" };
  return { ok: true };
}
