// Painel de Conectividade (aba Nuvem do RealGear): mostra o estado REAL — verde só com execução comprovada.
import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { connectivityPing, startCrossAudit } from "./cloud.functions";
import { SPEC_IDS } from "./crossaudit";

type HB = { module: string; version: string | null; last_ok_at: string | null; last_error: string | null; last_error_at: string | null; runs: number };
type Run = { id: string; bike_id: string; status: string; status_reason: string | null; created_at: string; code_version: string };
type Audit = { run_id: string; metric: string; unit: string; ts_value: number | null; py_value: number | null; rel_diff: number | null; status: string };
type Failure = { failure_key: string; origin: string; severity: string; summary: string; status: string; created_at: string };
type Ev = { id: number; module: string; step: string; message: string; created_at: string };

const MODULES = ["Backend", "Banco de dados", "Wikipedia StreetRace", "RealGear", "Python Investigator", "Auditoria Cruzada", "Central de Falhas", "Fix Center", "Repair Sandbox"];
const TONE: Record<string, string> = { APROVADO: "bg-primary text-primary-foreground", "DIVERGÊNCIA": "bg-destructive text-destructive-foreground", INCONCLUSIVO: "bg-accent text-accent-foreground", "FALHA DE EXECUÇÃO": "bg-destructive text-destructive-foreground", BLOQUEADO: "bg-destructive text-destructive-foreground", AGUARDANDO_PYTHON: "bg-muted text-muted-foreground" };
const fmtT = (t: string | null) => (t ? new Date(t).toLocaleString("pt-BR") : "nunca");

export function CloudTab() {
  const [hbs, setHbs] = useState<HB[]>([]);
  const [runs, setRuns] = useState<Run[]>([]);
  const [audits, setAudits] = useState<Audit[]>([]);
  const [failures, setFailures] = useState<Failure[]>([]);
  const [events, setEvents] = useState<Ev[]>([]);
  const [ping, setPing] = useState<{ ok: boolean; ms: number; error?: string } | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const [h, r, a, f, e] = await Promise.all([
        supabase.from("service_heartbeats").select("*"),
        supabase.from("cloud_runs").select("id,bike_id,status,status_reason,created_at,code_version").order("created_at", { ascending: false }).limit(10),
        supabase.from("cross_audits").select("run_id,metric,unit,ts_value,py_value,rel_diff,status").order("created_at", { ascending: false }).limit(48),
        supabase.from("cloud_failures").select("failure_key,origin,severity,summary,status,created_at").order("created_at", { ascending: false }).limit(10),
        supabase.from("pipeline_events").select("id,module,step,message,created_at").order("id", { ascending: false }).limit(30),
      ]);
      const firstErr = [h, r, a, f, e].find((x) => x.error)?.error;
      setErr(firstErr ? `leitura do banco falhou: ${firstErr.message}` : null);
      setHbs((h.data ?? []) as HB[]); setRuns((r.data ?? []) as Run[]); setAudits((a.data ?? []) as Audit[]); setFailures((f.data ?? []) as Failure[]); setEvents((e.data ?? []) as Ev[]);
    } catch (e) { setErr(`backend indisponível: ${(e as Error).message}`); }
  }, []);
  useEffect(() => { void load(); const t = setInterval(load, 10000); return () => clearInterval(t); }, [load]);

  const doPing = async () => { setBusy("ping"); setPing(await connectivityPing()); await load(); setBusy(null); };
  const doRun = async (specId: string) => { setBusy(specId); await startCrossAudit({ data: { specId } }); await load(); setBusy(null); };
  const hb = (m: string) => hbs.find((x) => x.module === m);

  return (
    <div className="space-y-4">
      <div className="rounded-xl bg-secondary p-3 text-sm">
        <p className="font-semibold">Painel de Conectividade — estado real, comprovado por execução</p>
        <p className="text-xs text-muted-foreground">Verde só quando o módulo completou uma operação real no banco central. Interface publicada ≠ backend conectado.</p>
        {err && <p className="mt-1 text-destructive">{err}</p>}
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <button onClick={doPing} disabled={busy !== null} className="rounded-lg bg-primary px-3 py-1.5 text-sm text-primary-foreground disabled:opacity-60">{busy === "ping" ? "VERIFICANDO…" : "VERIFICAR CONEXÃO"}</button>
          {ping && <span className={`rounded px-2 py-1 text-xs ${ping.ok ? "bg-primary text-primary-foreground" : "bg-destructive text-destructive-foreground"}`}>{ping.ok ? `banco respondeu em ${ping.ms} ms` : `falha: ${ping.error}`}</span>}
        </div>
      </div>

      <div className="grid gap-2 md:grid-cols-3">
        {MODULES.map((m) => { const h = hb(m); const on = !!h?.last_ok_at; return (
          <div key={m} className="rounded-xl bg-secondary p-3 text-sm">
            <div className="flex items-center justify-between"><b>{m}</b><span className={`h-2.5 w-2.5 rounded-full ${on ? "bg-primary" : "bg-muted-foreground/40"}`} /></div>
            <p className="text-xs">{on ? "CONECTADO" : "SEM COMPROVAÇÃO"} · versão {h?.version ?? "—"}</p>
            <p className="text-xs text-muted-foreground">última comunicação: {fmtT(h?.last_ok_at ?? null)} · execuções: {h?.runs ?? 0}</p>
            {h?.last_error && <p className="text-xs text-destructive">último erro ({fmtT(h.last_error_at)}): {h.last_error}</p>}
          </div>); })}
      </div>

      <div className="rounded-xl bg-secondary p-3 text-sm">
        <p className="font-semibold">Nova auditoria cruzada (Wikipedia → RealGear → Python)</p>
        <p className="text-xs text-muted-foreground">Idempotente: mesma ficha + mesma condição + mesma versão de código reaproveita a execução, sem duplicar. Motos reais ficam INCONCLUSIVAS enquanto faltarem dados de fábrica.</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {SPEC_IDS.map((id) => <button key={id} onClick={() => doRun(id)} disabled={busy !== null} className="rounded-lg bg-primary px-3 py-1.5 text-sm text-primary-foreground disabled:opacity-60">{busy === id ? "EXECUTANDO…" : `Auditar ${id}`}</button>)}
        </div>
      </div>

      <div className="rounded-xl bg-secondary p-3 text-sm">
        <p className="font-semibold">Execuções</p>
        {!runs.length && <p className="text-xs text-muted-foreground">Nenhuma execução registrada no banco central.</p>}
        {runs.map((r) => <div key={r.id} className="mt-1 border-t border-border pt-1 text-xs">
          <span className={`rounded px-1 ${TONE[r.status] ?? "bg-muted"}`}>{r.status}</span> <b>{r.bike_id}</b> · {fmtT(r.created_at)} · código {r.code_version.slice(0, 12)}
          {r.status_reason && <div className="text-muted-foreground">{r.status_reason}</div>}
        </div>)}
      </div>

      {audits.length > 0 && <div className="overflow-x-auto rounded-xl bg-secondary p-3">
        <p className="text-sm font-semibold">Auditoria cruzada TS × Python (métrica a métrica)</p>
        <table className="mt-1 w-full text-xs"><thead><tr className="text-left text-muted-foreground"><th>Métrica</th><th>TypeScript</th><th>Python</th><th>Δ rel</th><th>Estado</th></tr></thead>
          <tbody>{audits.map((a, i) => <tr key={i} className="border-t border-border"><td>{a.metric} ({a.unit})</td><td className="font-mono">{a.ts_value?.toExponential(6) ?? "—"}</td><td className="font-mono">{a.py_value?.toExponential(6) ?? "—"}</td><td className="font-mono">{a.rel_diff?.toExponential(2) ?? "—"}</td><td><span className={`rounded px-1 ${TONE[a.status] ?? "bg-muted"}`}>{a.status}</span></td></tr>)}</tbody></table>
      </div>}

      <div className="rounded-xl bg-secondary p-3 text-sm">
        <p className="font-semibold">Central de Falhas (nuvem)</p>
        {!failures.length && <p className="text-xs text-muted-foreground">Nenhuma falha registrada.</p>}
        {failures.map((f) => <div key={f.failure_key} className="mt-1 border-t border-border pt-1 text-xs">
          <b>{f.failure_key}</b> · {f.severity} · {f.origin} · <span className="font-semibold">{f.status}</span>
          <div className="text-muted-foreground">{f.summary}</div>
        </div>)}
      </div>

      <div className="rounded-xl bg-secondary p-3 text-sm">
        <p className="font-semibold">Trilha de eventos (append-only)</p>
        {!events.length && <p className="text-xs text-muted-foreground">Sem eventos.</p>}
        {events.map((e) => <p key={e.id} className="border-t border-border py-0.5 font-mono text-[11px]">{fmtT(e.created_at)} · <b>{e.module}</b> · {e.step} · {e.message}</p>)}
      </div>
    </div>
  );
}
