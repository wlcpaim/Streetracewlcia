// StreetRace Cloud Integration 4.0 — núcleo puro da auditoria cruzada TS × Python.
// Só leitura sobre axles.ts/kinematics.ts: não altera fórmulas, constantes nem a corrida.
import { MOTO_SPECS, referenceSpec, sumInertia, axleLoads, slipRatio, omega, runBatteries, AXLES_VERSION, type MotoSpec } from "../realgear/axles";
import { chain, wikiRecalc, type Dado } from "../realgear/kinematics";
import { shaOf } from "../realgear/sha256";

export const CLOUD_CONTRACT = "streetrace.cloud/1.0.0";
export const PY_SCHEMA = "realgear.axles/1.0.0";
export type SpecId = "titan160" | "factor150" | "referencia";
export const SPEC_IDS: SpecId[] = ["titan160", "factor150", "referencia"];
export const COND = { marcha: 2, rpm: 6000, torque: 12, v: 15, a: 2 } as const;
export type CondIn = typeof COND;

export function specOf(id: SpecId): MotoSpec {
  if (id === "referencia") return referenceSpec();
  const s = MOTO_SPECS.find((x) => x.bikeId === id);
  if (!s) throw new Error(`ficha inexistente: ${id}`);
  return s;
}

/** Métricas comparadas: mesma grandeza, unidade SI e método nas duas rotas. */
export const METRICS: { key: string; unit: string; method: string }[] = [
  { key: "i_total", unit: "1", method: "i_p·i_g·i_f = (Zc/Zm) por estágio" },
  { key: "rpm_roda", unit: "rpm", method: "n_motor / i_total" },
  { key: "torque_roda", unit: "N·m", method: "T·i_total·η_p·η_g·η_c" },
  { key: "potencia_roda", unit: "W", method: "T_roda·ω_roda" },
  { key: "potencia_entrada", unit: "W", method: "T·2π·n/60" },
  { key: "v_corrente_media", unit: "m/s", method: "Z_pinhão·p·n_pinhão/60" },
  { key: "v_periferica_B", unit: "m/s", method: "ω_roda·r_din,B" },
  { key: "slip_B", unit: "1", method: "(ωr − v)/max(|ωr|,|v|)" },
  { key: "I_A", unit: "kg·m²", method: "Σ I geométrico (eixo A)" },
  { key: "I_B", unit: "kg·m²", method: "Σ I geométrico (eixo B)" },
  { key: "FzA", unit: "N", method: "(m·g·b − m·a·h)/L" },
  { key: "FzB", unit: "N", method: "(m·g·(L−b) + m·a·h)/L" },
];

/**
 * Tolerância relativa 1e-9. Justificativa: as duas rotas usam double IEEE-754 (ε = 2,2e-16) e fórmulas fechadas
 * com < 30 operações; o erro de arredondamento esperado é ≲ 30·ε ≈ 7e-15. 1e-9 dá margem de 10⁵ sobre isso e
 * ainda detecta qualquer erro de fórmula, unidade (fator ≥ 10⁻³) ou dado diferente. Piso absoluto 1e-12 para
 * grandezas que podem ser ~0 (escorregamento).
 */
export const REL_TOL = 1e-9, ABS_FLOOR = 1e-12;
export const TOL_BASIS = "rel 1e-9: double IEEE-754, fórmulas fechadas < 30 operações (erro ≲ 7e-15); piso abs 1e-12 para grandezas ≈ 0";

export const MISSING_TAG = "DADO AUSENTE — CÁLCULO LIMITADO — HOMOLOGAÇÃO BLOQUEADA";
const ok = (d: Dado | undefined) => !!d && d.valor !== null && Number.isFinite(d.valor as number);
const v = (d: Dado) => d.valor as number;

/** Dados indispensáveis para as 12 métricas. Lista os ausentes; nunca preenche. */
export function missingFor(s: MotoSpec, c: CondIn = COND): string[] {
  const k = s.kin, g = k.marchas[c.marcha - 1];
  const req: [string, Dado | undefined][] = [
    ["primária motora", k.primaria.motora], ["primária conduzida", k.primaria.conduzida],
    [`${c.marcha}ª motora`, g?.motora], [`${c.marcha}ª conduzida`, g?.conduzida], ["pinhão", k.pinhao], ["coroa", k.coroa],
    ["η primária", k.eta.primaria], ["η câmbio", k.eta.cambio], ["η corrente", k.eta.corrente], ["passo da corrente", s.corrente.passo],
    ["massa moto", s.veiculo.massaMoto], ["massa piloto", s.veiculo.massaPiloto], ["altura CG", s.veiculo.alturaCG],
    ["entre-eixos", s.veiculo.entreEixos], ["CG→eixo traseiro", s.veiculo.cgAteEixoTraseiro], ["raio dinâmico B", s.rodaB.raioDinamico],
  ];
  const out = req.filter(([, d]) => !ok(d)).map(([n]) => n);
  if (sumInertia(s.rodaA.componentes) === null) out.push("massas/raios dos componentes A");
  if (sumInertia(s.rodaB.componentes) === null) out.push("massas/raios dos componentes B");
  return out;
}

export type TsResult = { ok: true; metrics: Record<string, number>; wiki: { i_total: number; rpm_roda: number; torque_roda: number }; batteries: { aprovados: number; reprovados: number; indeterminados: number; eixos: Record<string, string>; homologacao: string } }
  | { ok: false; erro: string; pendentes: string[]; batteries: { aprovados: number; reprovados: number; indeterminados: number; eixos: Record<string, string>; homologacao: string } };

/** Rota RealGear (TypeScript): reaproveita chain(), axleLoads(), sumInertia(), slipRatio(). */
export function tsCompute(s: MotoSpec, c: CondIn = COND): TsResult {
  const r = runBatteries(s, { marcha: c.marcha, rpm: c.rpm, torque: c.torque, vVeiculo: c.v, acel: c.a, FtFreioA: 1500, FtFreioB: 800 });
  const batteries = { aprovados: r.testes.filter((t) => t.estado === "APROVADO").length, reprovados: r.testes.filter((t) => t.estado === "REPROVADO").length, indeterminados: r.testes.filter((t) => t.estado === "INDETERMINADO").length, eixos: r.eixos, homologacao: r.homologacao };
  const pend = missingFor(s, c);
  if (pend.length) return { ok: false, erro: MISSING_TAG, pendentes: pend, batteries };
  const o = chain({ ...s.kin, passoCorrente: s.corrente.passo, raioPneu: s.rodaB.raioDinamico }, c.marcha, c.rpm, c.torque);
  const last = o.estagios.at(-1)!, wRoda = omega(last.rpm), rB = v(s.rodaB.raioDinamico), veh = s.veiculo;
  const L = axleLoads(v(veh.massaMoto) + v(veh.massaPiloto), c.a, v(veh.alturaCG), v(veh.entreEixos), v(veh.cgAteEixoTraseiro));
  const w = wikiRecalc({ ...s.kin, raioPneu: s.rodaB.raioDinamico }, c.marcha, c.rpm, c.torque);
  return {
    ok: true, batteries,
    metrics: {
      i_total: o.iTotal, rpm_roda: last.rpm, torque_roda: last.torque, potencia_roda: last.torque * wRoda, potencia_entrada: c.torque * omega(c.rpm),
      v_corrente_media: o.vCorrente, v_periferica_B: wRoda * rB, slip_B: slipRatio(wRoda, rB, c.v),
      I_A: sumInertia(s.rodaA.componentes)!, I_B: sumInertia(s.rodaB.componentes)!, FzA: L.FzA, FzB: L.FzB,
    },
    wiki: { i_total: w.iTotal, rpm_roda: w.nRoda, torque_roda: w.tRoda },
  };
}

export type CmpStatus = "APROVADO" | "DIVERGÊNCIA" | "INCONCLUSIVO" | "FALHA DE EXECUÇÃO" | "BLOQUEADO";
export type MetricCmp = { metric: string; unit: string; method: string; ts: number | null; py: number | null; abs: number | null; rel: number | null; tolerance: number; status: CmpStatus };
export type PyResponse = { schema?: string | undefined; erro?: string | null | undefined; resultado?: Record<string, unknown> | null | undefined };

/** Compara métrica a métrica. Nunca esconde divergência: qualquer métrica fora da tolerância reprova a execução. */
export function compare(ts: TsResult, py: PyResponse): { status: CmpStatus; reason: string; rows: MetricCmp[] } {
  if (py.schema !== PY_SCHEMA) return { status: "BLOQUEADO", reason: `contrato Python inválido (${String(py.schema)}); esperado ${PY_SCHEMA}`, rows: [] };
  const pyOk = !py.erro && py.resultado && typeof py.resultado === "object";
  if (!ts.ok && !pyOk) {
    const both = /PENDENTE/.test(String(py.erro));
    return both ? { status: "INCONCLUSIVO", reason: `${MISSING_TAG}: ${ts.pendentes.join(", ")}`, rows: [] }
      : { status: "FALHA DE EXECUÇÃO", reason: `TS: ${ts.erro}; Python: ${py.erro}`, rows: [] };
  }
  if (!ts.ok) return { status: "DIVERGÊNCIA", reason: `TS bloqueou por dados ausentes (${ts.pendentes.join(", ")}) mas o Python calculou`, rows: [] };
  if (!pyOk) return { status: "FALHA DE EXECUÇÃO", reason: `Python não concluiu: ${py.erro}`, rows: [] };
  const rows: MetricCmp[] = METRICS.map((m) => {
    const t = ts.metrics[m.key] ?? null, raw = (py.resultado as Record<string, unknown>)[m.key];
    const p = typeof raw === "number" && Number.isFinite(raw) ? raw : null;
    if (t === null || p === null) return { metric: m.key, unit: m.unit, method: m.method, ts: t, py: p, abs: null, rel: null, tolerance: REL_TOL, status: "FALHA DE EXECUÇÃO" };
    const abs = Math.abs(t - p), rel = abs / Math.max(Math.abs(t), Math.abs(p), 1e-300);
    const pass = abs <= REL_TOL * Math.max(Math.abs(t), Math.abs(p)) + ABS_FLOOR;
    return { metric: m.key, unit: m.unit, method: m.method, ts: t, py: p, abs, rel, tolerance: REL_TOL, status: pass ? "APROVADO" : "DIVERGÊNCIA" };
  });
  const bad = rows.filter((r) => r.status !== "APROVADO");
  if (!bad.length) return { status: "APROVADO", reason: `${rows.length}/${rows.length} métricas dentro de ${TOL_BASIS}. Aprovação da comparação não homologa o veículo.`, rows };
  const st: CmpStatus = bad.some((r) => r.status === "DIVERGÊNCIA") ? "DIVERGÊNCIA" : "FALHA DE EXECUÇÃO";
  return { status: st, reason: `${bad.length} métrica(s) fora: ${bad.map((r) => r.metric).join(", ")}`, rows };
}

/** Fonte TS de cada métrica (para o Fix Center localizar a função). */
export const SOURCE_OF: Record<string, string> = {
  i_total: "src/game/realgear/kinematics.ts · chain()", rpm_roda: "src/game/realgear/kinematics.ts · chain()", torque_roda: "src/game/realgear/kinematics.ts · chain()",
  potencia_roda: "src/game/realgear/kinematics.ts · chain()", potencia_entrada: "src/game/realgear/kinematics.ts · rpmToRad()", v_corrente_media: "src/game/realgear/kinematics.ts · chain()",
  v_periferica_B: "src/game/realgear/axles.ts · omega()", slip_B: "src/game/realgear/axles.ts · slipRatio()", I_A: "src/game/realgear/axles.ts · inertia()", I_B: "src/game/realgear/axles.ts · inertia()",
  FzA: "src/game/realgear/axles.ts · axleLoads()", FzB: "src/game/realgear/axles.ts · axleLoads()",
};

/**
 * Fix Center para divergência TS×Python: arbitra com a terceira rota independente (Wikipedia wikiRecalc) quando
 * existe para a métrica, e o Repair Sandbox reexecuta o TS isolado a partir da entrada gravada. Nunca gera patch
 * automático em fórmula física: a proposta exige aprovação técnica.
 */
export function investigateDivergence(spec: MotoSpec, c: CondIn, stored: TsResult, rows: MetricCmp[]) {
  const bad = rows.filter((r) => r.status !== "APROVADO");
  const rerun = tsCompute(spec, c); // Repair Sandbox: reprodução isolada, sem tocar em nada persistido
  const reproduzido = rerun.ok && stored.ok && bad.every((r) => rerun.metrics[r.metric] === stored.metrics[r.metric]);
  const arb = bad.map((r) => {
    const w = stored.ok ? (stored.wiki as Record<string, number>)[r.metric] : undefined;
    if (w === undefined || r.ts === null || r.py === null) return { metric: r.metric, wikipedia: null, culpado: "INDETERMINADO (sem terceira rota para esta métrica)", fonteTs: SOURCE_OF[r.metric] };
    const tsOk = Math.abs(w - r.ts) <= REL_TOL * Math.abs(w) + ABS_FLOOR, pyOk = Math.abs(w - r.py) <= REL_TOL * Math.abs(w) + ABS_FLOOR;
    return { metric: r.metric, wikipedia: w, culpado: tsOk && !pyOk ? "Python (python/realgear/axles.py · compute)" : pyOk && !tsOk ? `TypeScript (${SOURCE_OF[r.metric]})` : "INDETERMINADO (as três rotas discordam)", fonteTs: SOURCE_OF[r.metric] };
  });
  return {
    fix: { causaRaiz: arb, proposta: "Nenhum patch automático em fórmula física. Corrigir o motor apontado exige revisão e aprovação técnica.", arquivos: [...new Set(arb.map((a) => a.fonteTs))] },
    sandbox: { reproduzido, isolado: true, rerunHash: shaOf(rerun), mensagem: reproduzido ? "Sandbox reexecutou o TS isolado com a mesma entrada: resultado idêntico ao gravado; a divergência é reproduzível." : "Reexecução isolada não reproduziu o valor gravado (instabilidade ou entrada alterada)." },
  };
}

export const runKeyOf = (id: SpecId, spec: MotoSpec, c: CondIn, codeVersion: string) => shaOf({ id, spec, c, codeVersion, contract: CLOUD_CONTRACT, axles: AXLES_VERSION });
