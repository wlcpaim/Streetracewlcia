// Preload inspector: crosses every equipped part through the real physics and writes a TXT report
// with the exact math (formula → numbers → result), a plain translation and a step-by-step race diary.
import { cloudStore } from "@/game/cloud/cloud-store";
import { DT, FUEL_DENSITY, RIDER_KG, drivetrain, SERVICES, STOCK_PSI, SPIN_GRIP, afrAt, mixState, engine, exhaustId, exhaustMul, exhaustShape, fuelFlow, gearSpeeds, mixFactor, newSim, powerShape, launchRpm, idealLaunch, LAUNCH_EVAL_M, idleRpm, stalled, stats, step, stress, tireOf, ccOf, timingOptimum, type BikeModel, type Setup } from "./physics";
import { CAM_FX, CAM_LABEL, clutchCapNm, SLOTS, partById, type Slot } from "./parts";
import { fuelChain } from "./rootcause";
import { exhaustInfo, exhaustSpec } from "./exhaust";
import { transmissionTxt } from "./intel/report";
import { mechTxtSteps } from "./mechlimits";
import { computeSync, computeSlices } from "./compute-slices";
import { partSheets } from "./part-sheet";

export type LiveReport = { id: string; at: string; pilot: string; bike: string; distance: number; status: string; txt: string; kind?: "corrida" | "dinamometro"; funnel?: { runId: string; estado: string; atual: number } };
export const LIVE_KEY = "streetrace-wiki-live";
export const LIVE_EVENT = "streetrace-wiki-live";

const f = (n: number, d = 2) => (Number.isFinite(n) ? n.toFixed(d) : "—");
const SLOT_ROLE: Partial<Record<Slot, string>> = {
  cilindro: "define o volume deslocado e quanto ar/combustível o motor pede", pistao: "fecha a câmara; forjado aguenta mais calor e pressão",
  biela: "transmite a força do pistão ao virabrequim; limita giro", molas: "fecham as válvulas; limitam o giro antes da flutuação",
  oleo: "película entre metais; desgasta com km", vela: "faísca da combustão", cabo: "leva a alta tensão à vela", bateria: "alimenta a injeção/faísca; pesa no conjunto",
  bico: "dosa o combustível por pulso; teto de vazão do sistema", bomba: "pressão/vazão no trilho; alimenta o bico", tbi: "corpo de borboleta: quanto ar entra",
  modulo: "corte de giro, mapa, ponto e trocas", escape: "tira os gases; diâmetro × comprimento sintonizam a onda",
  embreagem: "acopla motor e câmbio; torque acima da capacidade patina", pneu: "aderência e rolamento", susp: "transfere peso na largada", roda: "massa girante e peso",
};

/** Builds the full TXT for the player's bike on a track distance. Deterministic. */
export function preloadReport(pilot: string, b: BikeModel, s: Setup, distance: number, fuelL: number): LiveReport {
  return computeSync(preloadReportSteps(pilot, b, s, distance, fuelL));
}

function* preloadReportSteps(pilot: string, b: BikeModel, s: Setup, distance: number, fuelL: number): Generator<void, LiveReport> {
  const L: string[] = [];
  const H = (t: string) => L.push("", "-".repeat(78), t, "-".repeat(78));
  const e = engine(b, s), stt = stats(b, s, fuelL), sx = stress(b, s), tire = tireOf(s), gs = gearSpeeds(b, s), cc = ccOf(b, s);
  const riderKg = s.riderKg ?? RIDER_KG, mTot = stt.kg + riderKg;
  const traction = 0.62 * mTot * 9.81 * 1.05 * tire.grip;
  const clutch = clutchCapNm(s);
  const tqNm = stt.torque * 9.80665;
  const alerts: string[] = [];

  L.push("=".repeat(78), "STREETRACE WIKIPEDIA · RELATÓRIO DE PRELOAD · FÍSICA EXATA", "=".repeat(78));
  L.push(`PILOTO: ${pilot} | MOTO: ${b.name} | PISTA: ${distance} m | DATA: ${new Date().toISOString()}`);
  L.push(`Tanque: ${f(fuelL, 2)} L (${s.fuel}) | Km motor: ${Math.round(s.km)} | Km óleo: ${Math.round(s.oilKm)}`);

  H("1. PEÇAS EQUIPADAS · O QUE CADA UMA FAZ NO ALGORITMO");
  for (const k of SLOTS) {
    const p = partById(s.slots[k]);
    const fx = p ? [p.hp && `+${p.hp} cv`, p.hpMul && p.hpMul !== 1 && `hp ×${p.hpMul}`, p.kg && `${p.kg > 0 ? "+" : ""}${p.kg} kg`, p.flow && `vazão ×${p.flow}`, p.need && `pede +${Math.round(p.need * 100)}% comb.`, p.clutchNm && `${p.clutchNm} Nm`, p.grip && `grip ×${p.grip}`, p.crr && `rolamento ×${p.crr}`, p.rpm && `corte +${p.rpm}`].filter(Boolean).join(" · ") : "";
    L.push(`- ${k.toUpperCase().padEnd(10)} ${p ? `${p.brand ?? ""} ${p.name}`.trim() : s.slots[k]}${fx ? `  [${fx}]` : ""}`, `    função: ${SLOT_ROLE[k] ?? "—"}`);
  }
  L.push("", "FICHA TÉCNICA DE CADA PEÇA · NOME · DESCRIÇÃO · FÍSICA · FÓRMULAS · CONEXÕES", ...partSheets(b, s, fuelL, riderKg), "");
  const cam = CAM_FX[s.cam] ?? CAM_FX.original;
  L.push(`- COMANDO    ${CAM_LABEL[s.cam] ?? s.cam}  [pico ${cam.rpm >= 0 ? "+" : ""}${cam.rpm} rpm · hp ×${cam.mul}]`, `- CABEÇOTE   taxa ${s.compression}:1`, `- RELAÇÃO    ${s.front}×${s.rear} | pneu ${s.psi} psi | desgaste ${Math.round((s.tireWear ?? 0) * 100)}% | filtro ${s.airFilter}`);
  const sv = SERVICES.filter((x) => s.services.includes(x.id));
  L.push(`- OFICINA    ${sv.length ? sv.map((x) => x.name).join(", ") : "nenhum serviço"}`);

  H("2. CÓDIGO MATEMÁTICO · LINHAS DO CÁLCULO");
  const hpBase = e.eth ? b.hpEth : b.hpGas;
  L.push("[POTÊNCIA] engine()", `  hp = (hp_base + adições) × mul_total`, `  hp_base(${e.eth ? "etanol" : "gasolina"}) = ${hpBase} cv`, `  mul_taxa = 1 + (${s.compression} − 9,5) × 0,025 = ${f(1 + (s.compression - 9.5) * 0.025, 4)}${!e.eth && s.compression > 11 ? `  − detonação (${s.compression}−11)×0,04` : ""}`, `  mul_comando = ×${cam.mul} | pico = ${b.rpmPeak} + ${cam.rpm} + serviços = ${e.rpmPeak} rpm`, `  mul_escape(pico) = exhaustMul = ${f(exhaustMul(b, s, e.rpmPeak), 4)}`, `  RESULTADO: hp = ${f(e.hp, 2)} cv @ ${e.rpmPeak} rpm | corte ${e.rpmLimit} rpm | fuelMul ${f(e.fuelMul, 3)}`);
  L.push("", "[CILINDRADA E TORQUE]", `  cc = ${f(cc, 1)} cc`, `  torque = torque_base × (hp/hp_base) = ${f(stt.torque, 2)} kgf·m = ${f(tqNm, 1)} N·m`);
  L.push("", "[MASSA] stats()", `  m = seco+peças ${f(stt.kg - fuelL * FUEL_DENSITY[s.fuel], 1)} + comb ${f(fuelL, 2)}L × ${FUEL_DENSITY[s.fuel]} kg/L + piloto ${riderKg} = ${f(mTot, 1)} kg`);
  L.push("", "[PNEU] tireOf()", `  P = ${s.psi} psi × 6894,757 = ${f(s.psi * 6894.757, 0)} Pa (recomendada ${STOCK_PSI} psi) · k = k_carcaça + 0,55·P · δ = N/k = ${f((tire.deflM ?? 0) * 1000, 1)} mm`, `  grip = composto × μ_pressão(${f(tire.muPsi ?? 1, 4)}) × (1 − 0,18×desgaste) = ${f(tire.grip, 4)}`, `  crr(v) = 0,015 × composto × δ/δrec × [1 + 0,6·(v/33,3)²·(δ/δrec)^1,5] · parado = ${f(tire.crr, 5)}`, `  TRAÇÃO = 0,62 × ${f(mTot, 1)} × 9,81 × 1,05 × ${f(tire.grip, 4)} = ${f(traction, 1)} N  (patinando: ×${SPIN_GRIP})`);
  L.push("", "[EMBREAGEM]", `  cap(rpm) = ${clutch} N·m × ω ; ω = rpm × 2π/60`, `  torque do motor ${f(tqNm, 1)} N·m ${tqNm > clutch ? `> ${clutch} → PATINA no pico` : `≤ ${clutch} → acopla`}`);
  const dtr = drivetrain(b, s);
  L.push("", "[RELAÇÃO] drivetrain()", `  primária ${dtr.primary != null ? f(dtr.primary, 3) : "PENDENTE"} · final ${s.rear}/${s.front} = ${f(dtr.final, 4)} · r_din ${f(dtr.rDynM, 4)} m · corte ${dtr.rpmLimit} rpm (${dtr.origem})`, ...gs.map((v, i) => `  ${i + 1}ª: i = ${dtr.primary != null ? f(dtr.primary, 3) : "?"} × ${dtr.gears[i] != null ? f(dtr.gears[i]!, 3) : "?"} × ${f(dtr.final, 4)} = ${f(dtr.totals[i]!, 3)} → ${f(v, 1)} km/h no corte`));
  const ex = exhaustInfo(exhaustId(s), cc, e.rpmPeak), xs = exhaustSpec(exhaustId(s));
  L.push("", "[ESCAPE] exhaust.ts", `  tubo d=${xs.d} mm L=${xs.L} | d_ideal(pico) = ${f(ex.dIdeal, 1)} mm | ressonância em ${Math.round(ex.tunedRpm)} rpm`, `  ${ex.oversized ? "SUPERDIMENSIONADO: gás lento, perde embaixo" : ex.undersized ? "SUBDIMENSIONADO: restringe em alto giro" : "diâmetro casado com a cilindrada"}`);
  L.push("", "[ALIMENTAÇÃO] mixtureAt()/fuelChain()");
  for (const r of [...new Set([6000, 7000, 8000, 9000, e.rpmLimit])].filter((x) => x <= e.rpmLimit)) {
    const c = fuelChain(b, s, r);
    L.push(`  ${String(r).padStart(5)} rpm: pede ${f(c.need, 3)}× | entrega ${f(c.supply, 3)}× | duty ${f(c.dutyPct, 1)}% | AFR_actual ${f(afrAt(b, s, r, e.rpmPeak), 2)} (AFR_stoich ${f(mixState(b, s, r, e.rpmPeak).AFR_stoich, 1)} · lambda_mix ${f(mixState(b, s, r, e.rpmPeak).lambda_mix, 3)}) | ${c.lean > 0.02 ? "FALTA" : "ok"}`);
    if (c.lean > 0.02) alerts.push(`falta de combustível a ${r} rpm (bico ${c.bico}× < ${c.bicoNeeded}× necessário)`);
  }
  L.push(`  consumo = P(W)/1000 × BSFC / ρ / 3600 → no pico: ${f(fuelFlow(s.fuel, e.hp * 735.5) * e.fuelMul * 3600, 2)} L/h`);
  L.push("", "[PONTO]", `  ponto ótimo = ${f(timingOptimum(b, s), 2)}° | mapa ${s.ecu.timing}°`);
  // BUG 01: sem porcentagem de risco. Carga, capacidade e margem vêm de mechlimits (as mesmas contas que quebram na corrida).
  L.push("", "[LIMITES FÍSICOS] carga aplicada vs capacidade (ver seção FÍSICA DO MOTOR)", ...sx.causes.map((c) => `  · agravante cadastrado: ${c.cause}${c.src ? ` — ${c.src}` : ""}`), "  O antigo índice stress() (soma de pesos → %) não é probabilidade nem limite mecânico; não é usado para aprovar ou quebrar.");
  void sx;

  H("3. DIÁRIO DE BORDO · SIMULAÇÃO PASSO A PASSO (DT = 1/240 s)");
  const st = newSim(fuelL);
  const log = (msg: string) => L.push(`[${f(st.t, 2).padStart(6)}s | ${f(st.x, 0).padStart(5)}m | ${st.gear}ª | ${String(Math.round(st.rpm)).padStart(5)}rpm] ${msg}`);
  let spin0: number | null = null, slip0: number | null = null, lean0: number | null = null, res0: number | null = null, gear0 = 0, gear = 1;
  {
    const lr = launchRpm(b, s), two = !!(s.slots.modulo && s.ecu.launch && lr === Math.min(s.ecu.launch, e.rpmLimit));
    const idles = [0, 0.2, 0.4, 0.6, 0.8, 1].map((t) => idleRpm(s, t));
    const pAt = (r: number) => e.hp * powerShape(r, e.rpmPeak, b, s) * mixFactor(s, r, e.rpmPeak) * exhaustShape(b, s, r, e.rpmPeak);
    let best = 0, bestR = 0;
    for (let r = 4000; r <= e.rpmLimit; r += 50) { const p = pAt(r); if (p > best) { best = p; bestR = r; } }
    L.push("[PRÉ-LARGADA] 6 s: 0–3 s lenta · 3–6 s acelera no máximo e segura no corte (limitador ou 2-step) até largar");
    L.push(`  lenta = ${s.ecu.idle ?? 1300} + 28·sin(5,1t) + 12·sin(13,7t) + 6·sin(1,3t) → oscila ${Math.round(Math.min(...idles))}–${Math.round(Math.max(...idles))} rpm (monocilíndrico caçando)`);
    L.push(`  rampa = lenta + (giro_largada − lenta) × k², k = 0→1 em 3 s`);
    const il = idealLaunch(b, s);
    L.push(`  giro_largada = ${two ? `2-step ${s.ecu.launch}` : `giro de menor tempo até ${LAUNCH_EVAL_M} m na step() (${il.t60m.toFixed(3)} s; limite tração/empinada ${Math.round(il.limit)} N, μ ${il.mu.toFixed(3)}, ${il.kg.toFixed(1)} kg)`} = ${Math.round(lr)} rpm; no giro ideal cai ~250 rpm e volta 14×/s`);
    L.push(`  potência no drop = ${f(pAt(lr), 2)} cv | maior potência do motor = ${f(best, 2)} cv @ ${bestR} rpm (${f((pAt(lr) / best) * 100, 1)}%)`);
    if (pAt(lr) < best * 0.97) alerts.push(`largada a ${Math.round(lr)} rpm entrega ${f((pAt(lr) / best) * 100, 0)}% da potência máxima (pico real em ${bestR} rpm)`);
  }
  log(`Embreagem solta a ${Math.round(st.rpm = launchRpm(b, s))} rpm, ${f(e.hp, 1)} cv disponíveis.`);
  while (st.finishT === null && !stalled(st) && st.t < 600) {
    step(st, b, s, DT, distance);
    const inG = st.t - gear0;
    if (st.spin && spin0 === null) { spin0 = st.t; log(`Pneu PATINOU: força na roda passou da tração (${f(traction, 0)} N).`); }
    if (!st.spin && spin0 !== null) { log(`Pneu recuperou aderência após ${f(st.t - spin0, 2)} s patinando.`); spin0 = null; }
    if (st.slip > 0 && slip0 === null) { slip0 = st.t; log(`Embreagem PATINOU (${Math.round(st.slip * 100)}% do torque perdido; cap ${clutch} N·m).`); }
    if (st.slip <= 0 && slip0 !== null) { log(`Embreagem acoplou após ${f(st.t - slip0, 2)} s patinando.`); slip0 = null; }
    const c = fuelChain(b, s, st.rpm);
    if (c.lean > 0.02 && lean0 === null && st.shiftT <= 0) { lean0 = st.t; log(`Alimentação deu FALTA aos ${f(inG, 2)} s da ${st.gear}ª: pede ${f(c.need, 3)}×, chega ${f(c.supply, 3)}× (duty ${f(c.dutyPct, 0)}%).`); }
    if (c.lean <= 0.02 && lean0 !== null) { log(`Alimentação normalizou após ${f(st.t - lean0, 2)} s de falta.`); lean0 = null; }
    const shp = exhaustShape(b, s, st.rpm, e.rpmPeak), inRes = Math.abs(st.rpm - ex.tunedRpm) < 400;
    if (inRes && res0 === null) { res0 = st.t; log(`Escape em RESSONÂNCIA (${Math.round(ex.tunedRpm)} rpm): forma ${f(shp, 3)}×, potência ${f(e.hp * powerShape(st.rpm, e.rpmPeak, b, s) * mixFactor(s, st.rpm, e.rpmPeak) * shp, 1)} cv.`); }
    if (!inRes && res0 !== null) { log(`Saiu da faixa de ressonância após ${f(st.t - res0, 2)} s.`); res0 = null; }
    if (st.gear !== gear) { log(`Troca ${gear}ª→${st.gear}ª a ${f(st.v * 3.6, 1)} km/h (${f(inG, 2)} s na ${gear}ª, máx ${f(st.gearMax[gear - 1] ?? 0, 1)} km/h).`); gear = st.gear; gear0 = st.t; }
    yield;
  }
  if (spin0 !== null) log(`Pneu patinou ${f(st.t - spin0, 2)} s até o fim.`);
  if (lean0 !== null) log(`Falta de combustível durou ${f(st.t - lean0, 2)} s até o fim.`);
  log(st.finishT !== null ? `CHEGADA: ${f(st.finishT, 3)} s | vmax ${f(st.top, 1)} km/h | 0-100 ${st.t100 ? f(st.t100, 2) + " s" : "—"} | gasto ${f(fuelL - st.fuel, 3)} L` : "MOTOR APAGOU: tanque seco antes da chegada.");
  if (st.finishT === null) alerts.push("tanque seco antes da chegada");

  H("4. TRADUÇÃO · ESTÁ TUDO FUNCIONANDO?");
  L.push(alerts.length ? alerts.map((a) => `[ALERTA] ${a}`).join("\n") : "[OK] Conjunto coerente: alimentação acompanha, escape casado, sem tanque seco.");
  L.push(`Embreagem: ${tqNm > clutch ? "[GARGALO] torque acima da capacidade, patina." : "[OK] segura o torque."}`, `Escape: ${ex.oversized || ex.undersized ? "[ALERTA] diâmetro fora do ideal." : "[OK] sintonizado."}`, "=".repeat(78));

  const status = fuelL <= 0 || (st.finishT === null && st.x < 1) ? "TESTE NÃO EXECUTADO POR FALTA DE COMBUSTÍVEL" : alerts.length ? `${alerts.length} alerta(s)` : "OK";
  if (status.startsWith("TESTE NÃO")) L.push(`[${status}] nenhum resultado aprovado.`);
  L.push(transmissionTxt(b, s));
  L.push(yield* mechTxtSteps(b, s, distance, fuelL));
  return { id: `${Date.now()}`, at: new Date().toISOString(), pilot, bike: b.name, distance, status, txt: L.join("\n"), kind: "corrida" };
}

/** Stores the report for the Wiki "Ao Vivo" tab (same browser) and notifies open tabs.
 *  With `src` (the bike and setup the report came from) it is also sent to the RealGear funnel, off the UI thread. */
export function pushLive(r: LiveReport, src?: { bike: BikeModel; setup: Setup }) {
  try {
    const cur: LiveReport[] = JSON.parse(cloudStore.getItem(LIVE_KEY) ?? "[]");
    cloudStore.setItem(LIVE_KEY, JSON.stringify([r, ...cur].slice(0, 20)));
    window.dispatchEvent(new Event(LIVE_EVENT));
  } catch { /* storage cheio: ignora */ }
  if (src) setTimeout(() => { import("./engineering/dados/pipeline").then((m) => m.intakeLive(src.bike.id, src.setup, `ao vivo · ${r.kind ?? "corrida"} · ${r.pilot}`)).catch((e) => console.warn("eng-dados intake", e)); }, 0);
  if (src) setTimeout(() => { import("./realgear/live-intake").then((m) => m.analyzeLive(r, src.bike, src.setup)).catch((e) => console.warn("realgear intake", e)); }, 0);
}
/** Writes the funnel result back onto the stored live report. */
export function markLive(id: string, funnel: NonNullable<LiveReport["funnel"]>) {
  try {
    const cur: LiveReport[] = JSON.parse(cloudStore.getItem(LIVE_KEY) ?? "[]");
    cloudStore.setItem(LIVE_KEY, JSON.stringify(cur.map((x) => (x.id === id ? { ...x, funnel } : x))));
    window.dispatchEvent(new Event(LIVE_EVENT));
  } catch { /* cheio */ }
}
export function readLive(): LiveReport[] {
  try { return JSON.parse(cloudStore.getItem(LIVE_KEY) ?? "[]"); } catch { return []; }
}

/** Dyno pull audit: same full report on the dyno distance plus the measured pull data. */
export function dynoReport(pilot: string, b: BikeModel, s: Setup, distance: number, fuelL: number, pull: string[]): LiveReport {
  const r = preloadReport(pilot, b, s, distance, fuelL);
  const txt = r.txt.replace("RELATÓRIO DE PRELOAD", "RELATÓRIO DO DINAMÔMETRO") + "\n\n" + ["-".repeat(78), "DINAMÔMETRO · PUXADA MEDIDA", "-".repeat(78), ...pull].join("\n");
  return { ...r, txt, kind: "dinamometro" };
}

export async function dynoReportAsync(pilot: string, b: BikeModel, s: Setup, distance: number, fuelL: number, pull: string[], cancelled?: () => boolean): Promise<LiveReport> {
  const r = await computeSlices(preloadReportSteps(pilot, b, s, distance, fuelL), cancelled);
  const txt = r.txt.replace("RELATÓRIO DE PRELOAD", "RELATÓRIO DO DINAMÔMETRO") + "\n\n" + ["-".repeat(78), "DINAMÔMETRO · PUXADA MEDIDA", "-".repeat(78), ...pull].join("\n");
  return { ...r, txt, kind: "dinamometro" };
}
