import { drainIfMixBreak } from "./fuelmix";
// Background Trampo runtime: shifts per workplace on the map, stacked offers,
// a delivery list (up to MAX_RUNS, done one after another) and payout summaries.
import { useSyncExternalStore } from "react";
import { engineSafe } from "./missions";
import { gainXp, tripMul } from "./level";
import { courierMul, courierLevel, WORK_REQ, workUnlocked, rollJob, routeSeconds, type Job, type JobKind, type Stop } from "./trampo";
import { earn } from "./credit";
import { getPlayer, ledgerTag, setPlayer, type Player } from "./store";
import { bikeModel } from "./physics";
import { streetBreak } from "./mechlimits";
import { hpTripMul, jobKmPerL, tireWearMul } from "./usage";

export interface Workplace { id: string; label: string; kind: JobKind; place: string }
export const WORKPLACES: Workplace[] = [
  { id: "pizzaria", label: "Pizzaria", kind: "entrega", place: "Pizzaria Bella" },
  { id: "lanchonete", label: "Lanchonete", kind: "entrega", place: "Lanchonete do Zé" },
  { id: "acai", label: "Açaí", kind: "entrega", place: "Açaí da Praça" },
  { id: "taxi", label: "Moto Táxi", kind: "taxi", place: "" },
];
export const workplace = (id: string) => WORKPLACES.find((w) => w.id === id)!;

/** First-ever job: call arrives in ~2.5 s and lasts 10 s (demo). */
export const FIRST_JOB_S = 0.5;
export const FIRST_CALL_MS = 2500;
export const BUSY_MSG = "Termine sua corrida antes";

export interface Offer extends Job { from: string; expires: number; boardId?: string }
export interface Summary { pay: number; xp: number; up: boolean; bonus?: number; dry: boolean; broken?: boolean; level: number; place: string; stops?: Stop[] }
export type Run = NonNullable<Player["activeJobs"]>[number];

/** Max accepted calls in the delivery list at once. */
export const MAX_RUNS = 2;

export type NoticeKind = "info" | "ok" | "warn";
export interface Notice { id: number; msg: string; kind: NoticeKind }
/** Max toasts on screen; older ones drop so messages never pile up. */
export const MAX_NOTICES = 3;

interface RunState { offers: Offer[]; summaries: Summary[]; notices: Notice[] }
let rs: RunState = { offers: [], summaries: [], notices: [] };
const subs = new Set<() => void>();
const emit = (patch: Partial<RunState>) => { rs = { ...rs, ...patch }; subs.forEach((f) => f()); };
export const useRun = () => useSyncExternalStore((f) => (subs.add(f), () => subs.delete(f)), () => rs, () => rs);
export const getNotices = () => rs.notices;

let nid = 0;
/** Queued toast: same text is not repeated while visible; ok/info 2.4 s, warn 2.8 s. */
export function notify(msg: string, kind: NoticeKind = "warn") {
  if (rs.notices.some((n) => n.msg === msg)) return;
  const n: Notice = { id: ++nid, msg, kind };
  emit({ notices: [...rs.notices, n].slice(-MAX_NOTICES) });
  setTimeout(() => emit({ notices: rs.notices.filter((x) => x.id !== n.id) }), kind === "warn" ? 2800 : 2400);
}

export const runsOf = (p: Player | null = getPlayer()): Run[] => p?.activeJobs ?? [];
export const isBusy = (p: Player | null = getPlayer()) => runsOf(p).length > 0;

/** Why this call can't join the list (null = ok): max MAX_RUNS deliveries; a taxi ride goes alone. */
export function stackBlock(runs: Run[], kind: JobKind): string | null {
  if (!runs.length) return null;
  if (runs.length >= MAX_RUNS || kind === "taxi" || runs.some((r) => r.job.kind === "taxi")) return BUSY_MSG;
  return null;
}

/** Max workplaces with an open shift at once. */
export const MAX_SHIFTS = 2;
export const SHIFT_MSG = "Máximo de 2 lugares abertos. Feche um turno antes.";

export function toggleShift(id: string) {
  const open = getPlayer()?.shifts ?? [];
  if (!open.includes(id) && !workUnlocked(id, getPlayer()?.level ?? 1)) return notify(`Requer nível ${WORK_REQ[id]} (você está no ${getPlayer()?.level ?? 1}).`);
  if (!open.includes(id) && open.length >= MAX_SHIFTS) return notify(SHIFT_MSG);
  setPlayer((pl) => {
    const s = pl.shifts ?? [];
    return { ...pl, shifts: s.includes(id) ? s.filter((x) => x !== id) : [...s, id] };
  });
  if (!(getPlayer()?.shifts ?? []).includes(id)) emit({ offers: rs.offers.filter((o) => o.from !== id) });
  // Tutorial demo: the very first call arrives the moment the shift opens.
  const pl = getPlayer();
  if (pl && (pl.shifts ?? []).includes(id) && (pl.jobsDone ?? 0) === 0 && !(pl.activeJobs ?? []).length && pl.activeBike && !pl.broken) pushOffer(id, pl.level);
}

export function pushOffer(from: string, level: number) {
  if (rs.offers.some((o) => o.from === from) || rs.offers.length >= 4) return;
  const w = workplace(from);
  const j = rollJob(w.kind, level, Math.random, from, courierMul(getPlayer()?.jobsDone ?? 0));
  emit({ offers: [...rs.offers, { ...j, place: w.place || j.place, from, expires: Date.now() + TUTORIAL_OFFER_MS }] });
}
/** Tutorial call lasts 5 s; unanswered or refused, the shift closes so the guide restarts at Açaí. */
export const TUTORIAL_OFFER_MS = 5000;
/** After refusing a call, that workplace sends nothing to this player for REFUSE_COOLDOWN_MS. */
export const REFUSE_COOLDOWN_MS = 60000;
const cooldown: Record<string, number> = {};
const dismissed = new Set<string>();
/** Tutorial (no delivery done yet): a lost call closes the shift so the hand goes back to Açaí. */
function resetTutorialShift(from: string) {
  const pl = getPlayer();
  if (!pl || (pl.jobsDone ?? 0) > 0 || (pl.activeJobs ?? []).length || !(pl.shifts ?? []).includes(from)) return;
  setPlayer((x) => ({ ...x, shifts: (x.shifts ?? []).filter((s) => s !== from) }));
}
export const dropOffer = (id: string) => { dismissed.add(id); emit({ offers: rs.offers.filter((o) => o.id !== id) }); };
/** Player refused: hide it and pause that workplace for 60 s. */
export const refuseOffer = (id: string) => {
  const o = rs.offers.find((x) => x.id === id);
  dropOffer(id);
  if (!o) return;
  cooldown[o.from] = Date.now() + REFUSE_COOLDOWN_MS;
  if (!o.boardId) resetTutorialShift(o.from);
};
/** Replaces server offers with the latest board (local tutorial offers stay); refused/claimed ones stay hidden. */
export function setBoard(board: Offer[]) {
  const local = rs.offers.filter((o) => !o.boardId);
  const shifts = getPlayer()?.shifts ?? [];
  emit({ offers: [...local, ...board.filter((o) => !dismissed.has(o.id) && (cooldown[o.from] ?? 0) <= Date.now() && shifts.includes(o.from) && !local.some((l) => l.from === o.from))] });
}
/** Same checks as accept(), without side effects; used before asking the server. */
export function acceptBlock(o: Offer): string | null {
  const cur = getPlayer();
  if (!cur?.activeBike) return "Sem moto não dá pra pegar corre.";
  if (cur.broken) return "Motor quebrado: leva na Oficina antes de pegar corre.";
  return stackBlock(runsOf(), o.kind);
}
export const pruneOffers = () => {
  const now = Date.now();
  const gone = rs.offers.filter((o) => o.expires <= now);
  if (!gone.length) return;
  emit({ offers: rs.offers.filter((o) => o.expires > now) });
  gone.forEach((o) => { if (!o.boardId) resetTutorialShift(o.from); });
};

export function accept(o: Offer, now = Date.now()) {
  const cur = getPlayer();
  if (!cur?.activeBike) return notify("Sem moto não dá pra pegar corre.");
  if (cur.broken) return notify("Motor quebrado: leva na Oficina antes de pegar corre.");
  const block = stackBlock(runsOf(), o.kind);
  if (block) return notify(block);
  dropOffer(o.id);
  const pl0 = getPlayer();
  // First job ever is a 10 s demo so the mission isn't a long wait.
  const secs = (pl0?.jobsDone ?? 0) === 0 && !(pl0?.activeJobs ?? []).length ? FIRST_JOB_S : Math.max(5, Math.round(routeSeconds(o) * tripMul(pl0?.level ?? 1) * (pl0 ? hpTripMul(bikeModel(pl0.activeBike), pl0.setup) : 1)));
  const { from: _f, expires: _e, ...job } = o;
  setPlayer((pl) => {
    const list = pl.activeJobs ?? [];
    const start = Math.max(now, list.at(-1)?.endsAt ?? now);
    return { ...pl, activeJobs: [...list, { job, endsAt: start + secs * 1000, secs }] };
  });
}

/** Pays out every run in the list whose timer is over, in order (idempotent). */
export function settle(now = Date.now()) {
  const cur = getPlayer();
  const done = runsOf(cur).filter((r) => now >= r.endsAt);
  if (!cur || !done.length) return;
  const out: Summary[] = [];
  ledgerTag("Trampo · entregas");
  setPlayer((start) => {
    let pl = start;
    for (const { job } of done) {
      const bm = bikeModel(pl.activeBike);
      // engine already broken on an earlier run of the list: this one never leaves, nothing paid or counted
      if (pl.broken) {
        out.push({ pay: 0, xp: 0, up: false, dry: false, broken: true, level: pl.level, place: job.place });
        continue;
      }
      const need = job.km / jobKmPerL(bm, pl.setup);
      const dry = pl.fuelL < need;
      const frac = dry ? pl.fuelL / need : 1;
      const km = job.km * frac;
      const pay = dry ? 0 : job.pay;
      const xp = dry ? 0 : job.xp;
      const lv = gainXp(earn(pl, pay), xp);
      // física pura: quebra só se o regime de cruzeiro passa de um limite do material (sem sorteio)
      const broke = !dry && !engineSafe(pl) ? streetBreak(bm, pl.setup)?.cause ?? null : null;
      out.push({ pay, xp, up: lv.ups > 0, bonus: lv.bonus, dry, level: lv.player.level, place: job.place, ...(job.stops ? { stops: job.stops } : {}) });
      pl = {
        ...lv.player,
        jobsDone: (pl.jobsDone ?? 0) + (dry ? 0 : 1),
        fuelL: Math.max(0, Math.round((pl.fuelL - need * frac) * 1000) / 1000),
        tireKm: (pl.tireKm ?? 0) + km * tireWearMul(pl.setup),
        broken: broke,
        diagnosed: broke && !pl.broken ? false : !!pl.diagnosed,
        setup: { ...pl.setup, km: pl.setup.km + km, oilKm: pl.setup.oilKm + km },
      };
      pl = drainIfMixBreak(pl, broke);
    }
    // engine broke: the rest of the list is cancelled right away (bike can't leave the garage)
    return { ...pl, activeJobs: pl.broken ? [] : (pl.activeJobs ?? []).filter((r) => now < r.endsAt) };
  });
  emit({ summaries: [...rs.summaries, ...out] });
}
export const closeSummary = () => emit({ summaries: rs.summaries.slice(1) });
