// O mecânico: lê a física do motor e fala como preparador. Aponta a direção, nunca a peça/valor exato.
import { TITAN_160, engine, stress, timingOptimum, afrAt, type BikeModel, type Setup } from "./physics";
import { identify, mixDiagnosis, mixFixHint } from "./mech-identity";

export interface Forensic {
  /** O que foi encontrado na desmontagem. */
  found: string;
  /** Por que aconteceu (física). */
  why: string;
  /** O que precisa mudar pra não repetir (direção, sem receita pronta). */
  prevent: string;
}

const LAUDOS: [string, Forensic][] = [
  ["mistura pobre", {
    found: "Coroa do pistão derretida no lado do escape, vela branca e eletrodo fundido.",
    why: "Faltou combustível em alta: mistura pobre queima mais quente e devagar, a câmara passou do limite do alumínio e o pistão amoleceu.",
    prevent: "A alimentação não acompanha o ar que esse motor puxa. Ou entra mais combustível onde ela passa fome, ou o motor respira menos.",
  }],
  ["Válvula atropelada", {
    found: "Válvula torta, marca de batida na cabeça do pistão e guia ovalizada.",
    why: "No giro alto a mola não fechou a válvula a tempo (flutuação). O pistão subiu e encontrou ela aberta.",
    prevent: "Ou o giro está acima do que o trem de válvulas aguenta, ou falta folga entre válvula e pistão para o comando/válvulas usados.",
  }],
  ["Pistão furado", {
    found: "Furo na cabeça do pistão, canaletas com marca de batida de pino.",
    why: "Detonação: a mistura explodiu sozinha antes da faísca. Pressão e calor de compressão alta, ponto adiantado ou combustível fraco pra essa taxa.",
    prevent: "Essa combinação de taxa, ponto e combustível detona. Algum desses três precisa ceder, ou o pistão precisa ser mais forte.",
  }],
  ["Pistão travou", {
    found: "Pistão riscado e colado na parede, saia com alumínio transferido.",
    why: "Kit maior dilata mais e trabalha mais quente; a folga sumiu e o pistão agarrou.",
    prevent: "Esse cilindro maior pede montagem e acabamento à altura, e um conjunto que alivie a carga.",
  }],
  ["Anéis", {
    found: "Anéis partidos, cilindro espelhado e consumo de óleo.",
    why: "Cilindro novo sem acabamento interno não assenta anel: ele vibra, esquenta e quebra.",
    prevent: "O cilindro precisa do acabamento interno certo antes de levar carga.",
  }],
  ["trincado", {
    found: "Trinca vertical na camisa do cilindro.",
    why: "Diâmetro grande demais deixou a parede fina; a pressão de combustão abriu o metal.",
    prevent: "Esse diâmetro só segura com a camisa reforçada.",
  }],
  ["Biela", {
    found: "Biela partida, carcaça danificada e virabrequim empenado.",
    why: "Curso maior aumenta a velocidade do pistão e a força de inércia no PMS; a biela original passou do limite de fadiga.",
    prevent: "O conjunto de baixo não acompanha esse curso. Ou reforça embaixo, ou volta o curso.",
  }],
  ["Cabeçote", {
    found: "Face do cabeçote empenada, junta queimada e vazamento de compressão.",
    why: "Usinagem e fluxo extras subiram o calor e a pressão além do que esse cabeçote dissipa.",
    prevent: "O cabeçote está com mais serviço do que aguenta. Alivia o serviço ou alivia a carga térmica.",
  }],
  ["Câmbio", {
    found: "Dentes de engate espanados nas engrenagens.",
    why: "Corte de troca curto demais: a marcha entrou com o motor ainda empurrando.",
    prevent: "A troca precisa de mais tempo de corte pra aliviar a caixa.",
  }],
  ["Embreagem", {
    found: "Discos queimados, molas recozidas e campana marcada.",
    why: "Giro de largada alto patinou a embreagem parada, o calor queimou a lona.",
    prevent: "Ou a largada sai mais baixa, ou a embreagem precisa segurar mais.",
  }],
];

const GENERIC: Forensic = {
  found: "Motor fundido, bronzinas danificadas.",
  why: "A soma da preparação passou do que o conjunto aguenta.",
  prevent: "Volta o último passo e sobe a preparação aos poucos.",
};

export function forensic(cause: string): Forensic {
  return LAUDOS.find(([k]) => cause.includes(k))?.[1] ?? GENERIC;
}

/** Aviso depois do conserto: se a causa de risco continua montada, o mecânico avisa que vai quebrar de novo. */
export function rebuildWarning(s: Setup, bike: BikeModel = TITAN_160): string | null {
  const st = stress(bike, s);
  if (st.risk < 0.08) return null;
  const f = forensic(st.cause);
  const lvl = st.risk > 0.4 ? "Vai quebrar de novo, é questão de puxada." : st.risk > 0.2 ? "Do jeito que está, ela volta pra cá." : "Tá montada, mas no limite.";
  return `${lvl} ${f.prevent}`;
}

interface Gear { lo: number; hi: number; kmh: number; afr: number }
interface Rep { gears: (Gear | undefined)[]; t: number | null; vmax: number }

/** Dica após cada puxada, ligada à pista e ao motor. Funciona com ou sem módulo programável. */
export function pullAdvice(s: Setup, rep: Rep, dist: number, bike: BikeModel = TITAN_160): string {
  const e = engine(bike, s);
  const id = identify(bike, s), prog = id.modulo.programavel;
  const mix = mixDiagnosis(bike, s);
  const gears = rep.gears.filter(Boolean) as Gear[];
  const last = gears.length;
  const st = stress(bike, s);
  const stoich = s.fuel === "etanol" ? 9.0 : 14.7;

  // 1. Segurança primeiro
  if (st.risk > 0.3) return `Ouvi um barulho que não gostei. ${forensic(st.cause).prevent}`;
  const pobre = mix.bandas.find((x) => x.estado === "pobre");
  if (pobre) return `Em ${pobre.faixa} ela tá magra. ${mixFixHint(id, "pobre", pobre.faixa)}`;

  // 2. Relação vs pista
  const topG = gears[last - 1];
  const bouncing = topG && topG.hi >= e.rpmLimit - 150;
  if (last >= bike.gears && bouncing && dist >= 1000) return "Bateu no corte na última e ainda tinha pista. Pra essa distância a relação pede mais velocidade final.";
  if (last <= 3 && dist <= 500) return "A pista acabou e ela nem chegou nas marchas de cima. Dá pra encurtar a relação e sair mais forte.";
  if (last < bike.gears && dist >= 5000) return "Nem usou a última marcha nessa distância. A relação tá longa demais pra encher.";
  if (topG && dist >= 5000 && !bouncing && topG.hi < e.rpmPeak - 400) return "Na última ela fica abaixo do pico de força. Encurtando um pouco ela enche a marcha.";

  // 3. Mistura rica: lida em toda a puxada, por faixa (a bolinha nunca diz "redondinha" com excesso)
  const ricas = mix.bandas.filter((x) => x.estado === "rica");
  if (ricas.length) return `Tá gorda em ${ricas.map((x) => x.faixa).join(", ")}: afoga e perde força. ${mixFixHint(id, "rica", ricas[0]!.faixa)}`;

  // 4. Ponto / módulo
  if (prog) {
    const d = s.ecu.timing - timingOptimum(bike, s);
    if (d < -1.5) return "Ela tá preguiçosa no ponto. Dá pra acordar mais um pouco.";
    if (d > 1) return "Tô ouvindo um grilo lá dentro... ponto passou do que essa taxa aceita.";
    if ((s.ecu.tHigh ?? 0) < 0.5 && e.rpmLimit >= 10000) return "Lá em cima ela pede mais ponto do que na base.";
    if ((s.ecu.tLow ?? 0) > 0.5) return "Embaixo ela tá batendo leve. Ponto de baixa tá adiantado.";
    if (s.ecu.over == null && e.rpmLimit > 10800 && gears.some((g) => g.afr > stoich * 0.9)) return "Depois dos 10,5k a mistura vai sumindo. Tem faixa no módulo só pra isso.";
    const early = s.ecu.shift.findIndex((x) => x > 0 && x < e.rpmPeak - 300);
    if (early >= 0) return `Na ${early + 1}ª ela ainda tinha fôlego quando trocou.`;
    if ((s.ecu.qs ?? 220) >= 200) return "Essa troca tá demorando. Dá pra cortar mais seco, sem exagerar na caixa.";
    if (e.rpmLimit < e.rpmPeak + 600) return "Ela bate no corte logo depois de encher. Tem giro sobrando no motor.";
    if (dist <= 500 && !s.ecu.launch) return "Na largada ela sai caindo de giro. Tem recurso no módulo pra segurar a rotação.";
  } else {
    if (e.rpmLimit < e.rpmPeak + 600) return "O módulo de fábrica corta cedo. Esse motor tem giro, mas o módulo não deixa.";
  }

  // 5. Peças que limitam
  if (s.slots.escape === "escape-original" && e.hp > 17) return "O escape original tá estrangulando. O motor quer soltar mais gás.";
  if (s.airFilter === "original" && s.slots.cilindro !== "cilindro-original") return "Motor maior respirando pelo filtro original. Ele quer mais ar.";
  if (s.slots.cilindro === "cilindro-original" && dist >= 500) return "O conjunto tá redondo. Pra andar mais, tem que fuçar a moto.";
  if (id.ignicao === "platinado") return "Carburação afinada e platinado batendo certo. Agora é relação, pneu e motor pro pega.";
  if (id.ignicao === "cdi") return "Carburação afinada e CDI batendo certo. Agora é relação, pneu e motor pro pega.";
  if (!prog) return "Afinada em todo o giro. O ponto dessa central é de fábrica.";
  return "Tá redondinha. Agora é ir pro pega.";
}

/** Exposto para testes: AFR em um rpm com o setup atual. */
export const afrOf = (s: Setup, rpm: number, bike: BikeModel = TITAN_160) => afrAt(bike, s, rpm, engine(bike, s).rpmPeak);
