// Cartão de crédito: diagnosis, repair and maintenance go on the card first; cash only covers what the free limit can't.
// Purchases can be split up to 12x; every income pays the due installment of each open purchase automatically.
import type { Player } from "./store";

export const CREDIT_START = 5000;
/** Limit grows this much every time the bill is fully paid. */
export const CREDIT_RAISE = 0.025;
export const MAX_INSTALLMENTS = 12;

export type Installment = { label: string; amount: number; left: number };

const r2 = (n: number) => Math.round(n * 100) / 100;
export const creditLimit = (p: Player) => p.creditLimit ?? CREDIT_START;
export const creditDebt = (p: Player) => p.creditDebt ?? 0;
export const creditFree = (p: Player) => r2(creditLimit(p) - creditDebt(p));

/** Open installment plans; legacy debt without a plan becomes one single installment. */
export function plans(p: Player): Installment[] {
  const list = p.installments ?? [];
  const planned = r2(list.reduce((s, i) => s + i.amount * i.left, 0));
  const orphan = r2(creditDebt(p) - planned);
  return orphan > 0.009 ? [...list, { label: "Fatura anterior", amount: orphan, left: 1 }] : list;
}

/** Amount due on the next bill (one installment of each plan). */
export const nextBill = (p: Player) => r2(plans(p).reduce((s, i) => s + i.amount, 0));

/** Can `cost` be paid: card first, cash for the rest. */
export const canCharge = (p: Player, cost: number) => Math.max(0, cost - Math.max(0, creditFree(p))) <= p.money;

/** Charge `cost`: card limit first in `n` installments, cash only for what the limit can't cover. Null if both can't. */
export function chargeCard(p: Player, cost: number, n = 1, label = "Oficina"): Player | null {
  const onCard = r2(Math.min(cost, Math.max(0, creditFree(p))));
  const cash = r2(cost - onCard);
  if (cash > p.money) return null;
  const k = Math.min(MAX_INSTALLMENTS, Math.max(1, Math.round(n)));
  const installments = onCard > 0 ? [...plans(p), { label, amount: r2(onCard / k), left: k }] : plans(p);
  // rounding remainder stays on the debt as the sum of installments
  const debt = r2(installments.reduce((s, i) => s + i.amount * i.left, 0));
  return { ...p, money: r2(p.money - cash), creditDebt: debt, installments };
}

/** Kept for older callers: single-installment card charge. */
export const chargeRepair = (p: Player, cost: number) => chargeCard(p, cost, 1);

/** Pays the due installment of each plan that cash covers; a cleared bill raises the limit. */
export function settle(p: Player): Player {
  const open = plans(p);
  if (!open.length) return p;
  let money = p.money;
  const rest: Installment[] = [];
  for (const i of open) {
    if (money >= i.amount) {
      money = r2(money - i.amount);
      if (i.left > 1) rest.push({ ...i, left: i.left - 1 });
    } else rest.push(i);
  }
  if (money === p.money) return p;
  const debt = r2(rest.reduce((s, i) => s + i.amount * i.left, 0));
  const cleared = debt <= 0.009;
  return { ...p, money, installments: rest, creditDebt: cleared ? 0 : debt, creditLimit: cleared ? r2(creditLimit(p) * (1 + CREDIT_RAISE)) : creditLimit(p) };
}

/** Add income, then pay the due installments. */
export function earn(p: Player, amount: number): Player {
  return settle({ ...p, money: r2(p.money + amount) });
}
