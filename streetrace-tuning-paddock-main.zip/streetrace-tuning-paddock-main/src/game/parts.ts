// Moto Peças catalog. Transmission parts set the final drive; slot parts swap a component on the bike.

export type Slot = "modulo" | "bateria" | "susp" | "pneu" | "vela" | "cabo" | "oleo" | "cilindro" | "pistao" | "bico" | "escape" | "embreagem" | "molas" | "biela" | "vira" | "tbi" | "roda" | "bomba";
export type PartKind = "kit" | "pinhao" | "coroa" | Slot | "cabecote" | "comando" | "valvula" | "gicle_alta" | "gicle_lenta" | "junta_carb" | "junta_motor" | "carenagem" | "linha_comb" | "filtro_comb";

export interface Part {
  /** Jogo de anéis que vem montado no pistão (RIK = anéis de alta performance: 1º anel de aço nitretado, tolera mais calor). */
  rings?: "RIK";
  /** Molas dimensionadas: rotação de projeto (rpm) em que a mola segura o trem de válvulas com o comando montado. */
  springRpm?: number;
  /** Massa do trem de válvulas relativa ao de fábrica (válvula, prato, trava, retentor). */
  valveMassMul?: number;
  /** Altura instalada menor da válvula do kit (mm): soma na folga válvula-pistão. */
  valveRecessMm?: number;
  /** Biela avulsa: giro máximo sem quebrar (rpm); o limite de força escala com rpm² sobre a biela de fábrica. */
  rodRpm?: number;
  /** Ø real do pistão sob medida (mm); quando montado define a cilindrada. */
  boreMm?: number;
  /** Arquitetura de ignição em que a peça monta (ignition.ts). Sem campo = qualquer. */
  ign?: "platinado" | "cdi" | "ecu";
  /** Motos em que a peça monta. Sem campo = qualquer moto da arquitetura. */
  bikes?: string[];
  /** CDI sem corte eletrônico: rotação fica limitada só pela física (energia da centelha, molas). */
  noCut?: boolean;
  /** ECU fixa com avanço de ponto ajustável (Setup.ecu.timing), sem mapa completo. */
  ponto?: boolean;
  /** Limitador configurável pelo jogador (Setup.revCut), limitado a b.rpmLimit + rpm do módulo. */
  revCfg?: boolean;
  id: string;
  /** Kit completo: peças que o mecânico monta junto com o cilindro. */
  bundle?: { bico: string; cam: Cam; pistao?: string; front?: number; rear?: number; modulo?: string; molas?: string; bomba?: string; biela?: string; vira?: string; services?: string[] };
  kind: PartKind;
  name: string;
  brand: string;
  spec: string;
  price: number;
  front?: number;
  rear?: number;
  /** kg vs the factory component (negative = lighter). */
  kg?: number;
  hp?: number;
  rpm?: number;
  crr?: number;
  grip?: number;
  oilLife?: number;
  hpMul?: number;
  /** Factory component: always available in Fuçar, never sold. */
  factory?: boolean;
  /** Mechanical load added / removed (break risk) and fuel flow multiplier. */
  stress?: number;
  relief?: number;
  flow?: number;
  /** Displacement (cc) of a cylinder kit when not in the name. */
  cc?: number;
  /** Fuel demand added by displacement. */
  need?: number;
  cavas?: boolean;
  /** Programmable ECU (rev limit, timing, fuel trim). */
  prog?: boolean;
  /** Used up when installed (oil bottles, replacement heads/cams). */
  consumable?: boolean;
  /** Clutch torque capacity at the crank (N·m). */
  clutchNm?: number;
  /** Break-risk relief per failure cause. */
  fix?: Record<string, number>;
  /** Tire thermal window (°C) and grip multiplier when cold (estimates per compound). */
  tLo?: number;
  tHi?: number;
  coldMul?: number;
  /** Tire durability 0–1 (1 = Pirelli original); tread wear per km scales by 1/life. */
  life?: number;
  /** Largura relativa ao pneu de fábrica; estimativa de jogo, não medida do fabricante. */
  widthRatio?: number;
  /** Multiplicador do arrasto aerodinâmico do conjunto (1 = neutro). */
  aero?: number;
  /** Cam profile delivered by a comando part. */
  cam?: Cam;
  /** Ø do pino do pistão (pistão) ou do olhal do pé da biela (biela), mm. Sem valor = sem ficha. */
  pinMm?: number;
  /** Descrição completa do fabricante/anúncio (texto do jogador) e dados de ficha. */
  desc?: string;
  massG?: number;
  folgaMm?: number;
  taxa?: number;
  forjado?: boolean;
  /** Unidades na prateleira da Auto Peças por jogador (sem campo = sem limite). */
  shopStock?: number;
  /** Medida do giclê (número Keihin = Ø × 100 mm), lida pelo circuito do carburador (carb.ts). */
  jet?: number;
  /** Carenagem: multiplica o Cd·A do conjunto moto + piloto (bolha e carenagem fechada reduzem a área ao vento). */
  cdaMul?: number;
}

const pinhao = (t: number, price: number): Part => ({ id: `pinhao-${t}`, kind: "pinhao", name: `Pinhão ${t}T`, brand: "Riffel", spec: `428 · ${t}T`, price, front: t });
const coroa = (t: number, price: number): Part => ({ id: `coroa-${t}`, kind: "coroa", name: `Coroa ${t}T`, brand: "Riffel", spec: `428 · ${t}T`, price, rear: t });

// Auto Peças: vela, giclês Keihin, juntas e linha de combustível. Sem hp/flow: neutros na física (a corrida ainda não lê giclê, junta, mangueira nem filtro).
const CARB_BIKES = ["titan150", "cg125"];
const CARB_AND_FUEL: Part[] = [
  { id: "vela-ngk-d8es-l", kind: "vela", name: "D8ES-L", brand: "NGK", spec: "NGK - Grau térmico 8", price: 21.3, bikes: ["cg125"], shopStock: 12, desc: "Vela NGK D8ES-L para o cabeçote OHV da Honda CG 125 Bolinha (1976–1982). Não monta nos motores de rosca M10." },
  { id: "gicle-alta-95", kind: "gicle_alta", name: "Giclê 95", brand: "Keihin", spec: "Alta", price: 12, jet: 95, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-alta-98", kind: "gicle_alta", name: "Giclê 98", brand: "Keihin", spec: "Alta", price: 12, jet: 98, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-alta-100", kind: "gicle_alta", name: "Giclê 100", brand: "Keihin", spec: "Alta", price: 12, jet: 100, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-alta-102", kind: "gicle_alta", name: "Giclê 102", brand: "Keihin", spec: "Alta", price: 12, jet: 102, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-alta-105", kind: "gicle_alta", name: "Giclê 105", brand: "Keihin", spec: "Alta", price: 12, jet: 105, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-alta-108", kind: "gicle_alta", name: "Giclê 108", brand: "Keihin", spec: "Alta", price: 12, jet: 108, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-alta-110", kind: "gicle_alta", name: "Giclê 110", brand: "Keihin", spec: "Alta", price: 12, jet: 110, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-alta-112", kind: "gicle_alta", name: "Giclê 112", brand: "Keihin", spec: "Alta", price: 12, jet: 112, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-alta-115", kind: "gicle_alta", name: "Giclê 115", brand: "Keihin", spec: "Alta", price: 12, jet: 115, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-alta-118", kind: "gicle_alta", name: "Giclê 118", brand: "Keihin", spec: "Alta", price: 12, jet: 118, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-alta-120", kind: "gicle_alta", name: "Giclê 120", brand: "Keihin", spec: "Alta", price: 12, jet: 120, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-alta-123", kind: "gicle_alta", name: "Giclê 123", brand: "Keihin", spec: "Alta", price: 12, jet: 123, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-alta-125", kind: "gicle_alta", name: "Giclê 125", brand: "Keihin", spec: "Alta", price: 12, jet: 125, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-alta-130", kind: "gicle_alta", name: "Giclê 130", brand: "Keihin", spec: "Alta", price: 12, jet: 130, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-alta-135", kind: "gicle_alta", name: "Giclê 135", brand: "Keihin", spec: "Alta", price: 12, jet: 135, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-alta-140", kind: "gicle_alta", name: "Giclê 140", brand: "Keihin", spec: "Alta", price: 12, jet: 140, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-alta-145", kind: "gicle_alta", name: "Giclê 145", brand: "Keihin", spec: "Alta", price: 12, jet: 145, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-lenta-35", kind: "gicle_lenta", name: "Giclê 35", brand: "Keihin", spec: "Baixa", price: 10.6, jet: 35, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-lenta-38", kind: "gicle_lenta", name: "Giclê 38", brand: "Keihin", spec: "Baixa", price: 10.6, jet: 38, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-lenta-40", kind: "gicle_lenta", name: "Giclê 40", brand: "Keihin", spec: "Baixa", price: 10.6, jet: 40, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-lenta-42", kind: "gicle_lenta", name: "Giclê 42", brand: "Keihin", spec: "Baixa", price: 10.6, jet: 42, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-lenta-45", kind: "gicle_lenta", name: "Giclê 45", brand: "Keihin", spec: "Baixa", price: 10.6, jet: 45, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-lenta-48", kind: "gicle_lenta", name: "Giclê 48", brand: "Keihin", spec: "Baixa", price: 10.6, jet: 48, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-lenta-49", kind: "gicle_lenta", name: "Giclê 49", brand: "Keihin", spec: "Baixa", price: 10.6, jet: 49, bikes: CARB_BIKES, shopStock: 8 },
  { id: "gicle-lenta-50", kind: "gicle_lenta", name: "Giclê 50", brand: "Keihin", spec: "Baixa", price: 10.6, jet: 50, bikes: CARB_BIKES, shopStock: 8 },
  { id: "junta-carb-keihin-077a", kind: "junta_carb", name: "Keihin 077A", brand: "Keihin", spec: "CG 125 Bolinha", price: 9.3, bikes: ["cg125"], shopStock: 10 },
  { id: "junta-carb-keihin-pdc9", kind: "junta_carb", name: "Keihin PDC9", brand: "Keihin", spec: "CG 150 Titan ESD", price: 14.6, bikes: ["titan150"], shopStock: 10 },
  { id: "junta-motor-cg125", kind: "junta_motor", name: "Kit de juntas do motor", brand: "Vedamotors", spec: "CG 125 Bolinha · gasta 1 ao abrir o motor", price: 38, bikes: ["cg125"] },
  { id: "junta-motor-titan150", kind: "junta_motor", name: "Kit de juntas do motor", brand: "Vedamotors", spec: "CG 150 Titan ESD · gasta 1 ao abrir o motor", price: 45, bikes: ["titan150"] },
  { id: "junta-motor-titan160", kind: "junta_motor", name: "Kit de juntas do motor", brand: "Vedamotors", spec: "CG 160 Titan · gasta 1 ao abrir o motor", price: 49, bikes: ["titan160"] },
  { id: "junta-motor-factor150", kind: "junta_motor", name: "Kit de juntas do motor", brand: "Vedamotors", spec: "Factor 150 · gasta 1 ao abrir o motor", price: 47, bikes: ["factor150"] },
  { id: "mangueira-comb-etanol", kind: "linha_comb", name: "Mangueira de combustível", brand: "Genérica", spec: "Compatível com álcool", price: 16, shopStock: 14 },
  { id: "filtro-comb-etanol", kind: "filtro_comb", name: "Filtro de combustível", brand: "Genérica", spec: "Compatível com álcool", price: 18.6, shopStock: 10 },
];

const BASE_CATALOG: Part[] = [
  // Motor
  { id: "cilindro-original", kind: "cilindro", name: "Cilindro 57,3 mm", brand: "Honda", spec: "Original · 162,7 cc", price: 0, factory: true },
  { id: "cilindro-4mm", kind: "cilindro", name: "Cilindro 61,3 mm (4 mm)", cc: 190, brand: "KMP", spec: "Ø 61,3 mm · 190 cc · par do pistão 61,3 mm pino 15 mm", price: 1490, bundle: { bico: "bico-170", cam: "ma66", pistao: "pistao-forjado", modulo: "modulo-remap", biela: "biela-txk-racing", vira: "vira-ww3", services: ["pino-2"] }, hpMul: 1.2, need: 0.15, stress: 15 },
  { id: "cilindro-4mm-pino", kind: "cilindro", name: "Conjunto 4MM · peças do kit", cc: 190, brand: "Genérico", spec: "Cilindro 4MM com pistão · biela reforçada · bico de maior vazão · Pegador · embreagem reforçada · virabrequim WW3 · ECU remapeada · usinagem do curso +2 mm no virabrequim inclusa na montagem · sem escapamento", price: 3490, bundle: { bico: "bico-170", cam: "ma66", pistao: "pistao-forjado", modulo: "modulo-remap", biela: "biela-txk-racing", vira: "vira-ww3", services: ["pino-2"] }, hpMul: 1.2, need: 0.15, stress: 15 },
  { id: "cilindro-205", kind: "cilindro", name: "Cilindro 205 cc", brand: "Power Racing", spec: "Cilindro Ø 64,5 · pistão · bico 190 lb · comando MB 6,3 · relação 14x46 · módulo Race PnP · vem cru, sem acerto", price: 4290, bundle: { bico: "bico-190", cam: "mb63", front: 14, rear: 46, modulo: "modulo-pnp-race" }, hpMul: 1.32, need: 0.26, stress: 30 },
  { id: "cilindro-220", kind: "cilindro", name: "Cilindro 220 cc · pistão forjado", brand: "Power Racing", spec: "Cilindro Ø 67,0 · pistão forjado · bico AV 240 lb · comando MA 6,6 · relação 14x48 · módulo Race PnP · vem cru, sem acerto", price: 6490, bundle: { bico: "bico-240", cam: "ma66", front: 14, rear: 48, modulo: "modulo-pnp-race" }, hpMul: 1.45, need: 0.36, stress: 50 },
  // Kit 70mm: peças avulsas (sem kit pronto). Efeitos hpMul/need/stress são estimativas de jogo; a cilindrada vem de Ø 70,0 × curso do modelo (ccOf).
  { id: "cilindro-70mm", kind: "cilindro", name: "Cilindro encamisado 70,0 mm", brand: "Aftermarket", spec: "70mm · camisa Ø ext. 74 mm · exige usinar a carcaça", price: 2190, hpMul: 1.42, need: 0.34, stress: 45 },
  { id: "pistao-70mm-p14", kind: "pistao", name: "Pistão 70,0 mm · pino 14 mm", brand: "Aftermarket", spec: "70mm · não forjado · travas e anéis inclusos · biela pino 14 mm: original Titan, Metal Leve STD, WW3 STD", price: 890, relief: 10, pinMm: 14, forjado: false },
  { id: "pistao-70mm-p15", kind: "pistao", name: "Pistão 70,0 mm · pino 15 mm", brand: "Zayma", spec: "70mm · não forjado · taxa 12:1 · 174 g · folga 0,04 mm · biela pino 15 mm: TXK, original Factor", price: 890, relief: 10, pinMm: 15, forjado: false, massG: 174, folgaMm: 0.04, taxa: 12, desc: "Kit Pistão e Anéis Taxado Modelo Zayima p/ CRF 230 para 260cc · 4,5 mm · 70 mm · pino 15. Este pistão pode ser usado com álcool, metanol e pode ser adicionado até 30% de nitrometano; caso queira usar gasolina pode torneá-lo reto, ele é projetado para isso. Produto novo. Marca: MF. Modelo: CRF 230. Refere-se: 01 pistão + 01 pino do pistão + 02 travas do pistão + 01 jogo de anéis. Taxa 12:1. Peso 174 gramas. Folga recomendada 0,04. Pode ser torneado reto: pino → borda 13,9 mm + 3 mm de domo; do centro do pino à borda 21,4 mm + 3 mm de cabeça. A primeira canaleta do anel tem 5 mm; distância do primeiro anel até a borda 5 mm, possibilitando usar pino de 2 mm sem flange torneando o pistão. Kit pistão e anéis taxado para CRF 230 na medida 70 mm; para uso na CRF é necessário encamisar, usinar bloco do motor e ajustes na alimentação. Produto de alta qualidade e fabricação nacional." },
  { id: "pistao-original", kind: "pistao", name: "Pistão 57,3 mm", brand: "Honda", spec: "Original", price: 0, factory: true },
  { id: "pistao-forjado", kind: "pistao", name: "Pistão 61,3 mm · pino 15 mm", brand: "Metal Leve", spec: "Forjado · 4 mm · biela pino 15 mm: TXK (par do kit 4MM)", price: 690, relief: 15, hpMul: 1.01, pinMm: 15 },
  { id: "pistao-hc", kind: "pistao", name: "Pistão alta compressão", brand: "Power Racing", spec: "Cabeça abaulada · Ø do pino sem ficha", price: 540, hpMul: 1.09, stress: 12 },
  { id: "pistao-cavas", kind: "pistao", name: "Pistão com cavas", brand: "Power Racing", spec: "Cavas de válvula · Ø do pino sem ficha", price: 480, cavas: true },
  { id: "pistao-aneis", kind: "pistao", name: "Jogo de Anéis Premium", brand: "RIK", spec: "Anel de fogo nitretado", price: 260, hpMul: 1.03, relief: 4 },
  { id: "bico-original", kind: "bico", name: "Bico injetor", brand: "Honda", spec: "Original", price: 0, factory: true, flow: 1 },
  { id: "bico-150", kind: "bico", name: "Bico 150 lb", brand: "Bosch", spec: "4 furos", price: 320, flow: 1.18 },
  { id: "bico-alta", kind: "bico", name: "Bico Alta Vazão 210 lb", brand: "Fueltech", spec: "12 furos", price: 590, flow: 1.4 },
  { id: "bico-135", kind: "bico", name: "Bico 135 lb", brand: "Magneti Marelli", spec: "6 furos", price: 240, flow: 1.08 },
  { id: "bico-170", kind: "bico", name: "Bico 170 lb", brand: "Bosch", spec: "Bosch", price: 390, flow: 1.26 },
  { id: "bico-190", kind: "bico", name: "Bico 190 lb", brand: "Denso", spec: "10 furos", price: 470, flow: 1.33 },
  { id: "bico-240", kind: "bico", name: "Bico AV 240 lb", brand: "Pro Racing", spec: "14 furos", price: 760, flow: 1.55 },
  { id: "bico-280", kind: "bico", name: "Bico AV 280 lb", brand: "Fueltech", spec: "16 furos · etanol", price: 940, flow: 1.7 },
  // Bomba de combustível: vazão multiplica a entrega dos bicos
  { id: "bomba-original", kind: "bomba", name: "Bomba de combustível", brand: "Honda", spec: "Original", price: 0, factory: true, flow: 1 },
  { id: "bomba-gauss-gm14017", kind: "bomba", name: "Gauss GM14017 AV", brand: "Gauss", spec: "40 L/h · 2 bar", price: 280, flow: 1.08 },

  // Escapamento (kg vs coletor + silencioso original de 6,8 kg)
  { id: "escape-original", kind: "escape", name: "Escapamento com catalisador", brand: "Honda", spec: "Original", price: 0, factory: true },
  { id: "escape-gemoto", kind: "escape", name: "Escape trioval", brand: "Gemoto", spec: "Ø 30 mm · 900 mm", price: 620, kg: -3.0, flow: 1.01 },
  { id: "escape-dore", kind: "escape", name: "Dore", brand: "Dore", spec: "Ponteira esportiva · aço inox", price: 1066.67, kg: -5.0 },
  { id: "escape-polimet-tork", kind: "escape", name: "Polimet Tork", brand: "Polimet", spec: "Média/baixa · Ø 27 mm · 1050 mm", price: 520, kg: -2.4 },
  { id: "escape-rua-viuva", kind: "escape", name: "Viúva", brand: "Viúva", spec: "Ø 30 mm · 880 mm", price: 420, kg: -3.2 },
  { id: "escape-rua-chiadeira", kind: "escape", name: "Chiadeira", brand: "Chiadeira", spec: "Ø 31 mm · 860 mm", price: 475, kg: -3.6 },
  { id: "escape-rua-ronco-grosso", kind: "escape", name: "Ronco Grosso", brand: "Ronco Grosso", spec: "Ø 29 mm · 960 mm", price: 530, kg: -2.8 },
  { id: "escape-rua-garrafinha", kind: "escape", name: "Garrafinha", brand: "Garrafinha", spec: "Ø 28 mm · 1000 mm", price: 585, kg: -2.9 },
  { id: "escape-rua-megafone", kind: "escape", name: "Megafone", brand: "Megafone", spec: "Ø 34 mm · 780 mm", price: 640, kg: -4.2 },
  { id: "escape-rua-cano-reto", kind: "escape", name: "Cano Reto", brand: "Cano Reto", spec: "Ø 36 mm · 740 mm", price: 695, kg: -5.2 },
  { id: "escape-rua-abelha", kind: "escape", name: "Abelha", brand: "Abelha", spec: "Ø 30 mm · 900 mm", price: 750, kg: -3.9 },
  { id: "escape-rua-trovaozinho", kind: "escape", name: "Trovãozinho", brand: "Trovãozinho", spec: "Ø 32 mm · 840 mm", price: 805, kg: -4.1 },
  { id: "escape-rua-bigode", kind: "escape", name: "Bigode", brand: "Bigode", spec: "Ø 27 mm · 1080 mm", price: 860, kg: -2.5 },
  { id: "escape-rua-serrote", kind: "escape", name: "Serrote", brand: "Serrote", spec: "Ø 33 mm · 800 mm", price: 915, kg: -4.4 },
  { id: "escape-rua-tubarao", kind: "escape", name: "Tubarão", brand: "Tubarão", spec: "Ø 35 mm · 770 mm", price: 970, kg: -4.5 },
  { id: "escape-rua-caneta", kind: "escape", name: "Caneta", brand: "Caneta", spec: "Ø 26 mm · 1120 mm", price: 1025, kg: -2.2 },
  { id: "escape-ks", kind: "escape", name: "Escape esportivo", brand: "KS Escapamentos", spec: "Ø 32 mm · 820 mm", price: 990, kg: -3.6, flow: 1.03, stress: 2 },
  { id: "escape-grs", kind: "escape", name: "Escape esportivo", brand: "GRS", spec: "Ø 35 mm · 760 mm · alta rotação", price: 1890, kg: -4.6, flow: 1.05, stress: 6 },

  { id: "kit-15-44", kind: "kit", name: "Kit Relação 15x44", brand: "Vaz", spec: "428H · 118 elos", price: 189.9, front: 15, rear: 44 },
  { id: "kit-14-44", kind: "kit", name: "Kit Relação 14x44", brand: "Vaz Racing", spec: "428H · 118 elos", price: 219.9, front: 14, rear: 44 },
  { id: "kit-14-46", kind: "kit", name: "Kit Relação 14x46", brand: "Riffel Top", spec: "428H · 120 elos", price: 249.9, front: 14, rear: 46 },
  { id: "kit-16-42", kind: "kit", name: "Kit Relação 16x42", brand: "Riffel Top", spec: "428H · 118 elos", price: 239.9, front: 16, rear: 42 },
  { id: "kit-arrancada-14-48", kind: "kit", name: "Kit Arrancada 14x48", brand: "Vaz Racing", spec: "428HD · 122 elos", price: 299.9, front: 14, rear: 48 },
  { id: "kit-final-17-38", kind: "kit", name: "Kit Final 17x38", brand: "DID", spec: "428HD · 116 elos", price: 349.9, front: 17, rear: 38 },
  { id: "kit-16-40", kind: "kit", name: "Kit Relação 16x40", brand: "DID", spec: "428HD · 116 elos", price: 329.9, front: 16, rear: 40 },
  { id: "kit-18-34", kind: "kit", name: "Kit Relação 18x34", brand: "DID", spec: "428HD · 114 elos", price: 339.9, front: 18, rear: 34 },
  pinhao(13, 39.9),
  pinhao(14, 39.9),
  pinhao(15, 39.9),
  pinhao(16, 42.9),
  pinhao(17, 44.9),
  pinhao(18, 46.9),
  coroa(34, 84.9),
  coroa(36, 89.9),
  coroa(38, 89.9),
  coroa(39, 89.9),
  coroa(40, 94.9),
  coroa(42, 94.9),
  coroa(43, 99.9),
  coroa(44, 99.9),
  coroa(46, 104.9),
  coroa(48, 109.9),

  // Módulo
  { id: "modulo-original", kind: "modulo", name: "ECU PGM-FI", brand: "Honda", spec: "Corte 9.000 rpm", price: 0, factory: true },
  { id: "modulo-remap", kind: "modulo", ign: "ecu", name: "Infinitum remapeado", brand: "Servitec", spec: "Mapa original remapeado", price: 390, rpm: 1500 },
  { id: "modulo-deslimitador", kind: "modulo", ign: "ecu", name: "Deslimitador DL-1", brand: "Rev Street", spec: "Só tira o limitador", price: 249.9, rpm: 1500 },
  { id: "modulo-pnp-race", kind: "modulo", ign: "ecu", name: "Race PnP", brand: "Rev Street", spec: "Corte livre + curva de ponto esportiva", price: 459.9, rpm: 1800, hpMul: 1.02 },
  { id: "modulo-infinitum", kind: "modulo", ign: "ecu", bikes: ["titan160", "factor150"], name: "Infinitum", brand: "Servitec", spec: "Servitec Rpm Ajustável", price: 654.9, rpm: 2500, revCfg: true },
  { id: "cdi-servitec-150", kind: "modulo", ign: "cdi", bikes: ["titan150"], noCut: true, name: "CDI esportivo", brand: "Servitec", spec: "Servitec + rpm", price: 289.9 },
  { id: "modulo-athlon", kind: "modulo", ign: "ecu", bikes: ["titan160", "factor150"], name: "Athlon M250", brand: "Athlon Racing", spec: "Athlon Racing programável", price: 1890, prog: true },

  // Bateria
  { id: "bateria-original", kind: "bateria", name: "Bateria 12V 5Ah", brand: "Honda", spec: "Chumbo-ácido", price: 0, factory: true, kg: 0 },
  { id: "bateria-motobatt", kind: "bateria", name: "Lithium Pro 12V", brand: "Motobatt", spec: "LiFePO4", price: 420, kg: -1.63 },
  { id: "bateria-skyrich", kind: "bateria", name: "HJTX5L-FP", brand: "Skyrich", spec: "LiFePO4", price: 510, kg: -1.57 },
  { id: "bateria-bsli", kind: "bateria", name: "BSLi-02", brand: "BS Battery", spec: "LiFePO4", price: 680, kg: -1.53 },
  { id: "bateria-moura", kind: "bateria", name: "MA5-D 12V 5Ah", brand: "Moura", spec: "Chumbo-ácido", price: 189, kg: 0 },
  { id: "bateria-yuasa", kind: "bateria", name: "YTX7L-BS 12V 6Ah", brand: "Yuasa", spec: "AGM", price: 265, kg: 0.45 },
  { id: "bateria-pioneiro", kind: "bateria", name: "MBR 7-BS 12V 7Ah", brand: "Pioneiro", spec: "Chumbo-ácido", price: 220, kg: 0.8 },

  // Suspensão
  { id: "susp-original", kind: "susp", name: "Garfo telescópico · amortecedor duplo", brand: "Honda", spec: "Original", price: 0, factory: true, kg: 0 },
  { id: "susp-molas-drag", kind: "susp", name: "Molas dianteiras rebaixadas", brand: "Drag Parts", spec: "Curso curto", price: 145, kg: -0.6 },
  { id: "susp-amort-alu", kind: "susp", name: "Amortecedores traseiros alumínio", brand: "Racing Line", spec: "Par", price: 380, kg: -1.8 },
  { id: "susp-kit-t6", kind: "susp", name: "Kit suspensão alumínio T6", brand: "Drag Parts", spec: "Completo", price: 560, kg: -2.4 },
  { id: "susp-cofap", kind: "susp", name: "Amortecedores dupla mola", brand: "Cofap", spec: "Reforçado", price: 210, kg: 0.9 },
  { id: "susp-nakata", kind: "susp", name: "Amortecedores carga", brand: "Nakata", spec: "Reforçado", price: 240, kg: 1.3 },
  { id: "susp-blindada", kind: "susp", name: "Kit suspensão trabalho pesado", brand: "Cofap", spec: "Completo", price: 320, kg: 2.1 },

  // Pneus
  // Pneus da loja: kg relativo ao Pirelli original (15 kg); aderência e durabilidade na escala 0–100 do jogador
  { id: "pneu-mandrakin", kind: "pneu", aero: 0.9, name: "Mandrakin", brand: "Mandrakin", spec: "Básico", price: 189.9, kg: -10, widthRatio: 0.8, crr: 1, grip: 0.35, life: 0.9, tLo: 50, tHi: 85, coldMul: 0.88 },
  { id: "pneu-semislick-sport", kind: "pneu", aero: 1.1, name: "Semi-slick", brand: "Semi-slick", spec: "Esportivo", price: 890, kg: 15, widthRatio: 1.2, crr: 1, grip: 0.6, life: 0.8, tLo: 50, tHi: 90, coldMul: 0.86 },
  { id: "pneu-slick-racing", kind: "pneu", aero: 1.15, name: "Slick racing", brand: "Slick", spec: "Alta performance", price: 1590, kg: 45, widthRatio: 1.4, crr: 1, grip: 0.7, life: 0.6, tLo: 60, tHi: 100, coldMul: 0.8 },
  { id: "pneu-slick-pro", kind: "pneu", aero: 1.2, name: "Slick pro", brand: "Slick", spec: "Competição", price: 2490, kg: 75, widthRatio: 1.6, crr: 1, grip: 1, life: 0.4, tLo: 70, tHi: 110, coldMul: 0.72 },
  { id: "pneu-original", kind: "pneu", aero: 1.05, name: "80/100-18 · 100/80-18", brand: "Pirelli", spec: "Original", price: 0, factory: true, kg: 0, crr: 1, grip: 0.5, tLo: 50, tHi: 85, coldMul: 0.88, life: 1 },
  { id: "pneu-levorin", kind: "pneu", name: "Matrix 2.75-18 · 2.75-18", brand: "Levorin", spec: "Diagonal", price: 299.9, kg: -1.1, crr: 0.92, grip: 0.94 },
  { id: "pneu-supercity", kind: "pneu", name: "Super City 2.50-18 · 2.75-18", brand: "Pirelli", spec: "Diagonal", price: 389.9, kg: -1.6, crr: 0.88, grip: 0.9 },

  // Ignição
  { id: "vela-original", kind: "vela", name: "CPR8EA-9", brand: "NGK", spec: "Níquel", price: 0, factory: true },
  { id: "vela-iridium", kind: "vela", name: "Iridium IX CPR8EAIX-9", brand: "NGK", spec: "Irídio Ø 0,6 mm", price: 89.9, hp: 0.1 },
  { id: "vela-brisk", kind: "vela", name: "Silver AR12ZS", brand: "Brisk", spec: "Prata", price: 119.9, hp: 0.12 },
  { id: "vela-racing", kind: "vela", name: "Racing R0045Q", brand: "NGK", spec: "Competição", price: 249.9, hp: 0.15 },
  { id: "cabo-original", kind: "cabo", name: "Cabo de vela", brand: "Honda", spec: "Original", price: 0, factory: true },
  { id: "cabo-ibooster", kind: "cabo", name: "F10 Silicone 8,8 mm", brand: "Ibooster", spec: "Capacitivo", price: 289.9, hp: 0.1 },
  { id: "cabo-nology", kind: "cabo", name: "HotWires 8,0 mm", brand: "Nology", spec: "Capacitivo · malha terra", price: 349.9, hp: 0.1 },
  { id: "cabo-marelli", kind: "cabo", name: "Racing 8,0 mm", brand: "Magneti Marelli", spec: "Baixa resistência", price: 119.9, hp: 0.05 },

  // Lubrificação
  { id: "oleo-original", kind: "oleo", name: "Mineral 10W-30 · 1 L", brand: "Honda", spec: "Mineral", price: 39.9, oilLife: 1000, hpMul: 1, consumable: true },
  { id: "oleo-mobil", kind: "oleo", name: "Super Moto 10W-30 · 1 L", brand: "Mobil", spec: "Semissintético", price: 49.9, oilLife: 2000, hpMul: 1.003, consumable: true },
  { id: "oleo-motul", kind: "oleo", name: "7100 10W-30 · 1 L", brand: "Motul", spec: "100% sintético", price: 79.9, oilLife: 3000, hpMul: 1.006, consumable: true },

  // Embreagem
  { id: "embreagem-original", kind: "embreagem", name: "Discos e molas", brand: "Honda", spec: "Original", price: 0, factory: true, clutchNm: 22 },
  { id: "embreagem-molas", kind: "embreagem", name: "Molas de embreagem reforçadas", brand: "EBC", spec: "Carga +20%", price: 220, clutchNm: 26 },
  { id: "embreagem-discos", kind: "embreagem", name: "Discos esportivos + mola", brand: "Aftermarket", spec: "Discos de fricção esportivos · mola reforçada", price: 480, clutchNm: 31, fix: { "Embreagem queimada": 10 } },
  { id: "embreagem-molas-barnett", kind: "embreagem", name: "Molas Barnett", brand: "Barnett", spec: "Carga +30%", price: 290, clutchNm: 28 },
  { id: "embreagem-discos-ebc", kind: "embreagem", name: "Discos EBC CK", brand: "EBC", spec: "Fibra aramida", price: 360, clutchNm: 28, fix: { "Embreagem queimada": 6 } },
  { id: "embreagem-kit-vesrah", kind: "embreagem", name: "Kit embreagem Street", brand: "Vesrah", spec: "Discos + molas + separadores", price: 790, clutchNm: 33, fix: { "Embreagem queimada": 14 } },
  // P21 do Grau: mola diafragma (prato Belleville) no lugar das 4 molas helicoidais. Força de aperto ~constante com o desgaste
  // (curva F×deflexão plana na região de trabalho) → capacidade T = n·μ·F·r_m ≈ 22 N·m × 1,55 (estimado). Mais massa de disco = mais J até vitrificar.
  { id: "embreagem-p21-grau", kind: "embreagem", name: "Embreagem p21 · discos + molas", brand: "Do Grau", spec: "p21 · mola diafragma", price: 690, clutchNm: 34, fix: { "Embreagem queimada": 16 } },
  // material da Oficina: consumido pelo serviço que prepara a embreagem montada (μ e aperto maiores)
  { id: "embreagem-esp-kit", kind: "embreagem", name: "Discos esportivos + mola", brand: "Aftermarket", spec: "Material para preparar a embreagem montada", price: 320, consumable: true },
  { id: "embreagem-campana", kind: "embreagem", name: "Kit embreagem competição", brand: "Barnett", spec: "Kevlar · campana usinada", price: 1330, clutchNm: 38, kg: -0.3, fix: { "Embreagem queimada": 20, "Câmbio espanado": 6 } },

  // Trem de válvulas
  { id: "molas-original", kind: "molas", name: "Molas de válvula", brand: "Honda", spec: "Original", price: 0, factory: true },
  { id: "molas-duplas", kind: "molas", name: "Molas duplas reforçadas", brand: "Kibbel", spec: "Dupla · pratos aço", price: 920, fix: { "Válvula atropelada": 25 } },
  { id: "molas-comp", kind: "molas", name: "Conjunto de molas de competição", brand: "Ferzza", spec: "Dimensionado na compra para o motor e o comando montados · projeto 12.000 rpm", price: 690, springRpm: 12000 },
  { id: "kit-valv-comp-cg125", kind: "molas", name: "Kit de válvulas esportivo · CG 125 Bolinha", brand: "Ferzza", spec: "Válvulas inox com haste aliviada (adm 27 mm · esc 22 mm), cabeça rebaixada 0,3 mm · molas de competição dimensionadas, projeto 12.000 rpm · pratos e travas de aço temperado · feito para o kit 4MM com preparação suportada", price: 1290, springRpm: 12000, valveMassMul: 0.82, valveRecessMm: 0.3, bikes: ["cg125"] },
  { id: "kit-valv-comp-ap-cg125", kind: "molas", name: "Kit de válvulas Alta performance · CG 125 Bolinha", brand: "Ferzza", spec: "Válvulas inox nitretadas (adm 27 mm · esc 22 mm), cabeça rebaixada 0,5 mm · molas reforçadas, projeto 13.000 rpm · pratos de titânio aliviados e travas reforçadas · para categorias 300 a 400cc", price: 1742, springRpm: 13000, valveMassMul: 0.76, valveRecessMm: 0.5, bikes: ["cg125"] },
  { id: "kit-valv-comp-pro-cg125", kind: "molas", name: "Kit de válvulas competição · CG 125 Bolinha", brand: "Ferzza", spec: "Válvulas de titânio (adm 27 mm · esc 22 mm), cabeça rebaixada 0,8 mm · molas duplas progressivas de alta carga, projeto 14.500 rpm · pratos e travas de titânio · para competição Força Livre", price: 2322, springRpm: 14500, valveMassMul: 0.7, valveRecessMm: 0.8, bikes: ["cg125"] },
  { id: "kit-valv-comp-titan150", kind: "molas", name: "Kit de válvulas esportivo · CG 150 Titan", brand: "Ferzza", spec: "Válvulas inox com haste aliviada (adm 30 mm · esc 25 mm), cabeça rebaixada 0,3 mm · molas de competição dimensionadas, projeto 12.000 rpm · pratos e travas de aço temperado · feito para o kit 4MM com preparação suportada", price: 1390, springRpm: 12000, valveMassMul: 0.82, valveRecessMm: 0.3, bikes: ["titan150"] },
  { id: "kit-valv-comp-ap-titan150", kind: "molas", name: "Kit de válvulas Alta performance · CG 150 Titan", brand: "Ferzza", spec: "Válvulas inox nitretadas (adm 30 mm · esc 25 mm), cabeça rebaixada 0,5 mm · molas reforçadas, projeto 13.000 rpm · pratos de titânio aliviados e travas reforçadas · para categorias 300 a 400cc", price: 1877, springRpm: 13000, valveMassMul: 0.76, valveRecessMm: 0.5, bikes: ["titan150"] },
  { id: "kit-valv-comp-pro-titan150", kind: "molas", name: "Kit de válvulas competição · CG 150 Titan", brand: "Ferzza", spec: "Válvulas de titânio (adm 30 mm · esc 25 mm), cabeça rebaixada 0,8 mm · molas duplas progressivas de alta carga, projeto 14.500 rpm · pratos e travas de titânio · para competição Força Livre", price: 2502, springRpm: 14500, valveMassMul: 0.7, valveRecessMm: 0.8, bikes: ["titan150"] },
  { id: "kit-valv-comp-titan160", kind: "molas", name: "Kit de válvulas esportivo · CG 160 Titan", brand: "Ferzza", spec: "Válvulas inox com haste aliviada (adm 30 mm · esc 25 mm), cabeça rebaixada 0,3 mm · molas de competição dimensionadas, projeto 12.000 rpm · pratos e travas de aço temperado · feito para o kit 4MM com preparação suportada", price: 1390, springRpm: 12000, valveMassMul: 0.82, valveRecessMm: 0.3, bikes: ["titan160"] },
  { id: "kit-valv-comp-ap-titan160", kind: "molas", name: "Kit de válvulas Alta performance · CG 160 Titan", brand: "Ferzza", spec: "Válvulas inox nitretadas (adm 30 mm · esc 25 mm), cabeça rebaixada 0,5 mm · molas reforçadas, projeto 13.000 rpm · pratos de titânio aliviados e travas reforçadas · para categorias 300 a 400cc", price: 1877, springRpm: 13000, valveMassMul: 0.76, valveRecessMm: 0.5, bikes: ["titan160"] },
  { id: "kit-valv-comp-pro-titan160", kind: "molas", name: "Kit de válvulas competição · CG 160 Titan", brand: "Ferzza", spec: "Válvulas de titânio (adm 30 mm · esc 25 mm), cabeça rebaixada 0,8 mm · molas duplas progressivas de alta carga, projeto 14.500 rpm · pratos e travas de titânio · para competição Força Livre", price: 2502, springRpm: 14500, valveMassMul: 0.7, valveRecessMm: 0.8, bikes: ["titan160"] },
  { id: "kit-valv-comp-factor150", kind: "molas", name: "Kit de válvulas esportivo · Factor 150", brand: "Ferzza", spec: "Válvulas inox com haste aliviada (adm 28 mm · esc 23,5 mm), cabeça rebaixada 0,3 mm · molas de competição dimensionadas, projeto 12.000 rpm · pratos e travas de aço temperado · feito para o kit 4MM com preparação suportada", price: 1390, springRpm: 12000, valveMassMul: 0.82, valveRecessMm: 0.3, bikes: ["factor150"] },
  { id: "kit-valv-comp-ap-factor150", kind: "molas", name: "Kit de válvulas Alta performance · Factor 150", brand: "Ferzza", spec: "Válvulas inox nitretadas (adm 28 mm · esc 23,5 mm), cabeça rebaixada 0,5 mm · molas reforçadas, projeto 13.000 rpm · pratos de titânio aliviados e travas reforçadas · para categorias 300 a 400cc", price: 1877, springRpm: 13000, valveMassMul: 0.76, valveRecessMm: 0.5, bikes: ["factor150"] },
  { id: "kit-valv-comp-pro-factor150", kind: "molas", name: "Kit de válvulas competição · Factor 150", brand: "Ferzza", spec: "Válvulas de titânio (adm 28 mm · esc 23,5 mm), cabeça rebaixada 0,8 mm · molas duplas progressivas de alta carga, projeto 14.500 rpm · pratos e travas de titânio · para competição Força Livre", price: 2502, springRpm: 14500, valveMassMul: 0.7, valveRecessMm: 0.8, bikes: ["factor150"] },
  { id: "molas-pratos", kind: "molas", name: "Molas duplas + pratos leves", brand: "Kibbel", spec: "Pratos titânio", price: 1460, hpMul: 1.01, fix: { "Válvula atropelada": 40 } },

  // Biela e virabrequim
  { id: "biela-original", kind: "biela", name: "Biela", brand: "Honda", spec: "Original", price: 0, factory: true },
  // TXK Racing ref. 1105130 / L08342: pino do pistão Ø 15 mm (competição); CG 160, Bros 160, XRE 190. Limite = 9500 + 15×160 = 11900 N (calibrado, sem ensaio)
  { id: "biela-txk-racing", kind: "biela", name: "TXK · pino 14 mm", brand: "TXK", spec: "Alta performance", price: 780, pinMm: 14, rodRpm: 10500 },
  { id: "biela-forjada", kind: "biela", name: "Biela forjada reforçada", brand: "Hot Rods", spec: "Aço 4340 · Ø do olhal sem ficha", price: 1950, fix: { "Biela quebrada": 25 } },
  { id: "biela-vira", kind: "biela", name: "Virabrequim balanceado + biela forjada", brand: "Hot Rods", spec: "Dinâmico · Ø do olhal sem ficha", price: 4300, hpMul: 1.015, fix: { "Biela quebrada": 40, "Motor fundiu": 10 } },

  // Virabrequim (slot próprio, independente da biela)
  { id: "vira-original", kind: "vira", name: "Virabrequim", brand: "Honda", spec: "Original", price: 0, factory: true },

  // Corpo de borboleta
  { id: "tbi-original", kind: "tbi", name: "Corpo de borboleta Ø 28 mm", brand: "Honda", spec: "Original", price: 0, factory: true },
  { id: "carb-strada", kind: "tbi", name: "Carburador Strada Ø 30 mm", brand: "Keihin", spec: "Da CBX 200 Strada · venturi maior (medida estimada) · pede giclê acertado", price: 420, need: 0.05, bikes: ["cg125", "titan150"] },
  { id: "bolha-esportiva", kind: "carenagem", name: "Bolha esportiva", brand: "Genérica", spec: "Desvia o vento do peito do piloto", price: 260, cdaMul: 0.85 },
  { id: "enxuta-racha", kind: "carenagem", name: "Moto enxuta de racha (sem bolha)", brand: "Oficina", spec: "Guidão baixo, pedaleira recuada, sem retrovisor/pisca/para-lama, rabeta fina · piloto colado no tanque", price: 340, cdaMul: 0.7 },
  { id: "carenagem-comp", kind: "carenagem", name: "Carenagem fechada de competição", brand: "Genérica", spec: "Bolha alta + laterais fechadas, piloto deitado", price: 980, cdaMul: 0.65 },
  { id: "tbi-32", kind: "tbi", name: "TBI Ø 32 mm", brand: "Power Racing", spec: "Alumínio usinado", price: 1380, need: 0.08 },
  { id: "tbi-36", kind: "tbi", name: "TBI Ø 36 mm", brand: "Power Racing", spec: "Alumínio usinado", price: 2380, need: 0.15, stress: 4 },

  // Rodas
  { id: "roda-original", kind: "roda", name: "Liga leve 18\"", brand: "Honda", spec: "Original", price: 0, factory: true, kg: 0 },
  { id: "roda-raiada", kind: "roda", name: "Aro raiado alumínio 18\"", brand: "Stedi", spec: "Raios inox", price: 890, kg: -1.4 },
  { id: "roda-liga", kind: "roda", name: "Liga leve forjada 18\"", brand: "Marchesini", spec: "Alumínio forjado", price: 1450, kg: -2.2 },

  // Pneus (composto)
  { id: "pneu-sport", kind: "pneu", name: "Sport Demon 80/100-18 · 110/80-18", brand: "Pirelli", spec: "Composto esportivo", price: 720, kg: 0.3, crr: 1.05, grip: 1.1, tLo: 40, tHi: 95, coldMul: 0.9 },
  { id: "pneu-dragradial", kind: "pneu", name: "Drag Radial 90/90-18 · 120/70-17", brand: "Mickey Thompson", spec: "Radial de arrancada", price: 1290, kg: 0.6, crr: 1.08, grip: 1.25, tLo: 55, tHi: 100, coldMul: 0.82 },
  { id: "pneu-slick", kind: "pneu", name: "Slick 90/90-18 · 130/70-17", brand: "Pirelli", spec: "Slick de arrancada", price: 1890, kg: 0.9, crr: 1.12, grip: 1.42, tLo: 70, tHi: 110, coldMul: 0.72 },

  // v6 expansion (efeitos e preços: estimativas de jogo)
  { id: "pistao-fundido-ref", kind: "pistao", name: "Pistão fundido reforçado", brand: "Metal Leve", spec: "Liga hipereutética · Ø do pino sem ficha", price: 780, relief: 8 },
  { id: "pistao-forjado-cavas", kind: "pistao", name: "Pistão forjado com cavas", brand: "Power Racing", spec: "Forjado 2618 · cavas · Ø do pino sem ficha", price: 1250, relief: 18, cavas: true, hpMul: 1.01 },
  { id: "escape-ponteira-abafada", kind: "escape", name: "Ponteira abafada", brand: "TR", spec: "Ø 28 mm · 940 mm", price: 450, kg: -2.6 },
  { id: "escape-inox-completo", kind: "escape", name: "Escape inox Extreme HP", brand: "GRS", spec: "Ø 33 mm · 800 mm", price: 1090, kg: -3.9, flow: 1.03, stress: 3 },
  { id: "susp-molas-prog", kind: "susp", name: "Molas dianteiras progressivas", brand: "Hyperpro", spec: "Progressiva", price: 590, kg: -0.3 },
  { id: "susp-amort-regulavel", kind: "susp", name: "Amortecedor traseiro regulável", brand: "YSS", spec: "Pré-carga e retorno", price: 1650, kg: -1.2 },
  { id: "susp-cartucho", kind: "susp", name: "Cartucho dianteiro preparado", brand: "Andreani", spec: "Cartucho", price: 1850, kg: -0.8 },
  { id: "modulo-datalogger", kind: "modulo", ign: "ecu", name: "ECU programável com datalogger", brand: "FuelTech", spec: "Programável · datalogger", price: 2950, prog: true },
  { id: "bateria-litio-compacta", kind: "bateria", name: "Lítio compacta 12V", brand: "Shido", spec: "LiFePO4", price: 1180, kg: -1.75 },
  // Reposição
  { id: "cabecote-std", kind: "cabecote", name: "Cabeçote", brand: "Honda", spec: "STD · 9,5:1", price: 690, consumable: true },
  { id: "comando-std", kind: "comando", name: "Comando de válvulas", brand: "Honda", spec: "STD", price: 320, consumable: true },
  // Comandos de competição (2 por faixa, levantes diferentes)
  { id: "comando-b55", kind: "comando", name: "Comando Bravo · Baixa", brand: "Fortuna", spec: "Adm 5,5 · Esc 5,2 mm", price: 390, cam: "b55", consumable: true },
  { id: "comando-b58", kind: "comando", name: "Comando Tranquilo · Baixa", brand: "Kawahara", spec: "Adm 5,8 · Esc 5,5 mm", price: 430, cam: "b58", consumable: true },
  { id: "comando-mb60", kind: "comando", name: "Comando Cruzadinho · Média baixa", brand: "Fortuna", spec: "Adm 6,0 · Esc 5,8 mm", price: 520, cam: "mb60", consumable: true },
  { id: "comando-mb63", kind: "comando", name: "Comando Rua Brava · Média baixa", brand: "JR Racing", spec: "Adm 6,3 · Esc 6,0 mm", price: 580, cam: "mb63", consumable: true },
  { id: "comando-ma66", kind: "comando", name: "Comando Pegador", brand: "Genérico", spec: "Levante adm 6,6 · esc 6,4 mm", price: 690, cam: "ma66", consumable: true },
  { id: "comando-ma69", kind: "comando", name: "Comando Furioso · Média alta", brand: "Fortuna Racing", spec: "Adm 6,9 · Esc 6,6 mm", price: 760, cam: "ma69", consumable: true },
  { id: "comando-a72", kind: "comando", name: "Comando Gritador · Alta", brand: "Morumbi Racing", spec: "Adm 7,2 · Esc 7,0 mm", price: 890, cam: "a72", consumable: true },
  // Comandos de rua universais: levante pequeno, ganho modesto
  { id: "comando-manso", kind: "comando", name: "Comando Manso", brand: "Baixa", spec: "Levante 5,0 mm", price: 260, cam: "manso", consumable: true },
  { id: "comando-padaria", kind: "comando", name: "Comando Padaria", brand: "Média baixa", spec: "Levante 5,2 mm", price: 300, cam: "padaria", consumable: true },
  { id: "comando-pegador-rua", kind: "comando", name: "Comando Pegador", brand: "Média alta", spec: "Levante 5,4 mm", price: 340, cam: "pegador", consumable: true },
  { id: "comando-bala-rua", kind: "comando", name: "Comando Bala", brand: "Alta", spec: "Levante 5,6 mm", price: 380, cam: "bala", consumable: true },
  // 3 grupos de rua (Baixa · Média baixa · Média alta · Alta), levante 5,8 a 8,0 mm
  { id: "comando-quebrada", kind: "comando", name: "Comando Quebrada", brand: "Baixa", spec: "Levante 5,8 mm", price: 320, cam: "quebrada", consumable: true },
  { id: "comando-corujao", kind: "comando", name: "Comando Corujão", brand: "Média baixa", spec: "Levante 6,0 mm", price: 356, cam: "corujao", consumable: true },
  { id: "comando-viela", kind: "comando", name: "Comando Viela", brand: "Média alta", spec: "Levante 6,2 mm", price: 392, cam: "viela", consumable: true },
  { id: "comando-rasante", kind: "comando", name: "Comando Rasante", brand: "Alta", spec: "Levante 6,4 mm", price: 428, cam: "rasante", consumable: true },
  { id: "comando-muquico", kind: "comando", name: "Comando Muquiço", brand: "Baixa", spec: "Levante 6,6 mm", price: 464, cam: "muquico", consumable: true },
  { id: "comando-zegrau", kind: "comando", name: "Comando Zé Grau", brand: "Média baixa", spec: "Levante 6,8 mm", price: 500, cam: "zegrau", consumable: true },
  { id: "comando-tapa", kind: "comando", name: "Comando Tapa", brand: "Média alta", spec: "Levante 7,0 mm", price: 536, cam: "tapa", consumable: true },
  { id: "comando-foguete", kind: "comando", name: "Comando Foguete", brand: "Alta", spec: "Levante 7,2 mm", price: 572, cam: "foguete", consumable: true },
  { id: "comando-trovao", kind: "comando", name: "Comando Trovão", brand: "Baixa", spec: "Levante 7,4 mm", price: 608, cam: "trovao", consumable: true },
  { id: "comando-chicote", kind: "comando", name: "Comando Chicote", brand: "Média baixa", spec: "Levante 7,6 mm", price: 644, cam: "chicote", consumable: true },
  { id: "comando-cospefogo", kind: "comando", name: "Comando Cospe Fogo", brand: "Média alta", spec: "Levante 7,8 mm", price: 680, cam: "cospefogo", consumable: true },
  { id: "comando-semfreio", kind: "comando", name: "Comando Sem Freio", brand: "Alta", spec: "Levante 8,0 mm", price: 716, cam: "semfreio", consumable: true },
  { id: "comando-a75", kind: "comando", name: "Comando Bala · Alta", brand: "Kawahara Racing", spec: "Adm 7,5 · Esc 7,2 mm", price: 990, cam: "a75", consumable: true },
  // Válvulas maiores (montagem na Oficina → Cabeçote e válvulas)
  { id: "valvula-31-26", kind: "valvula", name: "Válvulas 31/26 mm", brand: "KMP", spec: "Adm 31 · Esc 26 mm", price: 380 },
  { id: "valvula-32-27", kind: "valvula", name: "Válvulas 32/27 mm", brand: "Ferzza", spec: "Adm 32 · Esc 27 mm", price: 520 },
  { id: "valvula-33-28", kind: "valvula", name: "Válvulas 33/28 mm", brand: "Ferzza Extreme", spec: "Adm 33 · Esc 28 mm", price: 690 },
  // Reposição original Honda (preços: estimativas de jogo)
  { id: "kit-15-44-honda", kind: "kit", name: "Kit Relação 15x44", brand: "Honda", spec: "STD · 428 118 elos", price: 289.9, front: 15, rear: 44 },
  // Pistões 4MM sob medida: Ø original + 4,0 mm, pino da biela original de cada moto
  { id: "pistao-4mm-cg125", kind: "pistao", boreMm: 60.5, name: "Pistão KMP 4MM 60,5 mm · CG 125 Bolinha", brand: "KMP", spec: "Ø 56,5 + 4,0 = 60,5 mm · OHV · anéis RIK alta performance · pino 15 mm", price: 290, rings: "RIK", pinMm: 15, bikes: ["cg125"] },
  { id: "pistao-4mm-titan150", kind: "pistao", boreMm: 61.3, name: "Pistão KMP 4MM 61,3 mm · CG 150 Titan", brand: "KMP", spec: "Ø 57,3 + 4,0 = 61,3 mm · OHC · anéis RIK alta performance · pino 14 mm", price: 320, rings: "RIK", pinMm: 14, bikes: ["titan150"] },
  { id: "pistao-4mm-titan160", kind: "pistao", boreMm: 61.3, name: "Pistão KMP 4MM 61,3 mm · CG 160 Titan", brand: "KMP", spec: "Ø 57,3 + 4,0 = 61,3 mm · OHC · anéis RIK alta performance · pino 14 mm", price: 340, rings: "RIK", pinMm: 14, bikes: ["titan160"] },
  { id: "pistao-4mm-factor150", kind: "pistao", boreMm: 61.3, name: "Pistão KMP 4MM 61,3 mm · Factor 150", brand: "KMP", spec: "Ø 57,3 + 4,0 = 61,3 mm · SOHC · anéis RIK alta performance · pino 15 mm", price: 340, rings: "RIK", pinMm: 15, bikes: ["factor150"] },
  { id: "biela-ferzza", kind: "biela", name: "Ferzza · pino 15 mm", brand: "Ferzza", spec: "Biela Forjada de Competição · aço SAE 4340 perfil H · seção 121 mm² · 102,5 mm entre centros", price: 890, rodRpm: 13000, pinMm: 15 },
  { id: "biela-ferzza-14", kind: "biela", name: "Ferzza · pino 14 mm", brand: "Ferzza", spec: "Biela Forjada de Competição · aço SAE 4340 perfil H · seção 121 mm² · 102,5 mm entre centros", price: 890, rodRpm: 13000, pinMm: 14 },
  // Cilindros KMP Premium encamisados: Ø do pistão KMP 4MM da mesma moto. Camisa mais fina que a parede original → limite térmico (stress) proporcional ao ganho de área (D²/D0² − 1); sem hpMul: o ganho vem só da cilindrada.
  { id: "cilindro-4mm-cg125", kind: "cilindro", name: "Kmp Premium", brand: "KMP", spec: "Encamisado · Ø 60,5 mm · para pistão KMP 4MM\nMoto específica: CG 125 Bolinha", price: 690, bikes: ["cg125"], stress: Math.round(((60.5 / 56.5) ** 2 - 1) * 100) },
  { id: "cilindro-4mm-titan150", kind: "cilindro", name: "Kmp Premium", brand: "KMP", spec: "Encamisado · Ø 61,3 mm · para pistão KMP 4MM\nMoto específica: CG 150 Titan", price: 740, bikes: ["titan150"], stress: Math.round(((61.3 / 57.3) ** 2 - 1) * 100) },
  { id: "cilindro-4mm-titan160", kind: "cilindro", name: "Kmp Premium", brand: "KMP", spec: "Encamisado · Ø 61,3 mm · para pistão KMP 4MM\nMoto específica: CG 160 Titan", price: 760, bikes: ["titan160"], stress: Math.round(((61.3 / 57.3) ** 2 - 1) * 100) },
  { id: "cilindro-4mm-factor150", kind: "cilindro", name: "Kmp Premium", brand: "KMP", spec: "Encamisado · Ø 61,3 mm · para pistão KMP 4MM\nMoto específica: Factor 150", price: 760, bikes: ["factor150"], stress: Math.round(((61.3 / 57.3) ** 2 - 1) * 100) },
  { id: "pistao-std-honda", kind: "pistao", name: "Pistão 57,3 mm · pino 14 mm", brand: "Honda", spec: "Original · biela pino 14 mm", price: 210, pinMm: 14 },
  { id: "cilindro-std-honda", kind: "cilindro", name: "Cilindro 57,3 mm (STD)", brand: "Honda", spec: "STD", price: 690 },
  { id: "biela-std-honda", kind: "biela", name: "Biela STD · pino 14 mm", brand: "Honda", spec: "Biela STD pino 14 mm", price: 420, pinMm: 14 },
  // WW3 STD: mesma geometria da original (104,50 mm entre centros); sem reforço → limite 9500 N, igual à STD
  { id: "biela-ww3", kind: "biela", name: "WW3 · pino 15 mm", brand: "WW3", spec: "Alta performance", price: 390, pinMm: 15, rodRpm: 10500 },
  // WW3 CG 160 ref. 13000-KVS-J00: curso 63,0 mm (R = 31,5 mm), mesma massa da original → neutro na física
  { id: "vira-ww3", kind: "vira", name: "Virabrequim STD · curso 63,0 mm", brand: "WW3", spec: "STD", price: 690 },
  { id: "bico-std-honda", kind: "bico", name: "Bico injetor", brand: "Honda", spec: "STD", price: 260, flow: 1 },
  { id: "embreagem-std-honda", kind: "embreagem", name: "Discos de embreagem", brand: "Honda", spec: "STD", price: 180, clutchNm: 22 },
  { id: "vela-std-ngk", kind: "vela", name: "CPR8EA-9", brand: "NGK", spec: "NGK - Grau térmico 8", price: 32.9, bikes: ["titan160"], shopStock: 15 },
  ...CARB_AND_FUEL,
  { id: "bateria-std-honda", kind: "bateria", name: "Bateria 12V 5Ah", brand: "Honda", spec: "STD", price: 249, kg: 0 },
  { id: "pneu-std-pirelli", kind: "pneu", name: "80/100-18 · 100/80-18", brand: "Pirelli", spec: "STD", price: 459.9, kg: 0, crr: 1, grip: 1 },
];

/** Factory replacement parts sold per bike model (Loja → Motos → Peças da moto). */
export const MODEL_PARTS: Record<string, string[]> = {
  titan160: ["kit-15-44-honda", "pinhao-15", "coroa-44", "cabecote-std", "comando-std", "pistao-std-honda", "bico-std-honda", "embreagem-std-honda", "vela-std-ngk", "bateria-std-honda", "pneu-std-pirelli", "oleo-original"],
};

/** Shelf prices: +50% over street reference. */
export const PARTS_CATALOG: Part[] = BASE_CATALOG.map((p) => ({ ...p, price: Math.round(p.price * 1.5 * 10) / 10 }));

/** Parts on sale per kind in Moto Peças (kinds not listed sell everything). Released aos poucos. */
export const SHOP_ONLY: Partial<Record<PartKind, string[]>> = {
  escape: ["escape-rua-viuva", "escape-rua-chiadeira", "escape-rua-ronco-grosso", "escape-rua-garrafinha", "escape-rua-megafone", "escape-rua-cano-reto", "escape-rua-abelha", "escape-rua-trovaozinho", "escape-rua-bigode", "escape-rua-serrote", "escape-rua-tubarao", "escape-rua-caneta"],
};
export const inShop = (p: Part) => !p.factory && (SHOP_ONLY[p.kind]?.includes(p.id) ?? true);

let PART_MAP: Map<string, (typeof PARTS_CATALOG)[number]> | null = null;
export const partById = (id: string) => (PART_MAP ??= new Map(PARTS_CATALOG.map((p) => [p.id, p]))).get(id);
/** Factory component (never sold, never stored as a loose part); oil bottles are consumables, not pieces. */
export const isFactoryPiece = (id: string) => { const x = partById(id); return !!x?.factory && !x.consumable; };
export const slotPart = (id: string | undefined, slot: Slot) => partById(id ?? "") ?? partById(`${slot}-original`)!;
export const SLOT_LABEL: Record<Slot, string> = { cilindro: "Cilindro", modulo: "Módulo", bateria: "Bateria", susp: "Suspensão", pneu: "Pneus", vela: "Vela", cabo: "Cabo de vela", oleo: "Óleo", pistao: "Pistão", bico: "Bico injetor", escape: "Escapamento", embreagem: "Embreagem", molas: "Molas de válvula", biela: "Biela", vira: "Virabrequim", tbi: "Corpo de borboleta", roda: "Rodas", bomba: "Bomba de combustível" };
export const SLOTS: Slot[] = ["cilindro", "pistao", "biela", "vira", "molas", "tbi", "bico", "escape", "embreagem", "roda", "modulo", "bateria", "susp", "pneu", "vela", "cabo", "oleo", "bomba"];
export const STOCK_SLOTS: Record<Slot, string> = { modulo: "modulo-original", bateria: "bateria-original", susp: "susp-original", pneu: "pneu-original", vela: "vela-original", cabo: "cabo-original", oleo: "oleo-original", cilindro: "cilindro-original", pistao: "pistao-original", bico: "bico-original", escape: "escape-original", embreagem: "embreagem-original", molas: "molas-original", biela: "biela-original", vira: "vira-original", tbi: "tbi-original", roda: "roda-original", bomba: "bomba-original" };

/** Oficina services. Prices above street rates. */
export const TAXAS = [
  { taxa: 10.5, price: 1450 },
  { taxa: 11.5, price: 2100 },
  { taxa: 12.5, price: 2900 },
  { taxa: 13.5, price: 3800 },
];
export type Cam = "original" | "mb" | "ma" | "b55" | "b58" | "mb60" | "mb63" | "ma66" | "ma69" | "a72" | "a75" | "manso" | "padaria" | "pegador" | "bala" | "quebrada" | "corujao" | "viela" | "rasante" | "muquico" | "zegrau" | "tapa" | "foguete" | "trovao" | "chicote" | "cospefogo" | "semfreio";
export const CAM_LABEL: Record<Cam, string> = {
  original: "Original",
  mb: "Original retrabalhado · média-baixa",
  ma: "Original retrabalhado · média-alta",
  b55: "Bravo · Baixa · Adm 5,5 · Esc 5,2 mm",
  b58: "Tranquilo · Baixa · Adm 5,8 · Esc 5,5 mm",
  mb60: "Cruzadinho · Média baixa · Adm 6,0 · Esc 5,8 mm",
  mb63: "Rua Brava · Média baixa · Adm 6,3 · Esc 6,0 mm",
  ma66: "Pegador · Adm 6,6 · Esc 6,4 mm",
  ma69: "Furioso · Média alta · Adm 6,9 · Esc 6,6 mm",
  a72: "Gritador · Alta · Adm 7,2 · Esc 7,0 mm",
  a75: "Bala · Alta · Adm 7,5 · Esc 7,2 mm",
  manso: "Manso · Baixa · Levante 5,0 mm",
  padaria: "Padaria · Média baixa · Levante 5,2 mm",
  pegador: "Pegador · Média alta · Levante 5,4 mm",
  bala: "Bala · Alta · Levante 5,6 mm",
  quebrada: "Quebrada · Baixa · Levante 5,8 mm",
  corujao: "Corujão · Média baixa · Levante 6,0 mm",
  viela: "Viela · Média alta · Levante 6,2 mm",
  rasante: "Rasante · Alta · Levante 6,4 mm",
  muquico: "Muquiço · Baixa · Levante 6,6 mm",
  zegrau: "Zé Grau · Média baixa · Levante 6,8 mm",
  tapa: "Tapa · Média alta · Levante 7,0 mm",
  foguete: "Foguete · Alta · Levante 7,2 mm",
  trovao: "Trovão · Baixa · Levante 7,4 mm",
  chicote: "Chicote · Média baixa · Levante 7,6 mm",
  cospefogo: "Cospe Fogo · Média alta · Levante 7,8 mm",
  semfreio: "Sem Freio · Alta · Levante 8,0 mm",
};
/** Cam effect on the engine: power peak shift (rpm), power multiplier, valve-to-piston risk without cavas. */
export const CAM_FX: Record<Cam, { rpm: number; mul: number; risk: number }> = {
  original: { rpm: 0, mul: 1, risk: 0 },
  mb: { rpm: -500, mul: 1.015, risk: 0 },
  ma: { rpm: 600, mul: 1.035, risk: 10 },
  b55: { rpm: -700, mul: 1.02, risk: 0 },
  b58: { rpm: -500, mul: 1.03, risk: 0 },
  mb60: { rpm: -200, mul: 1.035, risk: 0 },
  mb63: { rpm: 0, mul: 1.045, risk: 4 },
  ma66: { rpm: 400, mul: 1.055, risk: 10 },
  ma69: { rpm: 700, mul: 1.065, risk: 14 },
  a72: { rpm: 1000, mul: 1.075, risk: 20 },
  a75: { rpm: 1300, mul: 1.085, risk: 26 },
  // universais de rua: ganhos menores que os comandos de preparação
  manso: { rpm: -400, mul: 1.008, risk: 0 },
  padaria: { rpm: -150, mul: 1.012, risk: 0 },
  pegador: { rpm: 200, mul: 1.016, risk: 2 },
  bala: { rpm: 450, mul: 1.018, risk: 5 },
  quebrada: { rpm: -600, mul: 1.0096, risk: 2 },
  corujao: { rpm: -200, mul: 1.013, risk: 6 },
  viela: { rpm: 300, mul: 1.0164, risk: 10 },
  rasante: { rpm: 700, mul: 1.0198, risk: 14 },
  muquico: { rpm: -450, mul: 1.0192, risk: 10 },
  zegrau: { rpm: -50, mul: 1.0226, risk: 14 },
  tapa: { rpm: 450, mul: 1.026, risk: 18 },
  foguete: { rpm: 850, mul: 1.0294, risk: 22 },
  trovao: { rpm: -300, mul: 1.0288, risk: 18 },
  chicote: { rpm: 100, mul: 1.0322, risk: 22 },
  cospefogo: { rpm: 600, mul: 1.0356, risk: 26 },
  semfreio: { rpm: 1000, mul: 1.039, risk: 30 },
};
export const CAM_SERVICES: { cam: Exclude<Cam, "original">; label: string; price: number }[] = [
  { cam: "mb", label: "Média-baixa", price: 1250 },
  { cam: "ma", label: "Média-alta", price: 1650 },
];
export const headLabel = (t: number) => (t === 9.5 ? "Original · 9,5:1" : `Original taxado · ${t.toLocaleString("pt-BR")}:1`);

/** Serviço da Oficina sobre a embreagem montada: discos esportivos (μ 0,30 → 0,345, +15%) + mola reforçada (aperto +10%) → T = n·μ·F·r_m × 1,265 (estimado). */
export const CLUTCH_SPORT = "emb-esportivo";
export const CLUTCH_SPORT_MUL = 1.15 * 1.1;
/** Capacidade de torque (N·m) da embreagem instalada, com a preparação esportiva. Fonte única para corrida, quebra e relatórios. */
export const clutchCapNm = (s: { slots: Partial<Record<Slot, string>>; services: string[] }) =>
  (slotPart(s.slots.embreagem, "embreagem").clutchNm ?? 22) * (s.services.includes(CLUTCH_SPORT) ? CLUTCH_SPORT_MUL : 1);
