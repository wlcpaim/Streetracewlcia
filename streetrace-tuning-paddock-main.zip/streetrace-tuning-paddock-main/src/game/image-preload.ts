// Share concurrent requests; only decoded images enter the successful cache.
const loaded = new Set<string>();
const pending = new Map<string, Promise<void>>();
// Mantém as imagens decodificadas vivas (o navegador não descarta) e já envia a textura à GPU.
const keep = new Map<string, HTMLImageElement>();
const MAX_KEEP = 160; // teto do cache: descarta as mais antigas fora do uso
const RETRIES = 2;

export const preloadStats = { requests: 0, hits: 0, decoded: 0, failures: 0, retries: 0, ms: 0 };

let warmCtx: CanvasRenderingContext2D | null | undefined;
function warmGpu(img: HTMLImageElement) {
  try {
    if (warmCtx === undefined) { const c = document.createElement("canvas"); c.width = c.height = 2; warmCtx = c.getContext("2d"); }
    warmCtx?.drawImage(img, 0, 0, 2, 2);
  } catch { /* sem canvas: segue só com decode */ }
}

function remember(url: string, img: HTMLImageElement) {
  keep.delete(url); keep.set(url, img);
  while (keep.size > MAX_KEEP) { const old = keep.keys().next().value as string; keep.delete(old); loaded.delete(old); }
}

export function isPreloaded(url: string) { return loaded.has(url); }

export function preloadImages(urls: readonly string[], onProgress?: (done: number, total: number) => void): Promise<void[]> {
  const list = [...new Set(urls)];
  let done = 0;
  const tick = () => { done++; onProgress?.(done, list.length); };
  onProgress?.(0, list.length);
  return Promise.all(list.map((url) => track(url).then(tick)));
}

/** Baixa em segundo plano (ociosidade), sem bloquear a cena atual; falhas são silenciosas. */
export function prefetchImages(urls: readonly string[]) {
  const todo = [...new Set(urls)].filter((u) => !loaded.has(u) && !pending.has(u));
  if (!todo.length || typeof window === "undefined") return;
  const idle = (window as unknown as { requestIdleCallback?: (cb: () => void) => void }).requestIdleCallback ?? ((cb: () => void) => setTimeout(cb, 300));
  let i = 0;
  const next = () => { if (i >= todo.length) return; const u = todo[i++]!; track(u).catch(() => {}).finally(() => idle(next)); };
  idle(next); idle(next);
}

function attempt(url: string): Promise<HTMLImageElement> {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    let finished = false;
    const finish = (error?: Error) => {
      if (finished) return;
      finished = true;
      clearTimeout(timeout);
      image.onload = image.onerror = null;
      if (error) reject(error); else resolve(image);
    };
    const timeout = setTimeout(() => finish(new Error("A imagem demorou para carregar.")), 15000);
    image.onerror = () => finish(new Error("Não foi possível carregar a imagem."));
    image.onload = () => {
      if (image.decode) image.decode().then(() => finish(), () => finish(new Error("Não foi possível preparar a imagem.")));
      else finish();
    };
    image.src = url;
  });
}

function track(url: string): Promise<void> {
  preloadStats.requests++;
  if (loaded.has(url)) { preloadStats.hits++; return Promise.resolve(); }
  const existing = pending.get(url);
  if (existing) { preloadStats.hits++; return existing; }
  const t0 = typeof performance !== "undefined" ? performance.now() : 0;
  const task = (async () => {
    let err: unknown;
    for (let k = 0; k <= RETRIES; k++) {
      try {
        if (k > 0) { preloadStats.retries++; await new Promise((r) => setTimeout(r, 400 * k)); }
        const img = await attempt(url);
        loaded.add(url); remember(url, img); warmGpu(img);
        preloadStats.decoded++;
        if (t0) preloadStats.ms += performance.now() - t0;
        return;
      } catch (e) { err = e; }
    }
    preloadStats.failures++;
    throw err;
  })().finally(() => pending.delete(url));
  pending.set(url, task);
  return task;
}
