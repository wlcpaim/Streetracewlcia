// Collateral damage of an engine failure: what else the break took with it.
// Deterministic per failure + odometer so the same break always reads the same laudo.

export type DamageState = "Quebrado" | "Danificado" | "Desgastado";
export interface Damage {
  part: string;
  state: DamageState;
  /** Remaining condition 0..1. */
  life: number;
  /** Replacement part cost (R$, estimativa de jogo). */
  cost: number;
}

type Spec = [part: string, state: DamageState, cost: number];

/** Failure families matched by keyword (cause labels come from physics.stress()). */
const FAMILIES: [RegExp, Spec[]][] = [
  [/biela/i, [["Biela", "Quebrado", 420], ["Virabrequim", "Quebrado", 980], ["Bronzinas", "Quebrado", 160], ["Pistão", "Quebrado", 260], ["Cilindro", "Quebrado", 540], ["Carcaça do motor", "Danificado", 1250], ["Óleo", "Desgastado", 0]]],
  [/travou/i, [["Pistão", "Quebrado", 260], ["Anéis", "Quebrado", 110], ["Cilindro", "Quebrado", 540], ["Biela", "Danificado", 420], ["Bronzinas", "Desgastado", 160], ["Óleo", "Desgastado", 0]]],
  [/anéis|aneis|anel/i, [["Anéis", "Quebrado", 110], ["Cilindro", "Danificado", 540], ["Pistão", "Danificado", 260], ["Óleo", "Desgastado", 0]]],
  [/trinca/i, [["Cilindro", "Quebrado", 540], ["Pistão", "Danificado", 260], ["Junta do cabeçote", "Danificado", 45], ["Anéis", "Desgastado", 110]]],
  [/derretido|pobre/i, [["Pistão", "Quebrado", 260], ["Vela", "Quebrado", 38], ["Válvula de escape", "Danificado", 140], ["Cilindro", "Danificado", 540], ["Anéis", "Danificado", 110], ["Óleo", "Desgastado", 0]]],
  [/furado/i, [["Pistão", "Quebrado", 260], ["Anéis", "Danificado", 110], ["Cilindro", "Danificado", 540], ["Vela", "Danificado", 38], ["Óleo", "Desgastado", 0]]],
  [/válvula|valvula/i, [["Válvulas", "Quebrado", 280], ["Pistão", "Danificado", 260], ["Guias de válvula", "Danificado", 120], ["Cabeçote", "Danificado", 890], ["Molas de válvula", "Desgastado", 90], ["Comando", "Desgastado", 380]]],
  [/cabe/i, [["Cabeçote", "Quebrado", 890], ["Junta do cabeçote", "Quebrado", 45], ["Válvulas", "Danificado", 280], ["Comando", "Desgastado", 380]]],
  [/câmbio|cambio/i, [["Engrenagens do câmbio", "Quebrado", 760], ["Garfos seletores", "Danificado", 210], ["Embreagem", "Desgastado", 230]]],
  [/embreagem/i, [["Discos de embreagem", "Quebrado", 230], ["Molas de embreagem", "Danificado", 60], ["Platô", "Desgastado", 180], ["Óleo", "Desgastado", 0]]],
];
const FALLBACK: Spec[] = [["Bronzinas", "Quebrado", 160], ["Virabrequim", "Danificado", 980], ["Biela", "Danificado", 420], ["Bomba de óleo", "Desgastado", 150], ["Óleo", "Desgastado", 0]];

const RANGE: Record<DamageState, [number, number]> = { Quebrado: [0, 0.12], Danificado: [0.25, 0.5], Desgastado: [0.55, 0.78] };

export function damageSpecs(cause: string): Spec[] {
  return FAMILIES.find(([re]) => re.test(cause))?.[1] ?? FALLBACK;
}

export function collateral(cause: string, km = 0): Damage[] {
  // sem sorteio: vida restante = centro da faixa do estado, menos o desgaste do odômetro (1% a cada 1000 km, CALIBRADO)
  return damageSpecs(cause).map(([part, state, cost]) => {
    const [a, b] = RANGE[state];
    const life = Math.max(a, (a + b) / 2 - Math.min(km, 20000) / 1000 * 0.01 * (b - a) / 0.2);
    return { part, state, life: Math.round(life * 100) / 100, cost };
  });
}

/** Parts the rebuild has to buy (broken or damaged pieces get replaced; worn ones are reused). */
export function partsBill(cause: string) {
  return damageSpecs(cause).reduce((n, [, st, c]) => n + (st === "Desgastado" ? 0 : c), 0);
}
