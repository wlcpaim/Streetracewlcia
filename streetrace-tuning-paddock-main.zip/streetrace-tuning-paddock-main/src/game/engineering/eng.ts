// ENG IA — laboratório de engenharia. Só recebe moto e peças APROVADAS NEXUS (autopecas ApRec), monta Setups de teste
// e roda o mesmo runTest() do /admin (physics.step + mechStep). Nunca altera o Setup do jogador, o registro NEXUS
// ou o catálogo. Classificação por regras explícitas (CRITERIOS), sem sorteio nem nota inventada.
import { cloudStore } from "@/game/cloud/cloud-store";
import { runTest } from "../admin-lab";
import { STOCK_SETUP, bikeModel, type Setup } from "../physics";
import { PARTS_CATALOG, partById, type Part } from "../parts";
import { approvedParts, readAp, setupFor, type ApRec } from "../autopecas/autopecas";
import { dealerListing, shopListing, type ShopEntry } from "../shop-catalog";

export const ENG_VERSION = "eng-ia/1.0.0";
export const DIST_M = 201;
export const KEY = "streetrace-eng-v1";

export type Status = "AGUARDANDO" | "PREPARANDO" | "EXECUTANDO" | "PAUSADO" | "CONCLUÍDO" | "INTERROMPIDO" | "ERRO" | "AGUARDANDO DADOS";
export type Classe = "PÉSSIMA" | "RUIM" | "BOA" | "EXCELENTE" | "PERFEITA";
export type Fase = "A" | "B" | "E" | "G";
export type Metricas = { finishS: number | null; t0_100: number | null; vmaxKmh: number; fuelL: number; stress: number; quebrou: string | null; hp: number };
export type Caso = { key: string; fase: Fase; partIds: string[]; status: "PENDENTE" | "OK" | "ERRO"; m?: Metricas; classe?: Classe; categorias?: Record<string, Classe> | undefined; justificativa?: string | undefined; repetivel?: boolean | undefined; erro?: string };
export type Descarte = { partIds: string[]; motivo: string };
export type Job = {
  id: string; bikeId: string; status: Status; criado: string; atualizado: string; heartbeat: number;
  snapshot: { partId: string; nexusAt: string | null; runId: string; hash: string }[];
  base: Metricas | null; casos: Caso[]; cursor: number; descartes: Descarte[]; log: string[];
};
export type Preset = { id: string; nome: string; bikeId: string; jobId: string; objetivo: string; partIds: string[]; m: Metricas; classe: Classe; categorias: Record<string, Classe>; justificativa: string; data: string; versao: string; repetivel: boolean };
export type Kit = { id: string; nome: string; bikeId: string; presetId: string; partIds: string[]; classe: Classe; publicado: boolean; criado: string; versao: string };
export type Relatorio = { id: string; jobId: string; bikeId: string; data: string; versao: number; texto: string; comprovado: boolean };
export type Audit = { at: string; acao: string; alvo: string; detalhe: string };
export type EngState = { jobs: Job[]; presets: Preset[]; kits: Kit[]; relatorios: Relatorio[]; audit: Audit[] };

const empty = (): EngState => ({ jobs: [], presets: [], kits: [], relatorios: [], audit: [] });
export const readEng = (): EngState => { if (typeof cloudStore === "undefined") return empty(); try { const v = JSON.parse(cloudStore.getItem(KEY) ?? "null"); return v && Array.isArray(v.jobs) ? { ...empty(), ...v } : empty(); } catch { return empty(); } };
export const saveEng = (s: EngState) => {
  try { cloudStore.setItem(KEY, JSON.stringify(s)); } catch { /* cheio */ }
  if (typeof window !== "undefined") { window.dispatchEvent(new Event("eng-change")); if (!import.meta.env["VITEST"]) void import("../cloud/save-sync").then((m) => m.pushLater("eng")).catch(() => {}); }
  return s;
};

export const BIKES = dealerListing().map((d) => ({ id: d.bikeId!, nome: d.nome, entryId: d.id }));
export const bikeApproved = (ap: ApRec[], bikeId: string) => ap.find((r) => r.partId === `moto-${bikeId}` && r.etapa === "APROVADA NEXUS") ?? null;
export const approvedBikes = (ap: ApRec[] = readAp()) => BIKES.filter((b) => bikeApproved(ap, b.id));

/** Peças aprovadas pelo NEXUS para a moto (exclui a própria moto). Só elas entram em testes oficiais. */
export function approvedFor(bikeId: string, ap: ApRec[] = readAp()): ApRec[] {
  return approvedParts(ap).filter((r) => r.bikeId === bikeId && !r.partId.startsWith("moto-"));
}

/** Cobertura do catálogo global: todas as peças do jogo (inclusive fora da loja) com status de validação. */
export type CatItem = { id: string; nome: string; kind: string; marca: string; naLoja: boolean; fabrica: boolean; status: string };
export function catalog(bikeId: string, ap: ApRec[] = readAp()): CatItem[] {
  const loja = new Set(shopListing().map((e) => e.id));
  return PARTS_CATALOG.map((p) => {
    const r = ap.filter((x) => x.partId === p.id && x.bikeId === bikeId).at(-1);
    return { id: p.id, nome: p.name, kind: p.kind, marca: p.brand, naLoja: loja.has(p.id), fabrica: !!p.factory, status: r?.etapa ?? "NÃO ENVIADA AO FUNIL" };
  });
}

const entryOf = (id: string): ShopEntry | null => { const p = partById(id); return p ? { id: p.id, grupo: "", nome: p.name, part: p } : null; };
/** Aplica a diferença que cada peça faz sobre o Setup de fábrica (mesma regra de autopecas.setupFor). */
export function buildSetup(partIds: string[]): Setup {
  const s: Setup = structuredClone(STOCK_SETUP);
  for (const id of partIds) {
    const e = entryOf(id); if (!e) continue;
    const d = setupFor(e);
    for (const k of Object.keys(d.slots) as (keyof Setup["slots"])[]) if (d.slots[k] !== STOCK_SETUP.slots[k]) (s.slots as Record<string, string>)[k] = d.slots[k];
    if (d.front !== STOCK_SETUP.front) s.front = d.front;
    if (d.rear !== STOCK_SETUP.rear) s.rear = d.rear;
    if (d.cam !== STOCK_SETUP.cam) s.cam = d.cam;
    if (d.blend) s.blend = d.blend;
  }
  return s;
}

/** Grupo físico ocupado por cada peça: duas peças no mesmo grupo não montam juntas. */
const groupOf = (p: Part): string[] => (p.kind === "kit" || p.bundle ? ["pinhao", "coroa", ...(p.bundle ? ["cilindro", "bico", "comando"] : [])] : [p.kind]);
export function incompat(ids: string[]): string | null {
  const used = new Map<string, string>();
  for (const id of ids) {
    const p = partById(id); if (!p) return `${id}: peça não existe no catálogo`;
    for (const g of groupOf(p)) { const o = used.get(g); if (o) return `${o} e ${id} ocupam o mesmo posto (${g})`; used.set(g, id); }
  }
  return null;
}

export function measure(bikeId: string, s: Setup): Metricas {
  const r = runTest(bikeModel(bikeId), s, DIST_M, { id: "eng", group: "eng", label: "eng", track: `${DIST_M} m` }, false);
  return { finishS: r.result.finishS, t0_100: r.result.t0_100, vmaxKmh: r.result.vmaxKmh, fuelL: r.result.fuelUsedL, stress: r.stress.value, quebrou: r.breakdown?.cause ?? (r.result.stalled ? "motor apagou" : null), hp: r.engine.hp };
}

export const CRITERIOS = [
  "PÉSSIMA: quebrou, apagou ou não terminou os " + DIST_M + " m.",
  "RUIM: terminou, mas tempo ≥ ao da moto original.",
  "BOA: tempo menor que o original, ganho < 1%.",
  "EXCELENTE: ganho ≥ 1% e carga mecânica (stress) ≤ original + 10.",
  "PERFEITA: EXCELENTE, carga ≤ original e repetição (fase G) com resultado idêntico.",
] as const;

const cat = (better: boolean, equal: boolean, gain: number): Classe => (equal ? "RUIM" : !better ? "PÉSSIMA" : gain >= 1 ? "EXCELENTE" : "BOA");
export function classify(m: Metricas, b: Metricas, repetivel = false): { classe: Classe; categorias: Record<string, Classe>; justificativa: string } {
  const pct = (x: number, y: number) => ((y - x) / y) * 100;
  const categorias: Record<string, Classe> = {
    "Aceleração": m.finishS == null || b.finishS == null ? "PÉSSIMA" : cat(m.finishS < b.finishS, m.finishS === b.finishS, pct(m.finishS, b.finishS)),
    "Velocidade": cat(m.vmaxKmh > b.vmaxKmh, m.vmaxKmh === b.vmaxKmh, -pct(m.vmaxKmh, b.vmaxKmh)),
    "Consumo": cat(m.fuelL < b.fuelL, m.fuelL === b.fuelL, pct(m.fuelL, b.fuelL)),
    "Segurança": cat(m.stress < b.stress, m.stress === b.stress, b.stress ? pct(m.stress, b.stress) : 0),
  };
  if (m.quebrou || m.finishS == null || b.finishS == null) return { classe: "PÉSSIMA", categorias, justificativa: `Falhou: ${m.quebrou ?? "não terminou"}.` };
  const g = pct(m.finishS, b.finishS);
  const txt = `Tempo ${m.finishS.toFixed(3)} s vs ${b.finishS.toFixed(3)} s (ganho ${g.toFixed(2)}%), stress ${m.stress.toFixed(1)} vs ${b.stress.toFixed(1)}.`;
  if (g <= 0) return { classe: "RUIM", categorias, justificativa: txt };
  if (g < 1) return { classe: "BOA", categorias, justificativa: txt };
  if (m.stress > b.stress + 10) return { classe: "BOA", categorias, justificativa: txt + " Carga acima do limite da EXCELENTE." };
  if (repetivel && m.stress <= b.stress) return { classe: "PERFEITA", categorias, justificativa: txt + " Repetição idêntica confirmada." };
  return { classe: "EXCELENTE", categorias, justificativa: txt };
}

const RANK: Record<Classe, number> = { "PERFEITA": 4, "EXCELENTE": 3, "BOA": 2, "RUIM": 1, "PÉSSIMA": 0 };
export const byBest = (a: { classe: Classe; m: Metricas }, b: { classe: Classe; m: Metricas }) => RANK[b.classe] - RANK[a.classe] || (a.m.finishS ?? 1e9) - (b.m.finishS ?? 1e9) || a.m.stress - b.m.stress;
const ck = (ids: string[]) => [...ids].sort().join("+") || "original";

/** Prepara a execução: snapshot das aprovações + plano das fases A (individual) e B (pares). */
export function prepare(bikeId: string, at: string, ap: ApRec[] = readAp()): Job {
  const id = `ENG-${bikeId}-${at.replace(/\D/g, "").slice(0, 14)}`;
  const job: Job = { id, bikeId, status: "PREPARANDO", criado: at, atualizado: at, heartbeat: 0, snapshot: [], base: null, casos: [], cursor: 0, descartes: [], log: [] };
  if (!bikeApproved(ap, bikeId)) return { ...job, status: "AGUARDANDO DADOS", log: ["Moto não aprovada pelo NEXUS."] };
  const recs = approvedFor(bikeId, ap).filter((r) => partById(r.partId));
  const ids = [...new Set(recs.map((r) => r.partId))].filter((x) => !partById(x)?.factory);
  job.snapshot = recs.map((r) => ({ partId: r.partId, nexusAt: r.nexus?.at ?? null, runId: r.runId, hash: r.hash }));
  if (!ids.length) return { ...job, status: "AGUARDANDO DADOS", log: ["Nenhuma peça não-original aprovada pelo NEXUS para esta moto."] };
  for (const p of ids) job.casos.push({ key: ck([p]), fase: "A", partIds: [p], status: "PENDENTE" });
  for (let i = 0; i < ids.length; i++) for (let j = i + 1; j < ids.length; j++) {
    const pair = [ids[i]!, ids[j]!]; const why = incompat(pair);
    if (why) job.descartes.push({ partIds: pair, motivo: why }); else job.casos.push({ key: ck(pair), fase: "B", partIds: pair, status: "PENDENTE" });
  }
  job.log.push(`${at} · plano: ${ids.length} peças aprovadas, ${job.casos.length} casos, ${job.descartes.length} descartadas.`);
  return { ...job, status: "AGUARDANDO" };
}

/** Executa até n casos reais. Ao fim das fases A/B planeja E (melhor por posto) e G (repetição do top 3). */
export function runBatch(job: Job, n: number, at: string): Job {
  const j: Job = structuredClone(job);
  j.status = "EXECUTANDO"; j.atualizado = at; j.heartbeat = Date.now();
  if (!j.base) { j.base = measure(j.bikeId, structuredClone(STOCK_SETUP)); j.log.push(`${at} · referência original medida: ${j.base.finishS?.toFixed(3)} s.`); }
  const cache = new Map(j.casos.filter((c) => c.status === "OK" && c.fase !== "G").map((c) => [c.key, c]));
  for (let k = 0; k < n && j.cursor < j.casos.length; k++, j.cursor++) {
    const c = j.casos[j.cursor]!;
    try {
      const prev = c.fase === "G" ? null : cache.get(c.key);
      if (prev?.m && prev !== c) { Object.assign(c, { m: prev.m, classe: prev.classe, categorias: prev.categorias, justificativa: prev.justificativa + " (cache)", status: "OK" }); continue; }
      c.m = measure(j.bikeId, buildSetup(c.partIds));
      if (c.fase === "G") {
        const orig = j.casos.find((x) => x.key === c.key && x.fase !== "G");
        c.repetivel = !!orig?.m && JSON.stringify(orig.m) === JSON.stringify(c.m);
      }
      Object.assign(c, classify(c.m, j.base!, c.repetivel), { status: "OK" });
      cache.set(c.key, c);
    } catch (e) { c.status = "ERRO"; c.erro = String(e); j.log.push(`${at} · erro em ${c.key}: ${c.erro}`); }
  }
  if (j.cursor >= j.casos.length) {
    const has = (f: Fase) => j.casos.some((c) => c.fase === f);
    const ok = j.casos.filter((c) => c.status === "OK" && c.m && c.classe);
    if (!has("E")) {
      const best = new Map<string, Caso>();
      for (const c of ok.filter((x) => x.fase === "A" && RANK[x.classe!] >= 2)) {
        const g = groupOf(partById(c.partIds[0]!)!).join(","); const o = best.get(g);
        if (!o || byBest({ classe: c.classe!, m: c.m! }, { classe: o.classe!, m: o.m! }) < 0) best.set(g, c);
      }
      const ids = [...best.values()].map((c) => c.partIds[0]!);
      if (ids.length >= 2 && !incompat(ids)) { j.casos.push({ key: ck(ids), fase: "E", partIds: ids, status: "PENDENTE" }); return j; }
    }
    if (!has("G")) {
      const top = ok.filter((c) => RANK[c.classe!] >= 3).sort((a, b) => byBest({ classe: a.classe!, m: a.m! }, { classe: b.classe!, m: b.m! })).slice(0, 3);
      if (top.length) { for (const t of top) j.casos.push({ key: t.key, fase: "G", partIds: t.partIds, status: "PENDENTE" }); return j; }
    }
    j.status = "CONCLUÍDO"; j.log.push(`${at} · concluído: ${j.casos.length} casos executados.`);
  }
  return j;
}

/** Execução que ficou EXECUTANDO sem batimento (aba fechada) vira INTERROMPIDO e pode ser retomada. */
export const markStale = (s: EngState, now = Date.now()): EngState => ({ ...s, jobs: s.jobs.map((j) => (j.status === "EXECUTANDO" && now - j.heartbeat > 5000 ? { ...j, status: "INTERROMPIDO" as Status, log: [...j.log, "interrompido: sem batimento"] } : j)) });

const nomeDe = (ids: string[]) => ids.map((i) => partById(i)?.name ?? i).join(" + ") || "Original";
/** Ao concluir: presets (todos, sem apagar anteriores), relatório versionado e kits das melhores configurações. */
export function finalize(s: EngState, job: Job, at: string): EngState {
  const out: EngState = structuredClone(s);
  const bike = BIKES.find((b) => b.id === job.bikeId)?.nome ?? job.bikeId;
  const finals = new Map<string, Caso>();
  for (const c of job.casos) if (c.status === "OK" && c.m && c.classe && c.fase !== "G") finals.set(c.key, c);
  for (const g of job.casos) if (g.fase === "G" && g.status === "OK" && g.classe) { const o = finals.get(g.key); if (o) finals.set(g.key, { ...o, classe: g.classe, categorias: g.categorias, justificativa: g.justificativa, repetivel: g.repetivel }); }
  let n = out.presets.filter((p) => p.bikeId === job.bikeId).length;
  const novos: Preset[] = [...finals.values()].map((c) => ({ id: `${job.id}-${c.key}`, nome: `${bike.replace(/\s+/g, "")}-${c.fase === "E" ? "Completo" : c.partIds.length > 1 ? "Combo" : "Peca"}-${String(++n).padStart(2, "0")}`, bikeId: job.bikeId, jobId: job.id, objetivo: `Arrancada ${DIST_M} m`, partIds: c.partIds, m: c.m!, classe: c.classe!, categorias: c.categorias!, justificativa: c.justificativa!, data: at, versao: ENG_VERSION, repetivel: !!c.repetivel }));
  out.presets.push(...novos.filter((p) => !out.presets.some((x) => x.id === p.id)));
  for (const p of novos.filter((x) => RANK[x.classe] >= 3).sort(byBest).slice(0, 3)) {
    const id = `KIT-${p.id}`;
    if (!out.kits.some((k) => k.id === id)) out.kits.push({ id, nome: `Kit ${bike} · ${nomeDe(p.partIds)}`, bikeId: p.bikeId, presetId: p.id, partIds: p.partIds, classe: p.classe, publicado: false, criado: at, versao: ENG_VERSION });
  }
  const versao = out.relatorios.filter((r) => r.bikeId === job.bikeId).length + 1;
  const linhas = [
    `ENGENHARIA / RESULTADOS — ${bike} · ${job.id} · v${versao} · ${ENG_VERSION}`,
    `Objetivo: menor tempo em ${DIST_M} m sem violar a carga mecânica.`,
    `Motor de cálculo: admin-lab.runTest → physics.step + mechlimits.mechStep (determinístico).`,
    `Referência original: ${job.base?.finishS?.toFixed(3)} s · ${job.base?.vmaxKmh.toFixed(1)} km/h · stress ${job.base?.stress.toFixed(1)}`,
    `Peças aprovadas NEXUS (snapshot): ${job.snapshot.map((x) => `${x.partId}@${x.hash.slice(0, 8)}`).join(", ")}`,
    `Critérios: ${CRITERIOS.join(" | ")}`, "",
    ...novos.sort(byBest).map((p) => `[${p.classe}] ${nomeDe(p.partIds)} — ${p.justificativa}`), "",
    `Descartadas (${job.descartes.length}): ${job.descartes.map((d) => d.motivo).join("; ") || "nenhuma"}`,
    "Limitações: simulação coerente com o modelo do jogo, não é validação experimental.",
  ];
  out.relatorios.push({ id: `REL-${job.id}`, jobId: job.id, bikeId: job.bikeId, data: at, versao, texto: linhas.join("\n"), comprovado: false });
  out.audit.push({ at, acao: "FINALIZAR", alvo: job.id, detalhe: `${novos.length} presets, relatório v${versao}` });
  return out;
}

/** Publica/remove kit da loja. Verifica existência, compatibilidade, peças e classificação. */
export function setPublished(s: EngState, kitId: string, pub: boolean, at: string): { s: EngState; erro: string | null } {
  const k = s.kits.find((x) => x.id === kitId);
  if (!k) return { s, erro: "Kit não existe." };
  if (pub) {
    const why = incompat(k.partIds); if (why) return { s, erro: why };
    if (RANK[k.classe] < 3) return { s, erro: "Classificação abaixo de EXCELENTE." };
    const ap = approvedFor(k.bikeId).map((r) => r.partId);
    const falta = k.partIds.filter((i) => !ap.includes(i)); if (falta.length) return { s, erro: `Peças sem aprovação NEXUS: ${falta.join(", ")}` };
  }
  return { erro: null, s: { ...s, kits: s.kits.map((x) => (x.id === kitId ? { ...x, publicado: pub } : x)), audit: [...s.audit, { at, acao: pub ? "PUBLICAR_LOJA" : "REMOVER_LOJA", alvo: kitId, detalhe: k.partIds.join(",") }] } };
}

export const publishedKits = (s: EngState = readEng()) => s.kits.filter((k) => k.publicado);
export { nomeDe };
