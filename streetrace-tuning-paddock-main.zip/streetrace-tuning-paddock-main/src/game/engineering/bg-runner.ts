// ENG IA em segundo plano: um único laço global (montado na raiz) avança qualquer execução EXECUTANDO ou
// INTERROMPIDO em fatias pequenas, cedendo o navegador entre fatias para não travar o jogo nem a corrida.
// Usa exatamente runBatch/finalize de eng.ts — mesma física, mesmo resultado que rodar com a página aberta.
import { finalize, readEng, runBatch, saveEng } from "./eng";

export const BG_BATCH = 1;
let started = false;
let busy = false;

export function tickOnce(at = new Date().toISOString()): boolean {
  const s = readEng();
  const j = s.jobs.find((x) => x.status === "EXECUTANDO" || x.status === "INTERROMPIDO");
  if (!j) return false;
  const nj = runBatch(j, BG_BATCH, at);
  let ns = { ...s, jobs: s.jobs.map((x) => (x.id === nj.id ? nj : x)) };
  if (nj.status === "CONCLUÍDO") ns = finalize(ns, nj, at);
  saveEng(ns);
  return true;
}

export const engProgress = () => {
  const s = readEng(); const j = s.jobs.find((x) => x.status === "EXECUTANDO" || x.status === "INTERROMPIDO");
  return j ? { id: j.id, done: j.cursor, total: j.casos.length } : null;
};

export function startEngBackground() {
  if (started || typeof window === "undefined") return; started = true;
  const loop = () => {
    if (!busy) {
      busy = true;
      let worked = false;
      try { worked = tickOnce(); } catch (e) { console.error("ENG IA:", e); }
      busy = false;
      setTimeout(loop, worked ? 120 : 2000);
    }
  };
  setTimeout(loop, 1500);
}
