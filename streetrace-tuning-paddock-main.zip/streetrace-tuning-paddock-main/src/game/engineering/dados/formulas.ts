// ENGENHARIA DE DADOS — biblioteca de fórmulas com recálculo INDEPENDENTE e análise dimensional.
// Nada aqui importa a física do jogo: cada função é reescrita a partir da equação para servir de conferência.
export type Dim = [number, number, number, number]; // [M, L, T, Θ]
export const D = {
  um: [0, 0, 0, 0] as Dim, m: [0, 1, 0, 0] as Dim, m2: [0, 2, 0, 0] as Dim, m3: [0, 3, 0, 0] as Dim, kg: [1, 0, 0, 0] as Dim,
  s: [0, 0, 1, 0] as Dim, hz: [0, 0, -1, 0] as Dim, ms: [0, 1, -1, 0] as Dim, ms2: [0, 1, -2, 0] as Dim, N: [1, 1, -2, 0] as Dim,
  Nm: [1, 2, -2, 0] as Dim, W: [1, 2, -3, 0] as Dim, Pa: [1, -1, -2, 0] as Dim, kgm3: [1, -3, 0, 0] as Dim, kgs: [1, 0, -1, 0] as Dim, m3s: [0, 3, -1, 0] as Dim,
};
export const mul = (...ds: Dim[]): Dim => ds.reduce((a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2], a[3] + b[3]] as Dim, D.um);
export const inv = (d: Dim): Dim => [-d[0], -d[1], -d[2], -d[3]];
export const pow = (d: Dim, n: number): Dim => [d[0] * n, d[1] * n, d[2] * n, d[3] * n];
export const sameDim = (a: Dim, b: Dim) => a.every((x, i) => Math.abs(x - b[i]!) < 1e-9);
export const dimTxt = (d: Dim) => (["kg", "m", "s", "K"].map((u, i) => (d[i] ? `${u}${d[i] === 1 ? "" : "^" + d[i]}` : "")).filter(Boolean).join("·") || "adimensional");

export type Var = { sym: string; nome: string; si: string; dim: Dim };
export type Formula = {
  id: string; nome: string; eq: string; vars: Var[]; saida: Var; hipoteses: string[]; limites: string[];
  codigo: string[]; mecanicas: string[]; componentes: string[];
  /** Dimensão produzida pelas operações (deve bater com saida.dim). */
  dimOps: Dim;
  calc: (x: Record<string, number>) => number;
};
const v = (sym: string, nome: string, si: string, dim: Dim): Var => ({ sym, nome, si, dim });

export const FORMULAS: Formula[] = [
  { id: "vd", nome: "Cilindrada (volume deslocado)", eq: "Vd = (π/4) × D² × S", vars: [v("D", "diâmetro do cilindro", "m", D.m), v("S", "curso", "m", D.m)], saida: v("Vd", "volume deslocado", "m³", D.m3),
    hipoteses: ["cilindro reto", "curso = 2 × raio da manivela"], limites: ["um cilindro"], codigo: ["src/game/physics.ts › ccOf (lê cc do kit)", "src/game/enginephys.ts › geoOf (deriva D de cc e S)"], mecanicas: ["Cilindrada", "Compressão", "Torque"], componentes: ["cilindro", "pistao", "vira"],
    dimOps: mul(pow(D.m, 2), D.m), calc: (x) => (Math.PI / 4) * x["D"]! ** 2 * x["S"]! },
  { id: "omega", nome: "Velocidade angular", eq: "ω = 2π × n / 60", vars: [v("n", "rotação", "rpm (1/min)", D.hz)], saida: v("ω", "velocidade angular", "rad/s", D.hz),
    hipoteses: ["rotação constante no instante"], limites: [], codigo: ["src/game/enginephys.ts › omegaOf"], mecanicas: ["Rotação", "Potência"], componentes: ["vira"], dimOps: D.hz, calc: (x) => (2 * Math.PI * x["n"]!) / 60 },
  { id: "potencia", nome: "Potência", eq: "P = T × ω", vars: [v("T", "torque", "N·m", D.Nm), v("ω", "velocidade angular", "rad/s", D.hz)], saida: v("P", "potência", "W", D.W),
    hipoteses: ["eixo rígido"], limites: [], codigo: ["src/game/enginephys.ts › T=P/ω", "src/game/physics.ts › stats"], mecanicas: ["Torque", "Potência"], componentes: ["vira", "embreagem"], dimOps: mul(D.Nm, D.hz), calc: (x) => x["T"]! * x["ω"]! },
  { id: "vpm", nome: "Velocidade média do pistão", eq: "Vp = 2 × S × n / 60", vars: [v("S", "curso", "m", D.m), v("n", "rotação", "1/min", D.hz)], saida: v("Vp", "velocidade média", "m/s", D.ms),
    hipoteses: ["média sobre uma volta"], limites: ["referência usual de projeto < 20 m/s"], codigo: ["(não calculada pelo jogo — conferência própria)"], mecanicas: ["Cinemática do pistão"], componentes: ["pistao", "vira", "biela"], dimOps: mul(D.m, D.hz), calc: (x) => (2 * x["S"]! * x["n"]!) / 60 },
  { id: "lambda-biela", nome: "Razão manivela/biela e ângulo máximo", eq: "λ = r / L ; β_max = asin(λ)", vars: [v("r", "raio da manivela = S/2", "m", D.m), v("L", "biela centro a centro", "m", D.m)], saida: v("λ", "razão", "—", D.um),
    hipoteses: ["biela rígida"], limites: ["λ < 0,35 em motores de rua"], codigo: ["src/game/enginephys.ts › pistonX / pistonAcc (k = rM/lM)"], mecanicas: ["Cinemática do pistão", "Esforços mecânicos"], componentes: ["biela", "vira"], dimOps: mul(D.m, inv(D.m)), calc: (x) => x["r"]! / x["L"]! },
  { id: "acel-pms", nome: "Aceleração do pistão no PMS", eq: "a = r × ω² × (1 + λ)", vars: [v("r", "raio da manivela", "m", D.m), v("ω", "velocidade angular", "rad/s", D.hz), v("λ", "r/L", "—", D.um)], saida: v("a", "aceleração", "m/s²", D.ms2),
    hipoteses: ["série de 2ª ordem"], limites: [], codigo: ["src/game/enginephys.ts › pistonAcc"], mecanicas: ["Cinemática do pistão", "Esforços mecânicos"], componentes: ["pistao", "biela"], dimOps: mul(D.m, pow(D.hz, 2)), calc: (x) => x["r"]! * x["ω"]! ** 2 * (1 + x["λ"]!) },
  { id: "forca-inercia", nome: "Força de inércia alternativa", eq: "F = m × a", vars: [v("m", "massa alternativa", "kg", D.kg), v("a", "aceleração", "m/s²", D.ms2)], saida: v("F", "força", "N", D.N),
    hipoteses: ["massa concentrada no pino"], limites: [], codigo: ["src/game/enginephys.ts › rodLoads (inertiaTdcN)"], mecanicas: ["Esforços mecânicos"], componentes: ["pistao", "biela"], dimOps: mul(D.kg, D.ms2), calc: (x) => x["m"]! * x["a"]! },
  { id: "taxa", nome: "Taxa de compressão", eq: "ε = (Vd + Vc) / Vc", vars: [v("Vd", "volume deslocado", "m³", D.m3), v("Vc", "volume da câmara", "m³", D.m3)], saida: v("ε", "taxa", "—", D.um),
    hipoteses: ["Vc inclui junta, cavas e domo"], limites: ["gasolina C ~ ≤ 11:1 sem detonar (estimado no jogo)"], codigo: ["src/game/enginephys.ts › geoOf (vcM3 = vd/(cr−1))"], mecanicas: ["Compressão", "Combustão"], componentes: ["cabecote", "pistao", "cilindro"], dimOps: mul(D.m3, inv(D.m3)), calc: (x) => (x["Vd"]! + x["Vc"]!) / x["Vc"]! },
  { id: "vel-marcha", nome: "Velocidade teórica por marcha", eq: "v = (n / (i_p × i_m × i_f)) × 2π × r / 60", vars: [v("n", "rotação do motor", "1/min", D.hz), v("i", "relação total i_p·i_m·i_f", "—", D.um), v("r", "raio do pneu", "m", D.m)], saida: v("v", "velocidade", "m/s", D.ms),
    hipoteses: ["sem patinagem", "raio dinâmico = estático × fator de rolagem (estimado, não medido)"], limites: [], codigo: ["src/game/physics.ts › drivetrain / gearSpeeds (primária × marcha × coroa/pinhão, r_din)"], mecanicas: ["Relações de marcha", "Velocidade"], componentes: ["pinhao", "coroa", "pneu", "embreagem"], dimOps: mul(D.hz, D.m), calc: (x) => (x["n"]! / x["i"]!) * 2 * Math.PI * x["r"]! / 60 },
  { id: "torque-roda", nome: "Torque transmitido à roda", eq: "T_roda = T_motor × i_total × η", vars: [v("T", "torque do motor", "N·m", D.Nm), v("i", "relação total", "—", D.um), v("η", "eficiência", "—", D.um)], saida: v("T_roda", "torque na roda", "N·m", D.Nm),
    hipoteses: ["η constante"], limites: [], codigo: ["src/game/physics.ts › wheelTorqueNm (ETA = registry drivetrain.eta_total)"], mecanicas: ["Torque transmitido", "Perdas mecânicas"], componentes: ["embreagem", "pinhao", "coroa"], dimOps: D.Nm, calc: (x) => x["T"]! * x["i"]! * x["η"]! },
  { id: "tracao", nome: "Força de atrito / tração", eq: "F = μ × N", vars: [v("μ", "coeficiente de atrito", "—", D.um), v("N", "carga normal", "N", D.N)], saida: v("F", "força", "N", D.N),
    hipoteses: ["Coulomb"], limites: [], codigo: ["src/game/ground.ts", "src/game/physics.ts › tireOf"], mecanicas: ["Aderência"], componentes: ["pneu"], dimOps: D.N, calc: (x) => x["μ"]! * x["N"]! },
  { id: "transf-carga", nome: "Transferência de carga", eq: "ΔN = m × a × h / L", vars: [v("m", "massa", "kg", D.kg), v("a", "aceleração", "m/s²", D.ms2), v("h", "altura do CG", "m", D.m), v("L", "entre-eixos", "m", D.m)], saida: v("ΔN", "carga transferida", "N", D.N),
    hipoteses: ["regime quase estático"], limites: [], codigo: ["src/game/ground.ts"], mecanicas: ["Transferência de carga"], componentes: ["pneu"], dimOps: mul(D.kg, D.ms2, D.m, inv(D.m)), calc: (x) => (x["m"]! * x["a"]! * x["h"]!) / x["L"]! },
  { id: "arrasto", nome: "Força de arrasto", eq: "Fd = 0,5 × ρ × Cd·A × v²", vars: [v("ρ", "densidade do ar", "kg/m³", D.kgm3), v("CdA", "área de arrasto", "m²", D.m2), v("v", "velocidade", "m/s", D.ms)], saida: v("Fd", "força", "N", D.N),
    hipoteses: ["escoamento turbulento"], limites: [], codigo: ["src/game/physics.ts › RHO, CDA"], mecanicas: ["Arrasto aerodinâmico"], componentes: [], dimOps: mul(D.kgm3, D.m2, pow(D.ms, 2)), calc: (x) => 0.5 * x["ρ"]! * x["CdA"]! * x["v"]! ** 2 },
  { id: "duty", nome: "Ciclo de trabalho do bico", eq: "duty = (q_ciclo / Q_bico × 60000 + t_morto) / (120000 / n)", vars: [v("q", "combustível por ciclo", "cm³", D.m3), v("Q", "vazão do bico", "cm³/min", D.m3s), v("t0", "tempo morto", "ms", D.s), v("n", "rotação", "1/min", D.hz)], saida: v("duty", "fração do ciclo", "—", D.um),
    hipoteses: ["4 tempos: 1 injeção a cada 2 voltas"], limites: ["> 85 % alto, ≥ 100 % saturado"], codigo: ["src/game/enginephys.ts › injectionAt"], mecanicas: ["Injeção", "Vazão"], componentes: ["bico", "bomba"], dimOps: mul(D.s, inv(D.s)), calc: (x) => ((x["q"]! / x["Q"]!) * 60000 + x["t0"]!) / (120000 / x["n"]!) },
];
export const formula = (id: string) => FORMULAS.find((f) => f.id === id)!;
/** Verificação dimensional: as operações produzem a unidade declarada? */
export const dimOk = (f: Formula) => sameDim(f.dimOps, f.saida.dim);
