// ENG IA → NEXUS → WIKISTREETRACE. A Eng IA nunca se homologa: o NEXUS refaz contas críticas por outra rota,
// confere as evidências e só então o Wiki recebe o registro (append-only, versionado, com herança por moto).
import { cloudStore } from "@/game/cloud/cloud-store";
import type { Setup } from "../../physics";
import { auditar, fnv, hashOf, pior, strokeReal, boreOf, TOL_PADRAO, type Auditoria, type Estado, type Tol } from "./audit";
import { slotPart } from "../../parts";
import { rodMmOf } from "../../data/engine_catalog";

export const KEY = "streetrace-engdados-v1";
export type NexusCheck = { id: string; titulo: string; ok: boolean; detalhe: string };
export type NexusParecer = { at: string; auditId: string; checks: NexusCheck[]; veredito: "HOMOLOGADO" | "DEVOLVIDO"; motivo: string };
export type WikiRec = {
  id: string; versao: number; at: string; bikeId: string; tipo: "BASE" | "DERIVADA"; chave: string; auditId: string; hash: string; parent: string | null;
  sistemas: Record<string, string[]>; formulas: string[]; alterados: string[]; reavaliados: string[];
};
export type Registro = { aud: Auditoria; nexus: NexusParecer | null };
export type DadosState = { registros: Registro[]; wiki: WikiRec[] };
const empty = (): DadosState => ({ registros: [], wiki: [] });
export const readDados = (): DadosState => { if (typeof cloudStore === "undefined") return empty(); try { const v = JSON.parse(cloudStore.getItem(KEY) ?? "null"); return v && Array.isArray(v.registros) ? { ...empty(), ...v } : empty(); } catch { return empty(); } };
export const saveDados = (s: DadosState) => { try { cloudStore.setItem(KEY, JSON.stringify({ ...s, registros: s.registros.slice(-60) })); } catch { /* cheio */ } if (typeof window !== "undefined") window.dispatchEvent(new Event("eng-dados-change")); return s; };

/** Rota independente para o volume: integra A·dx do mecanismo biela-manivela de 0 a π (Simpson) — deve dar A·S. */
export function vdIntegrado(boreMm: number, strokeMm: number, rodMm: number, n = 2000) {
  const r = strokeMm / 2000, l = rodMm / 1000, A = Math.PI * (boreMm / 1000) ** 2 / 4;
  const x = (t: number) => r * (1 - Math.cos(t)) + l - Math.sqrt(l * l - (r * Math.sin(t)) ** 2);
  const h = Math.PI / n; let s = 0;
  for (let i = 0; i <= n; i++) { const t = i * h; const dx = (x(t + 1e-6) - x(t - 1e-6)) / 2e-6; s += (i === 0 || i === n ? 1 : i % 2 ? 4 : 2) * A * dx; }
  return (s * h) / 3;
}

/** NEXUS — 2ª conferência. Não copia o resultado da Eng IA: refaz, compara e procura aprovação indevida. */
export function nexusRevisar(a: Auditoria, at = new Date().toISOString()): NexusParecer {
  const c: NexusCheck[] = [];
  const h = hashOf({ bike: a.bikeId, setup: a.snapshot, v: a.versao });
  c.push({ id: "hash", titulo: "Fotografia dos dados íntegra", ok: h === a.hash, detalhe: `hash recalculado ${h} vs ${a.hash}` });
  const calcs = a.conexoes.flatMap((x) => x.checks).filter((k) => k.calc);
  const indevidas = calcs.filter((k) => k.estado === "APROVADO" && (k.calc!.relDiff == null || k.calc!.relDiff > k.calc!.tol));
  c.push({ id: "aprov-indevida", titulo: "Nenhuma aprovação fora da tolerância", ok: !indevidas.length, detalhe: indevidas.length ? indevidas.map((k) => k.titulo).join("; ") : `${calcs.length} recálculos reconferidos` });
  const naoDetect = calcs.filter((k) => k.estado !== "REPROVADO" && k.calc!.relDiff != null && k.calc!.relDiff > k.calc!.tol);
  c.push({ id: "nao-detectado", titulo: "Nenhum erro não detectado", ok: !naoDetect.length, detalhe: naoDetect.length ? naoDetect.map((k) => k.titulo).join("; ") : "todas as divergências foram marcadas" });
  // volume por integração (rota diferente da Eng IA)
  const cyl = slotPart(a.snapshot.slots.cilindro, "cilindro"), d = boreOf(cyl, a.bikeId), s = strokeReal(a.bikeId, a.snapshot);
  const vdCk = a.conexoes.find((x) => x.id === "motor-basico")?.checks.find((k) => k.id === "cc")?.calc;
  if (typeof d.valor === "number" && typeof s.valor === "number" && vdCk?.recalculado != null) {
    const vi = vdIntegrado(d.valor, s.valor, rodMmOf(a.bikeId) ?? 100);
    const rel = Math.abs(vi - vdCk.recalculado) / vdCk.recalculado;
    c.push({ id: "vd-integral", titulo: "Volume por integração da cinemática = Eng IA", ok: rel < 1e-4, detalhe: `∫A·dx = ${(vi * 1e6).toFixed(3)} cm³ vs Eng IA ${(vdCk.recalculado * 1e6).toFixed(3)} cm³ (Δ ${(rel * 100).toExponential(2)} %)` });
  } else c.push({ id: "vd-integral", titulo: "Volume por integração da cinemática", ok: false, detalhe: "dados de Ø/curso ausentes — não verificável" });
  const pend = a.conexoes.flatMap((x) => x.checks).filter((k) => k.essencial && (k.estado === "PENDENTE" || k.estado === "INCONCLUSIVO"));
  c.push({ id: "pendencias", titulo: "Sem pendência essencial", ok: !pend.length, detalhe: pend.length ? `${pend.length} pendentes: ${pend.slice(0, 4).map((k) => k.titulo).join("; ")}${pend.length > 4 ? "…" : ""}` : "nenhuma" });
  const tres = a.niveis.peca === "APROVADO" && a.niveis.conexao === "APROVADO" && a.niveis.conjunto === "APROVADO";
  c.push({ id: "tres-niveis", titulo: "Peça, conexão e conjunto aprovados", ok: tres, detalhe: `peça ${a.niveis.peca} · conexão ${a.niveis.conexao} · conjunto ${a.niveis.conjunto}` });
  const ok = c.every((x) => x.ok);
  return { at, auditId: a.id, checks: c, veredito: ok ? "HOMOLOGADO" : "DEVOLVIDO", motivo: ok ? "todas as conferências independentes passaram" : c.filter((x) => !x.ok).map((x) => x.titulo).join(" · ") };
}

const SIST: Record<string, string> = { "vira-biela": "Motor", "biela-pistao": "Motor", "pistao-cilindro": "Motor", "motor-basico": "Motor", "cabecote-pistao": "Motor", transmissao: "Transmissão", alimentacao: "Combustível", "ignicao-escape": "Motor" };
/** Campo do Setup → conexões que precisam ser reavaliadas (herança: só o afetado volta ao funil). */
export const AFETA: Record<string, string[]> = {
  cilindro: ["pistao-cilindro", "motor-basico", "alimentacao"], pistao: ["pistao-cilindro", "biela-pistao", "cabecote-pistao", "motor-basico"], biela: ["vira-biela", "biela-pistao"],
  vira: ["vira-biela", "motor-basico"], services: ["vira-biela", "motor-basico", "cabecote-pistao"], compression: ["motor-basico"], cam: ["cabecote-pistao", "alimentacao"],
  bico: ["alimentacao"], bomba: ["alimentacao"], modulo: ["alimentacao", "ignicao-escape"], escape: ["ignicao-escape"], embreagem: ["transmissao"], front: ["transmissao"], rear: ["transmissao"], pneu: ["transmissao"], psi: ["transmissao"], fuel: ["alimentacao"],
};
export function diffSetup(a: Setup, b: Setup): string[] {
  const out: string[] = [];
  for (const k of Object.keys(b.slots) as (keyof Setup["slots"])[]) if (a.slots[k] !== b.slots[k]) out.push(k);
  for (const k of ["compression", "cam", "front", "rear", "psi", "fuel"] as const) if (a[k] !== b[k]) out.push(k);
  if (hashOf([...a.services].sort()) !== hashOf([...b.services].sort())) out.push("services");
  return out;
}
export const afetadas = (alterados: string[]) => [...new Set(alterados.flatMap((k) => AFETA[k] ?? []))];

/** Publica somente o que o NEXUS homologou. Nunca sobrescreve: cria nova versão com o pai identificado. */
export function publicarWiki(st: DadosState, r: Registro, at = new Date().toISOString()): { st: DadosState; rec: WikiRec | null; motivo: string } {
  if (!r.nexus || r.nexus.veredito !== "HOMOLOGADO") return { st, rec: null, motivo: "bloqueado: sem homologação NEXUS" };
  if (r.aud.estado !== "APROVADO") return { st, rec: null, motivo: "bloqueado: Eng IA não aprovou" };
  const base = [...st.wiki].reverse().find((w) => w.bikeId === r.aud.bikeId && w.tipo === "BASE") ?? null;
  const alterados = base ? diffSetup(st.registros.find((x) => x.aud.id === base.auditId)?.aud.snapshot ?? r.aud.snapshot, r.aud.snapshot) : [];
  const sistemas: Record<string, string[]> = {};
  r.aud.conexoes.forEach((c) => { (sistemas[SIST[c.id] ?? "Outros"] ??= []).push(`${c.origem} → ${c.destino}`); });
  const versao = st.wiki.filter((w) => w.chave === r.aud.chave).length + 1;
  const rec: WikiRec = { id: `WIKI-${fnv(r.aud.id + at)}`, versao, at, bikeId: r.aud.bikeId, tipo: base && alterados.length ? "DERIVADA" : "BASE", chave: r.aud.chave, auditId: r.aud.id, hash: r.aud.hash,
    parent: base?.id ?? null, sistemas, formulas: [...new Set(r.aud.conexoes.flatMap((c) => c.formulas))], alterados, reavaliados: afetadas(alterados) };
  return { st: { ...st, wiki: [...st.wiki, rec] }, rec, motivo: "publicado" };
}

/** Ciclo completo: Eng IA audita → NEXUS revisa → Wiki (só se homologado). Reprovações anteriores são preservadas. */
export function ciclo(st: DadosState, a: { bikeId: string; setup: Setup; motivo: string; componente?: string }, tol: Tol = TOL_PADRAO, at = new Date().toISOString()) {
  const chave = hashOf({ bike: a.bikeId, setup: a.setup });
  const tentativa = st.registros.filter((r) => r.aud.chave === chave).length + 1;
  const aud = auditar({ ...a, at, tentativa }, tol);
  const reg: Registro = { aud, nexus: nexusRevisar(aud, at) };
  let next: DadosState = { ...st, registros: [...st.registros, reg] };
  const pub = publicarWiki(next, reg, at); next = pub.st;
  return { st: next, reg, wiki: pub.rec, motivo: pub.motivo };
}
export const aprovados = (st: DadosState) => st.registros.filter((r) => r.nexus?.veredito === "HOMOLOGADO" && st.wiki.some((w) => w.auditId === r.aud.id));
export const reprovados = (st: DadosState) => st.registros.filter((r) => r.aud.estado === "REPROVADO" || r.nexus?.veredito === "DEVOLVIDO");
export const estadoGeral = (rs: Registro[]): Estado => pior(rs.map((r) => r.aud.estado));

/** Entrada automática: relatórios ao vivo do jogo (preload-report.pushLive) chegam aqui com a moto e o Setup reais. */
export function intakeLive(bikeId: string, setup: Setup, motivo: string) {
  const r = ciclo(readDados(), { bikeId, setup, motivo });
  saveDados(r.st);
  return r;
}
