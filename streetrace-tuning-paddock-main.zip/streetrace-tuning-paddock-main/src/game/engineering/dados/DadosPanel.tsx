import { useEffect, useMemo, useState } from "react";
import { STOCK_SETUP, type Setup } from "../../physics";
import { getPlayer } from "../../store";
import { partById, type Slot } from "../../parts";
import { kit4Pieces } from "../../workshop";
import { catalogoAtivo, pior, TOL_PADRAO, type Check, type Estado, type Ficha, type Tol } from "./audit";
import { FORMULAS, dimOk, dimTxt } from "./formulas";
import { afetadas, aprovados, ciclo, diffSetup, readDados, reprovados, saveDados, type DadosState, type Registro } from "./pipeline";

const AREAS = ["Funil ao vivo", "Componentes", "Conexões", "Auditoria integrada", "Mecânicas", "Fórmulas", "Aprovados", "Reprovados", "WikiStreetRace"] as const;
type Area = (typeof AREAS)[number];
const COR: Record<Estado, string> = { APROVADO: "bg-primary text-primary-foreground", REPROVADO: "bg-destructive text-destructive-foreground", PENDENTE: "bg-accent text-accent-foreground", INCONCLUSIVO: "bg-muted text-muted-foreground", "NÃO APLICÁVEL": "bg-secondary text-secondary-foreground" };
export const Est = ({ e }: { e: Estado }) => <span className={`inline-block shrink-0 rounded px-1.5 py-0.5 text-[10px] font-bold ${COR[e]}`}>{e}</span>;
const Card = ({ t, children, right }: { t: string; children: React.ReactNode; right?: React.ReactNode }) => (
  <div className="rounded-xl border border-border bg-card p-3"><div className="mb-2 flex items-center justify-between gap-2"><div className="text-xs font-bold uppercase tracking-widest text-muted-foreground">{t}</div>{right}</div>{children}</div>
);
const Btn = (p: React.ButtonHTMLAttributes<HTMLButtonElement>) => <button {...p} className={`rounded-lg bg-primary px-3 py-1.5 text-sm font-bold text-primary-foreground disabled:opacity-40 ${p.className ?? ""}`} />;

/** Kit 4MM montado como a Oficina monta (mesmas peças + pino cursado +2 mm + 15x42). */
export function kit4Setup(): Setup {
  const slots = { ...STOCK_SETUP.slots } as Record<Slot, string>;
  for (const id of kit4Pieces()) { const k = partById(id)?.kind as Slot | undefined; if (k && k in slots) slots[k] = id; }
  return { ...structuredClone(STOCK_SETUP), slots, cam: "ma66", services: ["pino-2"], front: 15, rear: 42 };
}

function CheckRow({ c }: { c: Check }) {
  const [open, setOpen] = useState(false);
  return (
    <li className="border-b border-border/50 py-1.5 last:border-0">
      <button className="flex w-full items-start gap-2 text-left" onClick={() => setOpen(!open)}>
        <Est e={c.estado} /><span className="flex-1 text-sm">{c.titulo}{!c.essencial && <span className="ml-1 text-[10px] text-muted-foreground">(não essencial)</span>}</span>
      </button>
      <p className="ml-1 mt-0.5 text-xs text-muted-foreground">{c.detalhe}</p>
      {open && c.calc && (
        <div className="mt-1 rounded bg-secondary p-2 font-mono text-[11px] leading-relaxed">
          <div>{c.calc.eq}</div>
          {c.calc.entradas.map((e) => <div key={e.sym}>{e.sym} = {e.valor ?? "AUSENTE"} {e.unidade} <span className="text-muted-foreground">[{e.origem}]</span></div>)}
          <div>recalculado: {c.calc.recalculado ?? "—"} {c.calc.unidade}</div>
          <div>jogo: {c.calc.jogo ?? "—"} ({c.calc.jogoFonte})</div>
          <div>Δ abs {c.calc.absDiff ?? "—"} · Δ rel {c.calc.relDiff == null ? "—" : (c.calc.relDiff * 100).toFixed(4) + " %"} · tolerância {(c.calc.tol * 100).toFixed(2)} %</div>
        </div>
      )}
    </li>
  );
}

function FichaView({ f }: { f: Ficha }) {
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-center gap-2"><b>{f.nome}</b><span className="text-xs text-muted-foreground">{f.id} · {f.categoria} · {f.grupo}</span><Est e={f.estado} /></div>
      <div className="grid grid-cols-2 gap-2 text-xs"><div>Conferência matemática: <Est e={f.estadoMat} /></div><div>Conferência física: <Est e={f.estadoFis} /></div></div>
      <div className="text-xs"><b>Motos:</b> {f.bikes.join(", ")} · <b>Mecânicas:</b> {f.mecanicas.join(", ") || "—"} · <b>Conecta com:</b> {f.conectados.join(", ") || "—"} · <b>Fórmulas:</b> {f.formulas.join(", ") || "nenhuma aplicável com os dados atuais"}</div>
      <table className="w-full text-xs"><thead><tr className="text-left text-muted-foreground"><th>Dado</th><th>Valor</th><th>Origem</th></tr></thead>
        <tbody>{f.dados.map((d) => <tr key={d.nome} className="border-t border-border/50"><td className="py-0.5">{d.nome}</td><td>{d.valor ?? "AUSENTE"} {d.valor != null && d.unidade !== "—" ? d.unidade : ""}</td><td title={d.fonte}>{d.origem}</td></tr>)}</tbody></table>
      <ul>{[...f.checks, f.usadoPeloJogo].map((c) => <CheckRow key={c.id} c={c} />)}</ul>
    </div>
  );
}

function RegistroView({ r }: { r: Registro }) {
  const a = r.aud;
  return (
    <div className="space-y-3">
      <div className="text-xs text-muted-foreground">{a.id} · {new Date(a.at).toLocaleString("pt-BR")} · {a.bike} · {a.motivo} · tentativa {a.tentativa} · {a.versao} · hash {a.hash}</div>
      <ol className="grid gap-1 md:grid-cols-7">
        {a.etapas.map((e) => <li key={e.n} className="rounded-lg border border-border p-2 text-xs"><div className="mb-1 flex items-center justify-between gap-1"><b>{e.n}. {e.nome}</b></div><Est e={e.estado} /><p className="mt-1 text-muted-foreground">{e.detalhe}</p></li>)}
      </ol>
      <div className="flex flex-wrap gap-2 text-xs">Peça <Est e={a.niveis.peca} /> Conexão <Est e={a.niveis.conexao} /> Conjunto <Est e={a.niveis.conjunto} /> · NEXUS: <b>{r.nexus?.veredito ?? "—"}</b></div>
      {r.nexus && <ul className="text-xs">{r.nexus.checks.map((c) => <li key={c.id}>{c.ok ? "✔" : "✖"} {c.titulo} — <span className="text-muted-foreground">{c.detalhe}</span></li>)}</ul>}
    </div>
  );
}

export function DadosPanel() {
  const [st, setSt] = useState<DadosState>(() => readDados());
  const [area, setArea] = useState<Area>("Funil ao vivo");
  const [tol, setTol] = useState<Tol>(TOL_PADRAO);
  const [sel, setSel] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const [msg, setMsg] = useState("");
  useEffect(() => { const f = () => setSt(readDados()); window.addEventListener("eng-dados-change", f); return () => window.removeEventListener("eng-dados-change", f); }, []);
  const cat = useMemo(() => catalogoAtivo(tol), [tol]);
  const last = st.registros.at(-1) ?? null;

  const rodar = (bikeId: string, setup: Setup, motivo: string) => {
    const r = ciclo(readDados(), { bikeId, setup, motivo }, tol);
    saveDados(r.st); setSt(r.st); setSel(r.reg.aud.id);
    setMsg(`${r.reg.aud.bike}: Eng IA ${r.reg.aud.estado} · NEXUS ${r.reg.nexus?.veredito} · Wiki: ${r.motivo}`);
  };
  const atual = () => { const p = getPlayer(); if (!p?.activeBike) { setMsg("Nenhuma moto ativa no save do jogo."); return; } rodar(p.activeBike, p.setup, "preparação atual do jogador"); };
  const regSel = st.registros.find((r) => r.aud.id === sel) ?? last;

  return (
    <div className="space-y-3">
      <div className="rounded-xl border border-border bg-card p-3">
        <div className="text-lg font-bold">ENGENHARIA DE DADOS</div>
        <p className="text-xs text-muted-foreground">Jogo → Eng IA (1ª conferência: peça, conexão, conjunto) → NEXUS (2ª conferência independente) → WikiStreetRace. Somente leitura: nada aqui altera o jogo.</p>
        <div className="mt-2 flex flex-wrap gap-2">
          <Btn onClick={atual}>Auditar preparação atual</Btn>
          <Btn onClick={() => rodar("titan160", kit4Setup(), "CG 160 · preparação 4 MM (exemplo obrigatório)")}>CG 160 · 4 MM</Btn>
          <Btn onClick={() => rodar("titan160", STOCK_SETUP, "CG 160 · original")} className="bg-secondary text-secondary-foreground">CG 160 original</Btn>
          <Btn onClick={() => rodar("factor150", STOCK_SETUP, "Factor 150 · original")} className="bg-secondary text-secondary-foreground">Factor 150 original</Btn>
        </div>
        {msg && <p className="mt-2 rounded bg-secondary p-2 text-xs">{msg}</p>}
      </div>
      <nav className="flex flex-wrap gap-1">{AREAS.map((a) => <button key={a} onClick={() => setArea(a)} className={`rounded-lg px-2.5 py-1 text-xs ${area === a ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>{a}</button>)}</nav>

      {area === "Funil ao vivo" && (
        <>
          <Card t={`Auditorias recebidas (${st.registros.length})`}>
            {!st.registros.length && <p className="text-sm text-muted-foreground">Nenhuma ainda. Corridas e dinamômetro enviam automaticamente; ou use os botões acima.</p>}
            <ul className="max-h-64 overflow-auto">{[...st.registros].reverse().map((r) => (
              <li key={r.aud.id}><button onClick={() => setSel(r.aud.id)} className={`flex w-full items-center gap-2 border-b border-border/50 py-1 text-left text-xs ${regSel?.aud.id === r.aud.id ? "font-bold" : ""}`}>
                <Est e={r.aud.estado} /><span className="flex-1 truncate">{r.aud.bike} · {r.aud.motivo}</span><span className="text-muted-foreground">{new Date(r.aud.at).toLocaleTimeString("pt-BR")}</span></button></li>))}</ul>
          </Card>
          {regSel && <Card t="Funil de conferência"><RegistroView r={regSel} /></Card>}
          <Card t="Tolerâncias numéricas">
            <div className="flex flex-wrap gap-3 text-xs">{(Object.keys(tol) as (keyof Tol)[]).map((k) => <label key={k} className="flex items-center gap-1">{k} <input type="number" step="0.001" min="0" className="w-20 rounded border border-border bg-background px-1" value={tol[k]} onChange={(e) => setTol({ ...tol, [k]: Math.max(0, Number(e.target.value) || 0) })} /></label>)}</div>
          </Card>
        </>
      )}

      {area === "Componentes" && (
        <div className="grid gap-3 md:grid-cols-[16rem_1fr]">
          <Card t={`Peças da loja (${cat.length})`}>
            <ul className="max-h-[32rem] overflow-auto">{cat.map((f) => <li key={f.id}><button onClick={() => setSel(f.id)} className={`flex w-full items-center gap-2 py-1 text-left text-xs ${sel === f.id ? "font-bold" : ""}`}><Est e={f.estado} /><span className="truncate">{f.nome} <span className="text-muted-foreground">· {f.id}</span></span></button></li>)}</ul>
          </Card>
          <Card t="Ficha técnica individual">{(() => { const f = cat.find((x) => x.id === sel) ?? cat[0]; return f ? <FichaView f={f} /> : null; })()}</Card>
        </div>
      )}

      {(area === "Conexões" || area === "Auditoria integrada") && !last && <p className="text-sm text-muted-foreground">Rode uma auditoria (ex.: CG 160 · 4 MM) para ver as conexões.</p>}
      {area === "Conexões" && regSel && (
        <>
          <Card t={`Mapa de conexões · ${regSel.aud.bike} · ${regSel.aud.motivo}`}>
            <div className="flex flex-wrap items-center gap-1 text-xs">{["Pistão", "Biela", "Virabrequim", "Embreagem", "Câmbio", "Pinhão/Coroa", "Pneu", "Solo"].map((n, i, a) => <span key={n} className="flex items-center gap-1"><span className="rounded border border-border px-2 py-1">{n}</span>{i < a.length - 1 && <span>→</span>}</span>)}</div>
          </Card>
          {regSel.aud.conexoes.map((c) => (
            <Card key={c.id} t={`${c.origem} → ${c.destino}`} right={<Est e={c.estado} />}>
              <p className="text-xs text-muted-foreground">{c.tipo} · compartilham: {c.compartilhados.join(", ")} · fórmulas: {c.formulas.join(", ") || "—"}</p>
              <ul>{c.checks.map((k) => <CheckRow key={k.id} c={k} />)}</ul>
            </Card>
          ))}
        </>
      )}

      {area === "Auditoria integrada" && regSel && (
        <>
          <Card t={`Conjunto · ${regSel.aud.bike}`} right={<Est e={regSel.aud.niveis.conjunto} />}>
            <p className="text-xs">Peças montadas: {Object.values(regSel.aud.snapshot.slots).filter((x) => !x.endsWith("-original")).join(", ") || "todas originais"} · comando {regSel.aud.snapshot.cam} · {regSel.aud.snapshot.front}x{regSel.aud.snapshot.rear} · serviços {regSel.aud.snapshot.services.join(", ") || "—"}</p>
          </Card>
          <Card t="As 12 perguntas da preparação">
            <ol className="space-y-1">{regSel.aud.perguntas.map((p) => <li key={p.n} className="text-sm"><div className="flex items-start gap-2"><Est e={p.estado} /><span>{p.n}. {p.pergunta}</span></div><p className="ml-1 text-xs text-muted-foreground">{p.resposta}</p></li>)}</ol>
          </Card>
          <Card t="Fluxo de torque até o solo (1ª marcha)"><ul className="text-xs">{regSel.aud.cadeia.map((c) => <li key={c.etapa}><b>{c.etapa}:</b> {c.valor}</li>)}</ul></Card>
          <Card t={`Problemas (${regSel.aud.problemas.length})`}>
            {regSel.aud.problemas.map((p, i) => (
              <div key={i} className="mb-2 rounded border border-border p-2 text-xs">
                <b>{p.principal}</b> — {p.conexao}<br />Causa: {p.causa}<br />Evidência: <span className="font-mono">{p.evidencia}</span><br />Consequências: {p.consequencias}<br />Correção: {p.correcao}<br />Regressão: {p.regressao.join(", ")}
              </div>))}
            {!regSel.aud.problemas.length && <p className="text-xs text-muted-foreground">Nenhuma divergência comprovada (pendências podem existir).</p>}
          </Card>
        </>
      )}

      {area === "Mecânicas" && (() => {
        const CATS: [string, string[]][] = [["Motor", ["Cilindrada", "Compressão", "Combustão", "Torque", "Potência", "Rotação", "Cinemática do pistão", "Esforços mecânicos"]], ["Combustível e injeção", ["Injeção", "Vazão", "Mistura"]], ["Transmissão", ["Relações de marcha", "Torque transmitido", "Perdas mecânicas"]], ["Dinâmica", ["Velocidade", "Transferência de carga", "Aderência", "Arrasto aerodinâmico"]]];
        return CATS.map(([c, ms]) => (
          <Card key={c} t={c}>
            {ms.map((m) => { const fs = FORMULAS.filter((f) => f.mecanicas.includes(m)); if (!fs.length) return null; const ck = last?.aud.conexoes.flatMap((x) => x.checks).filter((k) => k.calc && fs.some((f) => f.id === k.calc!.formulaId)) ?? [];
              return (<div key={m} className="border-b border-border/50 py-1.5 text-xs last:border-0"><div className="flex items-center gap-2"><b>{m}</b>{ck.length ? <Est e={pior(ck.map((k) => k.estado))} /> : <Est e="PENDENTE" />}</div>
                <div className="text-muted-foreground">Fórmulas: {fs.map((f) => f.eq).join(" · ")}</div><div className="text-muted-foreground">Arquivos: {[...new Set(fs.flatMap((f) => f.codigo))].join(" · ")}</div><div className="text-muted-foreground">Componentes: {[...new Set(fs.flatMap((f) => f.componentes))].join(", ")}</div></div>); })}
          </Card>));
      })()}

      {area === "Fórmulas" && (
        <Card t="Central de fórmulas" right={<input placeholder="Pesquisar…" value={q} onChange={(e) => setQ(e.target.value)} className="w-40 rounded border border-border bg-background px-2 py-1 text-xs" />}>
          {FORMULAS.filter((f) => !q || `${f.nome} ${f.eq} ${f.mecanicas.join(" ")} ${f.componentes.join(" ")}`.toLowerCase().includes(q.toLowerCase())).map((f) => (
            <div key={f.id} className="border-b border-border/50 py-2 text-xs last:border-0">
              <div className="flex items-center gap-2"><b>{f.nome}</b><Est e={dimOk(f) ? "APROVADO" : "REPROVADO"} /><span className="text-muted-foreground">dimensional: {dimTxt(f.dimOps)} → {f.saida.si}</span></div>
              <div className="font-mono">{f.eq}</div>
              <div>{f.vars.map((v) => `${v.sym}: ${v.nome} [${v.si}]`).join(" · ")}</div>
              <div className="text-muted-foreground">Hipóteses: {f.hipoteses.join("; ") || "—"} · Limites: {f.limites.join("; ") || "—"}</div>
              <div className="text-muted-foreground">Código: {f.codigo.join(" · ")} · Mecânicas: {f.mecanicas.join(", ")}</div>
            </div>))}
        </Card>
      )}

      {area === "Aprovados" && (
        <Card t="Homologados (Eng IA + NEXUS + Wiki)">
          {aprovados(st).map((r) => <RegistroView key={r.aud.id} r={r} />)}
          {!aprovados(st).length && <p className="text-sm text-muted-foreground">Nenhum conjunto homologado. Só entra aqui o que passou nos três níveis e na revisão do NEXUS.</p>}
        </Card>
      )}

      {area === "Reprovados" && (
        <Card t={`Reprovados e devolvidos (${reprovados(st).length})`}>
          {[...reprovados(st)].reverse().map((r) => (
            <div key={r.aud.id} className="mb-2 rounded border border-border p-2 text-xs">
              <div className="flex flex-wrap items-center gap-2"><Est e={r.aud.estado} /><b>{r.aud.bike}</b> · {r.aud.motivo} · tentativa {r.aud.tentativa} · NEXUS {r.nexus?.veredito}</div>
              <div className="text-muted-foreground">Motivo NEXUS: {r.nexus?.motivo}</div>
              <ul className="mt-1 list-disc pl-4">{r.aud.problemas.map((p, i) => <li key={i}>{p.principal} — {p.causa}. Correção: {p.correcao}</li>)}</ul>
            </div>))}
        </Card>
      )}

      {area === "WikiStreetRace" && (
        <Card t="Base homologada e herança">
          {!st.wiki.length && <p className="text-sm text-muted-foreground">Vazio: nenhum registro reprovado ou pendente vira referência oficial.</p>}
          {st.wiki.map((w) => <div key={w.id} className="border-b border-border/50 py-1 text-xs">{w.id} v{w.versao} · {w.bikeId} · {w.tipo} · pai {w.parent ?? "—"} · alterados: {w.alterados.join(", ") || "—"} · reavaliar: {w.reavaliados.join(", ") || "—"}</div>)}
          {last && (
            <p className="mt-2 text-xs text-muted-foreground">Herança da última auditoria vs moto original: alterados {diffSetup(STOCK_SETUP, last.aud.snapshot).join(", ") || "nada"} → só voltam ao funil: {afetadas(diffSetup(STOCK_SETUP, last.aud.snapshot)).join(", ") || "nenhuma conexão"}.</p>
          )}
        </Card>
      )}
    </div>
  );
}
