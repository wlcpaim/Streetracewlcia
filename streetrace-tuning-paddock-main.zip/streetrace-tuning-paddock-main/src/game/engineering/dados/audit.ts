// ENGENHARIA DE DADOS (ENG IA) — 1ª conferência matemática e física, em três níveis: PEÇA → CONEXÃO → CONJUNTO.
// Somente leitura: lê o que o jogo produz (engine/geoOf/gearSpeeds/injectionAt/buildOf) e confronta com o
// recálculo independente de formulas.ts. Nunca altera Setup, peças, RealGear ou resultados de corrida.
import { ETA, STOCK_SETUP, bikeModel, ccOf, drivetrain, engine, pinOffsetMm, gearSpeeds, stats, tireOf, type BikeModel, type Setup } from "../../physics";
import { geoOf, injectionAt } from "../../enginephys";
import { buildOf } from "../../mechlimits";
import { ENGINE_CATALOG, rodMmOf, strokeMmOf } from "../../data/engine_catalog";
import { clutchCapNm, slotPart, type Part } from "../../parts";
import { shopListing, type ShopEntry } from "../../shop-catalog";
import { setupFor } from "../../autopecas/autopecas";
import { tireRadius } from "../../intel/powertrain";
import { FORMULAS, dimOk, formula } from "./formulas";

export const DADOS_VERSION = "eng-dados/1.0.0";
export type Estado = "APROVADO" | "REPROVADO" | "PENDENTE" | "INCONCLUSIVO" | "NÃO APLICÁVEL";
export type Origem = "FICHA" | "JOGO" | "CALCULADO" | "ESTIMADO" | "AUSENTE";
export type Dado = { nome: string; valor: number | string | null; unidade: string; origem: Origem; fonte: string };
export type Entrada = { sym: string; valor: number | null; unidade: string; origem: Origem };
export type Calc = {
  formulaId: string; nome: string; eq: string; entradas: Entrada[]; substituicao: string; recalculado: number | null; unidade: string;
  jogo: number | null; jogoFonte: string; absDiff: number | null; relDiff: number | null; tol: number; estado: Estado; nota: string;
};
export type Check = { id: string; titulo: string; estado: Estado; detalhe: string; essencial: boolean; fisico: boolean; calc?: Calc | undefined };
export type Ficha = {
  id: string; nome: string; categoria: string; grupo: string; marca: string; bikes: string[]; dados: Dado[]; checks: Check[];
  mecanicas: string[]; conectados: string[]; formulas: string[]; usadoPeloJogo: Check; estadoMat: Estado; estadoFis: Estado; estado: Estado;
};
export type Conexao = { id: string; origem: string; destino: string; tipo: string; compartilhados: string[]; formulas: string[]; checks: Check[]; estado: Estado };
export type Pergunta = { n: number; pergunta: string; estado: Estado; resposta: string; ref: string };
export type Problema = { principal: string; componente: string; conexao: string; causa: string; evidencia: string; consequencias: string; correcao: string; dependentes: string[]; regressao: string[] };
export type Etapa = { n: number; nome: string; estado: Estado; detalhe: string };
export type Auditoria = {
  id: string; at: string; motivo: string; bikeId: string; bike: string; componente: string; mecanica: string; versao: string; hash: string; snapshot: Setup;
  tol: Tol; etapas: Etapa[]; fichas: Ficha[]; conexoes: Conexao[]; perguntas: Pergunta[]; cadeia: { etapa: string; valor: string }[]; problemas: Problema[];
  niveis: { peca: Estado; conexao: Estado; conjunto: Estado }; estado: Estado; tentativa: number; chave: string;
};
export type Tol = { geometria: number; velocidade: number; numerico: number };
export const TOL_PADRAO: Tol = { geometria: 0.01, velocidade: 0.03, numerico: 0.005 };

// ---------- utilitários ----------
const RANK: Estado[] = ["REPROVADO", "PENDENTE", "INCONCLUSIVO", "APROVADO"];
/** Pior estado manda; NÃO APLICÁVEL não conta; lista vazia nunca aprova (INCONCLUSIVO). */
export function pior(es: Estado[]): Estado {
  const v: Estado[] = es.filter((e) => e !== "NÃO APLICÁVEL");
  if (!v.length) return es.length ? "NÃO APLICÁVEL" : "INCONCLUSIVO";
  return RANK.find((r) => v.includes(r)) ?? "INCONCLUSIVO";
}
export function fnv(s: string) { let h = 0x811c9dc5; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h.toString(16).padStart(8, "0"); }
const canon = (x: unknown): string => (Array.isArray(x) ? `[${x.map(canon).join(",")}]` : x && typeof x === "object" ? `{${Object.keys(x as object).sort().map((k) => `${JSON.stringify(k)}:${canon((x as Record<string, unknown>)[k])}`).join(",")}}` : JSON.stringify(x ?? null));
export const hashOf = (x: unknown) => fnv(canon(x));
const fx = (x: number | null | undefined, d = 3) => (x == null || !Number.isFinite(x) ? "—" : x.toLocaleString("pt-BR", { maximumFractionDigits: d }));
const num = (s: string | undefined) => (s ? Number(s.replace(",", ".")) : NaN);

/** Recalcula pela fórmula independente e compara com o valor que o jogo produziu. Sem dado → PENDENTE (nunca aprova). */
export function conferir(formulaId: string, ent: Entrada[], jogo: number | null, jogoFonte: string, tol: number, nota = ""): Calc {
  const f = formula(formulaId);
  const faltando = ent.filter((e) => e.valor == null || !Number.isFinite(e.valor));
  const x: Record<string, number> = {}; ent.forEach((e) => { if (e.valor != null) x[e.sym] = e.valor; });
  const rec = faltando.length ? null : f.calc(x);
  const abs = rec != null && jogo != null ? Math.abs(rec - jogo) : null;
  const rel = abs != null && rec != null ? abs / Math.max(Math.abs(rec), 1e-12) : null;
  const estado: Estado = !dimOk(f) ? "REPROVADO" : faltando.length ? "PENDENTE" : jogo == null ? "INCONCLUSIVO" : rel! <= tol ? "APROVADO" : "REPROVADO";
  return {
    formulaId, nome: f.nome, eq: f.eq, entradas: ent, substituicao: `${f.saida.sym} = ${ent.map((e) => `${e.sym}=${fx(e.valor, 6)} ${e.unidade}`).join(", ")}`,
    recalculado: rec, unidade: f.saida.si, jogo, jogoFonte, absDiff: abs, relDiff: rel, tol, estado,
    nota: [faltando.length ? `ausente: ${faltando.map((e) => e.sym).join(", ")}` : "", !dimOk(f) ? "fórmula dimensionalmente inconsistente" : "", nota].filter(Boolean).join(" · "),
  };
}
const chk = (id: string, titulo: string, estado: Estado, detalhe: string, o: { essencial?: boolean; fisico?: boolean; calc?: Calc } = {}): Check =>
  ({ id, titulo, estado, detalhe, essencial: o.essencial ?? true, fisico: o.fisico ?? true, calc: o.calc });
const show = (x: number | null, u: string) => (u === "m³" && x != null ? `${fx(x * 1e6, 3)} cm³` : `${fx(x, 4)} ${u === "—" ? "" : u}`.trim());
const fromCalc = (id: string, titulo: string, c: Calc, o: { essencial?: boolean; fisico?: boolean } = {}) =>
  chk(id, titulo, c.estado, c.estado === "APROVADO" ? `recalculado ${show(c.recalculado, c.unidade)} = jogo ${show(c.jogo, c.unidade)} (Δ ${fx((c.relDiff ?? 0) * 100, 3)} % ≤ ${c.tol * 100} %)`
    : c.estado === "REPROVADO" ? `recalculado ${show(c.recalculado, c.unidade)} ≠ jogo ${show(c.jogo, c.unidade)} (Δ abs ${show(c.absDiff, c.unidade)} · rel ${fx((c.relDiff ?? 0) * 100, 2)} % > ${c.tol * 100} %)${c.nota ? " · " + c.nota : ""}`
    : c.nota || "sem valor do jogo para comparar", { ...o, calc: c });

// ---------- dados físicos lidos do jogo e das fichas ----------
const catNum = (bikeId: string, k: string): number | null => { const v = ENGINE_CATALOG[bikeId]?.p[k]?.valor; return typeof v === "number" ? v : null; };
/** Ø declarado no nome/especificação da peça (mm). Peça de fábrica usa a ficha do fabricante. */
export function boreOf(p: Part, bikeId: string): Dado {
  if (p.factory) return { nome: "Ø", valor: catNum(bikeId, "diametro"), unidade: "mm", origem: catNum(bikeId, "diametro") != null ? "FICHA" : "AUSENTE", fonte: "engine_catalog (ficha do fabricante)" };
  const m = /(?:Ø\s*)?(\d{2}[,.]\d)\s*(?:mm)?/.exec(`${p.name} ${p.spec}`);
  if (m && (/mm|Ø/.test(`${p.name} ${p.spec}`))) return { nome: "Ø", valor: num(m[1]), unidade: "mm", origem: "JOGO", fonte: `nome/especificação da peça: "${p.name}"` };
  if (/std/i.test(`${p.id} ${p.spec}`)) return { nome: "Ø", valor: catNum(bikeId, "diametro"), unidade: "mm", origem: "FICHA", fonte: "peça STD = Ø de fábrica" };
  return { nome: "Ø", valor: null, unidade: "mm", origem: "AUSENTE", fonte: "peça não informa o diâmetro" };
}
export { pinOffsetMm };
/** Curso real montado: ficha do modelo + pino cursado (serviço). */
export function strokeReal(bikeId: string, s: Setup): Dado {
  const c = strokeMmOf(bikeId);
  const off = pinOffsetMm(s);
  return { nome: "S real", valor: c == null ? null : c + off, unidade: "mm", origem: c == null ? "AUSENTE" : off ? "CALCULADO" : "FICHA", fonte: off ? `ficha ${fx(c)} mm + pino cursado +${off} mm` : "ficha do fabricante" };
}
function ratios(bikeId: string): { prim: number | null; marchas: number[] } {
  const p = ENGINE_CATALOG[bikeId]?.p;
  const prim = /^(\d+[,.]\d+)/.exec(String(p?.["relacaoPrimaria"]?.valor ?? ""));
  const ms = [...String(p?.["relacoesCambio"]?.valor ?? "").matchAll(/ª\s*(\d+[,.]\d+)/g)].map((m) => num(m[1]));
  return { prim: prim ? num(prim[1]) : null, marchas: ms };
}
const torqueNm = (b: BikeModel, s: Setup) => stats(b, s).torque * 9.80665;

// ---------- NÍVEL 2: conexões de um conjunto montado ----------
export function conexoes(bikeId: string, s: Setup, tol: Tol = TOL_PADRAO): Conexao[] {
  const b = bikeModel(bikeId);
  const geo = geoOf(b, s);
  const sr = strokeReal(bikeId, s);
  const rod = rodMmOf(bikeId);
  const cyl = slotPart(s.slots.cilindro, "cilindro"), pis = slotPart(s.slots.pistao, "pistao"), bie = slotPart(s.slots.biela, "biela");
  const dc = boreOf(cyl, bikeId), dp = boreOf(pis, bikeId);
  const out: Conexao[] = [];
  const add = (id: string, origem: string, destino: string, tipo: string, compartilhados: string[], checks: Check[]) =>
    out.push({ id, origem, destino, tipo, compartilhados, formulas: [...new Set(checks.map((c) => c.calc?.formulaId).filter((x): x is string => !!x))], checks, estado: pior(checks.map((c) => c.estado)) });

  // Virabrequim + biela
  const S = typeof sr.valor === "number" ? sr.valor : null;
  const lam = conferir("lambda-biela", [{ sym: "r", valor: S == null ? null : S / 2000, unidade: "m", origem: sr.origem }, { sym: "L", valor: rod == null ? null : rod / 1000, unidade: "m", origem: rod == null ? "AUSENTE" : "FICHA" }],
    geo.rM / geo.lM, "enginephys.geoOf → rM/lM", tol.geometria, "o jogo usa o curso do catálogo na cinemática");
  const rpmLim = engine(b, s).rpmLimit;
  const vpm = conferir("vpm", [{ sym: "S", valor: S == null ? null : S / 1000, unidade: "m", origem: sr.origem }, { sym: "n", valor: rpmLim, unidade: "1/min", origem: "JOGO" }], null, "", tol.numerico);
  add("vira-biela", "Virabrequim", "Biela", "articulação (moente)", ["curso", "raio da manivela", "biela centro a centro"], [
    chk("curso-jogo", "Curso usado pelo jogo = curso montado", S == null ? "PENDENTE" : Math.abs(geo.strokeMm - S) / S <= tol.geometria ? "APROVADO" : "REPROVADO",
      S == null ? "curso sem ficha" : `montado ${fx(S)} mm (${sr.fonte}) · jogo usa ${fx(geo.strokeMm)} mm (${geo.strokeOrigem})`),
    fromCalc("lambda", "λ = r/L recalculado vs cinemática do jogo", lam),
    chk("lambda-lim", "λ dentro do limite de projeto (< 0,35)", lam.recalculado == null ? "PENDENTE" : lam.recalculado < 0.35 ? "APROVADO" : "REPROVADO",
      lam.recalculado == null ? "faltam dados" : `λ = ${fx(lam.recalculado, 4)} · β_max = ${fx(Math.asin(lam.recalculado) * 180 / Math.PI, 2)}°`),
    chk("vpm", "Velocidade média do pistão no corte", vpm.recalculado == null ? "PENDENTE" : vpm.recalculado < 20 ? "APROVADO" : "REPROVADO",
      vpm.recalculado == null ? "faltam dados" : `Vp = 2·${fx(S! / 1000, 5)}·${rpmLim}/60 = ${fx(vpm.recalculado, 3)} m/s (ref. < 20 m/s)`, { calc: vpm }),
    chk("massas", "Massa alternativa e rotativa", "PENDENTE", "massa do pistão/biela sem ficha (catálogo: DESCONHECIDO); o jogo usa recKg ESTIMADO"),
  ]);

  // Biela + pistão
  const pinFicha = catNum(bikeId, "pinoPistao");
  const bPin = bie.factory || /std/i.test(`${bie.id} ${bie.spec}`) ? pinFicha : (() => { const m = /(\d{2})\s*mm/.exec(bie.spec); return m ? Number(m[1]) : null; })();
  const pPin = pis.factory || /std/i.test(`${pis.id} ${pis.spec}`) ? pinFicha : null;
  add("biela-pistao", "Biela", "Pistão", "pino do pistão", ["diâmetro do pino", "altura de compressão"], [
    chk("pino", "Ø do pino: olhal da biela = furo do pistão", bPin == null || pPin == null ? "PENDENTE" : bPin === pPin ? "APROVADO" : "REPROVADO",
      `biela ${bPin == null ? "AUSENTE" : fx(bPin) + " mm"} (${bie.name}) · pistão ${pPin == null ? "AUSENTE" : fx(pPin) + " mm"} (${pis.name})${bPin != null && pPin == null ? " — pistão não informa o pino" : ""}`),
    chk("altura-comp", "Altura de compressão do pistão", "PENDENTE", "sem medida; o jogo usa compHeightMm ESTIMADO"),
  ]);

  // Pistão + cilindro
  const dcv = typeof dc.valor === "number" ? dc.valor : null, dpv = typeof dp.valor === "number" ? dp.valor : null;
  add("pistao-cilindro", "Pistão", "Cilindro", "ajuste deslizante", ["diâmetro", "folga de montagem", "dilatação térmica"], [
    chk("diametro", "Ø pistão = Ø cilindro", dcv == null || dpv == null ? "PENDENTE" : Math.abs(dcv - dpv) <= 0.05 ? "APROVADO" : "REPROVADO",
      `cilindro ${dcv == null ? "AUSENTE" : fx(dcv) + " mm"} (${dc.fonte}) · pistão ${dpv == null ? "AUSENTE" : fx(dpv) + " mm"} (${dp.fonte})`),
    chk("folga", "Folga de montagem e dilatação", "PENDENTE", "folga pistão-cilindro sem ficha; não presumida"),
  ]);

  // Virabrequim + cilindro + pistão + biela: cilindrada real
  const vd = conferir("vd", [{ sym: "D", valor: dcv == null ? null : dcv / 1000, unidade: "m", origem: dc.origem }, { sym: "S", valor: S == null ? null : S / 1000, unidade: "m", origem: sr.origem }],
    ccOf(b, s) * 1e-6, "physics.ccOf (cc declarado do kit)", tol.geometria);
  const boreJogo = conferir("vd", [{ sym: "D", valor: geo.boreMm / 1000, unidade: "m", origem: "JOGO" }, { sym: "S", valor: geo.strokeMm / 1000, unidade: "m", origem: "JOGO" }],
    vd.recalculado, "Vd do conjunto montado (Ø peça × curso real)", tol.geometria, `o jogo deriva Ø ${fx(geo.boreMm)} mm de cc e curso de catálogo`);
  const vc = vd.recalculado == null ? null : vd.recalculado / (s.compression - 1);
  const taxa = conferir("taxa", [{ sym: "Vd", valor: vd.recalculado, unidade: "m³", origem: "CALCULADO" }, { sym: "Vc", valor: null, unidade: "m³", origem: "AUSENTE" }], s.compression, "Setup.compression", tol.numerico, "volume da câmara não medido");
  add("motor-basico", "Virabrequim + Biela", "Pistão + Cilindro", "conjunto alternativo", ["curso real", "volume deslocado", "taxa de compressão"], [
    fromCalc("cc", "Cilindrada real (Ø × curso montado) = cc usado pelo jogo", vd),
    fromCalc("geo-jogo", "Geometria interna do jogo reproduz o volume montado", boreJogo),
    chk("taxa", "Taxa calculada com volume real da câmara", "PENDENTE", `taxa declarada ${fx(s.compression, 2)}:1; Vc exigido = ${fx(vc == null ? null : vc * 1e6, 2)} cm³, mas a câmara não foi medida`, { calc: taxa }),
    chk("pms-pmi", "Pistão alcança PMS/PMI e altura de bloco", "PENDENTE", "altura do cilindro, junta e altura de compressão ausentes"),
  ]);

  // Cabeçote + comando + válvulas + pistão
  const bd = buildOf(b, s);
  add("cabecote-pistao", "Cabeçote + Comando + Válvulas", "Pistão", "sincronismo e folga pistão-válvula", ["levantamento", "duração", "folga pistão-válvula"], [
    chk("folga-pv", "Folga pistão-válvula > 0", bd.clearance0 <= 0 ? "REPROVADO" : "INCONCLUSIVO",
      `jogo: ${fx(bd.clearance0, 2)} mm (modelo ESTIMADO: 1,1 − 0,5·serviços de levante − 0,03·risco do comando + cava; cavas ${bd.cavas ? "sim" : "não"}); conta correta, parâmetros não medidos`),
    chk("sincronismo", "Sincronismo e duração do comando", "PENDENTE", `comando "${s.cam}": duração e ângulos de abertura sem ficha`),
    chk("valvulas", "Diâmetro das válvulas", "PENDENTE", "diâmetro de válvula sem ficha no catálogo"),
  ]);

  // Embreagem + câmbio + final + pneu
  const tq = torqueNm(b, s), cap = clutchCapNm(s);
  const { prim, marchas } = ratios(bikeId);
  const r = drivetrain(b, s).rDynM; // raio dinâmico do pneu montado (o mesmo da corrida)
  const gs = gearSpeeds(b, s);
  const gearChecks = marchas.map((g, i) => {
    const c = conferir("vel-marcha", [{ sym: "n", valor: rpmLim, unidade: "1/min", origem: "JOGO" }, { sym: "i", valor: prim == null ? null : prim * g * (s.rear / s.front), unidade: "—", origem: prim == null ? "AUSENTE" : "FICHA" }, { sym: "r", valor: r, unidade: "m", origem: r == null ? "AUSENTE" : "CALCULADO" }],
      gs[i] == null ? null : gs[i]! / 3.6, "physics.drivetrain (primária × marcha × coroa/pinhão, r_din)", tol.velocidade, "raio dinâmico = estático × fator de rolagem (estimado)");
    return fromCalc(`marcha-${i + 1}`, `${i + 1}ª: velocidade no corte (fichas de relação × pneu) = jogo`, c);
  });
  add("transmissao", "Embreagem + Câmbio + Pinhão/Coroa", "Pneu", "cadeia de redução", ["torque", "relações", "raio do pneu"], [
    chk("embreagem", "Embreagem suporta o torque do motor", tq <= cap ? "APROVADO" : "REPROVADO", `torque ${fx(tq, 2)} N·m (stats: kgf·m × 9,80665) vs capacidade ${fx(cap, 1)} N·m (margem ${fx((cap / tq - 1) * 100, 1)} %)`, { essencial: true }),
    ...gearChecks,
    chk("raio-din", "Raio dinâmico do pneu", "PENDENTE", `raio geométrico ${fx(r, 4)} m (${b.tires}); raio dinâmico sob carga não medido`, { essencial: false }),
  ]);

  // Alimentação: bico + bomba vs demanda
  const e = engine(b, s);
  const inj = injectionAt(b, s, e.rpmPeak, 1);
  const fuelCyc = inj.demandCcMin / (e.rpmPeak / 2);
  const du = conferir("duty", [{ sym: "q", valor: fuelCyc, unidade: "cm³", origem: "JOGO" }, { sym: "Q", valor: inj.injCcMin, unidade: "cm³/min", origem: "JOGO" }, { sym: "t0", valor: inj.deadMs, unidade: "ms", origem: "ESTIMADO" }, { sym: "n", valor: e.rpmPeak, unidade: "1/min", origem: "JOGO" }],
    inj.duty / 100, "enginephys.injectionAt", tol.numerico);
  add("alimentacao", "Bomba + Bico", "Motor", "vazão de combustível", ["demanda", "vazão do bico", "pressão de linha"], [
    fromCalc("duty", "Duty do bico recalculado = jogo", du),
    chk("duty-lim", "Bico atende à demanda (duty < 100 %)", du.recalculado == null ? "PENDENTE" : du.recalculado < 1 ? "APROVADO" : "REPROVADO", `duty ${fx((du.recalculado ?? 0) * 100, 1)} % a ${Math.round(e.rpmPeak)} rpm`),
    chk("bomba", "Bomba acompanha a demanda", inj.pumpCcMin >= inj.demandCcMin ? "APROVADO" : "REPROVADO", `bomba ${fx(inj.pumpCcMin, 1)} cm³/min (vazão ESTIMADA) vs demanda ${fx(inj.demandCcMin, 1)} cm³/min`),
  ]);

  // Ignição e escape: sem ficha → não presumir
  add("ignicao-escape", "Ignição + Escape", "Combustão", "ponto e fluxo de saída", ["avanço", "diâmetro e comprimento do tubo"], [
    chk("ponto", "Avanço de ignição", "PENDENTE", "curva de avanço de fábrica sem ficha; ótimo do jogo é ESTIMADO", { essencial: false }),
    chk("escape", "Escape casado com a cilindrada", "INCONCLUSIVO", "geometria do tubo vem do modelo de escape do jogo (exhaust.ts), sem medição", { essencial: false }),
  ]);
  return out;
}

// ---------- NÍVEL 1: ficha individual ----------
const CAT: Record<string, string> = { cilindro: "Motor", pistao: "Motor", biela: "Motor", vira: "Motor", comando: "Motor", cabecote: "Motor", molas: "Motor", valvula: "Motor", bico: "Combustível e injeção", bomba: "Combustível e injeção", tbi: "Combustível e injeção", modulo: "Gerenciamento", escape: "Escape", embreagem: "Transmissão", kit: "Transmissão", pinhao: "Transmissão", coroa: "Transmissão", pneu: "Rodagem", roda: "Rodagem", susp: "Rodagem" };
const MEC: Record<string, string[]> = { cilindro: ["Cilindrada", "Compressão", "Torque"], pistao: ["Cinemática do pistão", "Esforços mecânicos", "Compressão"], biela: ["Cinemática do pistão", "Esforços mecânicos"], vira: ["Cinemática do pistão", "Cilindrada"], comando: ["Combustão", "Rotação"], bico: ["Injeção", "Vazão", "Mistura"], bomba: ["Vazão", "Injeção"], embreagem: ["Embreagem", "Patinagem", "Torque transmitido"], kit: ["Relações de marcha", "Velocidade"], pinhao: ["Relações de marcha"], coroa: ["Relações de marcha"], escape: ["Potência"], modulo: ["Mistura", "Rotação"], pneu: ["Aderência", "Resistência ao rolamento"] };
const CON: Record<string, string[]> = { cilindro: ["pistao", "cabecote"], pistao: ["cilindro", "biela", "cabecote"], biela: ["pistao", "vira"], vira: ["biela", "embreagem"], comando: ["cabecote", "pistao"], bico: ["bomba", "modulo"], bomba: ["bico"], embreagem: ["vira", "cambio"], kit: ["cambio", "pneu"], pinhao: ["coroa", "cambio"], coroa: ["pinhao", "pneu"], escape: ["cabecote"], modulo: ["bico"], pneu: ["coroa", "solo"] };

/** Assinatura observável do jogo: se a peça declara um efeito, alguma destas saídas tem de mudar. */
function assinatura(b: BikeModel, s: Setup) {
  const e = engine(b, s), st = stats(b, s), t = tireOf(s);
  return { hp: e.hp, rpm: e.rpmLimit, kg: st.kg, top: gearSpeeds(b, s).at(-1) ?? 0, cap: clutchCapNm(s), duty: injectionAt(b, s, 8000, 1).duty, crr: t.crr, grip: t.grip, cc: ccOf(b, s) };
}
export function ficha(e: ShopEntry, tol: Tol = TOL_PADRAO): Ficha | null {
  const p = e.part; if (!p) return null;
  const bikeId = e.bikeId ?? "titan160";
  const b = bikeModel(bikeId);
  const s = setupFor(e);
  const dados: Dado[] = [
    { nome: "Fabricante", valor: p.brand || null, unidade: "—", origem: p.brand ? "JOGO" : "AUSENTE", fonte: "parts.ts" },
    { nome: "Material", valor: null, unidade: "—", origem: "AUSENTE", fonte: "liga/tratamento não informados" },
    { nome: "Massa vs original", valor: p.kg ?? null, unidade: "kg", origem: p.kg != null ? "JOGO" : "AUSENTE", fonte: "parts.ts › kg" },
    { nome: "Tolerâncias dimensionais", valor: null, unidade: "mm", origem: "AUSENTE", fonte: "não informadas" },
  ];
  if (p.cc != null) dados.push({ nome: "Cilindrada declarada", valor: p.cc, unidade: "cm³", origem: "JOGO", fonte: "parts.ts › cc" });
  if (["cilindro", "pistao"].includes(p.kind)) dados.push(boreOf(p, bikeId));
  if (p.clutchNm != null) dados.push({ nome: "Capacidade da embreagem", valor: p.clutchNm, unidade: "N·m", origem: "JOGO", fonte: "parts.ts › clutchNm" });
  if (p.flow != null) dados.push({ nome: "Vazão relativa", valor: p.flow, unidade: "× original", origem: "JOGO", fonte: "parts.ts › flow" });
  if (p.front != null) dados.push({ nome: "Pinhão", valor: p.front, unidade: "dentes", origem: "JOGO", fonte: "parts.ts" });
  if (p.rear != null) dados.push({ nome: "Coroa", valor: p.rear, unidade: "dentes", origem: "JOGO", fonte: "parts.ts" });
  const lift = /Levante\s+Adm\s+(\d+[,.]\d+)/.exec(p.spec); if (lift) dados.push({ nome: "Levante admissão", valor: num(lift[1]), unidade: "mm", origem: "JOGO", fonte: "especificação" });

  const checks: Check[] = [];
  if (p.kind === "cilindro") {
    const d = boreOf(p, bikeId), sr = strokeReal(bikeId, s);
    const c = conferir("vd", [{ sym: "D", valor: typeof d.valor === "number" ? d.valor / 1000 : null, unidade: "m", origem: d.origem }, { sym: "S", valor: typeof sr.valor === "number" ? sr.valor / 1000 : null, unidade: "m", origem: sr.origem }], ccOf(b, s) * 1e-6, "physics.ccOf", tol.geometria);
    checks.push(fromCalc("cc", "Cilindrada declarada = π/4·D²·S (curso montado)", c));
  }
  if (p.kind === "embreagem") { const tq = torqueNm(b, { ...STOCK_SETUP }); checks.push(p.clutchNm == null ? chk("cap", "Capacidade ≥ torque da moto original", "PENDENTE", "peça não declara capacidade de torque") : chk("cap", "Capacidade ≥ torque da moto original", p.clutchNm >= tq ? "APROVADO" : "REPROVADO", `${fx(p.clutchNm)} N·m vs ${fx(tq, 2)} N·m (margem ${fx((p.clutchNm / tq - 1) * 100, 1)} %)`)); }
  if (p.kind === "pinhao" || p.kind === "coroa" || p.kind === "kit") {
    const i = s.rear / s.front; const gs = gearSpeeds(b, s).at(-1)!, g0 = gearSpeeds(b, STOCK_SETUP).at(-1)!;
    const rel = (STOCK_SETUP.rear / STOCK_SETUP.front) / i;
    checks.push(chk("relacao", "Velocidade final escala com a relação (v ∝ 1/i)", Math.abs(gs / g0 - rel) <= tol.numerico ? "APROVADO" : "REPROVADO", `i = ${s.rear}/${s.front} = ${fx(i, 4)} · v_jogo/v_std ${fx(gs / g0, 4)} vs esperado ${fx(rel, 4)}`));
  }
  if (p.kind === "biela") checks.push(chk("comprimento", "Comprimento centro a centro", /std/i.test(`${p.id} ${p.spec}`) && rodMmOf(bikeId) != null ? "APROVADO" : "PENDENTE", /std/i.test(`${p.id} ${p.spec}`) ? `STD = ficha ${fx(rodMmOf(bikeId))} mm` : `especificação "${p.spec}" não define o comprimento`));
  if (p.kind === "pistao") {
    const d = boreOf(p, bikeId);
    checks.push(chk("diametro", "Diâmetro do pistão informado", d.valor == null ? "PENDENTE" : "APROVADO", d.valor == null ? d.fonte : `Ø ${fx(d.valor as number)} mm (${d.fonte})`));
    const pin = p.factory || /std/i.test(`${p.id} ${p.spec}`) ? catNum(bikeId, "pinoPistao") : null;
    checks.push(chk("pino", "Diâmetro do pino e altura de compressão", pin == null ? "PENDENTE" : "INCONCLUSIVO", pin == null ? "pino e altura de compressão não informados" : `pino ${fx(pin)} mm (ficha); altura de compressão AUSENTE`));
  }
  if (p.kind === "comando") checks.push(chk("duracao", "Duração e sincronismo", "PENDENTE", "só o levante é informado"));
  if (p.kind === "bico") checks.push(chk("vazao", "Vazão absoluta do bico", "INCONCLUSIVO", `vazão relativa ${fx(p.flow)}× sobre base ESTIMADA (EST.injFlowCcMin)`));
  checks.push(chk("material", "Propriedades do material", "PENDENTE", "material não informado — resistência e limite térmico não verificáveis", { essencial: false }));

  // usado pelo jogo?
  const a0 = assinatura(b, STOCK_SETUP), a1 = assinatura(b, s);
  const mudou = (Object.keys(a0) as (keyof typeof a0)[]).filter((k) => Math.abs(a0[k] - a1[k]) > 1e-9);
  const igualStd = (p.front == null || p.front === STOCK_SETUP.front) && (p.rear == null || p.rear === STOCK_SETUP.rear) && (p.front != null || p.rear != null) && p.kind !== "kit" ? true : p.kind === "kit" && (p.front ?? STOCK_SETUP.front) === STOCK_SETUP.front && (p.rear ?? STOCK_SETUP.rear) === STOCK_SETUP.rear;
  const declara = !igualStd && (p.hpMul != null || (p.flow != null && p.flow !== 1) || p.clutchNm != null || p.front != null || p.rear != null || !!p.cam || p.crr != null || p.grip != null || p.kg != null || p.cc != null || !!p.bundle);
  const std = /std/i.test(`${p.id} ${p.spec}`) || igualStd;
  const usado = chk("usado", "O resultado chega ao jogo", mudou.length ? "APROVADO" : std || !declara ? "INCONCLUSIVO" : "REPROVADO",
    mudou.length ? `saídas alteradas: ${mudou.join(", ")}` : std ? "peça equivalente à original: nenhuma saída deve mudar e nenhuma mudou" : declara ? "peça declara efeito mas nenhuma saída do jogo mudou" : "peça sem parâmetro físico que o jogo leia", { fisico: false });
  const mats = checks.filter((c) => c.calc).map((c) => c.estado);
  const fis = checks.filter((c) => c.fisico && c.essencial).map((c) => c.estado);
  const estadoMat = mats.length ? pior(mats) : "INCONCLUSIVO", estadoFis = fis.length ? pior(fis) : "INCONCLUSIVO";
  return {
    id: p.id, nome: p.name, categoria: CAT[p.kind] ?? "Outros", grupo: e.grupo, marca: p.brand, bikes: e.bikeId ? [e.bikeId] : ["titan160", "factor150"], dados, checks,
    mecanicas: MEC[p.kind] ?? [], conectados: CON[p.kind] ?? [], formulas: [...new Set(checks.map((c) => c.calc?.formulaId).filter((x): x is string => !!x))],
    usadoPeloJogo: usado, estadoMat, estadoFis, estado: fis.length ? pior([...checks.filter((c) => c.essencial).map((c) => c.estado), usado.estado]) : pior(["INCONCLUSIVO", usado.estado]),
  };
}
/** Catálogo = espelho da loja jogável (shop-catalog), nunca o catálogo geral. */
export const catalogoAtivo = (tol: Tol = TOL_PADRAO) => shopListing().map((e) => ficha(e, tol)).filter((f): f is Ficha => !!f);

// ---------- NÍVEL 3 + funil ----------
const PERG: [string, string][] = [
  ["O curso real corresponde ao informado?", "vira-biela/curso-jogo"], ["O pistão alcança corretamente o PMS e PMI?", "motor-basico/pms-pmi"],
  ["O comprimento da biela é compatível?", "vira-biela/lambda-lim"], ["A altura de compressão do pistão está correta?", "biela-pistao/altura-comp"],
  ["Existe interferência entre pistão e cabeçote?", "cabecote-pistao/folga-pv"], ["A taxa de compressão foi calculada com o volume real?", "motor-basico/taxa"],
  ["O comando possui sincronismo compatível?", "cabecote-pistao/sincronismo"], ["As válvulas possuem folga suficiente?", "cabecote-pistao/valvulas"],
  ["A embreagem suporta o torque calculado?", "transmissao/embreagem"], ["A transmissão utiliza relações coerentes?", "transmissao/marcha-1"],
  ["O pneu possui raio dinâmico corretamente considerado?", "transmissao/raio-din"], ["O sistema de alimentação atende à demanda calculada?", "alimentacao/duty-lim"],
];
const DEPS: Record<string, string[]> = { "vira-biela": ["motor-basico", "biela-pistao"], "biela-pistao": ["motor-basico"], "pistao-cilindro": ["motor-basico", "cabecote-pistao"], "motor-basico": ["alimentacao", "transmissao"], "cabecote-pistao": ["motor-basico"], transmissao: [], alimentacao: [], "ignicao-escape": [] };

export function auditar(a: { bikeId: string; setup: Setup; motivo: string; componente?: string; mecanica?: string; at?: string; tentativa?: number }, tol: Tol = TOL_PADRAO): Auditoria {
  const at = a.at ?? new Date().toISOString();
  const snapshot = structuredClone(a.setup);
  const hash = hashOf({ bike: a.bikeId, setup: snapshot, v: DADOS_VERSION });
  const b = bikeModel(a.bikeId);
  const recebido = !!ENGINE_CATALOG[a.bikeId] && !!snapshot.slots && Number.isFinite(snapshot.compression);
  const conx = recebido ? conexoes(a.bikeId, snapshot, tol) : [];
  const shop = shopListing();
  const montadas = new Set([...Object.values(snapshot.slots), `comando-${snapshot.cam}`]);
  const fichas = shop.filter((e) => e.part && montadas.has(e.part.id)).map((e) => ficha(e, tol)).filter((f): f is Ficha => !!f);
  const flat = conx.flatMap((c) => c.checks.map((k) => ({ ...k, ref: `${c.id}/${k.id}`, con: c })));
  const perguntas: Pergunta[] = PERG.map(([q, ref], i) => { const k = flat.find((x) => x.ref === ref); return { n: i + 1, pergunta: q, ref, estado: k?.estado ?? "PENDENTE", resposta: k?.detalhe ?? "sem verificação" }; });
  const formulasUsadas = [...new Set(flat.map((k) => k.calc?.formulaId).filter((x): x is string => !!x))];
  const dimFail = formulasUsadas.filter((id) => !dimOk(formula(id)));
  const calcs = flat.filter((k) => k.calc);
  const peca = fichas.length ? pior(fichas.map((f) => f.estado)) : "INCONCLUSIVO";
  const conexao = conx.length ? pior(conx.map((c) => c.estado)) : "PENDENTE";
  const essenciais = flat.filter((k) => k.essencial).map((k) => k.estado);
  const conjunto = pior([...essenciais, peca, conexao]);
  const e = engine(b, snapshot), tq = torqueNm(b, snapshot);
  const { prim, marchas } = ratios(a.bikeId);
  const cadeia = [
    { etapa: "Motor (stats)", valor: `${fx(tq, 2)} N·m · ${fx(e.hp, 1)} cv @ ${Math.round(e.rpmPeak)} rpm` },
    { etapa: "Embreagem", valor: `capacidade ${fx(clutchCapNm(snapshot), 1)} N·m` },
    { etapa: "Primária", valor: prim == null ? "AUSENTE" : `× ${fx(prim, 3)} → ${fx(tq * (prim ?? 0), 1)} N·m` },
    { etapa: "1ª marcha", valor: marchas[0] == null ? "AUSENTE" : `× ${fx(marchas[0], 3)} → ${fx(tq * (prim ?? 0) * marchas[0], 1)} N·m` },
    { etapa: "Final (coroa/pinhão)", valor: `× ${snapshot.rear}/${snapshot.front} = ${fx(snapshot.rear / snapshot.front, 3)} → ${fx(tq * (prim ?? 0) * (marchas[0] ?? 0) * snapshot.rear / snapshot.front, 1)} N·m` },
    { etapa: `Roda (× η ${ETA})`, valor: `${fx(tq * (prim ?? 0) * (marchas[0] ?? 0) * snapshot.rear / snapshot.front * ETA, 1)} N·m` },
    { etapa: "Pneu → solo", valor: (() => { const r = drivetrain(b, snapshot).rDynM; return r ? `F = T/r_din = ${fx(tq * (prim ?? 0) * (marchas[0] ?? 0) * snapshot.rear / snapshot.front * ETA / r, 0)} N (limitada por μ·N no ground.ts)` : "raio AUSENTE"; })() },
  ];
  const problemas: Problema[] = flat.filter((k) => k.estado === "REPROVADO").map((k) => ({
    principal: k.titulo, componente: k.con.origem, conexao: `${k.con.origem} → ${k.con.destino}`, causa: k.calc?.nota || k.detalhe,
    evidencia: k.calc ? `${k.calc.eq} · ${k.calc.substituicao} → ${fx(k.calc.recalculado, 6)} ${k.calc.unidade} vs jogo ${fx(k.calc.jogo, 6)} (${k.calc.jogoFonte})` : k.detalhe,
    consequencias: `afeta ${(DEPS[k.con.id] ?? []).join(", ") || "somente esta conexão"}`,
    correcao: k.calc ? `fazer ${k.calc.jogoFonte} usar ${k.calc.eq} com os dados montados (requer aprovação técnica — Eng IA não altera o jogo)` : "revisar a peça ou o dado de origem",
    dependentes: DEPS[k.con.id] ?? [], regressao: [`${k.con.id}/${k.id}`, ...(DEPS[k.con.id] ?? [])],
  }));
  const funcionais = flat.filter((k) => ["curso-jogo", "geo-jogo", "cc", "duty"].includes(k.id) || k.id.startsWith("marcha-")).map((k) => k.estado);
  const etapas: Etapa[] = [
    { n: 1, nome: "Recebimento", estado: recebido ? "APROVADO" : "PENDENTE", detalhe: recebido ? `moto ${b.name}, ${Object.keys(snapshot.slots).length} slots, hash ${hash}` : "dados incompletos" },
    { n: 2, nome: "Identificação matemática", estado: !formulasUsadas.length ? "PENDENTE" : dimFail.length ? "REPROVADO" : "APROVADO", detalhe: `${formulasUsadas.length} fórmulas: ${formulasUsadas.join(", ")}${dimFail.length ? ` · inconsistentes: ${dimFail.join(", ")}` : " · dimensões conferidas"}` },
    { n: 3, nome: "Conferência independente", estado: pior(calcs.map((k) => k.estado)), detalhe: `${calcs.filter((k) => k.estado === "APROVADO").length}/${calcs.length} recálculos batem com o jogo` },
    { n: 4, nome: "Conferência física", estado: pior(flat.filter((k) => k.fisico && !k.calc).map((k) => k.estado)), detalhe: `${flat.filter((k) => k.fisico && !k.calc).length} limites e relações físicas verificados` },
    { n: 5, nome: "Conferência dos componentes", estado: peca, detalhe: `${fichas.length} peças montadas com ficha individual` },
    { n: 6, nome: "Conferência funcional", estado: pior([...funcionais, ...fichas.map((f) => f.usadoPeloJogo.estado)]), detalhe: "curso, geometria, cilindrada, velocidades e injeção comparados com o que o jogo usa" },
    { n: 7, nome: "Resultado", estado: conjunto, detalhe: `peça ${peca} · conexão ${conexao} · conjunto ${conjunto}` },
  ];
  const chave = hashOf({ bike: a.bikeId, setup: snapshot });
  return { id: `ED-${hash}-${fnv(at)}`, at, motivo: a.motivo, bikeId: a.bikeId, bike: b.name, componente: a.componente ?? "conjunto completo", mecanica: a.mecanica ?? "todas", versao: DADOS_VERSION, hash, snapshot, tol,
    etapas, fichas, conexoes: conx, perguntas, cadeia, problemas, niveis: { peca, conexao, conjunto }, estado: conjunto, tentativa: a.tentativa ?? 1, chave };
}
export { FORMULAS };
