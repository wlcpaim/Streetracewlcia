import { useEffect, useMemo, useRef, useState } from "react";
import { DadosPanel } from "./dados/DadosPanel";
import { readAp, sendToFunnel, nexusAudit, saveAp } from "../autopecas/autopecas";
import { dealerListing } from "../shop-catalog";
import {
  BIKES, CRITERIOS, approvedBikes, approvedFor, bikeApproved, byBest, catalog, finalize, markStale, nomeDe, prepare,
  readEng, runBatch, saveEng, setPublished, type Classe, type EngState, type Job, type Preset,
} from "./eng";

const MENU = ["Engenharia de Dados", "Painel geral", "Motocicletas", "Laboratório de testes", "Execuções em andamento", "Histórico de testes", "Presets", "Comparador", "Kits completos", "Relatórios técnicos", "WikiStreetRace", "Banco de componentes", "Configurações da ENG IA"] as const;
type Menu = (typeof MENU)[number];
const CLS: Record<Classe, string> = { "PÉSSIMA": "bg-destructive text-destructive-foreground", "RUIM": "bg-accent text-accent-foreground", "BOA": "bg-secondary text-secondary-foreground", "EXCELENTE": "bg-primary/70 text-primary-foreground", "PERFEITA": "bg-primary text-primary-foreground" };
export const Badge = ({ c }: { c: Classe }) => <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${CLS[c]}`}>{c}</span>;
const Btn = (p: React.ButtonHTMLAttributes<HTMLButtonElement>) => <button {...p} className={`rounded-lg bg-primary px-3 py-1.5 text-sm font-bold text-primary-foreground disabled:opacity-40 ${p.className ?? ""}`} />;
const Card = ({ t, children }: { t: string; children: React.ReactNode }) => <div className="rounded-xl border border-border bg-card p-3"><div className="mb-2 text-xs font-bold uppercase tracking-widest text-muted-foreground">{t}</div>{children}</div>;
const f = (x: number | null | undefined, d = 3) => (x == null ? "—" : x.toFixed(d));

export function EngPanel() {
  const [s, setS] = useState<EngState>(() => markStale(readEng()));
  const [menu, setMenu] = useState<Menu>("Engenharia de Dados");
  const [bike, setBike] = useState("titan160");
  const [running, setRunning] = useState<string | null>(null);
  const [batch, setBatch] = useState(4);
  const [msg, setMsg] = useState("");
  const [ap, setAp] = useState(() => readAp());
  const [cmp, setCmp] = useState<string[]>([]);
  const ref = useRef(s); ref.current = s;
  const commit = (n: EngState) => { setS(n); saveEng(n); };

  useEffect(() => { const f = () => setS(readEng()); window.addEventListener("eng-change", f); return () => window.removeEventListener("eng-change", f); }, []);
  void running; void batch;

  const start = (bikeId: string) => {
    const j = prepare(bikeId, new Date().toISOString(), ap);
    const cur = readEng(); commit({ ...cur, jobs: [...cur.jobs, j], audit: [...cur.audit, { at: j.criado, acao: "INICIAR", alvo: j.id, detalhe: j.status }] });
    if (j.status === "AGUARDANDO") setStatus(j.id, "EXECUTANDO");
    setMenu("Execuções em andamento");
  };
  const setStatus = (id: string, st: Job["status"]) => { const cur = readEng(); commit({ ...cur, jobs: cur.jobs.map((j) => (j.id === id ? { ...j, status: st, heartbeat: Date.now() } : j)) }); };
  const certifyBike = (id: string) => {
    const e = dealerListing().find((d) => d.bikeId === id)!;
    const at = new Date().toISOString(); let r = sendToFunnel(e, id, at);
    if (r.etapa === "AGUARDANDO NEXUS") { r = nexusAudit(r, at); saveAp([...readAp().filter((x) => x.key !== r.key), r]); }
    setAp(readAp()); setMsg(`${e.nome}: ${r.etapa} — ${r.motivo}`);
  };

  const jobs = s.jobs;
  const done = jobs.flatMap((j) => j.casos).filter((c) => c.status === "OK").length;
  const total = jobs.flatMap((j) => j.casos).length;
  const presets = useMemo(() => [...s.presets].sort(byBest), [s.presets]);
  const appBikes = approvedBikes(ap);

  return (
    <div className="flex flex-col gap-4 md:flex-row">
      <aside className="flex shrink-0 flex-row flex-wrap gap-1 md:w-52 md:flex-col">
        {MENU.map((m, i) => <button key={m} onClick={() => setMenu(m)} className={`rounded-lg px-3 py-1.5 text-left text-sm ${menu === m ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>{i + 1}. {m}</button>)}
      </aside>
      <section className="min-w-0 flex-1 space-y-3">
        {msg && <p className="rounded-lg bg-secondary p-2 text-sm">{msg}</p>}

        {menu === "Engenharia de Dados" && <DadosPanel />}
        {menu === "Painel geral" && (
          <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
            {([
              ["Motos aprovadas (NEXUS)", appBikes.length], ["Peças no catálogo", catalog(bike, ap).length], ["Peças aprovadas testáveis", BIKES.reduce((n, b) => n + approvedFor(b.id, ap).length, 0)],
              ["Casos executados", done], ["Casos planejados", total], ["Execuções em andamento", jobs.filter((j) => j.status === "EXECUTANDO").length],
              ["Combinações descartadas", jobs.reduce((n, j) => n + j.descartes.length, 0)], ["Presets salvos", s.presets.length], ["Kits gerados", s.kits.length], ["Kits publicados", s.kits.filter((k) => k.publicado).length],
              ["Última execução", jobs.at(-1)?.atualizado.slice(0, 19).replace("T", " ") ?? "—"], ["Taxa de conclusão", total ? `${Math.round((done / total) * 100)}%` : "—"],
            ] as [string, string | number][]).map(([k, v]) => <Card key={k} t={k}><div className="font-display text-2xl">{v}</div></Card>)}
            <p className="col-span-full text-xs text-muted-foreground">A ENG IA roda em segundo plano enquanto você joga em qualquer tela; ao reabrir o jogo ela continua de onde parou. Cadastrado ≠ testado.</p>
          </div>
        )}

        {(menu === "Motocicletas" || menu === "Laboratório de testes") && BIKES.map((b) => {
          const ok = bikeApproved(ap, b.id); const parts = approvedFor(b.id, ap);
          return (
            <Card key={b.id} t={b.nome}>
              <p className="text-sm">NEXUS: {ok ? `APROVADA em ${ok.nexus?.at.slice(0, 10) ?? "—"} · run ${ok.runId}` : "não aprovada — não entra em testes oficiais"}</p>
              <p className="text-sm">Peças aprovadas para esta moto: {parts.length ? parts.map((r) => r.nome).join(", ") : "nenhuma"}</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {!ok && <Btn onClick={() => certifyBike(b.id)}>Enviar moto ao funil → NEXUS</Btn>}
                <Btn disabled={!ok} onClick={() => { setBike(b.id); start(b.id); }}>START — INICIAR ENGENHARIA</Btn>
              </div>
              <p className="mt-2 text-xs text-muted-foreground">Peças entram aqui depois de aprovadas no Wikipedia StreetRace → Auto Peças.</p>
            </Card>
          );
        })}

        {(menu === "Execuções em andamento" || menu === "Histórico de testes") && [...jobs].reverse().filter((j) => (menu === "Histórico de testes") === (j.status === "CONCLUÍDO")).map((j) => (
          <Card key={j.id} t={`${j.id} · ${j.status}`}>
            <p className="text-sm">Progresso real: {j.casos.filter((c) => c.status !== "PENDENTE").length}/{j.casos.length} casos · descartados {j.descartes.length} · referência {f(j.base?.finishS)} s</p>
            <div className="my-2 flex flex-wrap gap-2">
              {["AGUARDANDO", "PAUSADO", "INTERROMPIDO"].includes(j.status) && <Btn onClick={() => { setStatus(j.id, "EXECUTANDO"); setRunning(j.id); }}>{j.status === "AGUARDANDO" ? "Executar" : "Retomar"}</Btn>}
              {j.status === "EXECUTANDO" && <Btn onClick={() => { setStatus(j.id, "PAUSADO"); setRunning(null); }}>Pausar</Btn>}
              {j.status === "CONCLUÍDO" && <Btn onClick={() => start(j.bikeId)}>Reexecutar</Btn>}
            </div>
            <div className="max-h-72 overflow-auto text-xs">
              <table className="w-full"><thead><tr className="text-left text-muted-foreground"><th>Fase</th><th>Peças</th><th>Tempo s</th><th>km/h</th><th>Stress</th><th>Classe</th></tr></thead>
                <tbody>{j.casos.map((c, i) => <tr key={i} className="border-t border-border"><td>{c.fase}</td><td>{nomeDe(c.partIds)}</td><td>{f(c.m?.finishS)}</td><td>{f(c.m?.vmaxKmh, 1)}</td><td>{f(c.m?.stress, 1)}</td><td>{c.classe ? <Badge c={c.classe} /> : c.status}</td></tr>)}</tbody></table>
              {j.descartes.map((d, i) => <p key={i} className="text-muted-foreground">Descartada: {d.motivo}</p>)}
            </div>
          </Card>
        ))}

        {menu === "Presets" && presets.map((p) => (
          <Card key={p.id} t={p.nome}>
            <div className="flex flex-wrap items-center gap-2 text-sm"><Badge c={p.classe} /> {nomeDe(p.partIds)} · {f(p.m.finishS)} s · {p.objetivo} · {p.data.slice(0, 10)} · {p.versao}
              <label className="ml-auto text-xs"><input type="checkbox" checked={cmp.includes(p.id)} onChange={(e) => setCmp(e.target.checked ? [...cmp, p.id] : cmp.filter((x) => x !== p.id))} /> comparar</label></div>
            <p className="text-xs text-muted-foreground">{p.justificativa}</p>
            <div className="mt-1 flex flex-wrap gap-1">{Object.entries(p.categorias).map(([k, v]) => <span key={k} className="text-xs">{k}: <Badge c={v} /></span>)}</div>
          </Card>
        ))}

        {menu === "Comparador" && <Comparador ps={s.presets.filter((p) => cmp.includes(p.id))} base={jobs.find((j) => j.base)?.base ?? null} />}

        {menu === "Kits completos" && s.kits.map((k) => (
          <Card key={k.id} t={k.nome}>
            <p className="text-sm"><Badge c={k.classe} /> {k.partIds.length} peças: {nomeDe(k.partIds)} · preset {k.presetId}</p>
            <p className="text-xs">Na loja: {k.publicado ? "SIM" : "NÃO"}</p>
            <div className="mt-2 flex gap-2">
              <Btn disabled={k.publicado} onClick={() => { const r = setPublished(s, k.id, true, new Date().toISOString()); setMsg(r.erro ?? "Kit publicado na Moto Peças."); if (!r.erro) commit(r.s); }}>ADICIONAR ÀS AUTOPEÇAS</Btn>
              <Btn disabled={!k.publicado} onClick={() => { const r = setPublished(s, k.id, false, new Date().toISOString()); setMsg("Kit removido da loja (histórico mantido)."); commit(r.s); }}>REMOVER DAS AUTOPEÇAS</Btn>
            </div>
          </Card>
        ))}

        {(menu === "Relatórios técnicos" || menu === "WikiStreetRace") && <Relatorios s={s} />}

        {menu === "Banco de componentes" && (
          <Card t={`Catálogo global · ${BIKES.find((b) => b.id === bike)?.nome}`}>
            <select value={bike} onChange={(e) => setBike(e.target.value)} className="mb-2 rounded bg-secondary p-1 text-sm">{BIKES.map((b) => <option key={b.id} value={b.id}>{b.nome}</option>)}</select>
            <div className="max-h-[60vh] overflow-auto text-xs"><table className="w-full"><thead><tr className="text-left text-muted-foreground"><th>ID</th><th>Categoria</th><th>Nome</th><th>Loja</th><th>Fábrica</th><th>Validação</th></tr></thead>
              <tbody>{catalog(bike, ap).map((c) => <tr key={c.id} className="border-t border-border"><td>{c.id}</td><td>{c.kind}</td><td>{c.nome}</td><td>{c.naLoja ? "sim" : "oculta"}</td><td>{c.fabrica ? "sim" : ""}</td><td>{c.status}</td></tr>)}</tbody></table></div>
          </Card>
        )}

        {menu === "Configurações da ENG IA" && (
          <Card t="Configurações">
            <label className="text-sm">Casos por lote: <input type="number" min={1} max={20} value={batch} onChange={(e) => setBatch(Math.max(1, Math.min(20, +e.target.value || 1)))} className="w-16 rounded bg-secondary p-1" /></label>
            <ul className="mt-2 list-disc pl-5 text-xs">{CRITERIOS.map((c) => <li key={c}>{c}</li>)}</ul>
            <p className="mt-2 text-xs text-muted-foreground">Auditoria ({s.audit.length}): {s.audit.slice(-8).map((a) => `${a.at.slice(11, 19)} ${a.acao} ${a.alvo}`).join(" · ")}</p>
          </Card>
        )}
      </section>
    </div>
  );
}

function Comparador({ ps, base }: { ps: Preset[]; base: Preset["m"] | null }) {
  if (!base || !ps.length) return <p className="text-sm text-muted-foreground">Marque “comparar” em Presets. A referência é a moto original medida na execução.</p>;
  const rows: [string, (m: Preset["m"]) => number | null, string][] = [["Tempo 201 m", (m) => m.finishS, "s"], ["0–100 km/h", (m) => m.t0_100, "s"], ["Vel. máx.", (m) => m.vmaxKmh, "km/h"], ["Potência", (m) => m.hp, "cv"], ["Combustível", (m) => m.fuelL, "L"], ["Carga mecânica", (m) => m.stress, "índice"]];
  return (
    <Card t="Comparador · origem: calculado pelo simulador do jogo (não é medição real)">
      <div className="overflow-auto text-xs"><table className="w-full"><thead><tr className="text-left text-muted-foreground"><th>Métrica</th><th>Original</th>{ps.map((p) => <th key={p.id}>{p.nome}</th>)}</tr></thead>
        <tbody>{rows.map(([n, g, u]) => <tr key={n} className="border-t border-border"><td>{n} ({u})</td><td>{f(g(base))}</td>{ps.map((p) => { const a = g(base), b = g(p.m); return <td key={p.id}>{f(b)} {a != null && b != null && <span className="text-muted-foreground">Δ {(b - a).toFixed(3)} ({a ? (((b - a) / a) * 100).toFixed(2) : "—"}%)</span>}</td>; })}</tr>)}</tbody></table></div>
    </Card>
  );
}

export function Relatorios({ s = readEng() }: { s?: EngState }) {
  if (!s.relatorios.length) return <p className="text-sm text-muted-foreground">Nenhum relatório ainda. Rode uma execução em /engenharia.</p>;
  return <>{[...s.relatorios].reverse().map((r) => (
    <Card key={r.id} t={`${r.id} · v${r.versao} · ${r.comprovado ? "COMPROVADO" : "SIMULAÇÃO (não comprovado experimentalmente)"}`}>
      <pre className="whitespace-pre-wrap text-xs">{r.texto}</pre>
      <Btn className="mt-2" onClick={() => { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([r.texto], { type: "text/plain" })); a.download = `${r.id}.txt`; a.click(); }}>Baixar TXT</Btn>
    </Card>
  ))}</>;
}
