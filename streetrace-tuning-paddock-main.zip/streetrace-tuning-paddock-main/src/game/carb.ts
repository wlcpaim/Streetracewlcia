/**
 * Carburador por circuitos (CG 150 PDC9 / CG 125 Keihin 077A). Escoamento real por orifício:
 *  ar no venturi:   ṁa = Cd_a·A_v·√(2ρa·Δp)        →  Δp = (ṁa/(Cd_a·A_v))² / (2ρa)
 *  combustível:     ṁf = Cd_j·A_ef·√(2ρf·(Δp − ρf·g·h))   (h = altura que o nível da cuba fica abaixo do pulverizador)
 *  agulha:          A_ef = min(A_giclê, π/4·(D_pulv² − d_agulha(θ)²))
 *  lenta/progressão: Δp_lenta = depressão do coletor atrás do pistonete, some com a abertura.
 * O ar (ṁa) vem do ciclo do jogo (enginephys.cycleAt). Giclê, venturi e boia são do manual (platforms.ts);
 * coeficientes de descarga, diâmetro do pulverizador e conicidade da agulha NÃO têm dado de fábrica: ESTIMADO.
 * Só cálculo; não altera a mistura da corrida (o jogador ainda não troca giclês).
 */
import { CONSTANTS } from "./physics-registry/constants";

export const CARB_EST = {
  cdAir: 0.85, // ESTIMADO: venturi de carburador pistonete, literatura 0,8–0,9
  cdJet: 0.65, // ESTIMADO: orifício curto de latão, literatura 0,6–0,75
  needleJetMm: 2.6, // ESTIMADO: pulverizador (needle jet) sem cota de fábrica
  needleMaxMm: 2.5, // ESTIMADO: diâmetro reto da agulha
  needleMinMm: 1.6, // ESTIMADO: ponta da agulha
  clipStepMm: 0.08, // ESTIMADO: cada posição de trava muda o diâmetro efetivo
  headBaseMm: 3, // ESTIMADO: nível nominal abaixo do pulverizador
  pilotOutletVac: 0.03, // ESTIMADO: depressão efetiva no giclê de lenta / P_atm (circuito sangrado pelo giclê de ar; sem medição)
} as const;
const G = 9.81, P_ATM = 101325, R_AIR = 287.05, T_AIR = 300;

export interface CarbJets { alta: number; lenta: number; boiaMm: number; venturiMm: number; clip?: number }
/** Número do giclê Keihin/Mikuni = diâmetro × 100 (mm). */
export const jetDiaMm = (n: number) => n / 100;
const area = (dMm: number) => (Math.PI / 4) * (dMm / 1000) ** 2;
const clamp = (x: number, a = 0, b = 1) => Math.max(a, Math.min(b, x));
const smooth = (a: number, b: number, x: number) => { const t = clamp((x - a) / (b - a)); return t * t * (3 - 2 * t); };

export interface CarbPoint { theta: number; airGs: number; dpVenturiPa: number; mainGs: number; pilotGs: number; fuelGs: number; afr: number; needleAreaMm2: number; jetAreaMm2: number; circuito: "lenta" | "progressão" | "principal" }

/** Vazões no ponto (θ = abertura 0–1, ṁa em kg/s do motor). */
/** Constantes efetivas de um carburador (padrão = CARB_EST). A reconstrução Top-Down (nexus/reconstrucao.ts)
 * resolve por inversão pilotOutletVac e mainSignal de cada moto; nunca alimenta a corrida. */
export interface CarbCal { cdJet: number; pilotOutletVac: number; mainSignal: number; needleMaxMm?: number; needleMinMm?: number; needleJetMm?: number }
export const CARB_DEFAULT_CAL: CarbCal = { cdJet: CARB_EST.cdJet, pilotOutletVac: CARB_EST.pilotOutletVac, mainSignal: 1 };
export function carbAt(j: CarbJets, theta: number, airKgS: number, rhoFuel: number, boiaStockMm = j.boiaMm, cal: CarbCal = CARB_DEFAULT_CAL): CarbPoint {
  const th = clamp(theta, 0.02, 1);
  const rhoA = P_ATM / (R_AIR * T_AIR);
  // pistonete fecha o venturi: área efetiva acompanha a abertura
  const aV = area(j.venturiMm) * Math.max(0.05, th);
  const dp = (airKgS / (CARB_EST.cdAir * aV)) ** 2 / (2 * rhoA);
  // boia mais alta (medida maior no flutuador) = nível mais baixo = mais cabeça a vencer
  const h = (CARB_EST.headBaseMm + (j.boiaMm - boiaStockMm)) / 1000;
  const nMax = cal.needleMaxMm ?? CARB_EST.needleMaxMm, nMin = cal.needleMinMm ?? CARB_EST.needleMinMm;
  const dNeedle = nMax - (nMax - nMin) * smooth(0.25, 0.75, th) - (j.clip ?? 0) * CARB_EST.clipStepMm;
  const aNeedle = Math.max(0, area(cal.needleJetMm ?? CARB_EST.needleJetMm) - area(Math.max(0, dNeedle)));
  const aJet = area(jetDiaMm(j.alta));
  const aMain = Math.min(aJet, aNeedle);
  const mainK = smooth(0.08, 0.3, th); // circuito principal só puxa quando o pistonete abre
  const main = mainK * cal.cdJet * aMain * Math.sqrt(2 * rhoFuel * Math.max(0, cal.mainSignal * dp - rhoFuel * G * h));
  const dpPilot = P_ATM * cal.pilotOutletVac * (1 - smooth(0.05, 0.35, th));
  const pilot = cal.cdJet * area(jetDiaMm(j.lenta)) * Math.sqrt(2 * rhoFuel * Math.max(0, dpPilot - rhoFuel * G * h));
  const fuel = main + pilot;
  return { theta: th, airGs: airKgS * 1000, dpVenturiPa: dp, mainGs: main * 1000, pilotGs: pilot * 1000, fuelGs: fuel * 1000, afr: fuel > 0 ? airKgS / fuel : Infinity,
    needleAreaMm2: aNeedle * 1e6, jetAreaMm2: aJet * 1e6, circuito: th < 0.1 ? "lenta" : th < 0.3 ? "progressão" : "principal" };
}

export const fuelRho = (eth: boolean) => (eth ? CONSTANTS["fuel.rho.etanol_hidratado"].valor : CONSTANTS["fuel.rho.gasolina_c_e27"].valor) * 1000;

/** Primeiro número de um texto de manual ("115 ou 118" → 115). */
export const firstNum = (v: unknown) => (typeof v === "number" ? v : typeof v === "string" ? parseFloat(v.replace(",", ".")) : NaN);
