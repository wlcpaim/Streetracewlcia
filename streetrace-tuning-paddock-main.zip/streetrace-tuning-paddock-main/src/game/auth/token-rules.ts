// Regras do token de acesso (anticheat): formato, validade e limite de tentativas. Puro e testável.
export const TOKEN_PREFIX = "SR-";
export const TOKEN_LEN = 32;
export const TOKEN_TTL_DAYS = 1;
export const tokenExpiresAt = (now: number) => new Date(now + TOKEN_TTL_DAYS * 86400_000).toISOString();
export const MAX_FAILS = 5;
export const FAIL_WINDOW_MIN = 15;
const ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function makeToken(rand: Uint8Array): string {
  let s = "";
  for (let i = 0; i < TOKEN_LEN; i++) s += ALPHA[(rand[i] ?? 0) % ALPHA.length];
  return TOKEN_PREFIX + s;
}
export const normalizeToken = (t: string) => t.trim().toUpperCase().replace(/\s+/g, "");
export const tokenFormatOk = (t: string) => new RegExp(`^${TOKEN_PREFIX}[${ALPHA}]{${TOKEN_LEN}}$`).test(t);
/** Bloqueia o aparelho/IP após MAX_FAILS erros dentro da janela. */
export const blocked = (failsInWindow: number) => failsInWindow >= MAX_FAILS;
export type TokenRow = { expires_at: string; revoked_at: string | null };
export function tokenUsable(row: TokenRow | null, now: number): "ok" | "inexistente" | "revogado" | "expirado" {
  if (!row) return "inexistente";
  if (row.revoked_at) return "revogado";
  if (new Date(row.expires_at).getTime() <= now) return "expirado";
  return "ok";
}
