// Token de acesso: gerar (logado) e entrar com token (público, com anticheat no servidor).
import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { createHash, randomBytes } from "node:crypto";
import { FAIL_WINDOW_MIN, blocked, makeToken, normalizeToken, tokenFormatOk, tokenUsable, tokenExpiresAt } from "./token-rules";

const sha = (s: string) => createHash("sha256").update(s).digest("hex");

export const checkTokenSession = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    const { data, error } = await db.from("token_guest_accounts").select("expires_at").eq("user_id", context.userId).maybeSingle();
    if (error) throw new Error("Verificação indisponível");
    return { expires_at: data?.expires_at ?? null };
  });

/** Gera um token novo e revoga os anteriores da conta (só um ativo por vez). */
export const generateAccessToken = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    const token = makeToken(randomBytes(32));
    const now = new Date();
    await db.from("access_tokens").update({ revoked_at: now.toISOString() }).eq("user_id", context.userId).is("revoked_at", null);
    const { data: guest } = await db.from("token_guest_accounts").select("expires_at").eq("user_id", context.userId).maybeSingle();
    if (guest && Date.parse(guest.expires_at) <= now.getTime()) throw new Error("Acesso expirado.");
    const { data: me } = await db.auth.admin.getUserById(context.userId);
    const isProfile = !!(me?.user?.app_metadata as { profile_of?: string } | undefined)?.profile_of;
    const expires = isProfile ? PROFILE_TOKEN_EXPIRES : guest?.expires_at ?? tokenExpiresAt(now.getTime());
    const { error } = await db.from("access_tokens").insert({ user_id: context.userId, token_hash: sha(token), prefix: token.slice(0, 7), expires_at: expires });
    if (error) throw new Error("não foi possível gerar o token");
    return { token, expires_at: expires };
  });

/** Creates a separate, unprivileged token-only identity. Never links existing accounts. */
export const generateGuestToken = createServerFn({ method: "POST" }).handler(async () => {
  const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
  const ip = (getRequestHeader("cf-connecting-ip") || getRequestHeader("x-forwarded-for") || "?").split(",")[0]?.trim() ?? "?";
  { const { isIpBlocked } = await import("@/admin/admin.server"); if (await isIpBlocked(ip === "?" ? null : ip)) throw new Error("Acesso bloqueado a partir desta rede."); }
  const { data: allowed, error: limitError } = await db.rpc("reserve_token_generation", { _ip_hash: sha("ip:" + ip) });
  if (limitError || !allowed) throw new Error("Aguarde 15 minutos antes de gerar outro token.");
  const email = `token-${randomBytes(12).toString("hex")}@token.streetrace.app`;
  const { data: account, error } = await db.auth.admin.createUser({ email, email_confirm: true, password: randomBytes(32).toString("hex"), user_metadata: { display_name: `Piloto ${randomBytes(4).toString("hex")}` } });
  if (error || !account.user) { console.error("token identity creation", error?.code, error?.status, error?.message.replace(/[^\s]+@[^\s]+/g, "[address]")); throw new Error("Não foi possível gerar o acesso."); }
  const userId = account.user.id, token = makeToken(randomBytes(32)), expires = tokenExpiresAt(Date.now());
  try {
    const guest = await db.from("token_guest_accounts").insert({ user_id: userId, expires_at: expires });
    const saved = await db.from("access_tokens").insert({ user_id: userId, token_hash: sha(token), prefix: token.slice(0, 7), expires_at: expires });
    if (guest.error || saved.error) throw new Error("Não foi possível guardar o acesso.");
    const { data: link, error: linkError } = await db.auth.admin.generateLink({ type: "magiclink", email });
    if (linkError || !link.properties.hashed_token) throw new Error("Não foi possível abrir a sessão.");
    return { token, expires_at: expires, hash: link.properties.hashed_token };
  } catch (e) {
    await db.from("access_tokens").delete().eq("user_id", userId);
    await db.from("token_guest_accounts").delete().eq("user_id", userId);
    await db.auth.admin.deleteUser(userId);
    throw e;
  }
});

/** Confere o token e devolve um código de uso único para abrir a sessão. */
export const loginWithToken = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string }) => {
    if (!d || typeof d.token !== "string" || d.token.length > 64) throw new Error("token inválido");
    return { token: normalizeToken(d.token) };
  })
  .handler(async ({ data }) => {
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    const ip = (getRequestHeader("cf-connecting-ip") || getRequestHeader("x-forwarded-for") || "?").split(",")[0]?.trim() ?? "?";
    const ipHash = sha("ip:" + ip);
    { const { isIpBlocked } = await import("@/admin/admin.server"); if (await isIpBlocked(ip === "?" ? null : ip)) return { ok: false as const, motivo: "Acesso bloqueado a partir desta rede." }; }
    const since = new Date(Date.now() - FAIL_WINDOW_MIN * 60_000).toISOString();
    const { count } = await db.from("token_attempts").select("id", { count: "exact", head: true }).eq("ip_hash", ipHash).eq("ok", false).gte("created_at", since);
    if (blocked(count ?? 0)) return { ok: false as const, motivo: `Muitas tentativas erradas. Aguarde ${FAIL_WINDOW_MIN} minutos.` };
    const fail = async (motivo: string) => { await db.from("token_attempts").insert({ ip_hash: ipHash, ok: false }); return { ok: false as const, motivo }; };
    if (!tokenFormatOk(data.token)) return fail("Token inválido.");
    const { data: row } = await db.from("access_tokens").select("id,user_id,expires_at,revoked_at").eq("token_hash", sha(data.token)).maybeSingle();
    const st = tokenUsable(row, Date.now());
    if (st !== "ok" || !row) return fail(st === "expirado" ? "Token expirado. Gere um novo." : "Token inválido.");
    const { data: guest } = await db.from("token_guest_accounts").select("expires_at").eq("user_id", row.user_id).maybeSingle();
    if (guest && Date.parse(guest.expires_at) <= Date.now()) return fail("Token expirado. Gere um novo.");
    const { data: u } = await db.auth.admin.getUserById(row.user_id);
    if (!u?.user?.email || !u.user.email_confirmed_at) return fail("Conta sem e-mail confirmado.");
    const { data: link, error } = await db.auth.admin.generateLink({ type: "magiclink", email: u.user.email });
    if (error || !link?.properties?.hashed_token) return { ok: false as const, motivo: "Não foi possível entrar agora." };
    await db.from("access_tokens").update({ last_used_at: new Date().toISOString() }).eq("id", row.id);
    await db.from("token_attempts").insert({ ip_hash: ipHash, ok: true });
    return { ok: true as const, hash: link.properties.hashed_token, expires_at: guest?.expires_at ?? row.expires_at };
  });

/** Token fixo que nunca expira (perfil criado dentro de outra conta). */
export const PROFILE_TOKEN_EXPIRES = "9999-12-31T23:59:59.000Z";

/**
 * Novo perfil = identidade própria e independente: conta separada (save, dinheiro, motos e token
 * individuais) com token fixo sem expiração. O vínculo com a conta criadora fica só em app_metadata
 * (gravado pelo servidor), nunca compartilha progresso.
 */
export const createProfileAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { name: string }) => {
    const name = typeof d?.name === "string" ? d.name.trim() : "";
    if (!/^[\p{L}\p{N} ._-]{3,16}$/u.test(name)) throw new Error("Nome precisa ter de 3 a 16 caracteres.");
    return { name };
  })
  .handler(async ({ data, context }) => {
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    const ip = (getRequestHeader("cf-connecting-ip") || getRequestHeader("x-forwarded-for") || "?").split(",")[0]?.trim() ?? "?";
    const { data: allowed } = await db.rpc("reserve_token_generation", { _ip_hash: sha("profile:" + context.userId + ":" + ip) });
    if (!allowed) throw new Error("Aguarde alguns minutos antes de criar outro perfil.");
    // anticheat: perfis não criam perfis, e cada conta tem no máximo MAX_PROFILES secundários
    const { data: me } = await db.auth.admin.getUserById(context.userId);
    if ((me?.user?.app_metadata as { profile_of?: string } | undefined)?.profile_of) throw new Error("Perfis secundários não podem criar outros perfis.");
    if ((await listOwnProfiles(db, context.userId)).length >= MAX_PROFILES) throw new Error(`Limite de ${MAX_PROFILES} perfis por conta.`);
    // nome precisa estar livre no banco (jogadores, sem diferenciar maiúsculas)
    const { data: taken } = await db.from("players").select("id").ilike("name", data.name.replace(/[%_\\]/g, (c) => "\\" + c)).limit(1);
    if (taken?.length) throw new Error("Esse nome já está em uso.");
    const email = `perfil-${randomBytes(12).toString("hex")}@token.streetrace.app`;
    const { data: acc, error } = await db.auth.admin.createUser({
      email, email_confirm: true, password: randomBytes(32).toString("hex"),
      user_metadata: { display_name: data.name }, app_metadata: { profile_of: context.userId },
    });
    if (error || !acc.user) throw new Error("Não foi possível criar o perfil.");
    const token = makeToken(randomBytes(32));
    const { error: e2 } = await db.from("access_tokens").insert({ user_id: acc.user.id, token_hash: sha(token), prefix: token.slice(0, 7), expires_at: PROFILE_TOKEN_EXPIRES });
    if (e2) { await db.auth.admin.deleteUser(acc.user.id); throw new Error("Não foi possível guardar o token."); }
    return { id: acc.user.id, name: data.name };
  });

/** Perfis secundários por conta (anticheat contra contas em massa no mesmo login). */
export const MAX_PROFILES = 1;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function listOwnProfiles(db: any, owner: string): Promise<{ id: string; name: string }[]> {
  const out: { id: string; name: string }[] = [];
  for (let page = 1; page <= 20; page++) {
    const { data, error } = await db.auth.admin.listUsers({ page, perPage: 1000 });
    if (error) throw new Error("Verificação indisponível.");
    const users = (data?.users ?? []) as { id: string; app_metadata?: { profile_of?: string }; user_metadata?: { display_name?: string } }[];
    for (const u of users) if (u.app_metadata?.profile_of === owner) out.push({ id: u.id, name: u.user_metadata?.display_name ?? "Perfil" });
    if (users.length < 1000) break;
  }
  return out;
}

export const listProfileAccounts = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    const { data: me } = await db.auth.admin.getUserById(context.userId);
    const owner = (me?.user?.app_metadata as { profile_of?: string } | undefined)?.profile_of ?? context.userId;
    const { data: o } = await db.auth.admin.getUserById(owner);
    const main = { id: owner, name: (o?.user?.user_metadata as { display_name?: string } | undefined)?.display_name ?? "Principal" };
    return { main, profiles: await listOwnProfiles(db, owner), max: MAX_PROFILES, current: context.userId, isOwner: owner === context.userId };
  });

/** Troca de sessão entre a conta principal e seus perfis (mesmo grupo), sem exibir token. */
export const switchProfileAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string }) => {
    if (!d || typeof d.id !== "string" || !/^[0-9a-f-]{36}$/i.test(d.id)) throw new Error("Perfil inválido.");
    return { id: d.id };
  })
  .handler(async ({ data, context }) => {
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    const ownerOf = async (id: string) => { const { data: u } = await db.auth.admin.getUserById(id); return { u: u?.user, owner: (u?.user?.app_metadata as { profile_of?: string } | undefined)?.profile_of ?? id }; };
    const me = await ownerOf(context.userId), target = await ownerOf(data.id);
    if (!target.u?.email || me.owner !== target.owner) throw new Error("Esse perfil não pertence à sua conta.");
    const { data: link, error } = await db.auth.admin.generateLink({ type: "magiclink", email: target.u.email });
    if (error || !link?.properties?.hashed_token) throw new Error("Não foi possível trocar de perfil.");
    return { hash: link.properties.hashed_token };
  });

/** Exclui um perfil secundário: só a conta dona (profile_of) pode, e a conta principal nunca. */
export const deleteProfileAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string }) => {
    if (!d || typeof d.id !== "string" || !/^[0-9a-f-]{36}$/i.test(d.id)) throw new Error("Perfil inválido.");
    return { id: d.id };
  })
  .handler(async ({ data, context }) => {
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    const { data: u } = await db.auth.admin.getUserById(data.id);
    if ((u?.user?.app_metadata as { profile_of?: string } | undefined)?.profile_of !== context.userId) throw new Error("Esse perfil não pertence à sua conta.");
    await db.from("access_tokens").delete().eq("user_id", data.id);
    await db.from("game_saves").delete().eq("user_id", data.id);
    await db.from("players").delete().eq("user_id", data.id);
    const { error } = await db.auth.admin.deleteUser(data.id);
    if (error) throw new Error("Não foi possível excluir o perfil.");
    return { ok: true };
  });
