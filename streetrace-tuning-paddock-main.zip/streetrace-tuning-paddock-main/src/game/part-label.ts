// Nome e descrição das peças exatamente como a Auto Peças mostra (loja e inventário usam o mesmo texto).
import type { Part } from "./parts";
import { exhaustDesc, srCodeOfCam, srCodeOfExhaust } from "./sintonia";

const SPEC_ONLY = new Set(["modulo", "vela", "pneu", "junta_carb", "gicle_alta", "gicle_lenta", "linha_comb", "filtro_comb"]);
export const shopName = (x: Part) => (x.kind === "kit" ? `${x.front}x${x.rear}` : x.kind === "pinhao" ? `Pinhão ${x.front} dentes` : x.kind === "coroa" ? `Coroa ${x.rear} dentes` : x.name);
const baseDesc = (x: Part) => (x.kind === "escape" ? exhaustDesc(x.id) : x.kind === "kit" || x.kind === "pinhao" || x.kind === "coroa" ? x.brand : SPEC_ONLY.has(x.kind) && x.spec ? x.spec : x.spec ? `${x.brand} · ${x.spec}` : x.brand);
/** Comandos de sintonia mostram o código SR# do casamento na frente; o escape já traz o SR# dentro da descrição. */
export const shopDesc = (x: Part) => {
  const code = x.kind === "comando" ? srCodeOfCam(x.cam) : null;
  return code ? `${code} · ${baseDesc(x)}` : baseDesc(x);
};
