// MODO PREPARADOR AUTOMÁTICO — o mecânico projeta a preparação por meta de velocidade.
// Só usa peças/serviços que existem no catálogo e valida cada candidato rodando a própria physics.step()
// (mesma física da corrida); nunca altera a física para forçar a meta. Toda preparação recebe o módulo Athlon
// com ponto, faixas e mistura calculados, e só é entregue depois da puxada no dinamômetro dar 100% de afinamento.
import { DT, ETA, SERVICES, serviceById, engine, exhaustMul, mixtureAt, newSim, stalled, step, stress, gearSpeeds, stats, timingOptimum, type BikeModel, type Setup } from "../physics";
import { PARTS_CATALOG, TAXAS, clutchCapNm, partById, slotPart, type Slot } from "../parts";
import { swapSlot } from "../component-swap";
import { validarConjunto } from "../pins/pins";
import { fuelChain } from "../rootcause";
import { priceNow } from "../economy";
import { afinamento, type Afinamento } from "../tuning";
import { MU_ASPHALT, tractionLimit } from "../ground";

export type EstadoPrep = "NÃO ANALISADO" | "EM PROJETO" | "AGUARDANDO CONFIRMAÇÃO" | "EM PREPARAÇÃO" | "EM AFINAÇÃO" | "EM AUDITORIA" | "APROVADO" | "AFINAÇÃO INCOMPLETA" | "RECURSOS INSUFICIENTES" | "REPROVADO";
export type Criterio = { nome: string; ok: boolean; valor: string };
export type Linha = { item: string; acao: "manter" | "substituir" | "usinar" | "ajustar"; detalhe: string; preco: number; noEstoque: boolean };
export type Marcha = { lo: number; hi: number; kmh: number };
export type Dino = { distancia: number; vmax: number; tempo: number | null; marchas: Marcha[]; afinamento: Afinamento; ponto: number; tLow: number; tHigh: number; corte: number; trims: { low: number; mid: number; high: number; over: number } };
export type Projeto = {
  metaKmh: number; estado: EstadoPrep; moto: string; setup: Setup; vmaxKmh: number; vmaxAtualKmh: number;
  hp: number; torqueNm: number; rpmPeak: number; rpmLimit: number; risco: number; marchas: number[];
  linhas: Linha[]; custo: number; criterios: Criterio[]; faltas: string[]; avisos: string[]; dino: Dino;
};

/** Módulo programável usado em toda preparação automática. */
export const MODULO_PREP = "modulo-athlon";
/** Cilindros vendidos peça por peça + o de fábrica (o kit 4MM pronto saiu da loja). */
const CILINDROS = ["cilindro-original", "cilindro-4mm", "cilindro-205", "cilindro-220"];
const FRONTS = [13, 14, 15, 16, 17];
const REARS = [36, 38, 40, 42, 44, 46, 48];
/** Pista do dinamômetro / medição de velocidade final (m). */
export const PISTA_VMAX = 2500;
const RISCO_MAX = 0.3;
/** Margem rica da mistura calculada: entrega 2% acima do que o motor pede (λ levemente rico, duty 98%). */
const MARGEM_MISTURA = 1.02;
/** Faixas do mapa Athlon onde o ponto ótimo da curva fica (timingBandFactor: máximo em −1° na baixa e +1,5° na alta). */
const T_LOW = -1, T_HIGH = 1.5;
const r1 = (n: number) => Math.round(n * 10) / 10;
const r2 = (n: number) => Math.round(n * 100) / 100;

/** Puxada no dinamômetro: mesma step() da corrida, registra a janela de giro e a velocidade de cada marcha. */
export function puxada(b: BikeModel, s: Setup, dist = PISTA_VMAX) {
  const st = newSim(b.tank);
  const g: Marcha[] = [];
  while (st.finishT === null && !stalled(st) && st.t < 300) {
    step(st, b, s, DT, dist);
    if (st.shiftT > 0) continue;
    const r = g[st.gear - 1] ?? (g[st.gear - 1] = { lo: st.rpm, hi: st.rpm, kmh: 0 });
    r.lo = Math.min(r.lo, st.rpm); r.hi = Math.max(r.hi, st.rpm); r.kmh = Math.max(r.kmh, st.v * 3.6);
  }
  return { gears: g.map((x) => ({ ...x, afr: 0 })), vmax: r1(st.top), t: st.finishT };
}
/** Velocidade final pela própria step(): roda PISTA_VMAX m com tanque cheio. */
export const vmaxSim = (b: BikeModel, s: Setup) => puxada(b, s).vmax;

function comKit(base: Setup, cilId: string): Setup {
  let s = swapSlot(base, "cilindro", cilId);
  const k = partById(cilId)?.bundle;
  if (!k) return s;
  for (const slot of ["pistao", "bico", "molas", "bomba", "biela", "vira"] as const) if (k[slot]) s = swapSlot(s, slot as Slot, k[slot]!);
  return { ...s, cam: k.cam, services: [...s.services.filter((id) => !(k.services && /^pino-/.test(id))), ...(k.services ?? []).filter((id) => !s.services.includes(id))] };
}

/** Athlon com mapa calculado: ponto = ótimo da taxa/combustível, faixas no ótimo, mistura casada em cada faixa e corte ≥ pico + 600. */
export function afinarAthlon(b: BikeModel, s0: Setup): Setup {
  let s = s0.slots.modulo === MODULO_PREP ? s0 : swapSlot(s0, "modulo", MODULO_PREP);
  const peak = engine(b, s).rpmPeak;
  const corte = Math.max(b.rpmLimit, Math.min(10000, Math.ceil((peak + 800) / 100) * 100), Math.ceil((peak + 600) / 100) * 100);
  const launch = Math.min(s0.ecu.launch || 0, 8000);
  s = { ...s, ecu: { ...s.ecu, rpm: corte, timing: r2(timingOptimum(b, s)), tLow: T_LOW, tHigh: T_HIGH, trim: 0, low: 0, mid: 0, high: 0, over: 0, closed: false, leanCut: false, softCut: false, launch } };
  const flow = slotPart(s.slots.bico, "bico").flow ?? 1;
  const at = (rpm: number) => { const m = mixtureAt({ ...s, ecu: { ...s.ecu, low: 0, mid: 0, high: 0, over: 0 } }, rpm, peak); return r2(((m.need * MARGEM_MISTURA - m.supply) / flow) * 100); };
  const hiRpm = Math.min(corte, 10500);
  s = { ...s, ecu: { ...s.ecu, timing: r2(timingOptimum(b, s)), low: at(5500), mid: at(7500), high: at(hiRpm), over: at(Math.max(corte, 10500)) } };
  return s;
}

function melhorEscape(b: BikeModel, s: Setup): Setup {
  const pk = engine(b, s).rpmPeak;
  let best = s, m = exhaustMul(b, s, pk), hp = engine(b, s).hp;
  for (const p of PARTS_CATALOG) if (p.kind === "escape") { const t = swapSlot(s, "escape", p.id); const x = exhaustMul(b, t, pk), h = engine(b, t).hp; if (x > m + 1e-9 || (Math.abs(x - m) < 1e-9 && h > hp + 1e-9)) { m = x; hp = h; best = t; } }
  return best;
}

const torqueNm = (b: BikeModel, s: Setup) => { const e = engine(b, s); return (e.hp * 735.5) / ((e.rpmPeak * 2 * Math.PI) / 60); };
function melhorEmbreagem(b: BikeModel, s: Setup): Setup {
  const T = torqueNm(b, s);
  if (clutchCapNm(s) >= T * 1.15) return s;
  const opts = PARTS_CATALOG.filter((p) => p.kind === "embreagem" && (p.clutchNm ?? 0) >= T * 1.15 && !p.consumable).sort((a, z) => a.price - z.price);
  return opts[0] ? swapSlot(s, "embreagem", opts[0].id) : s;
}

/** Força na roda no pico de potência em 1ª (F = P·η / v) — o que o pneu precisa segurar na largada. */
function forca1a(b: BikeModel, s: Setup) {
  const e = engine(b, s), v1 = ((gearSpeeds(b, s)[0] ?? 40) / 3.6) * (e.rpmPeak / e.rpmLimit);
  return (e.hp * 735.5 * ETA) / Math.max(1, v1);
}
const tracao = (b: BikeModel, s: Setup) => tractionLimit(MU_ASPHALT * (slotPart(s.slots.pneu, "pneu").grip ?? 1), stats(b, s, b.tank).kg);
/** Pneu mais barato que segura a força da 1ª sem patinar (se nenhum segura, o de maior aderência). */
function melhorPneu(b: BikeModel, s: Setup): Setup {
  const F = forca1a(b, s);
  if (tracao(b, s) >= F) return s;
  const opts = PARTS_CATALOG.filter((p) => p.kind === "pneu" && !p.factory).map((p) => swapSlot(s, "pneu", p.id));
  const ok = opts.filter((t) => tracao(b, t) >= F).sort((a, z) => (partById(a.slots.pneu)?.price ?? 0) - (partById(z.slots.pneu)?.price ?? 0));
  return ok[0] ?? opts.sort((a, z) => tracao(b, z) - tracao(b, a))[0] ?? s;
}

const comServico = (s: Setup, id: string): Setup => {
  const x = serviceById(id)!;
  let t: Setup = s;
  for (const pid of x.requires ?? []) { const p = partById(pid); if (p && p.kind in t.slots) t = swapSlot(t, p.kind as Slot, pid); }
  return { ...t, services: [...t.services, x.id] };
};
const podeServico = (s: Setup, id: string, bikeId: string | null) => {
  const x = serviceById(id);
  if (!x || x.install || x.prepFor || s.services.includes(x.id)) return false;
  if (x.exclusive && s.services.some((o) => serviceById(o)?.exclusive === x.exclusive)) return false;
  // pistão × pino × biela precisa fechar com ficha; conjunto desconhecido nunca entra na proposta
  const t = comServico(s, id);
  return validarConjunto(t.slots.pistao, t.slots.biela, bikeId).aprovado;
};

/** StressCheck: adiciona os serviços que mais aliviam a carga até zerar o risco (afinar é andar forte sem quebrar). */
function aliviar(b: BikeModel, s0: Setup): Setup {
  let s = s0;
  for (let i = 0; i < 16 && stress(b, s).risk > 1e-6; i++) {
    let best: Setup | null = null, br = stress(b, s).risk;
    const hp = engine(b, s).hp;
    for (const x of SERVICES) {
      if (!podeServico(s, x.id, b.id) || (x.hpMul ?? 1) < 1) continue;
      const t = comServico(s, x.id), r = stress(b, t).risk;
      if (r < br - 1e-6 && engine(b, t).hp >= hp * 0.995) { br = r; best = t; }
    }
    if (!best) break;
    s = best;
  }
  return s;
}

/** Fecha o conjunto: escape, embreagem, alívio de carga, Athlon calculado e pneu de tração. */
const fechar = (b: BikeModel, s: Setup) => melhorPneu(b, afinarAthlon(b, melhorEmbreagem(b, aliviar(b, afinarAthlon(b, melhorEscape(b, s))))));

/** Próximo passo de potência: o serviço (ou taxa do cabeçote) com mais cv por real que ainda fecha com risco zero. */
function maisPotencia(b: BikeModel, s: Setup): Setup | null {
  const hp0 = engine(b, s).hp;
  let best: Setup | null = null, score = 0;
  const tenta = (t: Setup, preco: number) => {
    const f = fechar(b, t), g = engine(b, f).hp - hp0;
    if (g > 0.05 && stress(b, f).risk <= 1e-6 && g / Math.max(1, preco) > score) { score = g / Math.max(1, preco); best = f; }
  };
  for (const x of SERVICES) if (podeServico(s, x.id, b.id) && (x.hpMul ?? 1) > 1) tenta(comServico(s, x.id), x.price);
  if (s.compression === 9.5) for (const t of TAXAS) tenta({ ...s, compression: t.taxa }, t.price);
  return best;
}

function linhas(b: BikeModel, atual: Setup, novo: Setup, owned: string[]): Linha[] {
  const out: Linha[] = [];
  for (const k of Object.keys(novo.slots) as Slot[]) {
    if (novo.slots[k] === atual.slots[k]) continue;
    const p = partById(novo.slots[k]); if (!p) continue;
    const tem = owned.includes(p.id);
    out.push({ item: k, acao: "substituir", detalhe: `${p.brand} ${p.name}`.trim(), preco: tem || p.factory ? 0 : r2(priceNow(p)), noEstoque: tem });
  }
  if (novo.cam !== atual.cam) out.push({ item: "comando", acao: "substituir", detalhe: `Comando ${novo.cam}`, preco: 0, noEstoque: true });
  if (novo.compression !== atual.compression) out.push({ item: "cabeçote", acao: "usinar", detalhe: `Taxar cabeçote ${novo.compression.toLocaleString("pt-BR")}:1`, preco: TAXAS.find((t) => t.taxa === novo.compression)?.price ?? 0, noEstoque: true });
  for (const id of novo.services.filter((x) => !atual.services.includes(x))) {
    const x = serviceById(id);
    out.push({ item: x?.group ?? "serviço", acao: "usinar", detalhe: x?.name ?? id, preco: x?.price ?? 0, noEstoque: true });
  }
  if (novo.front !== atual.front || novo.rear !== atual.rear) {
    const need = (id: string) => { const p = partById(id); return p && !owned.includes(id) ? r2(priceNow(p)) : 0; };
    out.push({ item: "relação", acao: "ajustar", detalhe: `${novo.front}x${novo.rear} (era ${atual.front}x${atual.rear})`, preco: (novo.front !== atual.front ? need(`pinhao-${novo.front}`) : 0) + (novo.rear !== atual.rear ? need(`coroa-${novo.rear}`) : 0), noEstoque: false });
  }
  if (novo.ecu.timing !== atual.ecu.timing || novo.slots.modulo !== atual.slots.modulo) out.push({ item: "módulo", acao: "ajustar", detalhe: `Mapa Athlon: ponto ${novo.ecu.timing}° · baixa ${novo.ecu.tLow}° · alta +${novo.ecu.tHigh}° · corte ${novo.ecu.rpm} rpm`, preco: 0, noEstoque: true });
  void b;
  return out;
}

function dinoDe(b: BikeModel, s: Setup, pux: ReturnType<typeof puxada>): Dino {
  return { distancia: PISTA_VMAX, vmax: pux.vmax, tempo: pux.t, marchas: pux.gears.map(({ lo, hi, kmh }) => ({ lo: Math.round(lo), hi: Math.round(hi), kmh: r1(kmh) })), afinamento: afinamento(b, s, pux, PISTA_VMAX),
    ponto: s.ecu.timing, tLow: s.ecu.tLow ?? 0, tHigh: s.ecu.tHigh ?? 0, corte: s.ecu.rpm, trims: { low: s.ecu.low ?? 0, mid: s.ecu.mid ?? 0, high: s.ecu.high ?? 0, over: s.ecu.over ?? 0 } };
}

export function auditar(b: BikeModel, s: Setup, metaKmh: number, vmax: number, af?: Afinamento): Criterio[] {
  const e = engine(b, s), sr = stress(b, s);
  const T = torqueNm(b, s);
  let lean = 0; for (let r = 5500; r <= e.rpmLimit; r += 250) lean = Math.max(lean, fuelChain(b, s, r).lean);
  const gs = gearSpeeds(b, s), F = forca1a(b, s), Tr = tracao(b, s);
  const out: Criterio[] = [
    { nome: "Velocidade no dinamômetro ≥ meta", ok: vmax >= metaKmh, valor: `${vmax} km/h (meta ${metaKmh})` },
    { nome: "Módulo Athlon com ponto calculado", ok: s.slots.modulo === MODULO_PREP && Math.abs(s.ecu.timing - timingOptimum(b, s)) < 0.05, valor: `${s.ecu.timing}° (ótimo ${r2(timingOptimum(b, s))}°)` },
    { nome: "Alimentação sem empobrecer", ok: lean <= 0.01, valor: `falta máx ${Math.round(lean * 100)}%` },
    { nome: "Embreagem sem patinar no pico", ok: clutchCapNm(s) >= T, valor: `${clutchCapNm(s)} N·m vs ${r1(T)} N·m` },
    { nome: "Pneu segura a 1ª sem patinar", ok: Tr >= F, valor: `${Math.round(Tr)} N de tração vs ${Math.round(F)} N na roda` },
    { nome: "Limites estruturais (StressCheck)", ok: sr.risk <= RISCO_MAX, valor: `risco ${r1(sr.risk * 100)}%` },
    { nome: "Última marcha alcança a meta no corte", ok: (gs.at(-1) ?? 0) >= metaKmh, valor: `${r1(gs.at(-1) ?? 0)} km/h no corte` },
    { nome: "Corte acima do pico", ok: e.rpmLimit >= e.rpmPeak + 600, valor: `pico ${e.rpmPeak} · corte ${e.rpmLimit} rpm` },
  ];
  if (af) out.push({ nome: "Afinamento no dinamômetro", ok: af.pct >= 100, valor: `${af.pct}% (${af.sistemas.map((x) => `${x.nome} ${x.pts}/${x.max}`).join(" · ")})` });
  return out;
}

type Cand = { s: Setup; v: number; ok: boolean; custo: number; risco: number; pux: ReturnType<typeof puxada>; af: Afinamento };
function avaliar(b: BikeModel, atual: Setup, s: Setup, metaKmh: number, owned: string[]): Cand[] {
  const out: Cand[] = [];
  for (const f of FRONTS) for (const r of REARS) {
    const t = melhorPneu(b, { ...s, front: f, rear: r });
    const pux = puxada(b, t), af = afinamento(b, t, pux, PISTA_VMAX);
    const ok = auditar(b, t, metaKmh, pux.vmax, af).every((c) => c.ok);
    out.push({ s: t, v: pux.vmax, ok, custo: linhas(b, atual, t, owned).reduce((n, l) => n + l.preco, 0), risco: stress(b, t).risk, pux, af });
  }
  return out;
}

/** Projeta a preparação: para cada cilindro sobe a potência passo a passo (serviços, taxa) até a meta fechar 100% no dinamômetro; escolhe a mais barata. */
export function projetar(b: BikeModel, atual: Setup, metaKmh: number, owned: string[] = []): Projeto {
  const vAtual = vmaxSim(b, atual);
  const cands: Cand[] = [];
  for (const cil of CILINDROS) {
    let s: Setup | null = fechar(b, cil === "cilindro-original" ? atual : comKit(atual, cil));
    for (let lvl = 0; s && lvl < 14; lvl++) {
      const cs = avaliar(b, atual, s, metaKmh, owned);
      cands.push(...cs);
      if (cs.some((c) => c.ok)) break;
      // poda: se nem a melhor relação chega perto, sobe potência; se a velocidade já passou, falta só acerto
      s = maisPotencia(b, s);
    }
  }
  const okc = cands.filter((c) => c.ok).sort((a, z) => a.custo - z.custo || a.risco - z.risco);
  const seguros = cands.filter((c) => c.risco <= RISCO_MAX).sort((a, z) => z.v - a.v);
  const pick = okc[0] ?? seguros[0] ?? cands.sort((a, z) => z.v - a.v)[0]!;
  const e = engine(b, pick.s);
  const crit = auditar(b, pick.s, metaKmh, pick.v, pick.af);
  const faltas: string[] = [];
  if (!okc.length) {
    faltas.push(`Maior velocidade validada no dinamômetro com o catálogo atual: ${pick.v} km/h (${e.hp} cv). Faltam ${r1(metaKmh - pick.v)} km/h.`);
    // potência necessária pela razão cúbica do arrasto (P ∝ v³) — estimativa, não validada pela simulação
    faltas.push(`Estimativa: P ≈ P_atual × (meta/v)³ ≈ ${r1(e.hp * (metaKmh / Math.max(1, pick.v)) ** 3)} cv no motor.`);
    for (const c of crit.filter((x) => !x.ok)) faltas.push(`${c.nome}: ${c.valor}`);
    faltas.push("A desenvolver no catálogo: kit de maior cilindrada, cabeçote/comando de competição e alívio de peso no quadro.");
  }
  const ls = linhas(b, atual, pick.s, owned);
  return {
    metaKmh, estado: okc.length ? "AGUARDANDO CONFIRMAÇÃO" : "RECURSOS INSUFICIENTES", moto: b.name, setup: pick.s,
    vmaxKmh: pick.v, vmaxAtualKmh: vAtual, hp: e.hp, torqueNm: r2(torqueNm(b, pick.s)),
    rpmPeak: e.rpmPeak, rpmLimit: e.rpmLimit, risco: r1(stress(b, pick.s).risk * 100),
    marchas: gearSpeeds(b, pick.s).map((v) => Math.round(v)), linhas: ls, custo: r2(ls.reduce((n, l) => n + l.preco, 0)),
    criterios: crit, faltas, avisos: [], dino: dinoDe(b, pick.s, pick.pux),
  };
}

/** Lê a meta do pedido: "kit afinado 100% 220 km/h", "quero 180 de final"… */
export function metaDoPedido(frase: string): number | null {
  const t = frase.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  if (!/afinad|prepar|kit|final|km\/?h|chegar|bater/.test(t)) return null;
  const m = t.match(/(\d{2,3})\s*(km\/?h|km|de final|por hora)/) ?? (/afinad|kit/.test(t) ? t.replace(/100\s*%/, "").match(/\b(\d{3})\b/) : null);
  const v = m ? parseInt(m[1]!, 10) : NaN;
  return v >= 60 && v <= 400 ? v : null;
}

/** Executa o projeto confirmado: compra o que falta, monta, usina, afina o Athlon e passa no dinamômetro antes de entregar. */
export function executar<P extends { money: number; parts: string[]; setup: Setup }>(p: P, b: BikeModel, pr: Projeto): { player: P; estado: EstadoPrep; vmax: number; criterios: Criterio[]; dino?: Dino; motivo?: string } {
  if (p.money < pr.custo) return { player: p, estado: "RECURSOS INSUFICIENTES", vmax: pr.vmaxAtualKmh, criterios: [], motivo: `Projeto custa ${pr.custo.toFixed(2)} e o saldo é ${p.money.toFixed(2)}.` };
  const parts = [...p.parts];
  for (const k of Object.keys(pr.setup.slots) as Slot[]) {
    const novo = pr.setup.slots[k], velho = p.setup.slots[k];
    if (novo === velho) continue;
    const i = parts.indexOf(novo); if (i >= 0) parts.splice(i, 1);
    if (velho && !partById(velho)?.factory) parts.push(velho);
  }
  // motor montado do zero: mapa recalculado com o motor cru e conferido no rolo
  const setup: Setup = afinarAthlon(b, { ...pr.setup, engineKm0: p.setup.km });
  const pux = puxada(b, setup), dino = dinoDe(b, setup, pux), crit = auditar(b, setup, pr.metaKmh, pux.vmax, dino.afinamento);
  return { player: { ...p, parts, setup, money: r2(p.money - pr.custo) }, estado: crit.every((c) => c.ok) ? "APROVADO" : "AFINAÇÃO INCOMPLETA", vmax: pux.vmax, criterios: crit, dino };
}
