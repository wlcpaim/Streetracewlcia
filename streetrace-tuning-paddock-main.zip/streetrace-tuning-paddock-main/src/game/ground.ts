// Dinâmica de solo da largada: transferência de carga, empinada (ângulo de pitch), patinagem com
// reação do piloto e temperatura do pneu. Determinístico; chamado por physics.step() a cada passo.
// Geometria e propriedades térmicas são ESTIMADAS (sem ficha medida) e ficam marcadas aqui.
import type { Part } from "./parts";
import { newRider, riderStep, type RiderState } from "./rider";

import { K } from "./physics-registry/constants";
import { tireGeometry, tireHeatStep } from "./tire";
const G = K("phys.g");
/** Geometria estimada (CG 160 / Factor 150 com piloto): entre-eixos, altura do CG, CG→eixo traseiro. */
export const GEO = { L: 1.315, h: 0.55, aR: 0.48 * 1.315, Icg: 14 } as const; // m, m, m, kg·m² (ESTIMADO)
/** Geometria de arfagem; a corrida passa a de cada moto + piloto (vehicle-dynamics.pitchGeometry). */
export type Geo = { L: number; h: number; aR: number; Icg: number };
/** Atrito do asfalto de rua seco, sem borracha depositada (calibrado para a largada patinar). ESTIMADO. */
export const MU_ASPHALT = 1.8; // Pirelli 50/100 a 40 psi: patina ~2 s andando; mais giro na largada = banda mais rápida = mais patinagem e calor (slideMul)
/** Ângulo em que o piloto fecha o acelerador e tempo de reação usado na previsão. */
export const WHEELIE_MAX_DEG = 50;
export const RIDER_REACT_S = 0.2;
/** Patinagem contínua acima disso faz o piloto aliviar; duração do alívio. */
export const SPIN_LIFT_AFTER_S = 5
/** Empinado por mais que isso, o piloto fecha para a frente descer. */
export const WHEELIE_HOLD_S = 5;
export const SPIN_LIFT_S = 0.15;
/** Pneu: massa da banda aquecida, calor específico da borracha, fração do atrito que vira calor no pneu. */
/** Energia de escorregamento que consome a banda inteira (J). ESTIMADO: ~30 largadas patinando 1,5 s. */
export const TIRE_LIFE_SLIP_J = 6e6;
export const TIRE = { bandKg: 0.35, cJkgK: 1800, heatShare: 0.5, ambC: 30, tauS: 90 } as const; // ESTIMADO

export interface Ground {
  /** força transmitida pela carcaça (N), deformação relativa, energia de histerese acumulada (J) */
  fx?: number; deformSlip?: number; hystJ?: number;
  /** Ângulo de pitch (rad) e velocidade angular (rad/s). 0 = eixo A no asfalto. */
  pitch: number;
  pitchW: number;
  /** Abertura do acelerador decidida pelo piloto (0..1). */
  thr: number;
  /** Tempo restante de alívio (s) e motivo. */
  liftT: number;
  liftWhy: "" | "empina" | "patina";
  spinT: number;
  /** Tempo contínuo empinado (s). */
  wheelT?: number;
  tireC: number;
  /** Température interne de carcasse; tireC est la surface en contact avec le sol. */
  tireCoreC?: number;
  /** Carga normal no eixo A e B (N) no último passo. */
  nFront: number;
  nRear: number;
  wheelie: boolean;
  /** Camada de pilotagem (rider.ts) e últimas observações. */
  rider?: RiderState;
  lastSpin?: boolean;
  lastTrac?: number;
  /** Desgaste do pneu nesta corrida (0..1 da vida) e energia dissipada patinando (J). */
  wear?: number;
  slipJ?: number;
}
export const newGround = (): Ground => ({ pitch: 0, pitchW: 0, thr: 1, liftT: 0, liftWhy: "", spinT: 0, tireC: TIRE.ambC, nFront: 0, nRear: 0, wheelie: false });

/** Fator de aderência pela temperatura: 1 dentro da janela do composto, cai frio ou superaquecido. */
export function tempGrip(t: Pick<Part, "tLo" | "tHi" | "coldMul">, C: number) {
  const lo = t.tLo ?? 15, hi = t.tHi ?? 95, cold = t.coldMul ?? 0.95;
  if (C < lo) return Math.max(cold, 1 - ((lo - C) / Math.max(1, lo - TIRE.ambC + 15)) * (1 - cold));
  if (C > hi) return Math.max(0.75, 1 - (C - hi) * 0.006);
  return 1;
}

/**
 * Atrito de deslizamento ÷ μ estático pela velocidade de escorregamento vs (banda − asfalto, m/s):
 * 0,85 quase sem deslizar (SPIN_GRIP) caindo até slide_mu_floor. Mais giro na largada = banda mais rápida =
 * menos atrito e mais calor (pSlip = Fx·vs).
 */
export function slideMul(vs: number) {
  const lo = K("tire.slide_mu_floor");
  return lo + (0.85 - lo) * Math.exp(-Math.max(0, vs) / K("tire.slide_v_c"));
}

/** Limite de tração com transferência de carga: F = μ·m·g·s/(1 − μ·h/L) (eixo A no chão). */
export function tractionLimit(mu: number, m: number, g: Geo = GEO) {
  const s = 1 - g.aR / g.L, hl = g.h / g.L;
  return mu * hl >= 1 ? Infinity : (mu * m * G * s) / (1 - mu * hl);
}
/** Força na roda que tira o eixo A do chão: F·h = m·g·aR. */
export const wheelieForce = (m: number, g: Geo = GEO) => (m * G * g.aR) / g.h;

/**
 * Um passo de solo. Recebe a força que o motor entrega na roda com acelerador pleno (fFull), a
 * velocidade equivalente da transmissão (vEq) e devolve a força real no asfalto e o acelerador.
 */
/**
 * sigma: comprimento de relaxação da carcaça (m); a força no asfalto segue o torque com dFx/dt = (F − Fx)·v_roda/σ,
 * então carcaça mole responde mais progressiva sem ganhar aderência. A diferença de giro dessa deformação NÃO é patinagem:
 * patinagem só existe quando o pedido passa de μ·N. pHyst: potência de histerese do rolamento (W) que aquece a banda.
 */
export function groundStep(gs: Ground, m: number, fFull: number, vEq: number, v: number, mu: number, tire: Pick<Part, "tLo" | "tHi" | "coldMul" | "kg" | "widthRatio">, dt: number, sigma = 0, pHyst = 0, GEOm: Geo = GEO) {
  // CAMADA 2: o piloto lê o passo anterior e decide o acelerador; a física abaixo só recebe o comando
  gs.rider ??= newRider();
  {
    const c = Math.cos(gs.pitch), sn = Math.sin(gs.pitch);
    const x = GEOm.aR * c - GEOm.h * sn, I = GEOm.Icg + m * (GEOm.aR ** 2 + GEOm.h ** 2);
    const wUp = Math.max(0, gs.pitchW), alphaG = Math.max(1e-3, (m * G * x) / I);
    const pred = gs.pitch > 0 ? gs.pitch + wUp * RIDER_REACT_S + (wUp * wUp) / (2 * alphaG) : 0;
    gs.thr = riderStep(gs.rider, { pitchDeg: (gs.pitch * 180) / Math.PI, predDeg: (pred * 180) / Math.PI, wheelT: gs.wheelT ?? 0, spinT: gs.spinT, spin: !!gs.lastSpin, fFull, trac: gs.lastTrac ?? Infinity }, dt);
    gs.liftWhy = gs.rider.mode === "patina" ? "patina" : gs.rider.mode ? "empina" : "";
  }
  // pneu gasto nesta corrida perde aderência progressivamente (mesma regra de tireOf: −18% no fim da vida)
  mu *= 1 - 0.18 * (gs.wear ?? 0);
  const muT = mu * tempGrip(tire, gs.tireC);
  const F = fFull * gs.thr;
  // normal: com a dianteira no chão, transferência ΔN = F·h/L; empinado, todo o peso no eixo B
  const nF0 = (m * G * GEOm.aR - F * GEOm.h) / GEOm.L;
  const airborne = gs.pitch > 0 || nF0 < 0;
  gs.nFront = airborne ? 0 : nF0;
  gs.nRear = m * G - gs.nFront;
  const trac = muT * gs.nRear;
  const spin = F > trac;
  const slide = slideMul(vEq - v);
  const target = spin ? trac * slide : F; // atrito dinâmico < estático, cai com a velocidade de escorregamento
  // relaxação da carcaça: sem sigma (testes antigos) a força é instantânea
  if (sigma > 0) gs.fx = (gs.fx ?? 0) + (target - (gs.fx ?? 0)) * Math.min(1, (dt * Math.max(vEq, 1)) / sigma);
  // escorregando, o atrito é dinâmico na hora (borracha desliza); aderida, a carcaça nunca passa de μ·N
  if (sigma > 0) gs.fx = spin ? target : Math.min(gs.fx!, trac);
  const Fx = sigma > 0 ? gs.fx! : target;
  gs.deformSlip = sigma > 0 ? Math.max(0, target - Fx) / Math.max(1, trac) : 0;
  // patinagem contínua → piloto alivia
  // banda ainda mais rápida que a moto também é patinagem (o piloto sente a roda girando em falso)
  gs.spinT = spin || vEq > v + 0.05 ? gs.spinT + dt : 0;
  gs.lastSpin = spin; gs.lastTrac = trac;
  // pitch: I·θ'' = Fx·y(θ) − m·g·x(θ), CG girado em torno do contato traseiro
  if (airborne) {
    const c = Math.cos(gs.pitch), sn = Math.sin(gs.pitch);
    const x = GEOm.aR * c - GEOm.h * sn, y = GEOm.aR * sn + GEOm.h * c;
    const I = GEOm.Icg + m * (GEOm.aR ** 2 + GEOm.h ** 2);
    gs.pitchW += ((Fx * y - m * G * x) / I) * dt;
    gs.pitch += gs.pitchW * dt;
    if (gs.pitch <= 0) { gs.pitch = 0; gs.pitchW = 0; } // eixo A volta ao asfalto
    gs.wheelT = (gs.wheelT ?? 0) + dt;
  }
  gs.wheelie = gs.pitch > 0;
  if (!gs.wheelie) gs.wheelT = 0;
  // calor: potência perdida no escorregamento + histerese; esfria por convecção (mais rápido com vento)
  // atrito de deslizamento × velocidade de escorregamento (banda − asfalto) vira calor na superfície da banda
  const pSlip = spin || vEq > v + 0.05 ? Fx * Math.max(0, vEq - v) : 0;
  const tg = tireGeometry(tire);
  const heat = tireHeatStep(gs.tireC, gs.tireCoreC ?? TIRE.ambC, v, pSlip, pHyst, dt, tg.massKg, tg.width);
  gs.tireC = heat.surfaceC;
  gs.tireCoreC = heat.coreC;
  gs.hystJ = (gs.hystJ ?? 0) + pHyst * dt;
  // desgaste: energia de escorregamento × carga × temperatura (borracha quente acima da janela gasta mais)
  if (pSlip > 0) {
    const hot = 1 + Math.max(0, gs.tireC - (tire.tHi ?? 95)) * 0.03;
    const e = pSlip * dt * hot;
    gs.slipJ = (gs.slipJ ?? 0) + e;
    gs.wear = Math.min(1, (gs.wear ?? 0) + e / TIRE_LIFE_SLIP_J);
  }
  return { Fx, spin, mu: muT, trac, slide };
}
