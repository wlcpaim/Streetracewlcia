import { stockSetupOf, type BikeModel } from "./physics";

/** Keep one immutable build per rival so the physics WeakMap caches stay warm. */
export function prepareRivals(bikes: readonly BikeModel[]) {
  return bikes.map((bike) => ({ bike, setup: stockSetupOf(bike.id) }));
}

/** Presentation only: physics still consumes every fixed step regardless of paint rate. */
export function createRacePaintClock() {
  const interval = 1000 / 30;
  let last = -Infinity;
  return (now: number) => {
    if (now - last < interval - 0.5) return false;
    last = now;
    return true;
  };
}