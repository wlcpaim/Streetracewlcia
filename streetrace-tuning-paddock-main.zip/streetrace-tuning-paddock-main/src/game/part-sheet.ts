// Ficha técnica por peça para a auditoria ao vivo: nome, descrição, física, fórmulas com os números
// reais do setup e a ligação com os componentes vizinhos (fluxo de dados na simulação). Somente leitura.
import { FUEL_DENSITY, STOCK_PSI, ccOf, engine, exhaustId, drivetrain, gearSpeeds, wheelForceN, stats, tireOf, type BikeModel, type Setup } from "./physics";
import { CAM_FX, CAM_LABEL, SLOTS, partById, type Slot } from "./parts";
import { exhaustInfo, exhaustSpec } from "./exhaust";

const f = (n: number, d = 2) => (Number.isFinite(n) ? n.toFixed(d) : "—");
type Sheet = { desc: string; fis: string; form: string[]; link: string };

/** Builds the per-part technical sheets (block 1 of the audit). Deterministic. */
export function partSheets(b: BikeModel, s: Setup, fuelL: number, riderKg: number): string[] {
  const e = engine(b, s), st = stats(b, s, fuelL), tire = tireOf(s), cc = ccOf(b, s);
  const m = st.kg + riderKg, g = 9.81, tqNm = st.torque * 9.80665;
  const wRpm = e.rpmPeak, w = (wRpm * 2 * Math.PI) / 60;
  const ratio = s.rear / s.front;
  const Fw = wheelForceN(b, s, 1, tqNm); // T × i_total(1ª) × η / r_din — a mesma cadeia da corrida
  const ex = exhaustInfo(exhaustId(s), cc, e.rpmPeak), xs = exhaustSpec(exhaustId(s));
  const trac = 0.62 * m * g * 1.05 * tire.grip;
  const P = (k2: Slot) => partById(s.slots[k2]);
  const S: Partial<Record<Slot, Sheet>> = {
    cilindro: { desc: "Camisa onde o pistão corre; o diâmetro define a cilindrada.", fis: "Volume deslocado, enchimento volumétrico, demanda de ar/combustível.",
      form: [`V = π/4 × D² × curso = ${f(cc, 1)} cc`, `hp ∝ V × mul_peça (hpMul ${P("cilindro")?.hpMul ?? 1}) → hp motor ${f(e.hp, 2)} cv`, `demanda comb. +${Math.round((P("cilindro")?.need ?? 0) * 100)}% sobre o bico`],
      link: "Cilindro → pistão → biela → virabrequim. A cilindrada entra em engine() (hp), em fuelChain() (pede combustível ao bico/bomba) e em exhaust.ts (diâmetro ideal do escape)." },
    pistao: { desc: "Fecha a câmara e recebe a pressão da combustão.", fis: "Força de gás F = p × A, carga térmica na coroa, inércia alternada.",
      form: [`A = π/4 × D² (D do cilindro)`, `F_gás = p_cil × A ; F_inércia = m_p × r × ω² × (1 + λ)`, `ω no pico = ${wRpm} × 2π/60 = ${f(w, 1)} rad/s`],
      link: "Pistão → pino → biela. A força entra em mechlimits (tração/compressão da biela) e o calor no limite da coroa." },
    biela: { desc: "Converte o movimento alternado em rotação.", fis: "Tração no PMS de escape, compressão/flambagem na combustão, fadiga.",
      form: [`F_tração = m_alt × r × ω² × (1 + r/L)`, `limite de giro → corte ${e.rpmLimit} rpm`],
      link: "Pistão → biela → moente do virabrequim → engrenagem primária → embreagem." },
    molas: { desc: "Fecham as válvulas seguindo o came.", fis: "Força da mola vs aceleração do trem de válvulas (flutuação).",
      form: [`F_mola ≥ m_trem × a_came(ω²)`, `flutua quando ω² × m × a_rel > k × x`],
      link: "Comando → tucho/balancim → válvula ↔ mola. Limita o giro usado em engine() e verificado em mechlimits (folga de válvula)." },
    oleo: { desc: "Película lubrificante entre metais.", fis: "Viscosidade, atrito hidrodinâmico, desgaste por km.",
      form: [`perda ∝ km_óleo (${Math.round(s.oilKm)} km) → reduz hp em engine()`],
      link: "Banha virabrequim, biela, comando e câmbio; o desgaste multiplica o hp do motor." },
    vela: { desc: "Gera a faísca que inicia a combustão.", fis: "Energia de ignição, início da queima (Wiebe).", form: ["x_b(θ) = 1 − exp(−a × ((θ−θ0)/Δθ)^(m+1))"],
      link: "Bateria → cabo → vela → câmara. O ponto do módulo define θ0." },
    cabo: { desc: "Leva a alta tensão até a vela.", fis: "Perda resistiva e estabilidade da centelha.", form: ["V_vela = V_bobina − I × R_cabo"], link: "Bobina/módulo → cabo → vela." },
    bateria: { desc: "Alimenta injeção e ignição.", fis: "Tensão estável e massa no conjunto.", form: [`massa entra em m_total = ${f(m, 1)} kg`], link: "Bateria → módulo, bomba, bico e bobina. O peso entra em stats()." },
    bico: { desc: "Injeta combustível por pulso.", fis: "Vazão mássica, duty cycle, teto de entrega.",
      form: [`vazão ×${P("bico")?.flow ?? 1}`, "duty = t_injeção / t_ciclo ; t_ciclo = 120/rpm", "λ_real = ar_real / (comb_entregue × AFR_stoich)"],
      link: "Bomba → trilho → bico → admissão. fuelChain(): demanda (cilindro, comando) vs entrega (bomba × bico × mapa)." },
    bomba: { desc: "Pressuriza o combustível no trilho.", fis: "Pressão e vazão volumétrica.", form: [`vazão ×${P("bomba")?.flow ?? 1}`, "Q_bico ∝ √(Δp)"], link: "Tanque → bomba → trilho → bico. Teto da cadeia de alimentação." },
    tbi: { desc: "Corpo de borboleta: controla a entrada de ar.", fis: "Escoamento por restrição (fluxo de ar).", form: ["ṁ_ar = Cd × A × √(2ρΔp)"], link: "Filtro → TBI → coletor → válvula de admissão. Define quanto ar o bico precisa acompanhar." },
    modulo: { desc: "Central de ignição/injeção.", fis: "Corte de giro, mapa de combustível e ponto.",
      form: [`corte = ${e.rpmLimit} rpm`, `ponto mapa ${s.ecu.timing}°`, "mistura(rpm) = trims por faixa (mixtureAt)"], link: "Lê rpm do virabrequim → comanda bico e vela; limita o giro de cada marcha e a largada." },
    escape: { desc: "Remove os gases e sintoniza a onda de pressão.", fis: "Velocidade dos gases, ressonância (onda), restrição.",
      form: [`tubo d = ${xs.d} mm · L = ${xs.L}`, `d_ideal = f(cc ${f(cc, 0)}, rpm ${wRpm}) = ${f(ex.dIdeal, 1)} mm`, `ressonância ≈ ${Math.round(ex.tunedRpm)} rpm`],
      link: "Válvula de escape → coletor → tubo → ponteira. exhaustMul()/exhaustShape() multiplicam a potência do motor por rpm." },
    embreagem: { desc: "Acopla o motor ao câmbio.", fis: "Atrito entre discos, capacidade de torque, calor de patinagem.",
      form: [`capacidade = ${P("embreagem")?.clutchNm ?? 22} N·m`, `torque motor = ${f(tqNm, 1)} N·m → ${tqNm > (P("embreagem")?.clutchNm ?? 22) ? "PATINA" : "acopla"}`, "P_patinagem = T × Δω"],
      link: "Virabrequim → engrenagem primária → cesta da embreagem → eixo primário do câmbio." },
    pneu: { desc: "Contato com o asfalto.", fis: "Atrito (aderência), resistência ao rolamento, calibragem.",
      form: [`grip = composto × μ_pressão(${s.psi} psi, rec ${STOCK_PSI}) × (1 − 0,18×desgaste) = ${f(tire.grip, 4)}`, `crr = ${f(tire.crr, 5)}`, `tração = 0,62 × ${f(m, 1)} × 9,81 × 1,05 × grip = ${f(trac, 1)} N`],
      link: "Roda traseira → pneu → asfalto. Força na roda acima da tração = patina (SPIN_GRIP)." },
    susp: { desc: "Transfere peso na largada.", fis: "Transferência de carga longitudinal.", form: ["ΔN = m × a × h_cg / entre-eixos"], link: "Chassi ↔ balança ↔ eixo traseiro; aumenta a carga no pneu traseiro." },
    roda: { desc: "Aro que gira com o pneu.", fis: "Massa e inércia girante.", form: ["m_eq = m + I/r²", `raio dinâmico ≈ ${f(drivetrain(b, s).rDynM, 4)} m (estático × fator de rolagem, estimado)`],
      link: "Cubo da roda traseira ← coxins ← coroa ← corrente 428 ← pinhão ← eixo secundário do câmbio." },
  };
  const L: string[] = [];
  const block = (slot: string, name: string, sh: Sheet) => L.push(
    `{ ${slot.toUpperCase()}`, `  Nome: ${name}`, `  Descrição: ${sh.desc}`, `  Matemática e física: ${sh.fis}`,
    "  Fórmulas da peça:", ...sh.form.map((x) => `    · ${x}`), `  Conexões: ${sh.link}`, "}");
  for (const sl of SLOTS) {
    const p = partById(s.slots[sl]);
    const sh = S[sl];
    if (sh) block(sl, p ? `${p.brand ?? ""} ${p.name} (${p.spec})`.trim() : s.slots[sl], sh);
  }
  const cam = CAM_FX[s.cam] ?? CAM_FX.original;
  block("comando", CAM_LABEL[s.cam] ?? s.cam, { desc: "Abre e fecha as válvulas; define onde o motor tem força.", fis: "Levantamento, duração e cruzamento de válvulas.",
    form: [`pico = ${b.rpmPeak} ${cam.rpm >= 0 ? "+" : "−"} ${Math.abs(cam.rpm)} (+ serviços) = ${e.rpmPeak} rpm`, `hp × ${cam.mul}`], link: "Virabrequim → corrente de comando (2:1) → came → válvulas → molas." });
  block("cabeçote", `taxa ${s.compression}:1`, { desc: "Fecha a câmara; a taxa define a compressão.", fis: "Ciclo Otto, detonação, folga pistão-válvula.",
    form: [`η_Otto = 1 − 1/r^(γ−1) = ${f(1 - 1 / Math.pow(s.compression, 0.4), 4)} (γ=1,4)`, `mul_taxa = 1 + (${s.compression} − 9,5) × 0,025 = ${f(1 + (s.compression - 9.5) * 0.025, 4)}`],
    link: "Cabeçote ↔ cilindro ↔ pistão; aloja válvulas, vela e comando." });
  block("transmissão", `pinhão ${s.front}T × coroa ${s.rear}T · corrente 428`, { desc: "Relação final entre câmbio e roda traseira.", fis: "Multiplicação de torque e redução de rotação (conservação de potência).",
    form: [`i_final = ${s.rear}/${s.front} = ${f(ratio, 3)}`, `T_roda = T_motor × i_prim × i_marcha × i_final × η`, `F_roda = T_roda / r_roda (1ª, estimado ≈ ${f(Fw, 0)} N)`, `v_marcha = (corte·2π/60) × r_din / (i_prim × i_marcha × ${s.rear}/${s.front}) → ${gearSpeeds(b, s).map((v) => f(v, 1)).join(" / ")} km/h`],
    link: "Eixo secundário do câmbio → pinhão → corrente 428 → coroa → coxins → cubo → roda traseira → pneu → asfalto. Em step(), a força na roda é T_motor × i_total × η ÷ r_din (mesma cadeia de physics.drivetrain) e é limitada pela tração do pneu." });
  block("combustível", `${s.fuel} · ${f(fuelL, 2)} L`, { desc: "Energia química do motor.", fis: "Densidade, AFR estequiométrico, consumo específico (BSFC).",
    form: [`massa = ${f(fuelL, 2)} × ${FUEL_DENSITY[s.fuel]} = ${f(fuelL * FUEL_DENSITY[s.fuel], 2)} kg`, "consumo = P × BSFC / ρ"], link: "Tanque → bomba → bico → câmara; massa entra em stats(), consumo em step()." });
  return L;
}
