// Identidade mecânica da moto EQUIPADA (lida do setup real, não do nome comercial) e diagnóstico da mistura
// por faixa de giro. Mecânico, dinamômetro, afinamento e /api/mecanico leem daqui para não confundir
// platinado, CDI e ECU nem chamar de "redondinha" uma mistura rica.
import { engine, mixState, type BikeModel, type Setup } from "./physics";
import { effectiveModulo, ignitionOf, hasElectronicCut, type IgnArch } from "./ignition";
import { PLATFORMS } from "./platform/platforms";
import { SLOTS, slotPart } from "./parts";

export interface MechIdentity {
  bikeId: string; nome: string; cc: number; ignicao: IgnArch; ignicaoLabel: string;
  alimentacao: string; eletrica: string; modulo: { id: string; nome: string; original: boolean; programavel: boolean; corteEletronico: boolean };
  /** O que o jogador consegue ajustar nesta arquitetura. */
  ajustes: string[]; modificadas: string[];
}
export const IGN_LABEL: Record<IgnArch, string> = { platinado: "Platinado (contato + condensador)", cdi: "CDI", ecu: "Injeção eletrônica (ECU)" };

export function identify(b: BikeModel, s: Setup): MechIdentity {
  const arch = ignitionOf(b.id), pf = PLATFORMS[b.id], mod = effectiveModulo(b, s);
  const prog = arch === "ecu" && !!mod.prog;
  const ajustes = arch === "platinado" ? ["relação", "pneu", "combustível", "peças de motor"]
    : arch === "cdi" ? ["relação", "pneu", "combustível", "CDI esportivo (sem corte)"]
    : prog ? ["mapa de injeção por faixa", "ponto", "corte", "2-step", "trocas"] : ["relação", "pneu", "combustível", "módulo da Moto Peças"];
  const modificadas = SLOTS.filter((k) => s.slots[k] && !slotPart(s.slots[k], k).factory).map((k) => slotPart(s.slots[k], k).name);
  return {
    bikeId: b.id, nome: b.name, cc: b.cc, ignicao: arch, ignicaoLabel: IGN_LABEL[arch],
    alimentacao: arch === "ecu" ? "injeção eletrônica" : "carburador",
    eletrica: pf?.versao ?? "—",
    modulo: arch === "platinado"
      ? { id: "—", nome: "sem módulo (platinado)", original: true, programavel: false, corteEletronico: false }
      : { id: mod.id, nome: mod.name, original: !!mod.factory, programavel: prog, corteEletronico: hasElectronicCut(b, mod) },
    ajustes, modificadas,
  };
}

export type MixState = "rica" | "pobre" | "ideal";
export interface MixBand { faixa: "baixa" | "média" | "alta"; lo: number; hi: number; lambdaMin: number; lambdaMax: number; estado: MixState }
export interface MixDiag { estado: MixState; bandas: MixBand[]; lambdaMin: number; lambdaMax: number; variacao: number }
/** Limites de λ: < 0,80 excesso; > 0,95 falta; entre eles, janela de potência. */
export const LAMBDA_RICH = 0.8, LAMBDA_LEAN = 0.95;
const classify = (l: number): MixState => (l < LAMBDA_RICH ? "rica" : l > LAMBDA_LEAN ? "pobre" : "ideal");

/** Varre toda a puxada (3.000 rpm até o corte) com a mistura da física e classifica cada faixa. */
export function mixDiagnosis(b: BikeModel, s: Setup): MixDiag {
  const e = engine(b, s), top = e.rpmLimit, cut1 = top / 3 + 2000, cut2 = (2 * top) / 3 + 1000;
  const bands: MixBand[] = [];
  for (let rpm = 3000; rpm <= top; rpm += 250) {
    const l = mixState(b, s, rpm, e.rpmPeak).lambda_mix, faixa = rpm < cut1 ? "baixa" : rpm < cut2 ? "média" : "alta";
    let x = bands.find((z) => z.faixa === faixa);
    if (!x) bands.push((x = { faixa, lo: rpm, hi: rpm, lambdaMin: l, lambdaMax: l, estado: "ideal" }));
    x.hi = rpm; x.lambdaMin = Math.min(x.lambdaMin, l); x.lambdaMax = Math.max(x.lambdaMax, l);
  }
  for (const x of bands) x.estado = x.lambdaMax > LAMBDA_LEAN ? "pobre" : x.lambdaMin < LAMBDA_RICH ? "rica" : "ideal";
  const lambdaMin = Math.min(...bands.map((x) => x.lambdaMin)), lambdaMax = Math.max(...bands.map((x) => x.lambdaMax));
  const estado = bands.some((x) => x.estado === "pobre") ? "pobre" : bands.some((x) => x.estado === "rica") ? "rica" : "ideal";
  return { estado, bandas: bands, lambdaMin, lambdaMax, variacao: lambdaMax - lambdaMin };
}
export { classify as classifyLambda };

/** Como corrigir a mistura nesta arquitetura (direção, nunca a peça exata). */
export function mixFixHint(id: MechIdentity, estado: MixState, faixa?: string): string {
  if (estado === "ideal") return "";
  const mais = estado === "pobre";
  if (id.ignicao === "ecu" && id.modulo.programavel) return `${mais ? "Abre" : "Tira"} injeção no mapa${faixa ? ` na faixa ${faixa}` : ""}.`;
  if (id.ignicao === "ecu") return mais ? "Tá magra: o bico não dá conta desse motor." : "Tá gorda: o bico tá jogando demais.";
  return mais ? "Carburador magro: precisa de mais gasolina pra esse motor." : "Carburador gordo: tá entrando gasolina demais.";
}
