/**
 * Conversão "Passar pro Álcool" (motos carburadas não flex). O giclê ideal sai da equação de orifício:
 *   ṁ = Cd·A·√(2ρΔp) → para o mesmo ar na estequiometria: A_et/A_g = (AFR_g/AFR_et)·√(ρ_g/ρ_et)
 * O número do giclê é o diâmetro × 100, então jet_et = jet_g·√(A_et/A_g).
 * Giclê menor que o ideal entrega menos combustível (falta · mistura magra); maior entrega mais (excesso · gorda).
 * A mistura da corrida lê Setup.gicles em physics.mixtureCalc — nenhum multiplicador solto aqui.
 */
import { CONSTANTS } from "./physics-registry/constants";
import { partById } from "./parts";
import type { Player } from "./store";

const AFR_G = CONSTANTS["fuel.afr.gasolina_c_e27"].valor;
const AFR_E = CONSTANTS["fuel.afr.etanol_hidratado"].valor;
const RHO_G = CONSTANTS["fuel.rho.gasolina_c_e27"].valor;
const RHO_E = CONSTANTS["fuel.rho.etanol_hidratado"].valor;

/** Razão de área do orifício para o etanol entregar a estequiometria com o mesmo ar. */
export const JET_AREA_RATIO = (AFR_G / AFR_E) * Math.sqrt(RHO_G / RHO_E);
/** Giclê ideal no álcool a partir do giclê de fábrica na gasolina (número = Ø × 100). */
export const jetIdeal = (stockJet: number) => stockJet * Math.sqrt(JET_AREA_RATIO);

/** Giclês de fábrica (manual de cada carburador) e a junta de cada moto carburada. */
export const CARB_STOCK: Record<string, { alta: number; lenta: number; junta: string }> = {
  cg125: { alta: 100, lenta: 40, junta: "junta-carb-keihin-077a" },
  titan150: { alta: 115, lenta: 38, junta: "junta-carb-keihin-pdc9" },
};

/** Ganho da conversão por moto (cv), definido pelo dono do jogo: Bolinha +2,5 · Titan 150 +0,8. */
export const ALCOOL_GAIN: Record<string, number> = { cg125: 2.5, titan150: 0.8 };
export const alcoolGain = (bikeId: string) => ALCOOL_GAIN[bikeId] ?? 0;

/** Mangueira e filtro compatíveis com álcool (universais). */
export const ALCOOL_LINE = ["mangueira-comb-etanol", "filtro-comb-etanol"] as const;
/** Mão de obra da conversão na Oficina. */
export const ALCOOL_LABOR = 120;

export interface AlcoolRecipe { altaIdeal: number; lentaIdeal: number; junta: string; linha: string[] }
/** Receita da conversão da moto (null = injetada/flex, já nasce pronta pro álcool). */
export function alcoolRecipe(bikeId: string | null | undefined): AlcoolRecipe | null {
  const c = bikeId ? CARB_STOCK[bikeId] : null;
  if (!c) return null;
  return { altaIdeal: jetIdeal(c.alta), lentaIdeal: jetIdeal(c.lenta), junta: c.junta, linha: [...ALCOOL_LINE] };
}

/** Vazão entregue vs a pedida: razão de áreas (número do giclê ao quadrado). 1 = na medida. */
export const jetSupply = (jet: number, ideal: number) => (jet / ideal) ** 2;

const round2 = (n: number) => Math.round(n * 100) / 100;

/** Monta a conversão: consome giclês, junta, mangueira e filtro do estoque e grava a medida no motor. */
export function runAlcool(p: Player, altaId: string, lentaId: string, labor = ALCOOL_LABOR): Player {
  const rec = alcoolRecipe(p.activeBike);
  if (!rec || p.setup.alcool || p.money < labor) return p;
  const alta = partById(altaId), lenta = partById(lentaId);
  if (!alta?.jet || !lenta?.jet || alta.kind !== "gicle_alta" || lenta.kind !== "gicle_lenta") return p;
  const need = [altaId, lentaId, rec.junta, ...rec.linha];
  if (need.some((id) => !p.parts.includes(id))) return p;
  const parts = [...p.parts];
  for (const id of need) parts.splice(parts.indexOf(id), 1);
  return {
    ...p,
    money: round2(p.money - labor),
    parts,
    setup: { ...p.setup, alcool: true, gicles: { alta: alta.jet, lenta: lenta.jet, altaIdeal: rec.altaIdeal, lentaIdeal: rec.lentaIdeal } },
  };
}

/** Kit de juntas de carburador que serve na moto (consumido a cada abertura do carburador). */
export const juntaFor = (p: Player) => p.parts.find((id) => { const x = partById(id); return x?.kind === "junta_carb" && (!x.bikes || x.bikes.includes(p.activeBike ?? "")); }) ?? null;

/** Troca de giclê (universal, com ou sem álcool): abre o carburador, gasta 1 kit de juntas, o giclê novo sai do estoque e o antigo volta. */
export function swapJet(pl: Player, id: string): Player {
  const x = partById(id); const c = pl.activeBike ? CARB_STOCK[pl.activeBike] : undefined;
  if (!x?.jet || !c || (x.kind !== "gicle_alta" && x.kind !== "gicle_lenta")) return pl;
  const g = pl.setup.gicles ?? { alta: c.alta, lenta: c.lenta, altaIdeal: c.alta, lentaIdeal: c.lenta };
  const k = x.kind === "gicle_alta" ? "alta" : "lenta";
  if (g[k] === x.jet) return pl;
  const junta = juntaFor(pl);
  const parts = [...pl.parts]; const i = parts.indexOf(id);
  if (i < 0 || !junta) return pl;
  parts.splice(i, 1); parts.splice(parts.indexOf(junta), 1);
  const old = `gicle-${k}-${g[k]}`; if (partById(old)) parts.push(old);
  return { ...pl, parts, setup: { ...pl.setup, gicles: { ...g, [k]: x.jet } } };
}
