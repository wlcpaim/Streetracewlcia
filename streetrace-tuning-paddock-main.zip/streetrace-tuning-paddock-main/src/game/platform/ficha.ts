// Ficha técnica de fábrica por moto, lida só da plataforma (platforms.ts) e das válvulas de fábrica (sintonia.ts).
// Dado sem documento aparece como "sem ficha"; nada é inventado aqui.
import { platformOf, type Dado } from "./platforms";
import { factoryValves } from "../sintonia";

export type FichaRow = { k: string; v: string; origem: Dado["origem"] };
export type FichaGroup = { title: string; rows: FichaRow[] };

const fmt = (d: Dado | undefined): string => {
  if (!d || d.valor == null) return "sem ficha";
  const v = typeof d.valor === "number" ? d.valor.toLocaleString("pt-BR", { maximumFractionDigits: 3 }) : d.valor;
  return d.unidade && d.unidade !== "—" ? `${v} ${d.unidade}` : String(v);
};
const row = (k: string, d: Dado | undefined): FichaRow => ({ k, v: fmt(d), origem: d?.origem ?? "DESCONHECIDO" });
const txt = (k: string, v: string): FichaRow => ({ k, v, origem: "DOCUMENTADO" });

export function fichaOf(bikeId: string): FichaGroup[] {
  const P = platformOf(bikeId);
  if (!P) return [];
  const m = P.motor.dados, v = factoryValves(bikeId);
  const ali = Object.entries(P.alimentacao.dados).map(([k, d]) => row(LABEL[k] ?? k, d));
  const ign = Object.entries(P.ignicao.dados).map(([k, d]) => row(LABEL[k] ?? k, d));
  return [
    { title: "Motor de fábrica", rows: [
      txt("Arquitetura", `${P.motor.arquitetura} · ${P.motor.valvulas} válvulas · ${P.motor.refrigeracao}`),
      row("Diâmetro", m["diametro"]), row("Curso", m["curso"]), row("Taxa", m["taxa"]), row("Biela (c-c)", m["biela"]), row("Pino do pistão", m["pino"]),
      txt("Válvulas adm/esc", `${v.adm.toLocaleString("pt-BR")} / ${v.esc.toLocaleString("pt-BR")} mm`),
      ...(m["marchaLenta"] ? [row("Marcha lenta", m["marchaLenta"])] : []),
    ] },
    { title: "Alimentação e ignição", rows: [txt("Alimentação", P.alimentacao.componentes[0] ?? P.alimentacao.tipo), ...ali, txt("Ignição", P.ignicao.componentes[0] ?? P.ignicao.arq), ...ign, txt("Elétrica", `${P.eletrica.tensaoV} V · partida ${P.eletrica.partida}`)] },
    { title: "Transmissão", rows: [txt("Marchas", String(P.transmissao.marchas)), row("Primária", P.transmissao.dados["primaria"]), row("Câmbio", P.transmissao.dados["cambio"]), row("Final", P.transmissao.dados["final"])] },
    { title: "Ciclística", rows: [
      ...Object.entries(P.chassi.dados).map(([k, d]) => row(LABEL[k] ?? k, d)),
      ...Object.entries(P.suspensao).map(([k, d]) => row(LABEL[k] ?? k, d)),
      ...Object.entries(P.rodas).map(([k, d]) => row(LABEL[k] ?? k, d)),
      txt("Freios", `${P.freios.dianteiro} / ${P.freios.traseiro}`),
    ] },
  ];
}

const LABEL: Record<string, string> = {
  pressao: "Pressão de combustível", venturi: "Venturi", gicleAlta: "Giclê de alta", gicleLenta: "Giclê de lenta", boia: "Boia", parafusoAr: "Parafuso de ar", marchaLenta: "Marcha lenta",
  corte: "Corte", limitador: "Limitador", rpmMaxFicha: "Giro máximo de força",
  pesoSeco: "Peso seco", entreEixos: "Entre-eixos", comprimento: "Comprimento", altura: "Altura", assento: "Altura do assento", solo: "Vão livre", caster: "Cáster", trail: "Trail",
  garfoCurso: "Curso do garfo", traseiraCurso: "Curso traseiro", traseira: "Suspensão traseira", pneus: "Pneus", aro: "Aro",
};
