// Matriz de compatibilidade por moto. Cada peça recebe uma classe e o motivo técnico; nada é aprovado
// só por ser da mesma marca. A ignição usa ignition.fitsBike (fonte única da arquitetura elétrica).
import type { Part } from "../parts";
import { fitsBike, ignitionOf } from "../ignition";
import { PLATFORMS, isCarb, voltageOf } from "./platforms";

export type Compat = "OEM" | "DIRETO" | "ADAPTACAO" | "INCOMPATIVEL" | "NAO_COMPROVADO";
export const COMPAT_LABEL: Record<Compat, string> = { OEM: "Original", DIRETO: "Compatível direto", ADAPTACAO: "Adaptação", INCOMPATIVEL: "Incompatível", NAO_COMPROVADO: "Não comprovado" };

/** Peças de motor/preparação do catálogo atual foram dimensionadas na família Honda OHC 57,3 mm (CG 160). */
const MOTOR_INTERNO = new Set(["kit", "cilindro", "pistao", "biela", "vira", "cabecote", "comando", "valvula", "molas"]);
const INJECAO = new Set(["bico", "bomba", "tbi"]);
const CARB = new Set(["gicle_alta", "gicle_lenta", "junta_carb"]);

export function compatOf(part: Pick<Part, "id" | "kind" | "ign" | "bikes" | "factory" | "spec" | "name">, bikeId: string): { c: Compat; motivo: string } {
  const pf = PLATFORMS[bikeId];
  if (!pf) return { c: "NAO_COMPROVADO", motivo: "moto sem plataforma técnica cadastrada" };
  if (part.factory || part.id.endsWith("-original")) return { c: "OEM", motivo: `peça de fábrica da ${pf.nome}` };
  if (part.bikes && !part.bikes.includes(bikeId)) return { c: "INCOMPATIVEL", motivo: `aplicação só para ${part.bikes.join(", ")}` };
  if (part.kind === "modulo" && !fitsBike(part, bikeId)) return { c: "INCOMPATIVEL", motivo: `ignição ${ignitionOf(bikeId)} não aceita este módulo` };
  if (INJECAO.has(part.kind) && isCarb(bikeId)) return { c: "INCOMPATIVEL", motivo: "motor carburado: não tem bico, bomba elétrica nem corpo de borboleta" };
  if (CARB.has(part.kind) && !isCarb(bikeId)) return { c: "INCOMPATIVEL", motivo: "motor injetado: não tem carburador" };
  if (part.kind === "bateria") {
    const v = /\b(6|12)\s*V\b/i.exec(`${part.name} ${part.spec}`);
    const vb = voltageOf(bikeId);
    if (v && Number(v[1]) !== vb) return { c: "INCOMPATIVEL", motivo: `sistema elétrico ${vb} V, bateria de ${v[1]} V` };
    if (!v && vb === 6) return { c: "NAO_COMPROVADO", motivo: "tensão da bateria não informada; Bolinha é 6 V" };
  }
  if (part.bikes?.includes(bikeId)) return { c: "DIRETO", motivo: `aplicação declarada para a ${pf.nome}` };
  if (MOTOR_INTERNO.has(part.kind)) {
    if (bikeId === "titan160") return { c: "DIRETO", motivo: "catálogo de preparação dimensionado na CG 160 (Ø 57,3, pino 14)" };
    if (bikeId === "titan150") return { c: "ADAPTACAO", motivo: "mesmo Ø 57,3 da CG 160, curso 57,8 × 63,1: altura de compressão e biela precisam ser conferidas" };
    if (bikeId === "factor150") return { c: "ADAPTACAO", motivo: "Yamaha SOHC com pino 15: peça Honda exige conferência de pino, juntas e fixação" };
    return { c: "NAO_COMPROVADO", motivo: "Bolinha OHV (varetas, Ø 56,5, curso 49,5): sem medida que comprove montagem" };
  }
  return { c: "DIRETO", motivo: "peça de uso geral sem restrição dimensional cadastrada" };
}

/** Pode aparecer na loja desta moto? Incompatível nunca; o resto aparece com a classe à vista. */
export const sellableFor = (part: Parameters<typeof compatOf>[0], bikeId: string) => compatOf(part, bikeId).c !== "INCOMPATIVEL";
