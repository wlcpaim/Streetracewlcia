// Plataformas técnicas independentes por moto: motor, alimentação, ignição, elétrica, chassi, suspensão,
// rodas, freios e transmissão. Cada grandeza traz origem (DOCUMENTADO, CALCULADO, ESTIMADO, DESCONHECIDO),
// fonte e, quando estimada, faixa de incerteza. Nada aqui é compartilhado automaticamente entre motos.
import { ENGINE_CATALOG } from "../data/engine_catalog";
import { ignitionOf, type IgnArch } from "../ignition";

export type Origem = "DOCUMENTADO" | "CALCULADO" | "ESTIMADO" | "DESCONHECIDO";
export interface Dado { valor: number | string | null; unidade: string; origem: Origem; fonte: string; faixa?: [number, number] }
export type Feed = "carburador" | "injecao-honda" | "injecao-yamaha";

const F150 = "Ficha técnica Honda CG 150 Titan ESD 2004–2008 (fornecida pelo jogador)";
const F125 = "Ficha técnica Honda CG 125 1ª geração 1976–1982 (fornecida pelo jogador)";
const FCARB = "Especificação de carburação OEM fornecida pelo jogador";
const JOGO = "Cadastro do jogo (physics.ts BikeModel)";
const HAYNES = "Haynes CG125 1976–1991 (mercado europeu, 5 marchas) — NÃO aplicável à Bolinha brasileira de 4 marchas";

const doc = (valor: number | string, unidade: string, fonte: string): Dado => ({ valor, unidade, origem: "DOCUMENTADO", fonte });
const calc = (valor: number, unidade: string, formula: string): Dado => ({ valor, unidade, origem: "CALCULADO", fonte: formula });
const est = (valor: number | string, unidade: string, fonte: string, faixa?: [number, number]): Dado => ({ valor, unidade, origem: "ESTIMADO", fonte, ...(faixa ? { faixa } : {}) });
const unk = (unidade: string, fonte = "sem documento confiável para esta versão"): Dado => ({ valor: null, unidade, origem: "DESCONHECIDO", fonte });
const cat = (bike: string, k: string, unidade: string): Dado => {
  const p = ENGINE_CATALOG[bike]?.p[k];
  if (!p || p.valor == null) return unk(unidade);
  return { valor: p.valor, unidade: p.unidade || unidade, origem: p.origem === "CALCULADO" ? "CALCULADO" : p.origem === "OFICIAL" || p.origem === "MEDIDO" ? "DOCUMENTADO" : "ESTIMADO", fonte: p.fonte };
};

export interface Platform {
  bikeId: string; nome: string; versao: string;
  motor: { arquitetura: "OHV" | "OHC" | "SOHC"; acionamento: string; valvulas: number; lubrificacao: string; refrigeracao: string; dados: Record<string, Dado> };
  alimentacao: { tipo: Feed; componentes: string[]; dados: Record<string, Dado> };
  ignicao: { arq: IgnArch; componentes: string[]; dados: Record<string, Dado> };
  eletrica: { tensaoV: 6 | 12; partida: "pedal" | "eletrica" | "eletrica+pedal"; componentes: string[] };
  chassi: { quadro: string; dados: Record<string, Dado> };
  suspensao: Record<string, Dado>;
  rodas: Record<string, Dado>;
  freios: { dianteiro: "disco" | "tambor"; traseiro: "disco" | "tambor"; acionamento: string; dados: Record<string, Dado> };
  transmissao: { marchas: number; dados: Record<string, Dado> };
  /** Componentes que esta plataforma NÃO possui: o Scanner nunca pode exigi-los. */
  ausentes: string[];
}

const INJ = ["bico", "bomba", "tbi"];

export const PLATFORMS: Record<string, Platform> = {
  titan160: {
    bikeId: "titan160", nome: "Honda CG 160 Titan", versao: "flex, injeção PGM-FI",
    motor: { arquitetura: "OHC", acionamento: "comando no cabeçote por corrente, balancins", valvulas: 2, lubrificacao: "cárter úmido, bomba trocoidal", refrigeracao: "ar",
      dados: { diametro: cat("titan160", "diametro", "mm"), curso: cat("titan160", "curso", "mm"), taxa: cat("titan160", "taxaCompressao", "—"), biela: cat("titan160", "biela", "mm"), pino: cat("titan160", "pinoPistao", "mm"), marchaLenta: cat("titan160", "marchaLenta", "rpm") } },
    alimentacao: { tipo: "injecao-honda", componentes: ["ECU PGM-FI", "corpo de borboleta Honda", "bico injetor Honda", "bomba elétrica", "sensores (MAP, TPS, IAT, O2)"], dados: { pressao: cat("titan160", "pressaoCombustivel", "kPa") } },
    ignicao: { arq: "ecu", componentes: ["ignição comandada pela ECU", "bobina", "vela", "sensor de rotação"], dados: {} },
    eletrica: { tensaoV: 12, partida: "eletrica", componentes: ["estator", "regulador retificador", "bateria 12 V"] },
    chassi: { quadro: "tubular de aço tipo diamante", dados: { pesoSeco: doc(120, "kg", JOGO), entreEixos: unk("mm"), caster: unk("°"), trail: unk("mm") } },
    suspensao: { garfoCurso: unk("mm"), traseiraCurso: unk("mm"), traseira: doc("bichoque (2 amortecedores)", "—", JOGO) },
    rodas: { pneus: doc("80/100-18 · 100/80-18", "—", JOGO), aro: doc(18, "pol", JOGO) },
    freios: { dianteiro: "disco", traseiro: "tambor", acionamento: "hidráulico dianteiro (CBS) / mecânico traseiro", dados: { disco: unk("mm"), tambor: unk("mm") } },
    transmissao: { marchas: 5, dados: { primaria: cat("titan160", "relacaoPrimaria", "—"), cambio: cat("titan160", "relacoesCambio", "—"), final: cat("titan160", "relacaoFinal", "—") } },
    ausentes: ["carburador", "giclê", "platinado", "condensador", "CDI"],
  },
  factor150: {
    bikeId: "factor150", nome: "Yamaha Factor 150", versao: "UBS BlueFlex, injeção Yamaha",
    motor: { arquitetura: "SOHC", acionamento: "comando simples no cabeçote por corrente, balancins", valvulas: 2, lubrificacao: "cárter úmido", refrigeracao: "ar",
      dados: { diametro: cat("factor150", "diametro", "mm"), curso: cat("factor150", "curso", "mm"), taxa: cat("factor150", "taxaCompressao", "—"), biela: cat("factor150", "biela", "mm"), pino: cat("factor150", "pinoPistao", "mm"), marchaLenta: cat("factor150", "marchaLenta", "rpm") } },
    alimentacao: { tipo: "injecao-yamaha", componentes: ["ECU Yamaha", "corpo de borboleta Yamaha", "bico injetor Yamaha", "bomba de combustível", "sensores Yamaha"], dados: { pressao: cat("factor150", "pressaoCombustivel", "kPa") } },
    ignicao: { arq: "ecu", componentes: ["ignição TCI comandada pela ECU Yamaha", "bobina", "vela"], dados: {} },
    eletrica: { tensaoV: 12, partida: "eletrica", componentes: ["estator", "regulador retificador", "bateria 12 V"] },
    chassi: { quadro: "tubular de aço", dados: { pesoSeco: doc(133, "kg", JOGO), entreEixos: unk("mm"), caster: unk("°"), trail: unk("mm") } },
    suspensao: { garfoCurso: unk("mm"), traseiraCurso: unk("mm"), traseira: doc("bichoque (2 amortecedores)", "—", JOGO) },
    rodas: { pneus: doc("80/100-18 · 100/80-18", "—", JOGO), aro: doc(18, "pol", JOGO) },
    freios: { dianteiro: "disco", traseiro: "tambor", acionamento: "hidráulico dianteiro (UBS) / mecânico traseiro", dados: { disco: unk("mm"), tambor: unk("mm") } },
    transmissao: { marchas: 5, dados: { primaria: cat("factor150", "relacaoPrimaria", "—"), cambio: cat("factor150", "relacoesCambio", "—"), final: cat("factor150", "relacaoFinal", "—") } },
    ausentes: ["carburador", "giclê", "platinado", "condensador", "CDI", "PGM-FI"],
  },
  titan150: {
    bikeId: "titan150", nome: "Honda CG 150 Titan ESD", versao: "2004–2008, carburada, CDI 12 V (2009+ é PGM-FI e não é esta moto)",
    motor: { arquitetura: "OHC", acionamento: "comando no cabeçote por corrente, balancins", valvulas: 2, lubrificacao: "cárter úmido", refrigeracao: "ar",
      dados: { diametro: doc(57.3, "mm", F150), curso: doc(57.8, "mm", F150), taxa: doc(9.5, "—", F150), biela: unk("mm"), pino: unk("mm") } },
    alimentacao: { tipo: "carburador", componentes: ["carburador PDC9AA/PDC9AB 22 mm a vácuo", "coletor de admissão", "giclê principal", "giclê de lenta", "agulha", "pistonete", "boia"],
      dados: { venturi: doc(22, "mm", F150), gicleAlta: doc("115 ou 118 (conforme versão)", "#", FCARB), gicleLenta: doc(38, "#", FCARB), boia: doc("13,0 ou 13,8 (conforme versão)", "mm", FCARB), marchaLenta: doc("1.400 ± 100", "rpm", FCARB) } },
    ignicao: { arq: "cdi", componentes: ["CDI 12 V", "bobina de ignição", "estator (bobina de carga)", "sensor de pulsos", "vela"], dados: { corte: est(10000, "rpm", "Regra de corte autorizada pelo jogador; não é medição OEM") } },
    eletrica: { tensaoV: 12, partida: "eletrica", componentes: ["estator", "regulador retificador", "bateria 12 V"] },
    chassi: { quadro: "tubular de aço tipo diamante", dados: { pesoSeco: doc(112, "kg", F150), entreEixos: doc(1315, "mm", F150), comprimento: doc(1992, "mm", F150), altura: doc(1079, "mm", F150), assento: doc(792, "mm", F150), solo: doc(169, "mm", F150), caster: unk("°"), trail: unk("mm") } },
    suspensao: { garfoCurso: doc(130, "mm", F150), traseiraCurso: doc(101, "mm", F150), traseira: doc("duplo amortecedor", "—", F150) },
    rodas: { pneus: doc("2.75-18 · 90/90-18", "—", F150), aro: doc(18, "pol", F150) },
    freios: { dianteiro: "disco", traseiro: "tambor", acionamento: "hidráulico dianteiro / mecânico traseiro", dados: { disco: doc(240, "mm", F150), tambor: doc(130, "mm", F150) } },
    transmissao: { marchas: 5, dados: { primaria: cat("titan150", "relacaoPrimaria", "—"), cambio: cat("titan150", "relacoesCambio", "—"), final: cat("titan150", "relacaoFinal", "—") } },
    ausentes: ["bico injetor", "bomba elétrica", "corpo de borboleta", "ECU", "platinado", "condensador"],
  },
  cg125: {
    bikeId: "cg125", nome: "Honda CG 125 Bolinha", versao: "1976–1982, carburada, platinado 6 V, partida a pedal",
    motor: { arquitetura: "OHV", acionamento: "comando no bloco, varetas e balancins", valvulas: 2, lubrificacao: "cárter úmido, bomba trocoidal", refrigeracao: "ar",
      dados: { diametro: doc(56.5, "mm", F125), curso: doc(49.5, "mm", F125), taxa: doc(9.0, "—", F125), biela: unk("mm"), pino: est(15, "mm", "Haynes CG125: olho da biela 15,010–15,028 mm (mesma família de motor)", [15.01, 15.028]) } },
    alimentacao: { tipo: "carburador", componentes: ["carburador Keihin série 077A 20 mm", "coletor de admissão", "giclê principal", "giclê de lenta", "agulha", "parafuso de ar", "boia"],
      dados: { venturi: doc(20, "mm", F125), gicleAlta: doc(100, "#", FCARB), gicleLenta: doc(40, "#", FCARB), parafusoAr: doc(1.5, "volta", FCARB), boia: doc(18.5, "mm", FCARB) } },
    ignicao: { arq: "platinado", componentes: ["platinado", "condensador", "bobina de ignição 6 V", "circuito de baixa tensão", "vela e cabo"], dados: { limitador: doc("sem limitador de fábrica", "—", "ficha do jogador"), rpmMaxFicha: doc(9000, "rpm", F125) } },
    eletrica: { tensaoV: 6, partida: "pedal", componentes: ["magneto/alternador 6 V", "retificador", "bateria 6 V"] },
    chassi: { quadro: "tubular de aço tipo diamante (estampado)", dados: { pesoSeco: doc(94, "kg", F125), entreEixos: doc(1270, "mm", F125), comprimento: doc(1900, "mm", F125), altura: doc(1025, "mm", F125), solo: doc(140, "mm", F125), caster: unk("°"), trail: unk("mm") } },
    suspensao: { garfoCurso: doc(115, "mm", F125), traseiraCurso: doc(64, "mm", F125), traseira: doc("balança curva, duplo amortecedor", "—", F125) },
    rodas: { pneus: doc("2.50-18 · 2.75-18", "—", F125), aro: doc(18, "pol", F125) },
    freios: { dianteiro: "tambor", traseiro: "tambor", acionamento: "mecânico (cabo e haste)", dados: { tamborDianteiro: doc("102/110", "mm", F125), tamborTraseiro: doc("86/110", "mm", F125) } },
    transmissao: { marchas: 4, dados: { primaria: cat("cg125", "relacaoPrimaria", "—"), cambio: cat("cg125", "relacoesCambio", "—"), final: cat("cg125", "relacaoFinal", "—") } },
    ausentes: ["bico injetor", "bomba elétrica", "corpo de borboleta", "ECU", "CDI", "módulo", "partida elétrica"],
  },
};

export const platformOf = (bikeId: string): Platform | null => PLATFORMS[bikeId] ?? null;
export const isCarb = (bikeId: string) => PLATFORMS[bikeId]?.alimentacao.tipo === "carburador";
export const voltageOf = (bikeId: string) => PLATFORMS[bikeId]?.eletrica.tensaoV ?? 12;
export const INJECTION_SLOTS = INJ;
/** Sanidade: arquitetura de ignição da plataforma tem que bater com ignition.ts (fonte única do circuito). */
export const ignitionAgrees = (bikeId: string) => PLATFORMS[bikeId]?.ignicao.arq === ignitionOf(bikeId);
