// Pinos, conexões e cinemática biela-manivela. Read-only: não altera a física de corrida.
// Origem de cada valor: "ficha" (documentado), "calculado" (fórmula), "estimado" (valor típico de engenharia).
import { ENGINE_CATALOG } from "../data/engine_catalog";
import { partById, type Part } from "../parts";

export type Origem = "ficha" | "calculado" | "estimado";
export type Fixacao = "flutuante" | "prensado";
export interface Material { nome: string; tratamento: string; rho: number; tauAdm: number; sigmaAdm: number; origem: Origem }
// ρ kg/m³; tensões admissíveis MPa (núcleo, com fator de projeto já embutido) — valores típicos de catálogo.
export const MATERIAIS: Record<string, Material> = {
  "16MnCr5": { nome: "Aço 16MnCr5", tratamento: "cementado e retificado", rho: 7850, tauAdm: 210, sigmaAdm: 380, origem: "estimado" },
  "SAE8620": { nome: "Aço SAE 8620", tratamento: "cementado e temperado", rho: 7850, tauAdm: 230, sigmaAdm: 420, origem: "estimado" },
  "SAE4340": { nome: "Aço SAE 4340", tratamento: "temperado e nitretado", rho: 7850, tauAdm: 290, sigmaAdm: 520, origem: "estimado" },
};

export interface Pino { id: string; d: number; di: number; L: number; material: keyof typeof MATERIAIS; fixacao: Fixacao; aplicacao: string; origem: Origem }
/** Diâmetros com aplicação documentada nas fichas do jogo (Titan 14, Factor 15, Zayma 70 mm p15) e medidas comuns de reposição. Comprimento e Ø interno: estimados. */
export const PINOS: Pino[] = [
  { id: "pino-12", d: 12, di: 7, L: 40, material: "16MnCr5", fixacao: "flutuante", aplicacao: "monocilíndricos até 110 cc", origem: "estimado" },
  { id: "pino-13", d: 13, di: 7.5, L: 44, material: "16MnCr5", fixacao: "flutuante", aplicacao: "monocilíndricos 125 cc", origem: "estimado" },
  { id: "pino-14", d: 14, di: 8, L: 46, material: "SAE8620", fixacao: "flutuante", aplicacao: "Honda CG 160 Titan (ficha: Ø 14 mm)", origem: "ficha" },
  { id: "pino-15", d: 15, di: 9, L: 50, material: "SAE8620", fixacao: "flutuante", aplicacao: "Yamaha Factor 150 (ficha: Ø 15 mm), Zayma 70 mm, TXK", origem: "ficha" },
  { id: "pino-16", d: 16, di: 9.5, L: 54, material: "SAE4340", fixacao: "flutuante", aplicacao: "alta carga, cilindros acima de 220 cc", origem: "estimado" },
];
export interface Conexao { id: string; nome: string; funcao: string }
export const CONEXOES: Conexao[] = [
  { id: "olhal", nome: "Olhal menor da biela", funcao: "furo do pé da biela; recebe bucha ou o pino direto" },
  { id: "bucha", nome: "Bucha de bronze do pé da biela", funcao: "superfície de deslizamento do pino flutuante; Ø interno = Ø do pino + folga" },
  { id: "agulhas", nome: "Rolamento de agulhas", funcao: "usado em 2 tempos; não aplicável aos 4 tempos cadastrados" },
  { id: "travas", nome: "Travas de retenção (C ou arame)", funcao: "obrigatórias no pino flutuante; impedem o pino de riscar o cilindro" },
  { id: "flutuante", nome: "Pino flutuante", funcao: "gira no pistão e na bucha; folga 0,005–0,015 mm; exige travas" },
  { id: "prensado", nome: "Pino prensado/interferente", funcao: "interferência no olhal; dispensa travas; montagem com aquecimento da biela" },
];

const pinoOf = (d: number) => PINOS.find((p) => p.d === d) ?? null;
/** Massa do pino oco: m = ρ·π/4·(D²−d²)·L (calculado). */
export const massaPinoG = (p: Pino) => MATERIAIS[p.material]!.rho * Math.PI / 4 * ((p.d ** 2 - p.di ** 2) * p.L) * 1e-9 * 1000;
/** Carga admissível em cisalhamento duplo: F = 2·τ·A (N). */
export const cargaCisalhamentoN = (p: Pino) => 2 * MATERIAIS[p.material]!.tauAdm * Math.PI / 4 * (p.d ** 2 - p.di ** 2);
/** Carga admissível em flexão (viga bi-apoiada, carga distribuída no vão b): F = 8·σ·W/b, W = π(D⁴−d⁴)/(32D). Vão útil ≈ L/3 (estimado). */
export const cargaFlexaoN = (p: Pino) => { const W = Math.PI * (p.d ** 4 - p.di ** 4) / (32 * p.d); return 8 * MATERIAIS[p.material]!.sigmaAdm * W / (p.L / 3); };
export const limiteCargaN = (p: Pino) => Math.min(cargaCisalhamentoN(p), cargaFlexaoN(p));

/** Ø do pino que a peça aceita: peça com ficha, ou peça original pela ficha da moto. null = sem ficha (DESCONHECIDO). */
export function pinDe(partId: string | undefined, bikeId: string | null): number | null {
  const pt: Part | undefined = partId ? partById(partId) : undefined;
  if (pt?.pinMm) return pt.pinMm;
  if (!pt || pt.factory) { const v = ENGINE_CATALOG[bikeId ?? ""]?.p["pinoPistao"]?.valor; return typeof v === "number" ? v : null; }
  return null;
}

export interface Laudo { aprovado: boolean; bloqueado: boolean; motivo: string; solucao: string; pistaoMm: number | null; bielaMm: number | null }
/** Compatibilidade pistão × pino × biela. Bloqueia diâmetros diferentes; sem ficha → DESCONHECIDO (não aprova, não inventa). */
export function validarConjunto(pistaoId: string | undefined, bielaId: string | undefined, bikeId: string | null, pinoMm?: number): Laudo {
  const pistaoMm = pinDe(pistaoId, bikeId), bielaMm = pinDe(bielaId, bikeId);
  const pino = pinoMm ?? pistaoMm ?? bielaMm;
  const sol = "utilizar pistão e biela com dimensões compatíveis ou realizar um projeto de usinagem tecnicamente validado, quando possível.";
  if (pistaoMm != null && pino != null && pino !== pistaoMm) return { aprovado: false, bloqueado: true, motivo: `pino de ${pino} mm incompatível com alojamento do pistão de ${pistaoMm} mm.`, solucao: sol, pistaoMm, bielaMm };
  if (bielaMm != null && pino != null && pino !== bielaMm) return { aprovado: false, bloqueado: true, motivo: `pino de ${pino} mm incompatível com a bucha da biela de ${bielaMm} mm.`, solucao: sol, pistaoMm, bielaMm };
  if (pistaoMm == null || bielaMm == null) return { aprovado: false, bloqueado: false, motivo: `Ø do pino DESCONHECIDO (${pistaoMm == null ? "pistão" : "biela"} sem ficha).`, solucao: "cadastrar a ficha do fabricante antes da aprovação.", pistaoMm, bielaMm };
  if (pino == null || !pinoOf(pino)) return { aprovado: false, bloqueado: true, motivo: `não há pino de ${pino} mm com aplicação documentada.`, solucao: sol, pistaoMm, bielaMm };
  return { aprovado: true, bloqueado: false, motivo: `pino ${pino} mm · pistão ${pistaoMm} mm · biela ${bielaMm} mm`, solucao: "", pistaoMm, bielaMm };
}

/** Cinemática exata biela-manivela. r, l em m; retorna aceleração do pistão (m/s²) no ângulo θ (rad), positiva rumo ao PMS. */
export function aceleracaoExata(r: number, l: number, rpm: number, th: number): number {
  const w = 2 * Math.PI * rpm / 60, lam = r / l, s = Math.sin(th), c = Math.cos(th), k = Math.sqrt(1 - lam * lam * s * s);
  return -(w * w) * (-r * c - r * lam * ((c * c - s * s) / k + (lam * lam * s * s * c * c) / (k ** 3)));
}
/** Aproximação de 2ª ordem: a = r·ω²·(cosθ + λ·cos2θ). Apenas referência. */
export const aceleracaoAprox = (r: number, l: number, rpm: number, th: number) => r * (2 * Math.PI * rpm / 60) ** 2 * (Math.cos(th) + (r / l) * Math.cos(2 * th));
export const velMediaPistao = (cursoMm: number, rpm: number) => 2 * (cursoMm / 1000) * rpm / 60;

export interface Analise { vm: number; aPMS: number; fInercia: number; limite: number; fs: number; massaAlt: number; massaPino: number }
/** Força de inércia no PMS sobre o pino com massa alternativa (pistão + pino + travas/anéis, g). */
export function analisarPino(p: Pino, cursoMm: number, bielaMm: number, rpm: number, massaPistaoG: number, extrasG = 15): Analise {
  const r = cursoMm / 2000, l = bielaMm / 1000, mp = massaPinoG(p), massaAlt = massaPistaoG + mp + extrasG;
  const aPMS = aceleracaoExata(r, l, rpm, 0), fInercia = (massaAlt / 1000) * aPMS, limite = limiteCargaN(p);
  return { vm: velMediaPistao(cursoMm, rpm), aPMS, fInercia, limite, fs: limite / fInercia, massaAlt, massaPino: mp };
}
