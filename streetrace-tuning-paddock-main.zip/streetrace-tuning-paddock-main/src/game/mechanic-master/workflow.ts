import { CAMPOS, type Ficha, type Status } from "./types";
export type Acao = "avancar" | "aprovar_publicar" | "rejeitar" | "corrigir" | "atualizar_doc" | "reauditar";
const NEXT: Partial<Record<Status, Status>> = { "EM PESQUISA": "EM DOCUMENTAÇÃO", "EM DOCUMENTAÇÃO": "EM CÁLCULO", "EM CÁLCULO": "EM AUDITORIA", "EM AUDITORIA": "AGUARDANDO APROVAÇÃO", "EM CORREÇÃO": "EM AUDITORIA" };
/** Campos críticos sem valor bloqueiam a auditoria (nada é aprovado com DESCONHECIDO crítico). */
export const CRITICOS = ["fabricante", "material", "dimensoes", "limitesOperacao", "fontes"] as const;
export const lacunas = (f: Ficha) => CAMPOS.filter((c) => f[c]?.valor === null || f[c]?.valor === undefined);
export const bloqueios = (f: Ficha) => CRITICOS.filter((c) => f[c]?.valor === null || f[c]?.valor === undefined);
/** Transição de estado. Publicar exige ação explícita do admin e estado AGUARDANDO APROVAÇÃO/APROVADO. */
export function transicao(s: Status, a: Acao, f: Ficha): { ok: true; to: Status } | { ok: false; erro: string } {
  if (s === "PUBLICADO NO JOGO" && a !== "atualizar_doc" && a !== "reauditar") return { ok: false, erro: "Peça já publicada: dados validados não são apagados." };
  switch (a) {
    case "avancar": {
      const to = NEXT[s]; if (!to) return { ok: false, erro: `Sem próximo passo a partir de ${s}.` };
      if (to === "AGUARDANDO APROVAÇÃO" && bloqueios(f).length) return { ok: false, erro: `Auditoria bloqueada: ${bloqueios(f).join(", ")} DESCONHECIDO.` };
      return { ok: true, to };
    }
    case "aprovar_publicar":
      if (s !== "AGUARDANDO APROVAÇÃO" && s !== "APROVADO") return { ok: false, erro: "Só publica após auditoria concluída." };
      if (bloqueios(f).length) return { ok: false, erro: "Campos críticos desconhecidos." };
      return { ok: true, to: "PUBLICADO NO JOGO" };
    case "rejeitar": return { ok: true, to: "REJEITADO" };
    case "corrigir": return { ok: true, to: "EM CORREÇÃO" };
    case "atualizar_doc": return { ok: true, to: s === "PUBLICADO NO JOGO" ? s : "EM DOCUMENTAÇÃO" };
    case "reauditar": return { ok: true, to: s === "PUBLICADO NO JOGO" ? s : "EM AUDITORIA" };
  }
}
