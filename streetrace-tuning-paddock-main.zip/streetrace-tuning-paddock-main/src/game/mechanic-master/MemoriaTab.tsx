// MEMÓRIA DO MECÂNICO: painel admin. Mostra biblioteca (catálogo do jogo) + propostas do banco com a esteira de aprovação.
import { useEffect, useMemo, useState } from "react";
import { biblioteca, fabricantes } from "./library";
import { auditarFormulas } from "./formulas";
import { carregar, executar, proporPeca } from "./store";
import { lacunas, bloqueios, type Acao } from "./workflow";
import { CAMPOS, CAMPO_LABEL, CONFIANCA_LABEL, DESCONHECIDO, STATUSES, type Entrada, type Ficha } from "./types";
import services from "../data/workshop_services.json";

const ACOES: [Acao, string][] = [["avancar", "Avançar etapa"], ["aprovar_publicar", "Aprovar e adicionar ao jogo"], ["rejeitar", "Rejeitar"], ["corrigir", "Solicitar correção"], ["atualizar_doc", "Atualizar documentação"], ["reauditar", "Reexecutar auditoria"]];

export function MemoriaTab() {
  const lib = useMemo(biblioteca, []);
  const forms = useMemo(auditarFormulas, []);
  const [props, setProps] = useState<Entrada[]>([]);
  const [err, setErr] = useState<string | null>(null);
  const [q, setQ] = useState(""); const [sel, setSel] = useState<Entrada | null>(null);
  const [nome, setNome] = useState(""); const [cat, setCat] = useState("pistao");
  const reload = () => carregar().then(setProps).catch((e) => setErr(e.message ?? "Sem acesso (apenas admin)."));
  useEffect(() => { reload(); }, []);
  const all = [...props, ...lib];
  const count = (s: string) => all.filter((e) => e.status === s).length;
  const list = all.filter((e) => !q || `${e.key} ${e.ficha.nomeComercial?.valor ?? ""}`.toLowerCase().includes(q.toLowerCase())).slice(0, 80);
  const incons = forms.filter((f) => !f.ok).length;
  const stats: [string, number][] = [["Peças conhecidas", all.filter((e) => e.kind === "peca").length], ...STATUSES.map((s) => [s, count(s)] as [string, number]), ["Serviços", services.services.length], ["Fabricantes", fabricantes().length], ["Fórmulas", forms.length], ["Inconsistências", incons]];

  async function act(e: Entrada, a: Acao) { setErr(null); try { await executar(e, a); await reload(); setSel(null); } catch (x) { setErr((x as Error).message); } }
  async function nova() { if (!nome.trim()) return; const f = {} as Ficha; for (const c of CAMPOS) f[c] = DESCONHECIDO(); f.nomeComercial = { valor: nome.trim(), fonte: "proposta do admin", confianca: "F" }; f.categoria = { valor: cat, fonte: "proposta do admin", confianca: "F" }; try { await proporPeca(nome.trim(), cat, f); setNome(""); reload(); } catch (x) { setErr((x as Error).message); } }

  return (
    <div className="space-y-3">
      <header className="rounded-xl border border-border bg-card p-4">
        <h2 className="font-display text-xl">MEMÓRIA DO MECÂNICO</h2>
        <p className="text-xs text-muted-foreground">O mecânico aprende, documenta, calcula, audita e propõe. Só você autoriza o que entra no jogo.</p>
        <div className="mt-3 grid grid-cols-2 gap-1.5 sm:grid-cols-4 lg:grid-cols-8">
          {stats.map(([l, v]) => <div key={l} className="rounded-lg bg-secondary p-2"><p className="text-[9px] uppercase leading-tight text-muted-foreground">{l}</p><p className="font-mono text-lg font-bold tabular-nums">{v}</p></div>)}
        </div>
      </header>
      {err && <p className="rounded-lg border border-destructive bg-destructive/10 p-2 text-xs text-destructive">{err}</p>}
      <section className="rounded-xl border border-border bg-card p-3">
        <h3 className="mb-2 text-xs font-bold uppercase text-muted-foreground">Nova pesquisa de peça</h3>
        <div className="flex flex-wrap gap-2">
          <input value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Nome da peça" className="flex-1 rounded-lg border border-border bg-background px-2 py-1 text-sm" />
          <input value={cat} onChange={(e) => setCat(e.target.value)} placeholder="Categoria" className="w-32 rounded-lg border border-border bg-background px-2 py-1 text-sm" />
          <button onClick={nova} className="rounded-lg bg-primary px-3 py-1 text-xs font-bold text-primary-foreground">Registrar em pesquisa</button>
        </div>
      </section>
      <section className="rounded-xl border border-border bg-card p-3">
        <h3 className="mb-2 text-xs font-bold uppercase text-muted-foreground">Fórmulas · verificação independente</h3>
        <div className="grid gap-1 sm:grid-cols-2">{forms.map((f) => <div key={f.id} className="flex justify-between rounded bg-secondary px-2 py-1 text-[11px]"><span>{f.nome} <span className="font-mono text-muted-foreground">{f.expr}</span></span><span className={f.ok ? "text-primary" : "text-destructive"}>{f.ok ? "PASS" : "FALHA"} {f.erro.toFixed(2)}%</span></div>)}</div>
      </section>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar ficha…" className="w-full rounded-xl border border-border bg-card px-3 py-2 text-sm" />
      <ul className="divide-y divide-border overflow-hidden rounded-xl border border-border bg-card">
        {list.map((e) => <li key={e.key}><button onClick={() => setSel(sel?.key === e.key ? null : e)} className="flex w-full items-center justify-between px-3 py-2 text-left text-sm">
          <span>{String(e.ficha.nomeComercial?.valor ?? e.key)} <span className="text-[10px] text-muted-foreground">{e.kind}</span></span>
          <span className="flex gap-1 text-[10px]"><span className="rounded bg-muted px-1.5">{lacunas(e.ficha).length}/26 desconhecidos</span><span className="rounded bg-accent px-1.5 text-accent-foreground">{e.status}</span></span>
        </button>
        {sel?.key === e.key && <div className="space-y-2 bg-background/40 p-3">
          <div className="grid gap-1 sm:grid-cols-2 lg:grid-cols-3">{CAMPOS.map((c) => { const d = e.ficha[c]; return <div key={c} className="rounded border border-border px-2 py-1"><p className="text-[9px] uppercase text-muted-foreground">{CAMPO_LABEL[c]}</p><p className="text-xs font-bold">{d?.valor === null ? "DESCONHECIDO" : `${d.valor}${d.unidade ? " " + d.unidade : ""}`}</p><p className="text-[9px] text-muted-foreground">{d?.fonte}{d?.confianca ? ` · ${d.confianca} ${CONFIANCA_LABEL[d.confianca]}` : ""}</p></div>; })}</div>
          {bloqueios(e.ficha).length > 0 && <p className="text-[11px] text-destructive">Bloqueia aprovação: {bloqueios(e.ficha).map((c) => CAMPO_LABEL[c]).join(", ")}</p>}
          {!e.catalogId && <div className="flex flex-wrap gap-1">{ACOES.map(([a, l]) => <button key={a} onClick={() => act(e, a)} className="rounded-lg border border-border px-2 py-1 text-[11px] font-bold">{l}</button>)}</div>}
          {e.catalogId && <p className="text-[11px] text-muted-foreground">Peça já ativa no jogo (catálogo). Edite valores pelo NEXUS UPDATE.</p>}
        </div>}</li>)}
      </ul>
    </div>
  );
}
