// Biblioteca de fórmulas com unidades e verificação numérica independente.
export interface Formula { id: string; nome: string; expr: string; vars: string; check: () => { esperado: number; obtido: number } }
const PI = Math.PI;
export const FORMULAS: Formula[] = [
  { id: "cilindrada", nome: "Cilindrada", expr: "V = (π/4)·D²·C·N", vars: "D, C em cm; V em cm³", check: () => ({ esperado: 192.1, obtido: Math.round((PI / 4) * 6.13 ** 2 * 6.51 * 1 * 10) / 10 }) },
  { id: "taxa", nome: "Taxa de compressão", expr: "TC = (Vd + Vc)/Vc", vars: "cm³", check: () => ({ esperado: 9.5, obtido: (162.7 + 19.13) / 19.13 }) },
  { id: "vm", nome: "Velocidade média do pistão", expr: "Vm = 2·C·RPM/60", vars: "C em m; Vm em m/s", check: () => ({ esperado: 17.36, obtido: (2 * 0.0651 * 8000) / 60 }) },
  { id: "omega", nome: "Velocidade angular", expr: "ω = 2π·RPM/60", vars: "rad/s", check: () => ({ esperado: 837.76, obtido: (2 * PI * 8000) / 60 }) },
  { id: "pkw", nome: "Potência", expr: "P(kW) = T(N·m)·RPM/9550", vars: "kW", check: () => ({ esperado: 10.47, obtido: (12.5 * 8000) / 9550 }) },
  { id: "pw", nome: "Potência mecânica", expr: "P = T·ω", vars: "W", check: () => ({ esperado: 10472, obtido: 12.5 * ((2 * PI * 8000) / 60) }) },
  { id: "f", nome: "Força", expr: "F = m·a", vars: "N", check: () => ({ esperado: 1960, obtido: 200 * 9.8 }) },
  { id: "ec", nome: "Energia cinética", expr: "Ec = m·v²/2", vars: "J", check: () => ({ esperado: 250000, obtido: (200 * 50 ** 2) / 2 }) },
  { id: "p", nome: "Pressão", expr: "p = F/A", vars: "Pa", check: () => ({ esperado: 1e6, obtido: 1000 / 0.001 }) },
  { id: "rho", nome: "Densidade", expr: "ρ = m/V", vars: "kg/m³", check: () => ({ esperado: 745, obtido: 0.745 / 0.001 }) },
];
export const auditarFormulas = () => FORMULAS.map((f) => { const r = f.check(); const erro = Math.abs(r.obtido - r.esperado) / Math.abs(r.esperado) * 100; return { ...f, ...r, erro, ok: erro < 0.5 }; });
