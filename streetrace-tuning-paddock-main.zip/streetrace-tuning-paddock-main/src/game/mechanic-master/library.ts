// Ficha técnica derivada do catálogo ativo do jogo (sem inventar): campos não presentes ficam DESCONHECIDO.
import { PARTS_CATALOG, type Part } from "../parts";
import services from "../data/workshop_services.json";
import { CAMPOS, DESCONHECIDO, type Dado, type Entrada, type Ficha } from "./types";
const jogo = (valor: string | number, unidade?: string): Dado => ({ valor, unidade, fonte: "catálogo do jogo (parts.ts)", confianca: "F" });
function vazia(): Ficha { const f = {} as Ficha; for (const c of CAMPOS) f[c] = DESCONHECIDO(); return f; }
export function fichaDaPeca(p: Part): Ficha {
  const f = vazia();
  f.nomeComercial = jogo(p.name); f.categoria = jogo(p.kind);
  if (p.brand) f.fabricante = jogo(p.brand);
  if (p.spec) f.caracteristicasFisicas = jogo(p.spec);
  if (p.kg !== undefined) f.massa = jogo(p.kg, "kg vs original");
  if (p.cc) f.dimensoes = jogo(p.cc, "cm³");
  f.confiabilidade = { valor: "F", fonte: "sem documentação de fabricante anexada", confianca: "F" };
  return f;
}
interface Svc { id: string; name: string; group: string; price: number }
export function biblioteca(): Entrada[] {
  const pecas: Entrada[] = PARTS_CATALOG.map((p) => ({ key: `peca:${p.id}`, kind: "peca", status: "PUBLICADO NO JOGO", ficha: fichaDaPeca(p), catalogId: p.id }));
  const svcs: Entrada[] = (services.services as Svc[]).map((s) => { const f = vazia(); f.nomeComercial = { valor: s.name, fonte: "workshop_services.json", confianca: "F" }; f.categoria = { valor: s.group, fonte: "workshop_services.json", confianca: "F" }; return { key: `servico:${s.id}`, kind: "servico", status: "PUBLICADO NO JOGO", ficha: f, catalogId: s.id }; });
  return [...pecas, ...svcs];
}
export const fabricantes = () => [...new Set(PARTS_CATALOG.map((p) => p.brand).filter(Boolean))].sort();
