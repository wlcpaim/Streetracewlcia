// Persistência da memória do mecânico no banco (somente admin via RLS). Nunca escreve no catálogo do jogo.
import { supabase } from "@/integrations/supabase/client";
import { transicao, type Acao } from "./workflow";
import type { Entrada, Ficha, Status } from "./types";
export async function carregar(): Promise<Entrada[]> {
  const { data, error } = await supabase.from("mechanic_memory").select("item_key,kind,status,sheet").order("updated_at", { ascending: false });
  if (error) throw error;
  return (data ?? []).map((r) => ({ key: r.item_key, kind: r.kind as Entrada["kind"], status: r.status as Status, ficha: r.sheet as unknown as Ficha }));
}
export async function proporPeca(nome: string, categoria: string, ficha: Ficha) {
  const { data: u } = await supabase.auth.getUser(); const uid = u.user?.id ?? null;
  const key = `proposta:${categoria}:${nome.toLowerCase().replace(/\s+/g, "-")}`;
  const { error } = await supabase.from("mechanic_memory").insert({ item_key: key, kind: "peca", status: "EM PESQUISA", sheet: ficha as never, updated_by: uid });
  if (error) throw error;
  await supabase.from("mechanic_memory_events").insert({ item_key: key, action: "criar", to_status: "EM PESQUISA", actor: uid });
}
export async function executar(e: Entrada, a: Acao, note?: string) {
  const t = transicao(e.status, a, e.ficha); if (!t.ok) throw new Error(t.erro);
  const { data: u } = await supabase.auth.getUser(); const uid = u.user?.id ?? null;
  const { error } = await supabase.from("mechanic_memory").update({ status: t.to, updated_by: uid, updated_at: new Date().toISOString() }).eq("item_key", e.key);
  if (error) throw error;
  await supabase.from("mechanic_memory_events").insert({ item_key: e.key, action: a, from_status: e.status, to_status: t.to, note: note ?? null, actor: uid });
  return t.to;
}
