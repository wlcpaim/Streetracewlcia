// Mecânico Master AI: tipos da memória técnica. Conhecimento ≠ conteúdo autorizado no jogo.
export type Confianca = "A" | "B" | "C" | "D" | "E" | "F";
export const CONFIANCA_LABEL: Record<Confianca, string> = {
  A: "Documentação oficial do fabricante", B: "Documentação técnica reconhecida", C: "Catálogo de distribuidor identificado",
  D: "Medição/ensaio documentado", E: "Estimativa matemática fundamentada", F: "Informação não confirmada",
};
export type Status = "EM PESQUISA" | "EM DOCUMENTAÇÃO" | "EM CÁLCULO" | "EM AUDITORIA" | "AGUARDANDO APROVAÇÃO" | "APROVADO" | "REJEITADO" | "EM CORREÇÃO" | "PUBLICADO NO JOGO";
export const STATUSES: Status[] = ["EM PESQUISA", "EM DOCUMENTAÇÃO", "EM CÁLCULO", "EM AUDITORIA", "AGUARDANDO APROVAÇÃO", "APROVADO", "REJEITADO", "EM CORREÇÃO", "PUBLICADO NO JOGO"];
/** Um dado técnico: null = DESCONHECIDO, nunca inventado. */
export interface Dado { valor: string | number | null; unidade?: string | undefined; fonte: string; confianca: Confianca | null }
export const DESCONHECIDO = (fonte = "sem fonte documental"): Dado => ({ valor: null, fonte, confianca: null });
/** Ficha técnica: os 26 campos obrigatórios. */
export const CAMPOS = ["nomeTecnico", "nomeComercial", "fabricante", "codigo", "categoria", "aplicacao", "modelosCompativeis", "material", "massa", "dimensoes", "geometria", "tolerancias", "limitesOperacao", "temperaturaTrabalho", "resistenciaMecanica", "caracteristicasFisicas", "caracteristicasQuimicas", "compatibilidade", "preparacao", "servicosAplicaveis", "beneficios", "limitacoes", "falhasPossiveis", "formulas", "fontes", "confiabilidade"] as const;
export type Campo = (typeof CAMPOS)[number];
export const CAMPO_LABEL: Record<Campo, string> = { nomeTecnico: "Nome técnico", nomeComercial: "Nome comercial", fabricante: "Fabricante", codigo: "Código/SKU", categoria: "Categoria", aplicacao: "Aplicação", modelosCompativeis: "Modelos compatíveis", material: "Material", massa: "Massa", dimensoes: "Dimensões", geometria: "Geometria", tolerancias: "Tolerâncias", limitesOperacao: "Limites de operação", temperaturaTrabalho: "Temperatura de trabalho", resistenciaMecanica: "Resistência mecânica", caracteristicasFisicas: "Características físicas", caracteristicasQuimicas: "Características químicas", compatibilidade: "Compatibilidade", preparacao: "Possibilidades de preparação", servicosAplicaveis: "Serviços de usinagem aplicáveis", beneficios: "Benefícios", limitacoes: "Limitações", falhasPossiveis: "Possíveis falhas", formulas: "Fórmulas relacionadas", fontes: "Fontes documentais", confiabilidade: "Grau de confiabilidade" };
export type Ficha = Record<Campo, Dado>;
export interface Entrada { key: string; kind: "peca" | "servico"; status: Status; ficha: Ficha; catalogId?: string }
