/** Run deterministic generators in short browser tasks; yielding never advances simulation time. */
export async function computeSlices<T>(work: Generator<void, T>, cancelled: () => boolean = () => false): Promise<T> {
  while (true) {
    if (cancelled()) { work.return(undefined as T); throw new Error("Calculation cancelled"); }
    const start = performance.now();
    let next: IteratorResult<void, T>;
    do {
      next = work.next();
      if (next.done) return next.value;
    } while (performance.now() - start < 4);
    await yieldToFrame();
  }
}

export function computeSync<T>(work: Generator<void, T>): T {
  let next = work.next();
  while (!next.done) next = work.next();
  return next.value;
}

// MessageChannel yields without the 4 ms setTimeout clamp, so animation frames run between slices
const yieldToFrame = (): Promise<void> => typeof MessageChannel === "undefined"
  ? new Promise((r) => setTimeout(r, 0))
  : new Promise((r) => { const c = new MessageChannel(); c.port1.onmessage = () => { c.port1.close(); r(); }; c.port2.postMessage(0); });
