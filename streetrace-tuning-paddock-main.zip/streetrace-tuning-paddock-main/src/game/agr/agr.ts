// AGR: bateria automática de testes do dinamômetro. Roda a MESMA step() da corrida em todas as pistas oficiais (records.TRACKS).
import { DT, ETA, afrAt, engine, exhaustShape, gearSpeeds, mixFactor, newSim, powerShape, step, stalled, stress, type BikeModel, type Setup } from "../physics";
import { TRACKS } from "../records";
import { slotPart, type Slot } from "../parts";
import { RELEASE } from "../anticheat/release";
import { computeSlices, computeSync } from "../compute-slices";

export const AGR_VERSION = "AGR-2.0";
/** Identificação da física: protocolo de release + build publicado. */
export const physicsVersion = () => `P${RELEASE.protocol}·${typeof __BUILD_ID__ === "string" ? __BUILD_ID__.slice(0, 8) : "dev"}`;

/** Origem do dado: SIMULADO = física do jogo; ESTIMADO = parâmetro estimado (ex.: η da transmissão); DESCONHECIDO = não modelado. */
export type Origem = "SIMULADO" | "ESTIMADO" | "DESCONHECIDO";

export interface Shift { t: number; from: number; to: number; rpmBefore: number; rpmAfter: number; kmh: number }
export interface Sample { t: number; x: number; kmh: number; rpm: number; gear: number; kw: number }
export interface TrackResult {
  id: string; label: string; m: number;
  ok: boolean; motivo?: string;
  time: number | null; vmax: number; t60: number | null; t100: number | null; t100m: number | null;
  /** Tempo e velocidade a 25/50/75/100 % do percurso. */
  splits: { pct: number; x: number; t: number; kmh: number }[];
  accAvg: number; accPeak: number;
  rpmMin: number; rpmMax: number; limiterS: number;
  gearMax: number[]; cuts: number[]; topGear: number; shifts: Shift[];
  kwPeak: number; kwAvg: number; wheelKwAvg: number; lossKwAvg: number; dragNEnd: number;
  fuelL: number; tireCMax: number | null; spinS: number; wheelieS: number;
  samples: Sample[];
  comportamento: string[];
}
export interface BikeSnapshot { bikeId: string; bike: string; gear: string; components: { slot: string; part: string }[]; fuel: string; psi: number; compression: number; cam: string }
export interface Battery {
  id: string; date: number; agr: string; physics: string;
  snapshot: BikeSnapshot;
  engine: { hp: number; rpmPeak: number; tq: number; tqRpm: number; rpmLimit: number; wheelHp: number; risk: number; cause: string };
  tracks: TrackResult[];
  analise: { fortes: string[]; fracos: string[]; limites: string[]; faixas: string[]; eficiencia: string };
}

const r = (v: number, d = 2) => Math.round(v * 10 ** d) / 10 ** d;
const SLOT_ORDER: Slot[] = ["cilindro", "pistao", "biela", "vira", "molas", "tbi", "bico", "bomba", "escape", "modulo", "vela", "cabo", "embreagem", "pneu", "roda", "susp", "bateria", "oleo"];

export function snapshotOf(b: BikeModel, s: Setup): BikeSnapshot {
  return {
    bikeId: b.id, bike: b.name, gear: `${s.front}x${s.rear}`,
    components: SLOT_ORDER.filter((k) => k in s.slots).map((k) => { const x = slotPart(s.slots[k], k); return { slot: k, part: `${x.brand} ${x.name}` }; }),
    fuel: s.fuel, psi: s.psi, compression: s.compression, cam: String(s.cam),
  };
}

/** Pico de potência e torque da curva do rolo (mesma conta do Dino). */
export function enginePeaks(b: BikeModel, s: Setup) {
  const e = engine(b, s);
  let hp = 0, rpmPeak = 0, tq = 0, tqRpm = 0;
  for (let rpm = 3000; rpm <= e.rpmLimit; rpm += 250) {
    const h = e.hp * powerShape(rpm, e.rpmPeak, b, s) * mixFactor(s, rpm, e.rpmPeak) * exhaustShape(b, s, rpm, e.rpmPeak);
    const t = (h * 735.5) / ((rpm * 2 * Math.PI) / 60) / 9.81;
    if (h > hp) { hp = h; rpmPeak = rpm; }
    if (t > tq) { tq = t; tqRpm = rpm; }
  }
  const st = stress(b, s);
  return { hp: r(hp), rpmPeak, tq: r(tq), tqRpm, rpmLimit: e.rpmLimit, wheelHp: r(hp * ETA), risk: r(st.risk, 3), cause: st.cause };
}

/** Uma puxada completa na pista, com telemetria (física real, tanque cheio). */
export function runTrack(b: BikeModel, s: Setup, t: { id: string; label: string; m: number }, fuelL = b.tank): TrackResult {
  return computeSync(trackSteps(b, s, t, fuelL));
}

export function runTrackAsync(b: BikeModel, s: Setup, t: { id: string; label: string; m: number }, fuelL = b.tank, cancelled?: () => boolean): Promise<TrackResult> {
  return computeSlices(trackSteps(b, s, t, fuelL), cancelled);
}

function* trackSteps(b: BikeModel, s: Setup, t: { id: string; label: string; m: number }, fuelL: number): Generator<void, TrackResult> {
  const st = newSim(fuelL);
  const e = engine(b, s);
  const cuts = gearSpeeds(b, s);
  const shifts: Shift[] = [];
  const samples: Sample[] = [];
  const splits: TrackResult["splits"] = [];
  const marks = [0.25, 0.5, 0.75];
  let rpmMin = Infinity, rpmMax = 0, limiterS = 0, kwPeak = 0, kwSum = 0, wSum = 0, n = 0, accPeak = 0, tireCMax: number | null = null, spinS = 0, wheelieS = 0;
  let prevGear = 1, prevRpm = st.rpm, prevV = 0;
  const every = Math.max(1, Math.round(t.m / 40 / 0.5));
  let i = 0;
  while (st.finishT === null && !stalled(st) && st.t < 900) {
    prevGear = st.gear; prevRpm = st.rpm; prevV = st.v;
    step(st, b, s, DT, t.m);
    i++;
    if (st.gear !== prevGear) shifts.push({ t: r(st.t), from: prevGear, to: st.gear, rpmBefore: Math.round(prevRpm), rpmAfter: Math.round(st.rpm), kmh: r(st.v * 3.6, 1) });
    if (st.t > 0.5) rpmMin = Math.min(rpmMin, st.rpm);
    rpmMax = Math.max(rpmMax, st.rpm);
    if (st.limiter) limiterS += DT;
    if (st.spin) spinS += DT;
    if (st.wheelie) wheelieS += DT;
    const kw = (st.pEngW ?? 0) / 1000;
    kwPeak = Math.max(kwPeak, kw); kwSum += kw; wSum += (st.pW ?? 0) / 1000; n++;
    accPeak = Math.max(accPeak, (st.v - prevV) / DT);
    if (st.gr?.tireC != null) tireCMax = Math.max(tireCMax ?? -Infinity, st.gr.tireC);
    while (marks.length && st.x >= marks[0]! * t.m) { const p = marks.shift()!; splits.push({ pct: p * 100, x: r(st.x, 1), t: r(st.t, 3), kmh: r(st.v * 3.6, 1) }); }
    if (i % (every * 120) === 0) samples.push({ t: r(st.t), x: r(st.x, 1), kmh: r(st.v * 3.6, 1), rpm: Math.round(st.rpm), gear: st.gear, kw: r(kw) });
    yield;
  }
  const ok = st.finishT !== null;
  if (ok) splits.push({ pct: 100, x: t.m, t: r(st.finishT!, 3), kmh: r(st.v * 3.6, 1) });
  const time = ok ? r(st.finishT!, 3) : null;
  const comportamento: string[] = [];
  if (limiterS > 0.3) comportamento.push(`Bateu no corte ${r(limiterS, 1)} s (relação curta ou corte baixo para a pista)`);
  if (spinS > 0.2) comportamento.push(`Pneu patinou ${r(spinS, 2)} s na saída`);
  if (wheelieS > 0.2) comportamento.push(`Empinou ${r(wheelieS, 2)} s`);
  const topGear = Math.max(1, ...st.gearMax.map((v, k) => (v > 0 ? k + 1 : 1)));
  const topCut = cuts[topGear - 1] ?? 0;
  if (ok && topGear === cuts.length && st.top < topCut * 0.92) comportamento.push(`Última marcha parou em ${r(st.top, 0)} de ${r(topCut, 0)} km/h no corte: limitado por arrasto, não pela relação`);
  if (ok && topGear < cuts.length && limiterS > 0.3) comportamento.push(`Não chegou na ${cuts.length}ª: o percurso terminou na ${topGear}ª`);
  if (!comportamento.length) comportamento.push("Puxada limpa, sem corte, patinagem ou empinada relevantes");
  return {
    id: t.id, label: t.label, m: t.m, ok,
    ...(ok ? {} : { motivo: st.dry ? "Pane seca antes da chegada (tanque insuficiente para o percurso)" : "Moto parou antes da chegada" }),
    time, vmax: r(st.top, 1), t60: st.t60, t100: st.t100, t100m: st.t100m,
    splits, accAvg: r(ok ? st.v / st.finishT! : 0), accPeak: r(accPeak),
    rpmMin: Number.isFinite(rpmMin) ? Math.round(rpmMin) : 0, rpmMax: Math.round(rpmMax), limiterS: r(limiterS),
    gearMax: st.gearMax.map((v) => r(v, 1)), cuts: cuts.map((v) => r(v, 1)), topGear, shifts,
    kwPeak: r(kwPeak), kwAvg: r(kwSum / Math.max(1, n)), wheelKwAvg: r(wSum / Math.max(1, n)), lossKwAvg: r((kwSum - wSum) / Math.max(1, n)), dragNEnd: r(st.dragN ?? 0, 1),
    fuelL: r(fuelL - st.fuel, 4), tireCMax: tireCMax == null ? null : r(tireCMax, 1), spinS: r(spinS), wheelieS: r(wheelieS),
    samples, comportamento,
  };
  void e;
}

function analyse(b: BikeModel, s: Setup, eng: Battery["engine"], tracks: TrackResult[]): Battery["analise"] {
  const fortes: string[] = [], fracos: string[] = [], limites: string[] = [], faixas: string[] = [];
  const ok = tracks.filter((t) => t.ok);
  const spin = ok.filter((t) => t.spinS > 0.2);
  if (!spin.length) fortes.push("Tração na largada: sem patinagem relevante em nenhuma pista");
  else fracos.push(`Patinou na largada (${spin.map((t) => t.label).join(", ")}): psi, 2-step ou relação curta demais`);
  const lim = ok.filter((t) => t.limiterS > 0.3);
  if (lim.length) limites.push(`Corte de giro atingido em ${lim.map((t) => t.label).join(", ")}`);
  const drag = ok.filter((t) => t.comportamento.some((c) => c.includes("arrasto")));
  if (drag.length) limites.push(`Arrasto aerodinâmico limita a final em ${drag.map((t) => t.label).join(", ")}`);
  if (tracks.some((t) => !t.ok)) fracos.push(`Não completou: ${tracks.filter((t) => !t.ok).map((t) => `${t.label} (${t.motivo})`).join("; ")}`);
  if (eng.risk > 0.15) fracos.push(`Risco mecânico ${Math.round(eng.risk * 100)}% por puxada · ${eng.cause}`);
  else fortes.push(`Risco mecânico baixo (${Math.round(eng.risk * 100)}%)`);
  const e = engine(b, s);
  let lean = 0, rich = 0;
  const st = s.fuel === "etanol" ? 9 : 14.7;
  for (let rpm = 5000; rpm <= e.rpmLimit; rpm += 250) { const a = afrAt(b, s, rpm, e.rpmPeak); if (a > st * 0.95) lean++; if (a < st * 0.8) rich++; }
  faixas.push(`Torque máximo ${eng.tq} kgf·m a ${eng.tqRpm} rpm; potência máxima ${eng.hp} cv a ${eng.rpmPeak} rpm; corte ${eng.rpmLimit} rpm`);
  if (lean) fracos.push(`Mistura pobre em ${lean * 250} rpm de faixa`);
  if (rich) fracos.push(`Mistura rica (amarrada) em ${rich * 250} rpm de faixa`);
  if (!lean && !rich) fortes.push("Mistura dentro da janela em todo o giro");
  const eff = ok.length ? ok.reduce((n, t) => n + t.wheelKwAvg / Math.max(0.01, t.kwAvg), 0) / ok.length : 0;
  return { fortes, fracos, limites, faixas, eficiencia: ok.length ? `Potência média entregue à roda / potência do motor: ${Math.round(eff * 100)}% (η ${ETA} é ESTIMADO)` : "Sem pista completa" };
}

/** Bateria completa em todas as pistas oficiais; cede a thread entre pistas para não travar a tela. */
export async function runBattery(b: BikeModel, s: Setup, onTrack?: (done: number, total: number, last: TrackResult) => void, cancelled: () => boolean = () => false): Promise<Battery> {
  const tracks: TrackResult[] = [];
  for (const t of TRACKS) {
    await new Promise((res) => setTimeout(res, 0));
    let res: TrackResult;
    try { res = await runTrackAsync(b, s, t, b.tank, cancelled); } catch (err) {
      if (cancelled()) throw err;
      res = { ...emptyTrack(t), motivo: `Pista incompatível com esta configuração: ${(err as Error).message}` };
    }
    tracks.push(res);
    onTrack?.(tracks.length, TRACKS.length, res);
  }
  const eng = enginePeaks(b, s);
  return { id: `agr-${Date.now()}`, date: Date.now(), agr: AGR_VERSION, physics: physicsVersion(), snapshot: snapshotOf(b, s), engine: eng, tracks, analise: analyse(b, s, eng, tracks) };
}

/** Versão síncrona (testes). */
export function runBatterySync(b: BikeModel, s: Setup): Battery {
  const tracks = TRACKS.map((t) => runTrack(b, s, t));
  const eng = enginePeaks(b, s);
  return { id: "agr-sync", date: 0, agr: AGR_VERSION, physics: physicsVersion(), snapshot: snapshotOf(b, s), engine: eng, tracks, analise: analyse(b, s, eng, tracks) };
}

function emptyTrack(t: { id: string; label: string; m: number }): TrackResult {
  return { id: t.id, label: t.label, m: t.m, ok: false, time: null, vmax: 0, t60: null, t100: null, t100m: null, splits: [], accAvg: 0, accPeak: 0, rpmMin: 0, rpmMax: 0, limiterS: 0, gearMax: [], cuts: [], topGear: 0, shifts: [], kwPeak: 0, kwAvg: 0, wheelKwAvg: 0, lossKwAvg: 0, dragNEnd: 0, fuelL: 0, tireCMax: null, spinS: 0, wheelieS: 0, samples: [], comportamento: [] };
}
