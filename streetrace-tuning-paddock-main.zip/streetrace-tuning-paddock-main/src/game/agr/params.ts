// Limites técnicos e passos dos controles + e − do módulo programável (mesmos limites dos antigos sliders).
export interface Param { min: number; max: number; step: number; unit: string; def: number }
export const PARAMS = {
  rpm: { min: 8500, max: 13000, step: 100, unit: "rpm", def: 9000 },
  launch: { min: 0, max: 12000, step: 250, unit: "rpm", def: 0 },
  idle: { min: 1100, max: 2200, step: 50, unit: "rpm", def: 1300 },
  timing: { min: -4, max: 6, step: 0.5, unit: "°", def: 0 },
  tLow: { min: -4, max: 4, step: 0.5, unit: "°", def: 0 },
  tHigh: { min: -4, max: 6, step: 0.5, unit: "°", def: 0 },
  trim: { min: -15, max: 25, step: 1, unit: "%", def: 0 },
  low: { min: -15, max: 25, step: 1, unit: "%", def: 0 },
  mid: { min: -15, max: 25, step: 1, unit: "%", def: 0 },
  high: { min: -15, max: 25, step: 1, unit: "%", def: 0 },
  over: { min: -15, max: 30, step: 1, unit: "%", def: 0 },
  shift: { min: 0, max: 13000, step: 100, unit: "rpm", def: 0 },
  qs: { min: 40, max: 250, step: 5, unit: "ms", def: 220 },
  qsGear: { min: 0, max: 250, step: 5, unit: "ms", def: 0 },
} satisfies Record<string, Param>;
export type ParamId = keyof typeof PARAMS;

/** Um clique de + (dir 1) ou − (dir −1): sempre finito, no passo e dentro do limite. */
export function clampStep(id: ParamId, v: number, dir: number): number {
  const p: Param = PARAMS[id];
  const cur = Number.isFinite(v) ? v : v === Infinity ? p.max : v === -Infinity ? p.min : p.def;
  const next = Math.round((cur + dir * p.step) / p.step) * p.step;
  return Math.round(Math.min(p.max, Math.max(p.min, next)) * 100) / 100;
}
