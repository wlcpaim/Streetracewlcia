// Mapas salvos do dinamômetro (Player.dynoMaps): calibração completa + bateria AGR associada.
import type { Ecu, Setup } from "../physics";
import type { Player } from "../store";
import { AGR_VERSION, physicsVersion, type Battery, type BikeSnapshot } from "./agr";

export const MAX_MAPS = 30;
export interface DynoMap {
  id: string; name: string; date: number;
  bikeId: string; snapshot: BikeSnapshot;
  setup: Setup; ecu: Ecu;
  battery?: Battery;
  agr: string; physics: string;
}
const clean = (name: string) => name.replace(/\s+/g, " ").trim().slice(0, 24);
export const mapsOf = (p: Player) => p.dynoMaps ?? [];
export const nameTaken = (p: Player, name: string, except?: string) => mapsOf(p).some((m) => m.id !== except && m.name.toLowerCase() === clean(name).toLowerCase());

export function saveMap(p: Player, m: Omit<DynoMap, "id" | "date" | "agr" | "physics">, now = Date.now()): Player {
  const name = clean(m.name);
  if (!name || nameTaken(p, name) || mapsOf(p).length >= MAX_MAPS) return p;
  const map: DynoMap = { ...m, name, id: `dm-${now}-${mapsOf(p).length}`, date: now, agr: AGR_VERSION, physics: physicsVersion() };
  return { ...p, dynoMaps: [map, ...mapsOf(p)] };
}
/** Sobrescreve um mapa existente (só após confirmação na tela). */
export function overwriteMap(p: Player, id: string, patch: Pick<DynoMap, "setup" | "ecu" | "snapshot" | "battery">, now = Date.now()): Player {
  return { ...p, dynoMaps: mapsOf(p).map((m) => (m.id === id ? { ...m, ...patch, date: now, agr: AGR_VERSION, physics: physicsVersion() } : m)) };
}
export function renameMap(p: Player, id: string, name: string): Player {
  const n = clean(name);
  if (!n || nameTaken(p, n, id)) return p;
  return { ...p, dynoMaps: mapsOf(p).map((m) => (m.id === id ? { ...m, name: n } : m)) };
}
export function duplicateMap(p: Player, id: string, now = Date.now()): Player {
  const src = mapsOf(p).find((m) => m.id === id);
  if (!src || mapsOf(p).length >= MAX_MAPS) return p;
  let k = 2, name = clean(`${src.name} (2)`);
  while (nameTaken(p, name)) name = clean(`${src.name} (${++k})`);
  return { ...p, dynoMaps: [{ ...src, id: `dm-${now}-${mapsOf(p).length}`, name, date: now }, ...mapsOf(p)] };
}
export const deleteMap = (p: Player, id: string): Player => ({ ...p, dynoMaps: mapsOf(p).filter((m) => m.id !== id) });

/** Usa o mapa na moto: aplica a calibração do módulo; peças e relação só se o jogador tiver montado/possuir. */
export function applyMap(p: Player, id: string): { player: Player; avisos: string[] } {
  const m = mapsOf(p).find((x) => x.id === id);
  if (!m) return { player: p, avisos: ["Mapa não encontrado"] };
  if (m.bikeId !== p.activeBike) return { player: p, avisos: [`Mapa feito na ${m.snapshot.bike}: troque para essa moto para usar`] };
  const avisos: string[] = [];
  let setup: Setup = { ...p.setup, ecu: { ...m.ecu } };
  const hasF = p.parts.includes(`pinhao-${m.setup.front}`), hasR = p.parts.includes(`coroa-${m.setup.rear}`);
  if (m.setup.front !== p.setup.front || m.setup.rear !== p.setup.rear) {
    if (hasF && hasR) setup = { ...setup, front: m.setup.front, rear: m.setup.rear };
    else avisos.push(`Relação do mapa ${m.setup.front}x${m.setup.rear} não está no estoque: mantida ${p.setup.front}x${p.setup.rear}`);
  }
  const diff = Object.keys(m.setup.slots).filter((k) => m.setup.slots[k as keyof Setup["slots"]] !== p.setup.slots[k as keyof Setup["slots"]]);
  if (diff.length) avisos.push(`Peças diferentes das do mapa (${diff.join(", ")}): monte no Fuçar/Oficina para repetir o resultado`);
  return { player: { ...p, setup }, avisos };
}
