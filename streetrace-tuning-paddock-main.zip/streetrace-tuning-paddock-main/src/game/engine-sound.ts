// Synthesized single-cylinder 4T engine via Web Audio, voiced by the real build.
// Fire rate = rpm/120 (one combustion every 2 revs). No continuous noise sources: the whole voice is built from
// pressure-pulse harmonics, so there is no hiss. The voice is derived from the setup:
// exhaust = tone/pipe resonance/volume/backfire; displacement = deeper body and heavier flywheel; cam = lumpy idle;
// compression = sharper crack; open intake = induction growl. Gear shifts cut ignition for exactly the QS time.
// rpm and throttle follow the sim through inertia (flywheel), so launches and shifts glide like a real engine.
import { cloudStore } from "@/game/cloud/cloud-store";
import type { Setup } from "./physics";
import { displacement } from "./records";
import { slotPart } from "./parts";
import { onSound, soundMul } from "./settings";
import { faultLevels, misses, cycleHash, type Faults, type FaultId } from "./sound/faults";
import { MASTER_NEUTRAL, limitCurve, measure, undb, type Master, type Meter } from "./sound/master";

/**
 * cutoff/q: muffler tone · res/resGain: pipe resonance (Hz/dB) · gain: volume · pop: backfire chance ·
 * rasp: harmonic edge under load · bright: harmonic richness · drive: saturation
 */
export type Profile = { cutoff: number; q: number; res: number; resGain: number; gain: number; pop: number; rasp: number; bright: number; drive: number } & Partial<ProExtras>;
/** Controles profissionais (estúdio): todos opcionais e neutros quando ausentes, então os sons salvos não mudam. */
export type ProExtras = { bodyDb: number; throb: number; crankMix: number; echoMs: number; echoFb: number; compDb: number; airDb: number; sub: number };
export const PRO_NEUTRAL: ProExtras = { bodyDb: 0, throb: 1, crankMix: 0.1, echoMs: 0, echoFb: 0, compDb: -6, airDb: 0, sub: 0 };

export const PROFILES: Record<string, Profile> = {
  // catalisador + abafador de fábrica (CG/Factor de rua): "tuc-tuc" grave e encorpado, câmara do abafador
  // segura o agudo, sem estalo e sem rasgado — volume cheio como a moto original na rua
  // revisado: miolo labiríntico + catalisador → fino e abafado, sem peito grave, sem eco
  "escape-original": { cutoff: 520, q: 0.7, res: 340, resGain: 1.5, gain: 0.5, pop: 0, rasp: 0, bright: 0.3, drive: 1.1, sub: -8, bodyDb: -5, throb: 0.6, crankMix: 0.06, echoMs: 0, echoFb: 0, airDb: -4 },
  // Gemoto Trioval: ronco oco de lata, médio-grave forte
  "escape-polimet-tork": { cutoff: 900, q: 1.5, res: 260, resGain: 7, gain: 0.52, pop: 0.35, rasp: 0.06, bright: 0.6, drive: 2.2 },
  "escape-gemoto": { cutoff: 1000, q: 1.6, res: 290, resGain: 8, gain: 0.56, pop: 0.45, rasp: 0.08, bright: 0.68, drive: 2.4 },
  // Dore azul retrô: ponteira curta de alumínio, batida seca e berro limpo no alto
  // revisado: grosso e seco, sem eco/reverb, pouca saturação e agudo contido (conforto auditivo)
  "escape-dore": { cutoff: 1300, q: 0.9, res: 280, resGain: 5, gain: 0.62, pop: 0.3, rasp: 0.05, bright: 0.62, drive: 2.1, bodyDb: 3, sub: 2, throb: 1.15, crankMix: 0.05, echoMs: 0, echoFb: 0, airDb: -2 },
  // KS: médio rasgado e metálico
  "escape-ks": { cutoff: 1900, q: 1.6, res: 520, resGain: 5.5, gain: 0.66, pop: 0.7, rasp: 0.2, bright: 0.84, drive: 4 },
  // Inox completo: curva dimensionada, ressonância limpa em alta
  "escape-inox-completo": { cutoff: 2400, q: 2, res: 640, resGain: 7, gain: 0.7, pop: 0.75, rasp: 0.22, bright: 0.86, drive: 4.4 },
  "escape-ponteira-abafada": { cutoff: 2600, q: 1.8, res: 380, resGain: 6, gain: 0.72, pop: 0.9, rasp: 0.26, bright: 0.86, drive: 5 },
  // GRS competição: berro aberto de arrancada
  "escape-grs": { cutoff: 3600, q: 2.2, res: 700, resGain: 9, gain: 0.82, pop: 1, rasp: 0.32, bright: 0.92, drive: 6 },
};

// escapes de rua: timbre base de um escape de geometria parecida (só som, a física vem de exhaust.ts)
PROFILES["escape-rua-viuva"] = { ...PROFILES["escape-gemoto"]! , cutoff: PROFILES["escape-gemoto"]!.cutoff + 37 };
PROFILES["escape-rua-chiadeira"] = { ...PROFILES["escape-ks"]! , cutoff: PROFILES["escape-ks"]!.cutoff + 74 };
PROFILES["escape-rua-ronco-grosso"] = { ...PROFILES["escape-polimet-tork"]! , cutoff: PROFILES["escape-polimet-tork"]!.cutoff + 111 };
PROFILES["escape-rua-garrafinha"] = { ...PROFILES["escape-polimet-tork"]! , cutoff: PROFILES["escape-polimet-tork"]!.cutoff + 148 };
PROFILES["escape-rua-megafone"] = { ...PROFILES["escape-inox-completo"]! , cutoff: PROFILES["escape-inox-completo"]!.cutoff + 185 };
PROFILES["escape-rua-cano-reto"] = { ...PROFILES["escape-grs"]! , cutoff: PROFILES["escape-grs"]!.cutoff + 222 };
PROFILES["escape-rua-abelha"] = { ...PROFILES["escape-ponteira-abafada"]! , cutoff: PROFILES["escape-ponteira-abafada"]!.cutoff + 259 };
PROFILES["escape-rua-trovaozinho"] = { ...PROFILES["escape-dore"]! , cutoff: PROFILES["escape-dore"]!.cutoff + 296 };
PROFILES["escape-rua-bigode"] = { ...PROFILES["escape-gemoto"]! , cutoff: PROFILES["escape-gemoto"]!.cutoff + 333 };
PROFILES["escape-rua-serrote"] = { ...PROFILES["escape-ks"]! , cutoff: PROFILES["escape-ks"]!.cutoff + 370 };
PROFILES["escape-rua-tubarao"] = { ...PROFILES["escape-grs"]! , cutoff: PROFILES["escape-grs"]!.cutoff + 407 };
PROFILES["escape-rua-caneta"] = { ...PROFILES["escape-ponteira-abafada"]! , cutoff: PROFILES["escape-ponteira-abafada"]!.cutoff + 444 };

/** Equalizador do escapamento (aba Wiki): ganhos em dB por banda + ajustes do perfil, salvos por escape. */
export const EQ_BANDS = [60, 150, 400, 1000, 2500, 6000] as const;
/** faults/master: Sound Lab (só som; opcionais e neutros quando ausentes). */
export type ExhaustEq = { bands: number[]; profile: Partial<Profile>; faults?: Faults; master?: Partial<Master> };
const EQ_KEY = "streetrace-exhaust-eq-v1";
export function readEqs(): Record<string, ExhaustEq> { try { return JSON.parse(cloudStore.getItem(EQ_KEY) || "{}"); } catch { return {}; } }
export function saveEq(id: string, eq: ExhaustEq | null) { const all = readEqs(); if (eq) all[id] = eq; else delete all[id]; cloudStore.setItem(EQ_KEY, JSON.stringify(all)); }
/** Escape original de fábrica por moto: cada abafador OEM tem seu timbre (só som, nunca física). */
export const OEM_VOICE: Record<string, Partial<Profile>> = {
  // CG 125 Bolinha (OHV vareta): batida oca e cadenciada, mais mecânica, abafador simples
  cg125: { cutoff: 600, res: 300, resGain: 2, gain: 0.48, bright: 0.34, drive: 1.05, throb: 0.85, crankMix: 0.1, bodyDb: -3, sub: -5, airDb: -4 },
  // CG 150 Titan: pulso redondo e abafado, médio definido
  titan150: { cutoff: 560, res: 330, resGain: 1.8, gain: 0.5, bright: 0.3, drive: 1.05, throb: 0.7, crankMix: 0.06, bodyDb: -4, sub: -7, airDb: -4 },
  // Factor 150: silenciador longo Yamaha, soprado e linear
  factor150: { cutoff: 470, res: 360, resGain: 1.2, gain: 0.46, bright: 0.26, drive: 1.0, throb: 0.55, crankMix: 0.05, bodyDb: -5, sub: -8, airDb: -6 },
  // CG 160 Titan: catalisador, grave mais cheio
  titan160: { cutoff: 520, res: 320, resGain: 1.6, gain: 0.5, bright: 0.3, drive: 1.05, throb: 0.65, crankMix: 0.06, bodyDb: -2, sub: -5, airDb: -4 },
};
export function profileOf(id: string): Profile { const base = PROFILES[id] ?? PROFILES["escape-original"]!; const eq = typeof cloudStore !== "undefined" ? readEqs()[id] : undefined; return { ...base, ...(eq?.profile ?? {}) }; }

interface Voice { cc: number; cam: string; compression: number; intake: boolean; qs: number; idle: number; soft: boolean; prog: boolean }

export function ecuVoice(src: Setup) {
  const prog = !!slotPart(src.slots.modulo, "modulo").prog;
  return { prog, qs: prog ? src.ecu.qs ?? 220 : 220, idle: prog ? src.ecu.idle ?? 1300 : 1300, soft: prog && !!src.ecu.softCut };
}

export class EngineSound {
  private ctx: AudioContext;
  private master: GainNode;
  private out: GainNode;
  private unsub: () => void;
  private pulse: OscillatorNode;
  private edge: OscillatorNode;
  private edgeGain: GainNode;
  private crank: OscillatorNode;
  private am: OscillatorNode;
  private amDepth: GainNode;
  private filt: BiquadFilterNode;
  private intake: OscillatorNode;
  private intakeGain: GainNode;
  private intakeF: BiquadFilterNode;
  private popBuf: AudioBuffer;
  private p: Profile;
  private v: Voice;
  private cutPhase = 0;
  private lastPop = 0;
  private shiftUntil = 0;
  /** Smoothed rpm/throttle (flywheel inertia) and the audio time of the last update. */
  private r = 0;
  private thr = 0;
  private lastT = 0;
  private dead = false;
  private gate!: GainNode;
  private pipe!: BiquadFilterNode;
  private pipeBase = 0;
  private fx: Partial<Record<FaultId, { osc: OscillatorNode; g: GainNode; k: number }>> = {};
  private leak!: GainNode;
  private analyser!: AnalyserNode;
  private faults: Faults = {};
  private fireN = 0;
  private firePh = 0;
  private lastR = 0;
  private lastU = 0;
  private aBuf = new Float32Array(2048);
  /** Níveis atuais dos defeitos (0..1), para o painel. */
  levels: Record<string, number> = {};

  constructor(src: string | Setup, eqDraft?: ExhaustEq, bikeId?: string) {
    const exhaust = typeof src === "string" ? src : src.slots.escape;
    const base = { ...(PROFILES[exhaust] ?? PROFILES["escape-original"]!), ...(exhaust === "escape-original" && bikeId ? OEM_VOICE[bikeId] ?? {} : {}) };
    this.p = { ...base, ...(eqDraft ? eqDraft.profile : (typeof cloudStore !== "undefined" ? readEqs()[exhaust]?.profile : undefined) ?? {}) };
    const stored = typeof cloudStore !== "undefined" ? readEqs()[exhaust] : undefined;
    this.faults = (eqDraft ? eqDraft.faults : stored?.faults) ?? {};
    const mst: Master = { ...MASTER_NEUTRAL, ...((eqDraft ? eqDraft.master : stored?.master) ?? {}) };
    const eqBands = eqDraft?.bands ?? (typeof cloudStore !== "undefined" ? readEqs()[exhaust]?.bands : undefined) ?? [];
    this.v = typeof src === "string"
      ? { cc: 162.7, cam: "original", compression: 9.5, intake: false, qs: 220, idle: 1300, soft: false, prog: false }
      : { cc: displacement(src, bikeId), cam: src.cam, compression: src.compression, intake: src.airFilter !== "original", ...ecuVoice(src) };
    this.r = this.v.idle;
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.ctx = new Ctx();
    const c = this.ctx;
    const big = this.v.cc / 162.7; // 1 .. ~1.5

    this.master = c.createGain();
    this.master.gain.value = 0;
    this.out = c.createGain();
    this.out.gain.value = soundMul("engine");
    // limiter: lets the engine sit loud without crackling distortion on the speaker
    const lim = c.createDynamicsCompressor();
    lim.threshold.value = Math.min(-10, this.p.compDb ?? PRO_NEUTRAL.compDb); lim.knee.value = 12; lim.ratio.value = 8; lim.attack.value = 0.002; lim.release.value = 0.25;
    // masterização: ganho de reposição → soft clipper com teto → limitador de proteção → medidor
    const make = c.createGain(); make.gain.value = undb(mst.makeupDb) * (1 + mst.softClip) * 0.7; // folga contra estouro nos picos
    const clip = c.createWaveShaper(); clip.curve = limitCurve(mst.ceilingDb); clip.oversample = "4x";
    this.analyser = c.createAnalyser(); this.analyser.fftSize = 2048; this.analyser.smoothingTimeConstant = 0.6;
    this.out.connect(make).connect(lim).connect(clip).connect(this.analyser).connect(c.destination);
    this.unsub = onSound(() => this.out.gain.setTargetAtTime(soundMul("engine"), c.currentTime, 0.05));

    // combustion pulse: one sharp pressure wave per firing → full harmonic series, richer with louder pipes
    const N = 28;
    const re = new Float32Array(N), im = new Float32Array(N);
    for (let n = 1; n < N; n++) im[n] = Math.pow(n, -0.45) * Math.pow(this.p.bright, (n - 1) / 4) * (n % 2 ? 1 : 0.8);
    this.pulse = c.createOscillator();
    this.pulse.setPeriodicWave(c.createPeriodicWave(re, im));
    // harmonic edge: the raspy bark of an open pipe under load (pure harmonics, no noise)
    this.edge = c.createOscillator();
    this.edge.type = "sawtooth";
    const edgeHp = c.createBiquadFilter();
    edgeHp.type = "highpass";
    edgeHp.frequency.value = this.p.res * 1.6;
    this.edgeGain = c.createGain();
    this.edgeGain.gain.value = 0;
    // crank order (rpm/60): soft mechanical layer under the exhaust
    this.crank = c.createOscillator();
    this.crank.type = "sine";
    const gCrank = c.createGain();
    gCrank.gain.value = this.p.crankMix ?? PRO_NEUTRAL.crankMix;

    // per-firing throb (amplitude modulation at fire rate)
    const throb = c.createGain();
    throb.gain.value = 0.7;
    this.am = c.createOscillator();
    this.am.type = "sine";
    this.amDepth = c.createGain();
    this.amDepth.gain.value = 0.3;
    this.am.connect(this.amDepth).connect(throb.gain);

    // saturation: higher compression = harder crack; oversampled so it stays clean (no digital fizz)
    const drive = this.p.drive + Math.max(0, this.v.compression - 9.5) * 0.6;
    const shaper = c.createWaveShaper();
    const curve = new Float32Array(2048);
    const norm = Math.tanh(drive) * 1.25; // saída do saturador abaixo de 0 dBFS
    for (let i = 0; i < 2048; i++) curve[i] = Math.tanh(((i / 1024) - 1) * drive) / norm;
    shaper.curve = curve;
    shaper.oversample = "4x";

    // body resonance: bigger cylinder sits lower and heavier
    const body = c.createBiquadFilter();
    body.type = "peaking";
    body.frequency.value = 140 / Math.sqrt(big);
    body.Q.value = 1.1;
    body.gain.value = 4 + (big - 1) * 16 + (this.p.bodyDb ?? 0);
    // pipe resonance: each exhaust rings at its own length
    const pipe = c.createBiquadFilter();
    pipe.type = "peaking";
    pipe.frequency.value = this.p.res / Math.sqrt(big);
    pipe.Q.value = 2.2;
    pipe.gain.value = this.p.resGain;
    this.pipe = pipe; this.pipeBase = this.p.resGain;

    this.filt = c.createBiquadFilter();
    this.filt.type = "lowpass";
    this.filt.frequency.value = this.p.cutoff;
    this.filt.Q.value = this.p.q;
    // clean-up: no sub rumble, no harsh top
    const hp = c.createBiquadFilter();
    hp.type = "highpass";
    hp.frequency.value = mst.denoiseHz; // redução de ronco sub-sônico sem tocar nos estalos
    const top = c.createBiquadFilter();
    top.type = "lowpass";
    top.frequency.value = 6500;
    top.Q.value = 0.5;

    // portão da combustão: falha/engasgo apagam a explosão do ciclo, não o volume geral
    this.gate = c.createGain(); this.gate.gain.value = 1;
    this.pulse.connect(throb);
    this.edge.connect(edgeHp).connect(this.edgeGain).connect(throb);
    this.crank.connect(gCrank).connect(throb);
    // equalizador gráfico do escape (aba Equalizador): uma peaking por banda
    let tail: AudioNode = throb.connect(this.gate).connect(shaper).connect(body).connect(pipe).connect(this.filt).connect(hp).connect(top);
    EQ_BANDS.forEach((f, i) => {
      const g = eqBands[i] ?? 0; if (!g) return;
      const b = c.createBiquadFilter(); b.type = "peaking"; b.frequency.value = f; b.Q.value = 1; b.gain.value = g;
      tail = tail.connect(b);
    });
    // sub-grave (peito do escape) e ar/presença no topo
    if (this.p.sub) { const b = c.createBiquadFilter(); b.type = "lowshelf"; b.frequency.value = 90; b.gain.value = this.p.sub; tail = tail.connect(b); }
    if (this.p.airDb) { const b = c.createBiquadFilter(); b.type = "highshelf"; b.frequency.value = 3500; b.gain.value = this.p.airDb; tail = tail.connect(b); }
    tail.connect(this.master);
    // vazamento: sopro aberto em paralelo (agudo do pulso sem o tubo)
    const lk = c.createBiquadFilter(); lk.type = "highpass"; lk.frequency.value = 1400;
    this.leak = c.createGain(); this.leak.gain.value = 0;
    throb.connect(lk).connect(this.leak).connect(this.master);
    // defeitos mecânicos: nós criados uma vez, só os ganhos mudam durante a pilotagem
    const mk = (id: FaultId, type: OscillatorType, filt: [BiquadFilterType, number, number][], k: number, wave?: PeriodicWave) => {
      const osc = c.createOscillator(); if (wave) osc.setPeriodicWave(wave); else osc.type = type;
      const g = c.createGain(); g.gain.value = 0;
      let n: AudioNode = osc;
      for (const [t, f, q] of filt) { const b = c.createBiquadFilter(); b.type = t; b.frequency.value = f; b.Q.value = q; n = n.connect(b); }
      n.connect(g).connect(this.master); osc.start(); this.fx[id] = { osc, g, k };
    };
    const kre = new Float32Array(40), kim = new Float32Array(40); for (let i = 1; i < 40; i++) kim[i] = 1;
    mk("grilo", "square", [["bandpass", 6300, 9]], 0.5);
    mk("lata", "sawtooth", [["bandpass", 1850, 16], ["peaking", 2950, 12]], 0.9);
    mk("batida", "custom", [["highpass", 1100, 0.7]], 0.12, c.createPeriodicWave(kre, kim));
    // eco da lata: reflexão curta dentro do abafador (delay com realimentação)
    if ((this.p.echoMs ?? 0) > 0) {
      const dl = c.createDelay(0.1); dl.delayTime.value = this.p.echoMs! / 1000;
      const fb = c.createGain(); fb.gain.value = Math.min(0.85, this.p.echoFb ?? 0);
      const wet = c.createGain(); wet.gain.value = 0.5;
      tail.connect(dl); dl.connect(fb).connect(dl); dl.connect(wet).connect(this.master);
    }

    // intake growl: airbox resonance at twice the firing rate (louder with the filter removed)
    this.intake = c.createOscillator();
    this.intake.type = "triangle";
    this.intakeF = c.createBiquadFilter();
    this.intakeF.type = "bandpass";
    this.intakeF.Q.value = 3;
    this.intakeF.frequency.value = 500;
    this.intakeGain = c.createGain();
    this.intakeGain.gain.value = 0;
    this.intake.connect(this.intakeF).connect(this.intakeGain).connect(this.master);

    this.master.connect(this.out);

    // short decaying burst used only for backfire cracks (never looped → no hiss)
    this.popBuf = c.createBuffer(1, Math.floor(c.sampleRate * 0.12), c.sampleRate);
    const d = this.popBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * Math.exp(-i / (c.sampleRate * 0.018));

    this.pulse.start();
    this.edge.start();
    this.crank.start();
    this.am.start();
    this.intake.start();
  }

  resume() {
    if (this.ctx.state !== "running") this.ctx.resume().catch(() => {});
  }

  /** Flywheel: rpm climbs with a heavier lag than it falls; launching off idle flares up progressively. */
  private glide(rpm: number, throttle: number, t: number) {
    const dt = Math.min(0.1, Math.max(0, t - (this.lastT || t)));
    this.lastT = t;
    const big = this.v.cc / 162.7;
    const up = rpm > this.r;
    let tau = up ? 0.07 * Math.sqrt(big) : 0.05;
    if (up && this.r < 3200 && rpm - this.r > 1500) tau = 0.22; // embreagem mordendo na largada
    if (t < this.shiftUntil && !up) tau = 0.035; // troca: o giro despenca rápido
    const k = dt > 0 ? 1 - Math.exp(-dt / tau) : 1;
    this.r += (rpm - this.r) * k;
    this.thr += (throttle - this.thr) * (dt > 0 ? 1 - Math.exp(-dt / 0.05) : 1);
    return this.r;
  }

  /** Call every frame. `cut` = ignition cut (limiter, 2-step or gear shift); throttle 0..1. */
  update(rpmIn: number, throttle: number, cut: boolean, muted: boolean, kmh = 0) {
    if (this.dead) return;
    const t = this.ctx.currentTime;
    const rpm = this.glide(rpmIn, throttle, t);
    const dtU = this.lastU ? Math.min(0.1, Math.max(1e-3, t - this.lastU)) : 0.016; this.lastU = t;
    const accel = (rpm - (this.lastR || rpm)) / dtU; this.lastR = rpm;
    throttle = this.thr;
    // cycle-to-cycle variation: no two combustions are equal, strongest at low revs
    const jit = 1 + (Math.random() - 0.5) * Math.max(0.004, 0.035 - rpm / 300000);
    const fire = Math.max(9, (rpm / 120) * jit);
    const big = this.v.cc / 162.7;
    this.pulse.frequency.setTargetAtTime(fire, t, 0.006);
    this.edge.frequency.setTargetAtTime(fire, t, 0.006);
    this.am.frequency.setTargetAtTime(fire, t, 0.006);
    this.intake.frequency.setTargetAtTime(fire * 2, t, 0.01);
    this.crank.frequency.setTargetAtTime(rpm / 60, t, 0.006);
    // low rpm = each firing distinct; high rpm = smoother scream
    this.amDepth.gain.setTargetAtTime(Math.min(0.95, Math.max(0.08, 0.62 - rpm / 19000) * (this.p.throb ?? 1)), t, 0.03);
    const load = Math.min(1, throttle + kmh / 400);
    // closed throttle (overrun) darkens the tone; open throttle opens the muffler up
    this.filt.frequency.setTargetAtTime(this.p.cutoff * (0.45 + load * 0.65 + rpm / 22000) / Math.sqrt(big), t, 0.03);
    let vol = this.p.gain * (0.28 + load * 0.72) * (0.9 + (big - 1) * 0.5);
    const shifting = t < this.shiftUntil;
    if (cut || shifting) {
      this.cutPhase = (this.cutPhase + 1) % 4;
      if (shifting) vol *= 0.14;
      else if (this.v.soft) vol *= 0.6; // corte suave: atrasa o ponto, ronco engasgado sem silêncio
      else if (this.cutPhase < 2) vol *= 0.1;
      if (this.v.prog && t - this.lastPop > 0.06 && Math.random() < this.p.pop * (shifting ? 0.6 : 1)) this.pop();
    }
    this.edgeGain.gain.setTargetAtTime(this.p.rasp * (0.2 + load * 0.8) * Math.min(1, rpm / 7000), t, 0.03);
    this.intakeF.frequency.setTargetAtTime(380 + rpm / 14, t, 0.03);
    this.intakeGain.gain.setTargetAtTime(muted ? 0 : throttle * (this.v.intake ? 0.05 : 0.012) * Math.min(1, rpm / 9000), t, 0.03);
    this.master.gain.setTargetAtTime(muted ? 0 : vol * 0.5, t, 0.02); // rampa mais lenta: sem clique no corte
    this.faultStep(rpm, load, throttle, accel, fire, dtU, t, cut || shifting);
  }

  /** Defeitos: níveis do MechanicalFaultEngine aplicados a nós já existentes; falhas apagam explosões no ciclo. */
  private faultStep(rpm: number, load: number, throttle: number, accel: number, fire: number, dt: number, t: number, cut: boolean) {
    const L = faultLevels(this.faults, { rpm, load, throttle, accel });
    this.levels = L;
    const g = this.fx.grilo, la = this.fx.lata, ba = this.fx.batida;
    if (g) { g.osc.frequency.setTargetAtTime(rpm / 60 * 4, t, 0.01); g.g.gain.setTargetAtTime(L.grilo * g.k * (0.6 + 0.4 * Math.sin(t * rpm / 60 * 0.5)), t, 0.01); }
    if (la) { la.osc.frequency.setTargetAtTime(fire, t, 0.01); const irr = 0.55 + 0.45 * Math.sin(t * 7.3) * Math.sin(t * 2.9); la.g.gain.setTargetAtTime(L.lata * la.k * irr, t, 0.02); }
    if (ba) { ba.osc.frequency.setTargetAtTime(rpm / 60, t, 0.01); ba.g.gain.setTargetAtTime(L.batida * ba.k, t, 0.02); }
    this.leak.gain.setTargetAtTime(L.vazamento * 0.35 * (0.4 + 0.6 * load), t, 0.03);
    this.pipe.gain.setTargetAtTime(this.pipeBase * (1 - 0.6 * L.vazamento), t, 0.05);
    // contagem de explosões pelo próprio giro: cada ciclo novo decide se queima
    this.firePh += fire * dt;
    while (this.firePh >= 1) {
      this.firePh -= 1; this.fireN++;
      if (!cut && misses(this.fireN, L.falha, L.engasgo)) {
        const at = t; this.gate.gain.cancelScheduledValues(at);
        this.gate.gain.setTargetAtTime(0.08, at, 0.004); this.gate.gain.setTargetAtTime(1, at + 1 / fire, 0.008);
      }
      if (L.pipoco > 0 && t - this.lastPop > 0.07 && cycleHash(this.fireN + 7) < L.pipoco * 0.25) this.pop(Math.max(this.p.pop, 0.6) * L.pipoco + 0.2);
    }
  }

  /** Medidor real do que sai no alto-falante (depois do limitador). */
  meter(): Meter { this.analyser.getFloatTimeDomainData(this.aBuf); return measure(this.aBuf); }
  spectrum(out: Uint8Array<ArrayBuffer>) { this.analyser.getByteFrequencyData(out); }

  /** Gear change: cuts ignition for exactly the quickshift time with a crackle. */
  shift(ms = this.v.qs) {
    const t = this.ctx.currentTime;
    this.shiftUntil = t + Math.max(30, ms) / 1000;
    if (this.v.prog && Math.random() < 0.4 + this.p.pop * 0.6) this.pop();
  }

  /** 2-Step at the line: bounces on the launch rpm with ignition cut (only programmable modules). */
  launch(rpm: number, k: number, muted: boolean) {
    this.update(rpm + Math.sin(k * 40) * 120, 1, true, muted);
    this.resume();
  }

  /** Idle: lumpier cams lope harder; louder pipes miss a beat now and then. */
  idle(k: number, muted: boolean) {
    const cam = this.v.cam === "ma" ? 2.4 : this.v.cam === "mb" ? 1.4 : 1;
    const lope = (40 + this.p.pop * 90) * cam;
    let rpm = this.v.idle + this.p.pop * 150 + (cam - 1) * 250 + Math.sin(k * (5 + this.p.pop * 3) / cam) * lope + Math.sin(k * 2.3) * lope * 0.4;
    const miss = (this.p.pop > 0.5 || cam > 1.3) && Math.sin(k * 1.7 * cam) > 0.96;
    if (miss) rpm -= 150 * cam;
    this.update(rpm, 0.42 + this.p.rasp * 0.4, false, muted);
    this.resume();
    if (this.v.prog && miss && this.ctx.currentTime - this.lastPop > 0.5 && Math.random() < this.p.pop * 0.2 * cam) this.pop();
  }

  /** Backfire: low thump plus a short crack from unburnt fuel in the pipe. */
  pop(force = this.p.pop) {
    const c = this.ctx;
    const t = c.currentTime;
    this.lastPop = t;
    const thump = c.createOscillator();
    thump.type = "sine";
    thump.frequency.setValueAtTime(130 + Math.random() * 60, t);
    thump.frequency.exponentialRampToValueAtTime(55, t + 0.07);
    const tg = c.createGain();
    tg.gain.setValueAtTime(0.5 * force, t);
    tg.gain.exponentialRampToValueAtTime(0.001, t + 0.09);
    thump.connect(tg).connect(this.out);
    thump.start(t);
    thump.stop(t + 0.1);
    const s = c.createBufferSource();
    s.buffer = this.popBuf;
    const f = c.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 900 + Math.random() * 900;
    const g = c.createGain();
    g.gain.value = 0.35 * force;
    s.connect(f).connect(g).connect(this.out);
    s.start(t);
  }

  /** Engine failure: metallic bang, then it dies. */
  blow() {
    const c = this.ctx;
    const t = c.currentTime;
    const s = c.createBufferSource();
    s.buffer = this.popBuf;
    const f = c.createBiquadFilter();
    f.type = "bandpass";
    f.frequency.value = 1600;
    const g = c.createGain();
    g.gain.value = 0.5;
    s.connect(f).connect(g).connect(this.out);
    s.start(t);
    this.pulse.frequency.setTargetAtTime(8, t, 0.4);
    this.stop(0.5);
  }

  stop(tc = 0.1) {
    if (this.dead) return;
    this.dead = true;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(0, t, tc);
    this.intakeGain.gain.setTargetAtTime(0, t, tc);
    this.unsub();
    setTimeout(() => this.ctx.close().catch(() => {}), 400 + tc * 3000);
  }
}
