// Ignição física por arquitetura: platinado (CG 125), CDI (CG 150 ESD) e ECU (CG 160, Factor 150).
// Cada arquitetura tem circuito próprio; a energia da centelha por rotação decide até onde o motor
// queima a mistura. Valores marcados "HIPÓTESE" não têm medição publicada e aguardam validação.
import type { Part } from "./parts";
import { slotPart } from "./parts";
import type { BikeModel, Setup } from "./physics";

export type IgnArch = "platinado" | "cdi" | "ecu";
type Src = { value: number; unit: string; origem: "FICHA" | "HIPÓTESE" };

/** Arquitetura de fábrica por moto (fichas técnicas do fabricante). */
export const IGN_ARCH: Record<string, IgnArch> = { cg125: "platinado", titan150: "cdi", titan160: "ecu", factor150: "ecu" };
export const ignitionOf = (bikeId: string): IgnArch => IGN_ARCH[bikeId] ?? "ecu";

/** Platinado 6 V da CG 125: bobina indutiva interrompida pelos contatos. */
export const PLATINADO = {
  V: { value: 6.0, unit: "V", origem: "FICHA" } as Src, // sistema 6 V (ficha CG 125 1976–1982)
  R: { value: 1.5, unit: "Ω", origem: "HIPÓTESE" } as Src, // resistência do primário
  L: { value: 0.006, unit: "H", origem: "HIPÓTESE" } as Src, // indutância do primário
  dwellDeg: { value: 195, unit: "° vira", origem: "HIPÓTESE" } as Src, // contatos fechados por volta
  advanceDeg: { value: 15, unit: "° APMS", origem: "HIPÓTESE" } as Src, // avanço total do platinado
};
/** CDI 12 V da CG 150 ESD: capacitor carregado pela bobina do estator, descarregado no primário. */
export const CDI = {
  C: { value: 1e-6, unit: "F", origem: "HIPÓTESE" } as Src,
  Vmax: { value: 300, unit: "V", origem: "HIPÓTESE" } as Src,
  tau: { value: 0.0004, unit: "s", origem: "HIPÓTESE" } as Src, // constante de carga do capacitor
  eta: { value: 0.6, unit: "—", origem: "HIPÓTESE" } as Src, // eficiência de descarga até a vela
  factoryCut: { value: 9000, unit: "rpm", origem: "HIPÓTESE" } as Src, // corte autorizado pelo jogador, não medição OEM
};
/** Energia mínima na vela para queimar a mistura sem falha (HIPÓTESE, faixa de literatura 5–30 mJ). */
export const SPARK_MIN_J: Src = { value: 0.015, unit: "J", origem: "HIPÓTESE" };

/** Tempo por grau de virabrequim: 60 / (RPM × 360) segundos. */
export const timePerDeg = (rpm: number) => 60 / (rpm * 360);
/** Corrente no primário ao abrir o contato: I = V/R · (1 − e^(−t·R/L)), t = dwell em segundos. */
export function coilCurrent(rpm: number) {
  const t = PLATINADO.dwellDeg.value * timePerDeg(rpm), R = PLATINADO.R.value, L = PLATINADO.L.value;
  return (PLATINADO.V.value / R) * (1 - Math.exp((-t * R) / L));
}
/** Energia magnética na bobina do platinado: E = ½ L I². */
export const platinadoEnergy = (rpm: number) => 0.5 * PLATINADO.L.value * coilCurrent(rpm) ** 2;
/** Energia entregue pelo CDI: η · ½ C V², V = Vmax(1 − e^(−t/τ)), t = uma volta. */
export function cdiEnergy(rpm: number) {
  const v = CDI.Vmax.value * (1 - Math.exp(-(60 / rpm) / CDI.tau.value));
  return CDI.eta.value * 0.5 * CDI.C.value * v * v;
}
export const sparkEnergy = (arch: IgnArch, rpm: number) => (arch === "platinado" ? platinadoEnergy(rpm) : arch === "cdi" ? cdiEnergy(rpm) : Infinity);

/** Maior rotação em que a centelha ainda tem energia mínima (bissecção, 1 rpm). */
export function sparkLimitRpm(arch: IgnArch) {
  if (arch === "ecu") return Infinity;
  let lo = 1000, hi = 200000;
  if (sparkEnergy(arch, hi) >= SPARK_MIN_J.value) return hi;
  while (hi - lo > 1) { const m = (lo + hi) / 2; if (sparkEnergy(arch, m) >= SPARK_MIN_J.value) lo = m; else hi = m; }
  return lo;
}

/** Peça monta nesta moto? Arquitetura e lista de motos precisam bater; peça de fábrica sempre monta. */
export function fitsBike(part: Pick<Part, "kind" | "ign" | "bikes" | "factory">, bikeId: string) {
  if (part.factory) return true;
  if (part.bikes && !part.bikes.includes(bikeId)) return false;
  if (part.ign && part.ign !== ignitionOf(bikeId)) return false;
  if (part.kind === "modulo" && !part.ign && ignitionOf(bikeId) !== "ecu") return false;
  return true;
}
/** Módulo efetivo: peça incompatível não funciona, vale o de fábrica. */
export function effectiveModulo(b: BikeModel, s: Setup) {
  const m = slotPart(s.slots.modulo, "modulo");
  return fitsBike(m, b.id) ? m : slotPart("modulo-original", "modulo");
}
/** Bolinha não tem módulo: nenhum módulo é vendido nem equipado nela. */
export const hasModuloMenu = (bikeId: string) => ignitionOf(bikeId) !== "platinado";

/**
 * Teto de rotação das ignições sem ECU. Platinado e CDI sem corte não têm limitador:
 * o motor sobe até faltar energia na centelha ou a válvula flutuar (o que vier antes).
 * CDI original corta no valor de ficha. ECU devolve null (corte pelo mapa em physics.engine).
 */
/** Teto de leitura do platinado: limite da biela original (13.000 rpm), nunca um corte. */
export const PLATINADO_FREE_RPM = 13000;
export function ignitionRpmLimit(b: BikeModel, mod: Pick<Part, "noCut">, floatRpm: number): number | null {
  const arch = ignitionOf(b.id);
  if (arch === "ecu") return null;
  // platinado (Bolinha): sem limitador; o giro só para no teto de leitura e a biela original aguenta até ele (13.000 rpm)
  if (arch === "platinado") return PLATINADO_FREE_RPM;
  const phys = Math.min(sparkLimitRpm(arch), floatRpm);
  const lim = arch === "cdi" && !mod.noCut ? Math.min(b.rpmLimit, phys) : phys;
  return Math.floor(lim / 50) * 50;
}

/** Relatório de sincronização da centelha num rpm: tempo antes do PMS e energia disponível. */
export function sparkReport(b: BikeModel, rpm: number) {
  const arch = ignitionOf(b.id), adv = arch === "platinado" ? PLATINADO.advanceDeg.value : null;
  const E = sparkEnergy(arch, rpm);
  return { arch, rpm, tPorGrau_s: timePerDeg(rpm), avancoGraus: adv, tAntesPMS_s: adv == null ? null : adv * timePerDeg(rpm), energia_J: Number.isFinite(E) ? E : null, falha: E < SPARK_MIN_J.value };
}

/**
 * Corte eletrônico de giro de fábrica/módulo: ECU sempre corta pelo mapa; CDI corta salvo módulo noCut;
 * platinado não tem corte (o giro segue a carga até o equilíbrio de forças).
 */
export function hasElectronicCut(b: BikeModel, mod: Pick<Part, "noCut">) {
  const arch = ignitionOf(b.id);
  return arch === "ecu" || (arch === "cdi" && !mod.noCut);
}
