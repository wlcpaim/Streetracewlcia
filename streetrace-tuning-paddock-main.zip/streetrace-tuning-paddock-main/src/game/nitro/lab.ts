// RG-CHEM-NM-001 — Nitromethane Engineering Lab.
// Módulo científico read-only: oito motores de cálculo independentes sobre o nitrometano (CH3NO2).
// NÃO altera a corrida, Setup nem fuelmix.ts (mudar a corrida exige aprovação separada).
// Todo valor carrega origem; nada desconhecido é preenchido em silêncio; nada é aprovado pelo Nexus aqui.
import { cloudStore } from "@/game/cloud/cloud-store";
import { ENGINE_CATALOG } from "@/game/data/engine_catalog";

export const MODULE_ID = "RG-CHEM-NM-001";
export const MODULE_VERSION = "1.0.0";

export type Origem = "OFICIAL" | "CALCULADO" | "ILUSTRATIVO" | "HIPOTESE" | "ESTIMADO" | "DESCONHECIDO";
export type Classe = "APROVADO" | "APROVADO COM RESTRIÇÕES" | "NÃO APLICÁVEL" | "REPROVADO";
export type NexusStatus = "EM DESENVOLVIMENTO — NÃO APROVADO PELO NEXUS" | "AGUARDANDO NEXUS";

/* ---------------- 5. Dicionário de variáveis ---------------- */
export type Variavel = {
  nome: string; simbolo: string; unidade: string; tipo: "escalar" | "vetor" | "texto";
  valor: number | null; origem: Origem; precisao: string; faixa: [number, number] | null;
  dependencias: string[]; validacao: "VALIDADO" | "NÃO VALIDADO" | "DESCONHECIDO"; fonte: string;
};
const v = (o: Omit<Variavel, "tipo"> & { tipo?: Variavel["tipo"] }): Variavel => ({ tipo: "escalar", ...o });

/** Massas atômicas padrão IUPAC (valores convencionais, g/mol). */
export const ATOMIC: Record<"C" | "H" | "N" | "O", number> = { C: 12.011, H: 1.008, N: 14.007, O: 15.999 };
const R_U = 8.314462618; // J/(mol·K), CODATA (exato desde 2019)
const Y_O2_AIR = 0.2314; // fração mássica de O2 no ar seco
const P_ATM = 101325; // Pa, exata
/** PCI ilustrativo pedido no caso RG-NM-001 (não é medição experimental). */
export const LHV_NM_ILUSTRATIVO = 11.3e6; // J/kg

export const VARIAVEIS: Record<string, Variavel> = {
  M_C: v({ nome: "Massa atômica do carbono", simbolo: "M_C", unidade: "g/mol", valor: ATOMIC.C, origem: "OFICIAL", precisao: "±0,001", faixa: null, dependencias: [], validacao: "VALIDADO", fonte: "IUPAC, peso atômico convencional" }),
  M_H: v({ nome: "Massa atômica do hidrogênio", simbolo: "M_H", unidade: "g/mol", valor: ATOMIC.H, origem: "OFICIAL", precisao: "±0,001", faixa: null, dependencias: [], validacao: "VALIDADO", fonte: "IUPAC, peso atômico convencional" }),
  M_N: v({ nome: "Massa atômica do nitrogênio", simbolo: "M_N", unidade: "g/mol", valor: ATOMIC.N, origem: "OFICIAL", precisao: "±0,001", faixa: null, dependencias: [], validacao: "VALIDADO", fonte: "IUPAC, peso atômico convencional" }),
  M_O: v({ nome: "Massa atômica do oxigênio", simbolo: "M_O", unidade: "g/mol", valor: ATOMIC.O, origem: "OFICIAL", precisao: "±0,001", faixa: null, dependencias: [], validacao: "VALIDADO", fonte: "IUPAC, peso atômico convencional" }),
  R_u: v({ nome: "Constante universal dos gases", simbolo: "R", unidade: "J/(mol·K)", valor: R_U, origem: "OFICIAL", precisao: "exata", faixa: null, dependencias: [], validacao: "VALIDADO", fonte: "CODATA 2018 (SI 2019)" }),
  Y_O2: v({ nome: "Fração mássica de O₂ no ar seco", simbolo: "Y_O2", unidade: "kg/kg", valor: Y_O2_AIR, origem: "OFICIAL", precisao: "±0,0002", faixa: [0.2312, 0.2316], dependencias: [], validacao: "VALIDADO", fonte: "Composição padrão do ar seco (20,95 % v/v O₂)" }),
  P_atm: v({ nome: "Pressão atmosférica padrão", simbolo: "p₀", unidade: "Pa", valor: P_ATM, origem: "OFICIAL", precisao: "exata", faixa: null, dependencias: [], validacao: "VALIDADO", fonte: "Definição de atm" }),
  PCI_NM: v({ nome: "Poder calorífico inferior do nitrometano", simbolo: "PCI", unidade: "J/kg", valor: LHV_NM_ILUSTRATIVO, origem: "ILUSTRATIVO", precisao: "referência ilustrativa", faixa: [10.5e6, 11.7e6], dependencias: [], validacao: "NÃO VALIDADO", fonte: "Valor ilustrativo do caso RG-NM-001 (literatura cita ≈11,3 MJ/kg); não é medição deste projeto" }),
  M_NM: v({ nome: "Massa molar do nitrometano", simbolo: "M", unidade: "g/mol", valor: null, origem: "CALCULADO", precisao: "±0,004", faixa: null, dependencias: ["M_C", "M_H", "M_N", "M_O"], validacao: "VALIDADO", fonte: "M = Σ nᵢ·Mᵢ" }),
  AFR_st: v({ nome: "Relação ar/combustível estequiométrica", simbolo: "AFR", unidade: "kg/kg", valor: null, origem: "CALCULADO", precisao: "±0,002", faixa: [1.6, 1.8], dependencias: ["M_NM", "Y_O2"], validacao: "VALIDADO", fonte: "AFR = m_O2/(Y_O2·m_comb) pela reação balanceada" }),
  gamma: v({ nome: "Razão de calores específicos", simbolo: "γ(T)", unidade: "—", valor: null, origem: "ESTIMADO", precisao: "±0,02", faixa: [1.22, 1.40], dependencias: [], validacao: "NÃO VALIDADO", fonte: "Ajuste linear γ = 1,38 − 8·10⁻⁵·(T−300), típico de modelos zero-dimensionais; modelo simplificado" }),
  wiebe_a: v({ nome: "Parâmetro de eficiência de Wiebe", simbolo: "a", unidade: "—", valor: 5, origem: "HIPOTESE", precisao: "—", faixa: [3, 7], dependencias: [], validacao: "NÃO VALIDADO", fonte: "Valor usual de literatura; sem curva de pressão medida para nitrometano neste motor" }),
  wiebe_m: v({ nome: "Fator de forma de Wiebe", simbolo: "m", unidade: "—", valor: 2, origem: "HIPOTESE", precisao: "—", faixa: [1, 3], dependencias: [], validacao: "NÃO VALIDADO", fonte: "Valor usual de literatura" }),
  ve: v({ nome: "Eficiência volumétrica", simbolo: "η_v", unidade: "—", valor: null, origem: "DESCONHECIDO", precisao: "—", faixa: [0.5, 1.2], dependencias: [], validacao: "DESCONHECIDO", fonte: "Não medida; a simulação usa 1,0 como HIPÓTESE ideal declarada" }),
  h_w: v({ nome: "Coeficiente de troca de calor na parede", simbolo: "h", unidade: "W/(m²·K)", valor: null, origem: "DESCONHECIDO", precisao: "—", faixa: [0, 3000], dependencias: [], validacao: "DESCONHECIDO", fonte: "Variável do modelo; padrão 0 (adiabático) como HIPÓTESE" }),
};

/* ---------------- Motor genérico ---------------- */
export type Formula = { id: string; expr: string; dimensao: string; validade: string };
export type MotorInfo = { id: string; nome: string; versao: string; dependencias: string[]; entradas: string[]; saidas: string[]; formulas: Formula[] };

/* ---------------- 1. Chemical Engine ---------------- */
export type Formula_ = Record<"C" | "H" | "N" | "O", number>;
export const NM: Formula_ = { C: 1, H: 3, N: 1, O: 2 };
export const O2: Formula_ = { C: 0, H: 0, N: 0, O: 2 };
export const CO2: Formula_ = { C: 1, H: 0, N: 0, O: 2 };
export const H2O: Formula_ = { C: 0, H: 2, N: 0, O: 1 };
export const N2: Formula_ = { C: 0, H: 0, N: 2, O: 0 };
/** 4 CH3NO2 + 3 O2 → 4 CO2 + 6 H2O + 2 N2 */
export const REACAO = { reag: [[4, NM], [3, O2]] as [number, Formula_][], prod: [[4, CO2], [6, H2O], [2, N2]] as [number, Formula_][] };

export const chemical = {
  info: { id: "NM-E1-CHEM", nome: "Chemical Engine", versao: "1.0.0", dependencias: [], entradas: ["massas atômicas IUPAC", "fórmula CH3NO2"], saidas: ["M (g/mol)", "balanço atômico"],
    formulas: [{ id: "massa-molar", expr: "M = Σ(nᵢ × Mᵢ)", dimensao: "[g/mol] = [—]·[g/mol]", validade: "composição definida, isótopos naturais" },
      { id: "reacao", expr: "4CH₃NO₂ + 3O₂ → 4CO₂ + 6H₂O + 2N₂", dimensao: "mol", validade: "combustão completa ideal, sem dissociação" }] } as MotorInfo,
  molar(f: Formula_): number { return (Object.keys(f) as (keyof Formula_)[]).reduce((s, k) => s + f[k] * ATOMIC[k], 0); },
  atoms(side: [number, Formula_][]): Formula_ { const o: Formula_ = { C: 0, H: 0, N: 0, O: 0 }; for (const [n, f] of side) for (const k of Object.keys(o) as (keyof Formula_)[]) o[k] += n * f[k]; return o; },
  balance() { const r = chemical.atoms(REACAO.reag), p = chemical.atoms(REACAO.prod); return { reag: r, prod: p, ok: (Object.keys(r) as (keyof Formula_)[]).every((k) => r[k] === p[k]) }; },
  massBalance() { const m = (s: [number, Formula_][]) => s.reduce((t, [n, f]) => t + n * chemical.molar(f), 0); const a = m(REACAO.reag), b = m(REACAO.prod); return { reag: a, prod: b, erro: Math.abs(a - b) }; },
};

/* ---------------- 2. Stoichiometric Engine ---------------- */
export const stoich = {
  info: { id: "NM-E2-STOICH", nome: "Stoichiometric Engine", versao: "1.0.0", dependencias: ["NM-E1-CHEM"], entradas: ["M_NM", "Y_O2"], saidas: ["m_O2/m_comb", "AFR"],
    formulas: [{ id: "afr", expr: "AFR = m_ar / m_comb = (ν_O2·M_O2)/(ν_comb·M_comb) / Y_O2", dimensao: "[kg/kg]", validade: "ar seco, combustão completa, λ = 1" }] } as MotorInfo,
  o2PerKg(): number { return (3 * chemical.molar(O2)) / (4 * chemical.molar(NM)); },
  afr(): number { return stoich.o2PerKg() / Y_O2_AIR; },
};

/* ---------------- 3. Energy Engine ---------------- */
export const energy = {
  info: { id: "NM-E3-ENERGY", nome: "Energy Engine", versao: "1.0.0", dependencias: ["NM-E2-STOICH"], entradas: ["m (kg)", "PCI (J/kg)", "AFR"], saidas: ["Q (J)", "E_mist (J/kg)"],
    formulas: [{ id: "q", expr: "Q = m × PCI", dimensao: "[J] = [kg]·[J/kg]", validade: "PCI na mesma base (inferior, mássica)" },
      { id: "emix", expr: "E = PCI / (1 + AFR)", dimensao: "[J/kg mistura]", validade: "mistura estequiométrica homogênea" }] } as MotorInfo,
  q(m: number, pci: number) { assertPos({ m, pci }); return m * pci; },
  eMix(pci: number, afr: number) { assertPos({ pci }); if (!(afr >= 0)) throw new Error("AFR inválida"); return pci / (1 + afr); },
};

export function assertPos(o: Record<string, number | null | undefined>) {
  for (const [k, x] of Object.entries(o)) {
    if (x === null || x === undefined) throw new Error(`DADO AUSENTE: ${k}`);
    if (!Number.isFinite(x) || x <= 0) throw new Error(`VALOR INVÁLIDO: ${k} = ${x}`);
  }
}

/* ---------------- 4. Thermodynamic Engine (modelo simplificado 0-D) ---------------- */
export const thermo = {
  info: { id: "NM-E4-THERMO", nome: "Thermodynamic Engine", versao: "1.0.0", dependencias: ["NM-E1-CHEM", "NM-E5-COMB"], entradas: ["V(θ)", "n(θ)", "δQ", "h"], saidas: ["P(θ)", "T(θ)", "U(θ)"],
    formulas: [{ id: "gas", expr: "PV = nRT", dimensao: "[Pa·m³] = [mol]·[J/(mol·K)]·[K]", validade: "gás ideal, p < ~20 MPa" },
      { id: "1lei", expr: "ΔU = Q − W", dimensao: "[J]", validade: "sistema fechado (válvulas fechadas)" },
      { id: "gamma", expr: "γ(T) = 1,38 − 8·10⁻⁵ (T − 300)", dimensao: "[—]", validade: "300–3000 K, ESTIMADO" }] } as MotorInfo,
  gamma(T: number) { return Math.max(1.22, 1.38 - 8e-5 * (T - 300)); },
  pressure(n: number, T: number, V: number) { assertPos({ n, T, V }); return (n * R_U * T) / V; },
};

/* ---------------- 5. Combustion Model Engine ---------------- */
/** Mols de produtos / mols de reagentes (com N2 do ar, razão 3,76). */
const N2_PER_O2 = 0.7905 / 0.2095;
export const combustion = {
  info: { id: "NM-E5-COMB", nome: "Combustion Model Engine", versao: "1.0.0", dependencias: ["NM-E1-CHEM"], entradas: ["θ0", "Δθ", "a", "m"], saidas: ["x_b(θ)", "razão molar r"],
    formulas: [{ id: "wiebe", expr: "x_b = 1 − exp(−a·((θ−θ0)/Δθ)^(m+1))", dimensao: "[—]", validade: "modelo empírico; parâmetros HIPÓTESE" },
      { id: "molar", expr: "r = (4+6+2+3·3,76)/(4+3+3·3,76)", dimensao: "[—]", validade: "combustão completa com ar" }] } as MotorInfo,
  molarRatio() { const n2 = 3 * N2_PER_O2; return (4 + 6 + 2 + n2) / (4 + 3 + n2); },
  wiebe(th: number, th0: number, dth: number, a = 5, m = 2) { if (th <= th0) return 0; const x = Math.min(1, (th - th0) / dth); return 1 - Math.exp(-a * Math.pow(x, m + 1)); },
};

/* ---------------- 6. Mechanical Engine ---------------- */
export type Geometria = { boreMm: number | null; strokeMm: number | null; rodMm: number | null; cr: number | null; origem: string };
export function geometriaCatalogo(bikeId = "titan160"): Geometria {
  const p = ENGINE_CATALOG[bikeId]?.p; const num = (k: string) => { const x = p?.[k]?.valor; return typeof x === "number" ? x : null; };
  return { boreMm: num("diametro"), strokeMm: num("curso"), rodMm: num("biela"), cr: num("taxaCompressao"), origem: `engine_catalog.${bikeId}` };
}
export const mechanical = {
  info: { id: "NM-E6-MECH", nome: "Mechanical Engine", versao: "1.0.0", dependencias: ["engine_catalog"], entradas: ["D", "S", "L", "CR"], saidas: ["Vd", "V(θ)", "W = ∮P dV"],
    formulas: [{ id: "vd", expr: "Vd = π × D² × S / 4", dimensao: "[m³] = [m²]·[m]", validade: "cilindro reto" },
      { id: "vtheta", expr: "V(θ) = Vc + (πD²/4)·(L + r − r·cosθ − √(L² − r²sin²θ))", dimensao: "[m³]", validade: "biela-manivela sem desaxagem" },
      { id: "w", expr: "W = ∫ P dV (trapézio)", dimensao: "[J] = [Pa]·[m³]", validade: "passo ≤ 1°" }] } as MotorInfo,
  vd(boreM: number, strokeM: number) { assertPos({ boreM, strokeM }); return (Math.PI * boreM * boreM * strokeM) / 4; },
  volume(th: number, boreM: number, strokeM: number, rodM: number, cr: number) {
    const r = strokeM / 2, A = (Math.PI * boreM * boreM) / 4, vc = mechanical.vd(boreM, strokeM) / (cr - 1);
    return vc + A * (rodM + r - r * Math.cos(th) - Math.sqrt(rodM * rodM - r * r * Math.sin(th) ** 2));
  },
  work(P: number[], V: number[]) { let w = 0; for (let i = 1; i < P.length; i++) w += 0.5 * (P[i]! + P[i - 1]!) * (V[i]! - V[i - 1]!); return w; },
};

/* ---------------- 7. Performance Engine ---------------- */
export const performance = {
  info: { id: "NM-E7-PERF", nome: "Performance Engine", versao: "1.0.0", dependencias: ["NM-E6-MECH"], entradas: ["W_ciclo", "RPM", "Q_in"], saidas: ["T", "P", "η", "IMEP"],
    formulas: [{ id: "torque", expr: "T = W_ciclo / (4π)  (4 tempos: 1 ciclo = 2 voltas)", dimensao: "[N·m] = [J]/[rad]", validade: "torque indicado, sem atrito" },
      { id: "pot", expr: "P = T × 2π × RPM / 60", dimensao: "[W] = [N·m]·[rad/s]", validade: "regime permanente" },
      { id: "eta", expr: "η = energia útil / energia fornecida", dimensao: "[—]", validade: "0 < η < η_Otto" },
      { id: "imep", expr: "IMEP = W / Vd", dimensao: "[Pa]", validade: "—" }] } as MotorInfo,
  torque(w: number) { return w / (4 * Math.PI); },
  power(T: number, rpm: number) { if (!(rpm > 0)) throw new Error(`VALOR INVÁLIDO: rpm = ${rpm}`); return (T * 2 * Math.PI * rpm) / 60; },
  eff(util: number, fornecida: number) { assertPos({ fornecida }); return util / fornecida; },
};

/* ---------------- Simulação de ciclo fechado ---------------- */
export type SimInput = { bikeId: string; rpm: number; pci: number; ve: number; hW: number; th0Deg: number; dthDeg: number; stepDeg: number; Tin: number; pin: number; wallT: number };
export const SIM_DEFAULT: SimInput = { bikeId: "titan160", rpm: 8000, pci: LHV_NM_ILUSTRATIVO, ve: 1, hW: 0, th0Deg: -15, dthDeg: 50, stepDeg: 0.5, Tin: 300, pin: P_ATM, wallT: 450 };
export type SimPoint = { deg: number; V: number; P: number; T: number; xb: number };
export type SimResult = {
  input: SimInput; hipoteses: string[]; bloqueios: string[]; geo: Geometria;
  vd: number; mAir: number; mFuel: number; qIn: number; qWall: number; w: number; dU: number; closureErr: number;
  pMax: number; tMax: number; imep: number; torque: number; power: number; eta: number; etaOtto: number; pontos: SimPoint[];
};

/** Compressão → combustão → expansão com válvulas fechadas (−180° a +180° do PMS). Modelo SIMPLIFICADO. */
export function simulate(inp: SimInput = SIM_DEFAULT): SimResult {
  const geo = geometriaCatalogo(inp.bikeId);
  const bloqueios: string[] = [];
  for (const [k, x] of [["diâmetro", geo.boreMm], ["curso", geo.strokeMm], ["biela", geo.rodMm], ["taxa de compressão", geo.cr]] as const) if (x === null) bloqueios.push(`${k} DESCONHECIDO em ${geo.origem}`);
  if (bloqueios.length) throw new Error("DADO AUSENTE: " + bloqueios.join("; "));
  assertPos({ rpm: inp.rpm, pci: inp.pci, ve: inp.ve, stepDeg: inp.stepDeg, Tin: inp.Tin, pin: inp.pin, dthDeg: inp.dthDeg });
  if (inp.hW < 0) throw new Error(`VALOR INVÁLIDO: h = ${inp.hW}`);
  const D = geo.boreMm! / 1000, S = geo.strokeMm! / 1000, L = geo.rodMm! / 1000, cr = geo.cr!;
  const vd = mechanical.vd(D, S), afr = stoich.afr();
  const V0 = mechanical.volume(-Math.PI, D, S, L, cr);
  // carga fresca: ar a (pin, Tin) ocupando Vd·η_v, combustível na λ = 1
  const mAir = (inp.pin * vd * inp.ve) / ((R_U / 0.028965) * inp.Tin);
  const mFuel = mAir / afr, qIn = mFuel * inp.pci;
  const mMix = mAir + mFuel;
  const Mr = (4 * chemical.molar(NM) + 3 * chemical.molar(O2) + 3 * N2_PER_O2 * 28.0134) / (4 + 3 + 3 * N2_PER_O2) / 1000; // kg/mol da mistura
  const n0 = mMix / Mr, rM = combustion.molarRatio();
  let T = inp.Tin, n = n0, V = V0, P = thermo.pressure(n, T, V);
  const step = (inp.stepDeg * Math.PI) / 180, omega = (inp.rpm * 2 * Math.PI) / 60, A_wall0 = (Math.PI * D * D) / 2;
  let w = 0, qRel = 0, qWall = 0, U = 0, xbPrev = 0;
  const cv = (TT: number, nn: number) => (nn * R_U) / (thermo.gamma(TT) - 1);
  const U0 = cv(T, n) * T; U = U0;
  const pontos: SimPoint[] = [{ deg: -180, V, P, T, xb: 0 }];
  let pMax = P, tMax = T;
  for (let th = -Math.PI + step; th <= Math.PI + 1e-9; th += step) {
    const deg = (th * 180) / Math.PI;
    const Vn = mechanical.volume(th, D, S, L, cr);
    const xb = combustion.wiebe(deg, inp.th0Deg, inp.dthDeg, VARIAVEIS["wiebe_a"]!.valor!, VARIAVEIS["wiebe_m"]!.valor!);
    const dQ = (xb - xbPrev) * qIn;
    const area = A_wall0 + (4 * Vn) / D; const dt = step / omega;
    const dQw = inp.hW * area * (T - inp.wallT) * dt;
    const dW = P * (Vn - V); // previsão explícita
    // 1ª lei: U_n = U + dQ − dQw − dW, com n variável e γ(T) resolvido por ponto fixo
    const Un = U + dQ - dQw - dW;
    const nn = n0 * (1 + (rM - 1) * xb);
    let Tn = T; for (let k = 0; k < 20; k++) Tn = Un / cv(Tn, nn);
    const Pn = thermo.pressure(nn, Tn, Vn);
    // corretor: trabalho pelo trapézio para fechar a energia
    const dWc = 0.5 * (P + Pn) * (Vn - V);
    const Uc = U + dQ - dQw - dWc; let Tc = Tn; for (let k = 0; k < 20; k++) Tc = Uc / cv(Tc, nn);
    T = Tc; n = nn; V = Vn; P = thermo.pressure(n, T, V); U = Uc;
    w += dWc; qRel += dQ; qWall += dQw; xbPrev = xb;
    pMax = Math.max(pMax, P); tMax = Math.max(tMax, T);
    pontos.push({ deg, V, P, T, xb });
  }
  // ΔU recalculado do ESTADO final (n, T), não do acumulador: fecha a 1ª lei por rota independente
  const dU = cv(T, n) * T - U0, closureErr = Math.abs(qRel - qWall - w - dU) / qIn;
  const torque = performance.torque(w), power = performance.power(torque, inp.rpm);
  const g = thermo.gamma(inp.Tin);
  return {
    input: inp, geo, bloqueios: [], vd, mAir, mFuel, qIn, qWall, w, dU, closureErr, pMax, tMax,
    imep: w / vd, torque, power, eta: performance.eff(w, qIn), etaOtto: 1 - 1 / Math.pow(cr, g - 1), pontos,
    hipoteses: [
      "Modelo SIMPLIFICADO zero-dimensional de zona única; não é resultado experimental.",
      "Gás ideal, γ(T) linear ESTIMADO, composição migrando de reagentes a produtos com x_b.",
      `Combustão completa a λ = 1, Wiebe a=${VARIAVEIS["wiebe_a"]!.valor}, m=${VARIAVEIS["wiebe_m"]!.valor} (HIPÓTESE), início ${inp.th0Deg}°, duração ${inp.dthDeg}°.`,
      `η_v = ${inp.ve} (HIPÓTESE; valor real DESCONHECIDO).`,
      inp.hW === 0 ? "Parede adiabática (h = 0, HIPÓTESE)." : `Troca de calor h = ${inp.hW} W/(m²·K), parede ${inp.wallT} K.`,
      "Sem dissociação, sem blow-by, sem bombeamento: torque e potência INDICADOS, não no eixo.",
      `PCI ${inp.pci / 1e6} MJ/kg ${inp.pci === LHV_NM_ILUSTRATIVO ? "(ILUSTRATIVO)" : "(informado)"}.`,
    ],
  };
}

/* ---------------- 8. Scientific Validation Engine ---------------- */
export type Check = { id: string; motor: string; descricao: string; formula: string; esperado: string; encontrado: string; classe: Classe; evidencia: string };
const ok = (c: boolean, restr = false): Classe => (c ? (restr ? "APROVADO COM RESTRIÇÕES" : "APROVADO") : "REPROVADO");
const f = (x: number, d = 4) => x.toLocaleString("pt-BR", { maximumFractionDigits: d });

export const validation = {
  info: { id: "NM-E8-VALID", nome: "Scientific Validation Engine", versao: "1.0.0", dependencias: ["NM-E1…E7"], entradas: ["saídas dos motores"], saidas: ["checks", "classe final"],
    formulas: [{ id: "indep", expr: "rotas independentes: recálculo por outro caminho e comparação com tolerância", dimensao: "—", validade: "—" }] } as MotorInfo,
  run(sim: SimResult): Check[] {
    const C: Check[] = [];
    const bal = chemical.balance(), mb = chemical.massBalance(), M = chemical.molar(NM);
    C.push({ id: "V01", motor: "NM-E1-CHEM", descricao: "Balanço atômico da reação", formula: "Σ átomos reagentes = Σ átomos produtos", esperado: "C4 H12 N4 O14 nos dois lados", encontrado: JSON.stringify(bal.prod), classe: ok(bal.ok), evidencia: JSON.stringify(bal.reag) });
    C.push({ id: "V02", motor: "NM-E1-CHEM", descricao: "Conservação de massa", formula: "Σ ν·M reag = Σ ν·M prod", esperado: "erro < 1e-9 g", encontrado: `${f(mb.reag)} vs ${f(mb.prod)} g`, classe: ok(mb.erro < 1e-9), evidencia: `erro ${mb.erro}` });
    const Mind = 12.011 + 3 * 1.008 + 14.007 + 2 * 15.999;
    C.push({ id: "V03", motor: "NM-E1-CHEM", descricao: "Massa molar (rota independente)", formula: "M = 12,011 + 3·1,008 + 14,007 + 2·15,999", esperado: "61,04 g/mol", encontrado: `${f(M)} g/mol`, classe: ok(Math.abs(M - Mind) < 1e-9 && Math.abs(M - 61.04) < 0.01), evidencia: `independente ${f(Mind)}` });
    const afr = stoich.afr(), afrInd = (0.75 * 31.998) / 61.04 / 0.2314;
    C.push({ id: "V04", motor: "NM-E2-STOICH", descricao: "AFR estequiométrica", formula: "AFR = (3/4)·M_O2/M / Y_O2", esperado: "≈ 1,70 kg/kg", encontrado: f(afr), classe: ok(Math.abs(afr - afrInd) < 1e-3 && Math.abs(afr - 1.7) < 0.01), evidencia: `independente ${f(afrInd)}` });
    const e = energy.eMix(LHV_NM_ILUSTRATIVO, afr);
    C.push({ id: "V05", motor: "NM-E3-ENERGY", descricao: "Energia específica da mistura", formula: "E = PCI/(1+AFR)", esperado: "≈ 4,19 MJ/kg", encontrado: `${f(e / 1e6, 3)} MJ/kg`, classe: ok(Math.abs(e / 1e6 - 4.19) < 0.01, true), evidencia: "PCI ILUSTRATIVO → aprovado com restrições" });
    const pv = thermo.pressure(1, 273.15, 0.022413969545014137);
    C.push({ id: "V06", motor: "NM-E4-THERMO", descricao: "Equação dos gases (CNTP)", formula: "P = nRT/V, 1 mol, 273,15 K, 22,414 L", esperado: "101 325 Pa", encontrado: `${f(pv, 1)} Pa`, classe: ok(Math.abs(pv - P_ATM) < 1), evidencia: "volume molar CODATA" });
    const g = sim.geo, vdInd = (Math.PI / 4) * (g.boreMm! / 10) ** 2 * (g.strokeMm! / 10);
    C.push({ id: "V07", motor: "NM-E6-MECH", descricao: "Cilindrada (rota em cm³)", formula: "Vd = π/4·D²·S", esperado: `${f(vdInd, 2)} cm³`, encontrado: `${f(sim.vd * 1e6, 2)} cm³`, classe: ok(Math.abs(sim.vd * 1e6 - vdInd) < 1e-6), evidencia: g.origem });
    C.push({ id: "V08", motor: "NM-E4-THERMO", descricao: "Conservação de energia no ciclo", formula: "Q − Q_w − W − ΔU = 0", esperado: "erro < 0,1 % de Q", encontrado: `${f(sim.closureErr * 100, 5)} %`, classe: ok(sim.closureErr < 1e-3), evidencia: `Q=${f(sim.qIn)} J W=${f(sim.w)} J ΔU=${f(sim.dU)} J` });
    const pInd = performance.power(sim.torque, sim.input.rpm), pRoute = (sim.w * sim.input.rpm) / 120;
    C.push({ id: "V09", motor: "NM-E7-PERF", descricao: "Potência por duas rotas", formula: "T·ω = W·RPM/120", esperado: "iguais", encontrado: `${f(pInd)} vs ${f(pRoute)} W`, classe: ok(Math.abs(pInd - pRoute) < 1e-6), evidencia: "4 tempos" });
    C.push({ id: "V10", motor: "NM-E7-PERF", descricao: "Eficiência física", formula: "0 < η < η_Otto", esperado: `< ${f(sim.etaOtto, 3)}`, encontrado: f(sim.eta, 3), classe: ok(sim.eta > 0 && sim.eta < sim.etaOtto + 0.02, true), evidencia: "γ variável: η pode diferir de η_Otto(γ ar frio); modelo simplificado" });
    let threw = 0; for (const fn of [() => energy.q(1, null as unknown as number), () => energy.q(-1, 1), () => performance.power(1, 0)]) { try { fn(); } catch { threw++; } }
    C.push({ id: "V11", motor: "NM-E8-VALID", descricao: "Dados ausentes e inválidos bloqueiam", formula: "assertPos", esperado: "3 recusas", encontrado: `${threw} recusas`, classe: ok(threw === 3), evidencia: "null, negativo, rpm 0" });
    const again = simulate(sim.input);
    C.push({ id: "V12", motor: "NM-E8-VALID", descricao: "Reprodutibilidade", formula: "sim(x) = sim(x)", esperado: "hash idêntico", encontrado: hashOf(again.w) === hashOf(sim.w) ? "idêntico" : "divergente", classe: ok(again.w === sim.w), evidencia: hashOf(sim.w) });
    return C;
  },
};

/* ---------------- 24 camadas RealGear (aplicabilidade) ---------------- */
const CAMADAS = ["Identificação", "Origem dos dados", "Unidades SI", "Geometria", "Materiais", "Química", "Estequiometria", "Energia", "Termodinâmica", "Combustão", "Fluxo de admissão", "Escape", "Biela/forças", "Fadiga", "Térmica de componentes", "Lubrificação", "Transmissão", "Tração", "Desempenho", "Consumo", "Reprodutibilidade", "Regressão", "Documentação", "Nexus"];
export function camadas(checks: Check[]): { n: number; nome: string; classe: Classe; motivo: string }[] {
  const by = (ids: string[]): Classe => { const cs = checks.filter((c) => ids.includes(c.id)); if (cs.some((c) => c.classe === "REPROVADO")) return "REPROVADO"; if (cs.some((c) => c.classe === "APROVADO COM RESTRIÇÕES")) return "APROVADO COM RESTRIÇÕES"; return "APROVADO"; };
  const map: Record<number, [Classe, string]> = {
    1: ["APROVADO", `${MODULE_ID} v${MODULE_VERSION}`], 2: ["APROVADO COM RESTRIÇÕES", "PCI ilustrativo; γ e Wiebe estimados/hipótese"], 3: ["APROVADO", "todas as grandezas em SI"],
    4: [by(["V07"]), "V07"], 6: [by(["V01", "V02", "V03"]), "V01–V03"], 7: [by(["V04"]), "V04"], 8: [by(["V05"]), "V05"], 9: [by(["V06", "V08"]), "V06, V08"],
    10: ["APROVADO COM RESTRIÇÕES", "Wiebe com parâmetros HIPÓTESE"], 19: [by(["V09", "V10"]), "V09, V10"], 21: [by(["V12"]), "V12"], 22: ["APROVADO", "módulo read-only: corrida não alterada"], 23: ["APROVADO", "fórmulas com dimensão e validade"],
    24: ["NÃO APLICÁVEL", "ENG IA não declara aprovação do Nexus; aguardando auditoria independente"],
  };
  return CAMADAS.map((nome, i) => { const m = map[i + 1]; return { n: i + 1, nome, classe: m ? m[0] : "NÃO APLICÁVEL", motivo: m ? m[1] : "não aplicável a um estudo químico/termodinâmico de combustível" }; });
}

/* ---------------- Caso de referência RG-NM-001 ---------------- */
export function referenceCase() {
  const m = 1, afr = stoich.afr(), mAr = m * afr, Q = energy.q(m, LHV_NM_ILUSTRATIVO);
  return { id: "RG-NM-001", origem: "ILUSTRATIVO" as Origem, combustivel: "nitrometano puro, modelo ideal", m, afr, mAr, mTotal: m + mAr, pci: LHV_NM_ILUSTRATIVO, Q, eMix: energy.eMix(LHV_NM_ILUSTRATIVO, afr) };
}

export const MOTORES: MotorInfo[] = [chemical.info, stoich.info, energy.info, thermo.info, combustion.info, mechanical.info, performance.info, validation.info];

/* ---------------- Execução, relatório, armazenamento ---------------- */
export function hashOf(x: unknown): string { const s = JSON.stringify(x); let h = 0x811c9dc5; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h.toString(16).padStart(8, "0"); }

export type Execucao = { runId: string; at: string; versao: string; input: SimInput; ref: ReturnType<typeof referenceCase>; sim: Omit<SimResult, "pontos">; checks: Check[]; camadas: ReturnType<typeof camadas>; classe: Classe; nexus: NexusStatus };
export function executar(input: SimInput = SIM_DEFAULT, at = new Date().toISOString()): Execucao {
  const sim = simulate(input), checks = validation.run(sim), cam = camadas(checks);
  const classe: Classe = checks.some((c) => c.classe === "REPROVADO") ? "REPROVADO" : checks.some((c) => c.classe === "APROVADO COM RESTRIÇÕES") ? "APROVADO COM RESTRIÇÕES" : "APROVADO";
  const { pontos: _p, ...rest } = sim;
  return { runId: `RG-NM-${hashOf({ input, v: MODULE_VERSION })}-${at.replace(/\D/g, "").slice(0, 14)}`, at, versao: MODULE_VERSION, input, ref: referenceCase(), sim: rest, checks, camadas: cam, classe, nexus: "AGUARDANDO NEXUS" };
}

export function relatorio(x: Execucao): string {
  const s = x.sim, r = x.ref;
  return [
    "REALGEAR ENGINEERING REPORT", `Módulo: Nitromethane Engineering Lab · ID: ${MODULE_ID} · versão ${x.versao}`, `Execução: ${x.runId} · ${x.at}`, "",
    "1. IDENTIFICAÇÃO", "Nitrometano CH₃NO₂, estudo teórico/simulado. Não é instrução operacional.", "",
    "2. ORIGEM DOS DADOS", ...Object.values(VARIAVEIS).map((q) => `- ${q.simbolo} (${q.unidade}): ${q.valor ?? "DESCONHECIDO"} · ${q.origem} · ${q.fonte}`), `- Geometria: ${s.geo.origem} D=${s.geo.boreMm} mm S=${s.geo.strokeMm} mm L=${s.geo.rodMm} mm CR=${s.geo.cr}`, "",
    "3. COMPOSIÇÃO MOLECULAR", `M = 1·12,011 + 3·1,008 + 1·14,007 + 2·15,999 = ${f(chemical.molar(NM))} g/mol`, "",
    "4. BALANÇO ESTEQUIOMÉTRICO", "4CH₃NO₂ + 3O₂ → 4CO₂ + 6H₂O + 2N₂", `Átomos: ${JSON.stringify(chemical.balance().reag)} = ${JSON.stringify(chemical.balance().prod)}`, "",
    "5. RELAÇÃO AR/COMBUSTÍVEL", `m_O2/m_comb = 3·31,998/(4·${f(chemical.molar(NM))}) = ${f(stoich.o2PerKg())}`, `AFR = ${f(stoich.o2PerKg())}/0,2314 = ${f(r.afr)} kg/kg`, "",
    "6. PROPRIEDADES ENERGÉTICAS (RG-NM-001, ILUSTRATIVO)", `m=1 kg · m_ar=${f(r.mAr)} kg · m_total=${f(r.mTotal)} kg`, `Q = 1 × 11,3 MJ/kg = ${f(r.Q / 1e6)} MJ`, `E = 11,3/(1+${f(r.afr)}) = ${f(r.eMix / 1e6, 3)} MJ/kg mistura`, "",
    "7. MODELO TERMODINÂMICO", "PV = nRT · ΔU = Q − W · γ(T) = 1,38 − 8·10⁻⁵(T−300) (ESTIMADO)", `Massa de ar ${f(s.mAir * 1e6, 2)} mg · combustível ${f(s.mFuel * 1e6, 2)} mg · Q_in ${f(s.qIn, 2)} J`, `P_max ${f(s.pMax / 1e6, 2)} MPa · T_max ${f(s.tMax, 0)} K`, "",
    "8. MODELO DE COMBUSTÃO", `Wiebe θ0=${x.input.th0Deg}° Δθ=${x.input.dthDeg}° · razão molar produtos/reagentes ${f(combustion.molarRatio())}`, "",
    "9. MODELO MECÂNICO", `Vd = π·D²·S/4 = ${f(s.vd * 1e6, 2)} cm³ · W = ∮P dV = ${f(s.w, 2)} J · IMEP ${f(s.imep / 1e5, 2)} bar`, "",
    "10. RESULTADOS DE DESEMPENHO (SIMULADO, INDICADO)", `${x.input.rpm} rpm · T = W/4π = ${f(s.torque, 2)} N·m · P = T·2π·RPM/60 = ${f(s.power / 1000, 2)} kW (${f(s.power / 735.49875, 2)} cv) · η = ${f(s.eta * 100, 1)} %`, "",
    "11/12. VALIDAÇÃO MATEMÁTICA E FÍSICA", ...x.checks.map((c) => `[${c.classe}] ${c.id} ${c.descricao} · ${c.formula} · esperado ${c.esperado} · encontrado ${c.encontrado} · evidência ${c.evidencia}`), "",
    "13. LIMITAÇÕES", ...s.hipoteses.map((h) => `- ${h}`), "",
    "14. ERROS ENCONTRADOS", ...(x.checks.filter((c) => c.classe === "REPROVADO").map((c) => `- ${c.id}: esperado ${c.esperado}, encontrado ${c.encontrado}`).concat(x.checks.some((c) => c.classe === "REPROVADO") ? [] : ["- nenhum"])), "",
    "15. EVIDÊNCIAS / 24 CAMADAS", ...x.camadas.map((c) => `${String(c.n).padStart(2, "0")} ${c.nome}: ${c.classe} — ${c.motivo}`), "",
    "16. RESULTADO FINAL", `Classificação ENG IA: ${x.classe}`, `Status: ${x.nexus}. A ENG IA não declara aprovação do Nexus.`,
  ].join("\n");
}

const KEY = "rg-nm-lab-history-v1";
export function salvar(x: Execucao) { if (typeof cloudStore === "undefined") return; const h = historico(); h.unshift(x); cloudStore.setItem(KEY, JSON.stringify(h.slice(0, 50))); }
export function historico(): Execucao[] { if (typeof cloudStore === "undefined") return []; try { return JSON.parse(cloudStore.getItem(KEY) || "[]") as Execucao[]; } catch { return []; } }

export const VERSOES = [{ versao: "1.0.0", data: "2026-11-10", itens: ["8 motores de cálculo", "dicionário de variáveis", "simulação 0-D de ciclo fechado", "caso RG-NM-001", "12 verificações independentes", "relatório técnico", "mapa de 24 camadas"] }];
