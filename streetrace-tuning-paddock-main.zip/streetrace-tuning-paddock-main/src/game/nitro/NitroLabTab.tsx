import { useMemo, useState } from "react";
import { MODULE_ID, MODULE_VERSION, MOTORES, VARIAVEIS, VERSOES, SIM_DEFAULT, chemical, combustion, executar, historico, relatorio, salvar, simulate, stoich, NM, type Classe, type SimInput } from "./lab";

const MENU = ["Visão geral", "Composição química", "Estequiometria", "Energia", "Termodinâmica", "Combustão", "Mecânica", "Desempenho", "Simulações", "Fórmulas", "Testes", "Relatórios", "Histórico de versões"] as const;
const n = (x: number, d = 3) => x.toLocaleString("pt-BR", { maximumFractionDigits: d });
const badge = (c: Classe | string) => c === "APROVADO" ? "bg-primary/20 text-primary" : c === "REPROVADO" ? "bg-destructive/20 text-destructive" : "bg-secondary text-foreground";

function Row({ k, v, o }: { k: string; v: string; o?: string }) {
  return <div className="flex justify-between gap-3 border-b border-border/40 py-1 text-xs"><span className="text-muted-foreground">{k}</span><span className="text-right font-mono">{v}{o && <span className="ml-2 rounded bg-secondary px-1 text-[9px] uppercase">{o}</span>}</span></div>;
}
function F({ e, d }: { e: string; d?: string }) { return <div className="my-1 rounded bg-secondary/50 px-2 py-1 font-mono text-xs">{e}{d && <span className="ml-2 text-muted-foreground">· {d}</span>}</div>; }

export function NitroLabTab() {
  const [m, setM] = useState<(typeof MENU)[number]>("Visão geral");
  const [inp, setInp] = useState<SimInput>(SIM_DEFAULT);
  const [hist, setHist] = useState(() => historico());
  const run = useMemo(() => { try { return { x: executar(inp), sim: simulate(inp), err: null as string | null }; } catch (e) { return { x: null, sim: null, err: (e as Error).message }; } }, [inp]);
  const x = run.x, s = run.sim;
  const down = (txt: string, name: string) => { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([txt], { type: "text/plain" })); a.download = name; a.click(); };
  const num = (k: keyof SimInput, label: string, step = 1) => (
    <label className="text-xs">{label}<input type="number" step={step} value={inp[k] as number} onChange={(e) => setInp({ ...inp, [k]: Number(e.target.value) })} className="mt-1 w-full rounded border border-border bg-background px-2 py-1 font-mono" /></label>
  );
  const maxP = s ? Math.max(...s.pontos.map((p) => p.P)) : 1;

  return (
    <div className="flex flex-col gap-4 md:flex-row">
      <nav className="flex shrink-0 flex-wrap gap-1 md:w-48 md:flex-col">
        {MENU.map((t) => <button key={t} onClick={() => setM(t)} className={`rounded px-2 py-1 text-left text-xs ${m === t ? "bg-primary text-primary-foreground" : "bg-secondary/50"}`}>{t}</button>)}
      </nav>
      <section className="min-w-0 flex-1 rounded-lg border border-border p-4">
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <h2 className="text-sm font-bold">Nitromethane Engineering Lab · {MODULE_ID} v{MODULE_VERSION}</h2>
          {x && <span className={`rounded px-2 py-0.5 text-[10px] font-bold ${badge(x.classe)}`}>ENG IA: {x.classe}</span>}
          <span className="rounded bg-secondary px-2 py-0.5 text-[10px] font-bold">EM DESENVOLVIMENTO — NÃO APROVADO PELO NEXUS</span>
        </div>
        {run.err && <div className="mb-3 rounded bg-destructive/15 p-2 text-xs text-destructive">{run.err}</div>}

        {m === "Visão geral" && x && <div>
          <p className="mb-2 text-xs text-muted-foreground">Estudo teórico e simulado do nitrometano (CH₃NO₂). Resultados são de modelo, não medições; não altera a corrida.</p>
          <Row k="Massa molar" v={`${n(chemical.molar(NM))} g/mol`} o="calculado" />
          <Row k="AFR estequiométrica" v={`${n(x.ref.afr)} kg/kg`} o="calculado" />
          <Row k="Energia da mistura" v={`${n(x.ref.eMix / 1e6)} MJ/kg`} o="ilustrativo" />
          <Row k="Potência indicada simulada" v={`${n(x.sim.power / 735.49875, 1)} cv @ ${inp.rpm} rpm`} o="simulado" />
          <Row k="Verificações" v={`${x.checks.filter((c) => c.classe !== "REPROVADO").length}/${x.checks.length} sem reprovação`} />
        </div>}

        {m === "Composição química" && <div>
          <F e="M = Σ(nᵢ × Mᵢ)" d="[g/mol]" />
          <Row k="C × 1" v="12,011" o="IUPAC" /><Row k="H × 3" v="3 × 1,008" o="IUPAC" /><Row k="N × 1" v="14,007" o="IUPAC" /><Row k="O × 2" v="2 × 15,999" o="IUPAC" />
          <Row k="M (CH₃NO₂)" v={`${n(chemical.molar(NM), 4)} g/mol`} o="calculado" />
          <F e="4CH₃NO₂ + 3O₂ → 4CO₂ + 6H₂O + 2N₂" />
          <Row k="Átomos reagentes" v={JSON.stringify(chemical.balance().reag)} /><Row k="Átomos produtos" v={JSON.stringify(chemical.balance().prod)} />
          <Row k="Massa reagentes / produtos" v={`${n(chemical.massBalance().reag)} / ${n(chemical.massBalance().prod)} g`} />
        </div>}

        {m === "Estequiometria" && <div>
          <F e="AFR = m_ar / m_comb = (3·M_O2)/(4·M) / Y_O2" d="ar seco, λ = 1" />
          <Row k="m_O₂ / m_comb" v={n(stoich.o2PerKg(), 4)} o="calculado" /><Row k="Y_O₂ (ar seco)" v="0,2314" o="oficial" /><Row k="AFR" v={n(stoich.afr(), 4)} o="calculado" />
        </div>}

        {m === "Energia" && x && <div>
          <F e="Q = m × PCI" d="[J]" /><F e="E = PCI / (1 + AFR)" d="[J/kg mistura]" />
          <p className="mb-1 text-xs font-bold">Caso RG-NM-001 (referência ilustrativa)</p>
          <Row k="Massa de combustível" v="1 kg" /><Row k="Massa de ar" v={`${n(x.ref.mAr)} kg`} /><Row k="Massa total" v={`${n(x.ref.mTotal)} kg`} />
          <Row k="PCI" v="11,3 MJ/kg" o="ilustrativo" /><Row k="Energia química" v={`${n(x.ref.Q / 1e6)} MJ`} /><Row k="Energia específica da mistura" v={`${n(x.ref.eMix / 1e6)} MJ/kg`} />
        </div>}

        {m === "Termodinâmica" && x && <div>
          <F e="PV = nRT" /><F e="ΔU = Q − W − Q_parede" /><F e="γ(T) = 1,38 − 8·10⁻⁵(T − 300)" d="estimado" />
          <Row k="Calor liberado" v={`${n(x.sim.qIn, 2)} J`} /><Row k="Trabalho" v={`${n(x.sim.w, 2)} J`} /><Row k="Calor à parede" v={`${n(x.sim.qWall, 2)} J`} /><Row k="ΔU" v={`${n(x.sim.dU, 2)} J`} />
          <Row k="Fechamento da 1ª lei" v={`${n(x.sim.closureErr * 100, 6)} %`} /><Row k="Pressão máxima" v={`${n(x.sim.pMax / 1e6, 2)} MPa`} /><Row k="Temperatura máxima" v={`${n(x.sim.tMax, 0)} K`} />
        </div>}

        {m === "Combustão" && <div>
          <F e="x_b = 1 − exp(−a·((θ−θ0)/Δθ)^(m+1))" d="a, m: hipótese" />
          <Row k="Razão molar produtos/reagentes" v={n(combustion.molarRatio(), 4)} o="calculado" />
          <Row k="Início / duração" v={`${inp.th0Deg}° / ${inp.dthDeg}°`} o="hipótese" />
        </div>}

        {m === "Mecânica" && x && <div>
          <F e="Vd = π × D² × S / 4" /><F e="W = ∮ P dV" />
          <Row k="Diâmetro / curso / biela" v={`${x.sim.geo.boreMm} / ${x.sim.geo.strokeMm} / ${x.sim.geo.rodMm} mm`} o="catálogo" />
          <Row k="Taxa de compressão" v={`${x.sim.geo.cr}:1`} o="catálogo" /><Row k="Cilindrada" v={`${n(x.sim.vd * 1e6, 2)} cm³`} o="calculado" />
          <Row k="IMEP" v={`${n(x.sim.imep / 1e5, 2)} bar`} />
        </div>}

        {m === "Desempenho" && x && <div>
          <F e="T = W / 4π" d="4 tempos" /><F e="P = T × 2π × RPM / 60" /><F e="η = W / Q" />
          <Row k="Torque indicado" v={`${n(x.sim.torque, 2)} N·m`} o="simulado" /><Row k="Potência indicada" v={`${n(x.sim.power / 1000, 2)} kW · ${n(x.sim.power / 735.49875, 1)} cv`} o="simulado" />
          <Row k="Eficiência" v={`${n(x.sim.eta * 100, 1)} % (Otto ${n(x.sim.etaOtto * 100, 1)} %)`} />
          <p className="mt-2 text-[11px] text-muted-foreground">Indicado = sem atrito, bombeamento nem perdas reais. Não é potência no eixo.</p>
        </div>}

        {m === "Simulações" && <div>
          <div className="mb-3 grid grid-cols-2 gap-2 md:grid-cols-4">
            {num("rpm", "RPM", 100)}{num("ve", "η_v (hipótese)", 0.05)}{num("hW", "h parede W/m²K", 50)}{num("th0Deg", "Início combustão °", 1)}{num("dthDeg", "Duração °", 1)}{num("Tin", "T admissão K", 1)}{num("stepDeg", "Passo °", 0.25)}{num("wallT", "T parede K", 10)}
          </div>
          {s && <svg viewBox="0 0 360 120" className="h-40 w-full rounded bg-secondary/30">
            <polyline fill="none" stroke="hsl(var(--primary))" strokeWidth="1.5" points={s.pontos.map((p) => `${((p.deg + 180) / 360) * 360},${118 - (p.P / maxP) * 112}`).join(" ")} />
          </svg>}
          <p className="mt-1 text-[11px] text-muted-foreground">Pressão × ângulo do virabrequim (−180° a +180°).</p>
          <div className="mt-2 flex gap-2">
            <button disabled={!x} onClick={() => { if (x) { salvar(x); setHist(historico()); } }} className="rounded bg-primary px-3 py-1 text-xs text-primary-foreground disabled:opacity-40">Salvar execução</button>
            <button onClick={() => setInp(SIM_DEFAULT)} className="rounded bg-secondary px-3 py-1 text-xs">Padrão</button>
          </div>
        </div>}

        {m === "Fórmulas" && <div className="space-y-3">
          {MOTORES.map((mo) => <div key={mo.id}><p className="text-xs font-bold">{mo.nome} <span className="font-mono text-muted-foreground">{mo.id} v{mo.versao}</span></p>
            <p className="text-[11px] text-muted-foreground">Depende de: {mo.dependencias.join(", ") || "—"} · Entradas: {mo.entradas.join(", ")} · Saídas: {mo.saidas.join(", ")}</p>
            {mo.formulas.map((fo) => <F key={fo.id} e={fo.expr} d={`${fo.dimensao} · ${fo.validade}`} />)}</div>)}
          <p className="text-xs font-bold">Dicionário de variáveis</p>
          {Object.entries(VARIAVEIS).map(([k, q]) => <Row key={k} k={`${q.simbolo} · ${q.nome}`} v={`${q.valor ?? "DESCONHECIDO"} ${q.unidade}`} o={q.origem} />)}
        </div>}

        {m === "Testes" && x && <div className="space-y-1">
          {x.checks.map((c) => <div key={c.id} className="rounded border border-border/50 p-2 text-xs">
            <span className={`mr-2 rounded px-1 text-[10px] font-bold ${badge(c.classe)}`}>{c.classe}</span><b>{c.id}</b> {c.descricao}
            <div className="font-mono text-[11px] text-muted-foreground">{c.formula} · esperado {c.esperado} · encontrado {c.encontrado}</div></div>)}
          <p className="mt-3 text-xs font-bold">24 camadas RealGear</p>
          {x.camadas.map((c) => <Row key={c.n} k={`${c.n}. ${c.nome}`} v={c.motivo} o={c.classe} />)}
        </div>}

        {m === "Relatórios" && x && <div>
          <button onClick={() => down(relatorio(x), `${x.runId}.txt`)} className="mb-2 rounded bg-primary px-3 py-1 text-xs text-primary-foreground">Baixar relatório</button>
          <pre className="max-h-[480px] overflow-auto whitespace-pre-wrap rounded bg-secondary/40 p-2 text-[11px]">{relatorio(x)}</pre>
          {hist.length > 0 && <><p className="mt-3 text-xs font-bold">Execuções salvas</p>{hist.map((h) => <Row key={h.runId + h.at} k={h.runId} v={`${h.classe} · ${h.nexus}`} />)}</>}
        </div>}

        {m === "Histórico de versões" && VERSOES.map((ve) => <div key={ve.versao} className="text-xs"><b>v{ve.versao}</b> · {ve.data}<ul className="ml-4 list-disc">{ve.itens.map((i) => <li key={i}>{i}</li>)}</ul></div>)}
      </section>
    </div>
  );
}
