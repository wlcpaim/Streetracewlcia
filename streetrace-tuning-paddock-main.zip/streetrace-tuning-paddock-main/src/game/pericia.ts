// Perícia de quebra: after a break, 1000 deterministic tests isolate the culprit and audit the whole engine.
import { physicalBreak } from "./mechlimits";
import { STOCK_SETUP, engine, exhaustShape, fuelFlow, mixtureAt, powerShape, stats, stress, tireOf, type BikeModel, type Setup } from "./physics";
import { CAM_LABEL, SLOTS, partById } from "./parts";
import { SERVICES } from "./physics";
import { displacement } from "./records";
import { causaRaiz, fuelChain, type FluxoEvento } from "./rootcause";

export const PERICIA_TESTS = 1000;
const r3 = (n: number) => Math.round(n * 1000) / 1000;
/** Drops undefined optionals so the object fits Setup under exactOptionalPropertyTypes. */
const opt = (o: Record<string, unknown>): Setup => Object.fromEntries(Object.entries(o).filter(([, v]) => v !== undefined)) as unknown as Setup;
type Factor = { id: string; nome: string; revert: (s: Setup) => Setup; solo: (s: Setup) => Setup };

/** Every choice where the setup differs from the factory bike. */
function factors(s: Setup): Factor[] {
  const f: Factor[] = [];
  const S = STOCK_SETUP;
  for (const slot of SLOTS) if (s.slots[slot] !== S.slots[slot]) {
    const p = partById(s.slots[slot]);
    f.push({ id: `peca:${slot}`, nome: `${slot}: ${p ? `${p.brand} ${p.name}` : s.slots[slot]}`, revert: (x) => ({ ...x, slots: { ...x.slots, [slot]: S.slots[slot] } }), solo: () => ({ ...S, slots: { ...S.slots, [slot]: s.slots[slot] } }) });
  }
  if (s.cam !== S.cam) f.push({ id: "cam", nome: `Comando ${CAM_LABEL[s.cam]}`, revert: (x) => ({ ...x, cam: S.cam }), solo: () => ({ ...S, cam: s.cam }) });
  if (s.compression !== S.compression) f.push({ id: "taxa", nome: `Taxa ${s.compression}:1`, revert: (x) => ({ ...x, compression: S.compression }), solo: () => ({ ...S, compression: s.compression }) });
  for (const id of s.services) if (!S.services.includes(id)) {
    const sv = SERVICES.find((v) => v.id === id);
    f.push({ id: `serv:${id}`, nome: `Oficina: ${sv?.name ?? id}`, revert: (x) => ({ ...x, services: x.services.filter((v) => v !== id) }), solo: () => ({ ...S, services: [id] }) });
  }
  if (s.fuel !== S.fuel || JSON.stringify(s.blend ?? null) !== JSON.stringify(S.blend ?? null)) f.push({ id: "combustivel", nome: `Combustível ${s.fuel}${s.blend ? " (mistura)" : ""}`, revert: (x) => opt({ ...x, fuel: S.fuel, blend: S.blend }), solo: () => opt({ ...S, fuel: s.fuel, blend: s.blend }) });
  if (JSON.stringify(s.ecu) !== JSON.stringify(S.ecu)) f.push({ id: "ecu", nome: "Mapa do módulo", revert: (x) => ({ ...x, ecu: S.ecu }), solo: () => ({ ...S, ecu: s.ecu, slots: { ...S.slots, modulo: s.slots.modulo } }) });
  if (s.airFilter !== S.airFilter) f.push({ id: "filtro", nome: `Filtro de ar: ${s.airFilter}`, revert: (x) => ({ ...x, airFilter: S.airFilter }), solo: () => ({ ...S, airFilter: s.airFilter }) });
  if (s.km !== S.km || s.oilKm !== S.oilKm) f.push({ id: "uso", nome: `Uso: ${s.km} km, óleo com ${s.oilKm} km`, revert: (x) => opt({ ...x, km: S.km, oilKm: S.oilKm, engineKm0: S.engineKm0 }), solo: () => opt({ ...S, km: s.km, oilKm: s.oilKm, engineKm0: s.engineKm0 }) });
  return f;
}

/** Física é determinística: uma corrida responde se quebra, onde e por quê (n mantém o formato do relatório). */
function sample(b: BikeModel, s: Setup, distance: number, n: number, _tag: string) {
  const st = stress(b, s);
  const br = n > 0 ? physicalBreak(b, s, distance) : null;
  const at = br ? r3(br.at) : null;
  return { testes: n > 0 ? 1 : 0, quebras: br ? 1 : 0, taxaPct: br ? 100 : 0, riscoModeloPct: r3(st.risk * 100), causa: br?.cause ?? null, fisica: br?.fisica ?? null, distanciaMediaM: at, distanciaMinM: at, distanciaMaxM: at };
}

/** Full forensic report of a break: 1000 tests + engine audit. */
export function pericia(b: BikeModel, s: Setup, distance: number, ctx: { label: string; cause: string; atM: number; rpm: number; gear: number; fuelUsedL: number; tail: unknown[]; fluxo?: FluxoEvento[]; calorPistao?: number }) {
  const raiz = causaRaiz(b, s, ctx.cause, ctx.rpm);
  const fs = factors(s);
  const per = fs.length ? Math.max(10, Math.floor((PERICIA_TESTS * 0.6) / (fs.length * 2))) : 0;
  const repeat = PERICIA_TESTS - per * fs.length * 2;
  const base = sample(b, s, distance, Math.max(0, repeat), "base");
  const iso = fs.map((f) => {
    const sem = sample(b, f.revert(s), distance, per, `sem:${f.id}`);
    const so = sample(b, f.solo(s), distance, per, `so:${f.id}`);
    return { fator: f.nome, semEssaEscolha: sem, soEssaEscolhaNaMotoOriginal: so, quedaDeRiscoPts: r3(base.riscoModeloPct - sem.riscoModeloPct), causaMudaSemEla: sem.causa !== base.causa, semElaNaoQuebra: base.quebras > 0 && sem.quebras === 0, sozinhaQuebra: so.quebras > 0 };
  }).sort((a, b) => Number(b.semElaNaoQuebra) - Number(a.semElaNaoQuebra) || Number(b.sozinhaQuebra) - Number(a.sozinhaQuebra) || b.quedaDeRiscoPts - a.quedaDeRiscoPts);
  const culpado = iso[0];
  const totalTests = base.testes + iso.reduce((n, x) => n + x.semEssaEscolha.testes + x.soEssaEscolhaNaMotoOriginal.testes, 0);
  const e = engine(b, s), st = stress(b, s);
  const conclusao = culpado
    ? `Quebra "${ctx.cause}" se repete em ${base.taxaPct}% das puxadas iguais. A escolha que mais pesa é "${culpado.fator}": sem ela o risco cai de ${base.riscoModeloPct}% para ${culpado.semEssaEscolha.riscoModeloPct}%${culpado.causaMudaSemEla ? ` e o defeito muda para "${culpado.semEssaEscolha.causa ?? "nenhum"}"` : ""}. Sozinha na moto original ela dá ${culpado.soEssaEscolhaNaMotoOriginal.riscoModeloPct}% de risco${culpado.soEssaEscolhaNaMotoOriginal.riscoModeloPct < 5 ? ", então o problema é a soma do conjunto, não ela isolada" : ""}.`
    : `Moto sem modificações quebrou: só o desgaste explica (${base.taxaPct}% das puxadas).`;
  const rpms: number[] = []; for (let r = 3000; r <= e.rpmLimit; r += 500) rpms.push(r);
  const watts = e.hp * 745.7;
  return {
    titulo: `Laudo pericial · ${b.name} · ${ctx.label} · ${ctx.cause} aos ${Math.round(ctx.atM)} m · causa raiz: ${raiz.causaRaiz.split(" → ")[0]} (${totalTests} testes)`,
    causaRaiz: raiz.causaRaiz,
    correcao: raiz.correcao,
    investigacao: raiz.cadeia,
    conclusao,
    logDoFluxo: ctx.fluxo ?? [],
    momentoDaQuebra: { distanciaM: ctx.atM, rpm: ctx.rpm, marcha: ctx.gear, calorAcumuladoPistao: ctx.calorPistao ?? null, alimentacaoNoGiro: fuelChain(b, s, ctx.rpm), ultimosRegistrosDoMotor: ctx.tail },
    testes: { total: totalTests, repeticaoMesmaMoto: base, isolamentoPorEscolha: iso },
    estresse: { riscoPct: r3(st.risk * 100), causaPrincipal: st.cause, cargas: st.causes },
    motor: { cilindradaCc: displacement(s, b.id), ...e, ficha: stats(b, s, b.tank), taxa: s.compression, comando: CAM_LABEL[s.cam], km: s.km, oleoKm: s.oilKm },
    pecasEquipadas: SLOTS.map((slot) => { const p = partById(s.slots[slot]); return { slot, id: s.slots[slot], original: s.slots[slot] === STOCK_SETUP.slots[slot], peca: p ?? null }; }),
    oficina: s.services.map((id) => SERVICES.find((v) => v.id === id) ?? { id }),
    admissao: { filtroDeAr: s.airFilter, tbi: partById(s.slots.tbi) ?? s.slots.tbi, bico: partById(s.slots.bico) ?? s.slots.bico, bomba: partById(s.slots.bomba) ?? s.slots.bomba, modulo: partById(s.slots.modulo) ?? s.slots.modulo, mapa: s.ecu },
    vazaoEMisturaPorGiro: rpms.map((rpm) => { const m = mixtureAt(s, rpm, e.rpmPeak); return { rpm, combustivelPedido: r3(m.need), combustivelEntregue: r3(m.supply), situacao: m.lean > 0.02 ? "pobre" : m.lean < -0.02 ? "rica" : "certa", forcaRelativa: r3(powerShape(rpm, e.rpmPeak, b, s) * exhaustShape(b, s, rpm, e.rpmPeak)) }; }),
    consumo: { combustivel: s.fuel, mistura: s.blend ?? null, litrosPorHoraNoPico: r3(fuelFlow(s.fuel, watts) * 3600 * e.fuelMul), gastoNaCorridaL: ctx.fuelUsedL },
    escape: { id: s.slots.escape, peca: partById(s.slots.escape) ?? null },
    transmissao: { pinhao: s.front, coroa: s.rear, relacao: r3(s.rear / s.front) },
    pneu: { psi: s.psi, desgaste: s.tireWear ?? 0, ...tireOf(s) },
  };
}
export type Pericia = ReturnType<typeof pericia>;
