// BUG FIX — Wikipedia resolve falhas do RealGear (Fix Center/sandbox), NEXUS confere a mudança e aprova, e o projeto volta ao funil.
// Nada aqui altera Setup, corrida ou código principal: só overrides de sandbox reexecutados no runFunnel.
import { cloudStore } from "@/game/cloud/cloud-store";
import { runFunnel, type Estado } from "../realgear/funnel";
import { shaOf } from "../realgear/sha256";
import { PATCHABLE, type FixState } from "../realgear/fix/contracts";
import { processFailure, projectOf } from "../realgear/fix/pipeline";
import { triageOf, type Triagem } from "../realgear/fix/triage";

export const BUGFIX_KEY = "streetrace-bugfix-v1";
export type NexusCheck = { nome: string; pass: boolean; detalhe: string };
export type BugItem = {
  failureId: string; bike: string; camada: string; motivo: string; at: string;
  etapa: "RECEBIDA" | "SEM CORREÇÃO" | "AGUARDA MEDIÇÃO" | "DEVOLVIDA AO STREETRACE" | "RESOLVIDA" | "REPROVADA NEXUS" | "APROVADA NEXUS" | "APROVADA NO FUNIL" | "REPROVADA NO FUNIL";
  triagem?: Triagem; patchId?: string; execId?: string; resolvidaAt?: string; nota?: string;
  nexus?: { at: string; aprovado: boolean; checks: NexusCheck[] };
  funil?: { at: string; runId: string; estado: Estado; atual: number; hash: string };
};
export type BugState = { items: BugItem[] };

export const readBug = (): BugState => { try { const s = JSON.parse(cloudStore.getItem(BUGFIX_KEY) ?? "null"); return Array.isArray(s?.items) ? s : { items: [] }; } catch { return { items: [] }; } };
export const saveBug = (s: BugState) => { try { cloudStore.setItem(BUGFIX_KEY, JSON.stringify(s)); } catch { /* cheio */ } return s; };

/** Recebe todas as falhas do RealGear ainda não listadas. */
export function sync(b: BugState, fx: FixState): BugState {
  const have = new Set(b.items.map((i) => i.failureId));
  const novos = fx.failures.filter((f) => !have.has(f.failureId)).map<BugItem>((f) => ({ failureId: f.failureId, bike: f.bikeName, camada: `${f.camada.n} · ${f.camada.nome}`, motivo: f.mensagem, at: f.at, etapa: "RECEBIDA" }));
  return { items: [...b.items, ...novos] };
}
const put = (b: BugState, it: BugItem): BugState => ({ items: b.items.map((x) => (x.failureId === it.failureId ? it : x)) });

/** Wikipedia resolve: investigação → patch → sandbox. Só vira RESOLVIDA com validação A-APROVADO. */
export function resolve(b: BugState, fx: FixState, failureId: string, at: string): { b: BugState; fx: FixState } {
  const it = b.items.find((i) => i.failureId === failureId); if (!it) return { b, fx };
  const already = fx.validations.some((v) => v.failureId === failureId);
  if (!already) fx = processFailure(fx, failureId, at);
  const v = [...fx.validations].reverse().find((x) => x.failureId === failureId && x.caso === "A-APROVADO");
  if (!v) {
    const t = triageOf(fx, failureId);
    const etapa: BugItem["etapa"] = t?.categoria === "MEDIÇÃO AUSENTE" ? "AGUARDA MEDIÇÃO" : t?.categoria === "LIMITE FÍSICO DA PREPARAÇÃO" ? "DEVOLVIDA AO STREETRACE" : "SEM CORREÇÃO";
    return { b: put(b, { ...it, etapa, ...(t ? { triagem: t } : {}), nota: t ? `${t.categoria}: ${t.exigencia}` : `Sem correção comprovada pela física (${fx.status[failureId] ?? "—"}).` }), fx };
  }
  const { nexus: _n, funil: _f, ...base } = it;
  return { b: put(b, { ...base, etapa: "RESOLVIDA", patchId: v.patchId, execId: v.execId, resolvidaAt: at, nota: v.mensagem }), fx };
}

/** NEXUS confere de forma independente se houve mudança real mantendo a lógica. */
export function nexusChecks(it: BugItem, fx: FixState): NexusCheck[] {
  const p = fx.patches.find((x) => x.patchId === it.patchId), ex = fx.executions.find((x) => x.execId === it.execId);
  if (!p || !ex) return [{ nome: "Evidências presentes", pass: false, detalhe: "patch ou execução do sandbox ausente" }];
  const { patchId: _i, patchHash, ...body } = p;
  const keys = Object.keys(p.sandbox);
  const changed = JSON.stringify(ex.backup) !== JSON.stringify(ex.aplicado);
  return [
    { nome: "Integridade do patch (SHA-256)", pass: shaOf(body) === patchHash, detalhe: patchHash.slice(0, 16) },
    { nome: "Só constantes autorizadas", pass: keys.length > 0 && keys.every((k) => (PATCHABLE as readonly string[]).includes(k)), detalhe: keys.join(", ") || "nenhuma" },
    { nome: "Mudança real aplicada", pass: changed, detalhe: `${JSON.stringify(ex.backup)} → ${JSON.stringify(ex.aplicado)}` },
    { nome: "Teste original agora passa", pass: ex.originalPassou, detalhe: ex.depois.teste },
    { nome: "Sem regressões", pass: ex.regressoes.length === 0, detalhe: `${ex.regressoes.length} regressão(ões)` },
    { nome: "Lógica da corrida intacta", pass: ex.corridaIntacta, detalhe: ex.corridaIntacta ? "engine()/stats() idênticos" : "corrida mudou" },
  ];
}

/** NEXUS aprova só se todas as conferências passam; aprovado → reenvia ao funil completo. */
export function nexusReview(b: BugState, fx: FixState, failureId: string, at: string): BugState {
  const it = b.items.find((i) => i.failureId === failureId);
  if (!it || it.etapa !== "RESOLVIDA") return b;
  const checks = nexusChecks(it, fx), aprovado = checks.every((c) => c.pass);
  const reviewed: BugItem = { ...it, nexus: { at, aprovado, checks }, etapa: aprovado ? "APROVADA NEXUS" : "REPROVADA NEXUS" };
  if (!aprovado) return put(b, reviewed);
  const ev = fx.failures.find((f) => f.failureId === failureId)!, ex = fx.executions.find((x) => x.execId === it.execId)!;
  const x = runFunnel(projectOf(ev), at, ex.aplicado);
  const camadaOk = x.camadas[ev.camada.n - 1]?.conclusao === "APROVADA";
  return put(b, { ...reviewed, funil: { at, runId: x.runId, estado: x.estado, atual: x.atual, hash: x.hash }, etapa: camadaOk ? "APROVADA NO FUNIL" : "REPROVADA NO FUNIL" });
}

export const approved = (b: BugState) => b.items.filter((i) => i.etapa === "APROVADA NO FUNIL");
