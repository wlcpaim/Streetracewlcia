import { useEffect, useState } from "react";
import { readFix, saveFix } from "../realgear/fix/pipeline";
import { triageAll } from "../realgear/fix/triage";
import { approved, nexusReview, readBug, resolve, saveBug, sync, type BugItem } from "./bugfix";

const useBug = () => {
  const [b, setB] = useState(() => ({ items: [] as BugItem[] }));
  const refresh = () => setB(saveBug(sync(readBug(), readFix())));
  useEffect(() => { refresh(); const i = setInterval(refresh, 5000); return () => clearInterval(i); }, []);
  return [b, setB, refresh] as const;
};
const Row = ({ it, children }: { it: BugItem; children?: React.ReactNode }) => (
  <div className="rounded-xl border border-border bg-card p-3 text-sm">
    <div className="flex flex-wrap items-center justify-between gap-2"><b>{it.bike} · camada {it.camada}</b><span className="rounded bg-secondary px-2 py-0.5 text-xs font-bold">{it.etapa}</span></div>
    <p className="text-muted-foreground">{it.motivo}</p>
    {it.nota && <p className="mt-1 text-xs">{it.nota}</p>}
    {it.triagem && <div className="mt-2 rounded border border-border p-2 text-xs"><b>{it.triagem.categoria}</b> · prioridade {it.triagem.prioridade} · bloqueia {it.triagem.bloqueia} camada(s) · {it.triagem.ocorrencias} projeto(s)<p className="font-mono">{it.triagem.lei}</p><ul>{it.triagem.calculo.map((c) => <li key={c} className="font-mono">{c}</li>)}</ul></div>}
    {it.nexus && <ul className="mt-2 space-y-0.5 text-xs">{it.nexus.checks.map((c) => <li key={c.nome}>{c.pass ? "✔" : "✘"} {c.nome} — {c.detalhe}</li>)}</ul>}
    {it.funil && <p className="mt-1 text-xs">Funil: {it.funil.estado} · camada {it.funil.atual} · {it.funil.runId} · {new Date(it.funil.at).toLocaleString("pt-BR")}</p>}
    <p className="text-[10px] text-muted-foreground">{it.failureId}</p>
    {children}
  </div>
);

/** Wikipedia: recebe falhas do RealGear e resolve. */
export function WikiBugFix() {
  const [b, setB] = useBug();
  const go = (id: string) => { const r = resolve(readBug(), readFix(), id, new Date().toISOString()); saveFix(r.fx); setB(saveBug(r.b)); };
  if (!b.items.length) return <p className="text-sm text-muted-foreground">Nenhuma falha recebida do RealGear ainda.</p>;
  const rank = triageAll(readFix()).slice(0, 8);
  return <div className="space-y-2"><div className="rounded-xl border border-border bg-card p-3 text-xs"><b className="text-sm">Prioridades (estatística das falhas reais)</b><ol className="mt-1 list-decimal pl-4">{rank.map((t) => <li key={t.failureId}>[{t.prioridade}] camada {t.camada} · {t.categoria} · {t.exigencia}</li>)}</ol></div>{[...b.items].reverse().map((it) => <Row key={it.failureId} it={it}>{(it.etapa === "RECEBIDA" || it.etapa === "SEM CORREÇÃO" || it.etapa === "AGUARDA MEDIÇÃO" || it.etapa === "DEVOLVIDA AO STREETRACE" || it.etapa === "REPROVADA NEXUS" || it.etapa === "REPROVADA NO FUNIL") && <button onClick={() => go(it.failureId)} className="mt-2 rounded bg-primary px-3 py-1 text-xs font-bold text-primary-foreground">Resolver e enviar ao NEXUS</button>}</Row>)}</div>;
}

/** NEXUS: confere as correções e reenvia ao funil. */
export function NexusBugFix() {
  const [b, setB] = useBug();
  const list = b.items.filter((i) => i.etapa === "RESOLVIDA" || i.etapa === "REPROVADA NEXUS" || i.etapa === "REPROVADA NO FUNIL");
  const go = (id: string) => setB(saveBug(nexusReview(readBug(), readFix(), id, new Date().toISOString())));
  if (!list.length) return <p className="text-sm text-muted-foreground">Nenhuma correção aguardando conferência.</p>;
  return <div className="space-y-2">{list.map((it) => <Row key={it.failureId} it={it}>{it.etapa === "RESOLVIDA" && <button onClick={() => go(it.failureId)} className="mt-2 rounded bg-primary px-3 py-1 text-xs font-bold text-primary-foreground">Conferir, aprovar e reenviar ao funil</button>}</Row>)}</div>;
}

export function NexusApproved() {
  const [b] = useBug(); const list = approved(b);
  if (!list.length) return <p className="text-sm text-muted-foreground">Nada aprovado no funil ainda.</p>;
  return <div className="space-y-2">{list.map((it) => <Row key={it.failureId} it={it} />)}</div>;
}
