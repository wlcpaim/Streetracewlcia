// Aplica uma partida rankeada concluída e validada no servidor. Idempotente por match_id (UNIQUE no histórico).
// Partida cancelada/não concluída nunca chega aqui. Só o servidor escreve (service role).
import { atualizar, MMR_INICIAL, type RankedCat, type Resultado } from "./elo";

export async function aplicarPartida(m: { matchId: string; cat: RankedCat; a: string; b: string; resultadoA: Resultado; concluida: boolean; empatePermitido?: boolean }) {
  if (!m.concluida || m.a === m.b) return { aplicado: false, motivo: "partida inválida ou não concluída" };
  const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
  const { data: dup } = await db.from("mmr_history").select("id").eq("match_id", m.matchId).limit(1);
  if (dup?.length) return { aplicado: false, motivo: "partida já contabilizada" };
  const { data: rows } = await db.from("player_mmr").select("*").eq("category", m.cat).in("user_id", [m.a, m.b]);
  const get = (id: string) => rows?.find((r) => r.user_id === id) ?? { user_id: id, category: m.cat, mmr: MMR_INICIAL, matches: 0, wins: 0, losses: 0 };
  const pa = get(m.a), pb = get(m.b);
  const [ua, ub] = atualizar({ mmr: pa.mmr, partidas: pa.matches }, { mmr: pb.mmr, partidas: pb.matches }, m.resultadoA, { empatePermitido: !!m.empatePermitido });
  const hist = [[m.a, m.b, ua], [m.b, m.a, ub]] as const;
  const { error } = await db.from("mmr_history").insert(hist.map(([u, o, x]) => ({ match_id: m.matchId, user_id: u, opponent_id: o, category: m.cat, mmr_before: x.antes, opponent_mmr: x.adversario, expected: x.expectativa, result: x.resultado, k: x.k, delta: x.delta, mmr_after: x.depois })));
  if (error) return { aplicado: false, motivo: error.message };
  await db.from("player_mmr").upsert([[pa, ua], [pb, ub]].map(([p, x]) => ({ user_id: (p as typeof pa).user_id, category: m.cat, mmr: (x as typeof ua).depois, matches: (p as typeof pa).matches + 1, wins: (p as typeof pa).wins + ((x as typeof ua).resultado === 1 ? 1 : 0), losses: (p as typeof pa).losses + ((x as typeof ua).resultado === 0 ? 1 : 0), updated_at: new Date().toISOString() })));
  return { aplicado: true, a: ua, b: ub };
}
