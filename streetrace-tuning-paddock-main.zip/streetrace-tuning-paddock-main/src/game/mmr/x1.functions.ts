// 1x1 ranqueado: fila por MMR e corrida calculada no servidor. O cliente só pede para entrar/sair e lê o resultado.
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { CALIB_MATCHES, X1_CLASSES, X1_DISTANCES } from "./x1-core";

const Pid = z.object({ playerId: z.string().uuid() });

async function ownPlayer(sb: { from: (t: "players") => any }, playerId: string, userId: string) {
  // user_id explícito: amigos também enxergam o jogador pela RLS, mas só o dono pode jogar com ele
  const { data } = await sb.from("players").select("id,name").eq("id", playerId).eq("user_id", userId).maybeSingle();
  if (!data) throw new Error("jogador não pertence a esta conta");
  return data as { id: string; name: string };
}

export const x1Join = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Pid.extend({ distance: z.number().refine((v) => (X1_DISTANCES).includes(v)), mode: z.enum(["ranked", "casual"]).default("ranked"), category: z.enum(X1_CLASSES as unknown as ["200", "300", "fl"]), protocol: z.number().int().optional() }).parse(d))
  .handler(async ({ data, context }) => {
    // Anticheat no servidor: cliente desatualizado não entra (não é punido, só precisa atualizar)
    const { RELEASE } = await import("../anticheat/release");
    const { clientCompatible } = await import("../anticheat/update-rules");
    if (!clientCompatible(data.protocol, RELEASE.minProtocol)) return { status: "recusado" as const, motivo: "versão do jogo desatualizada, atualizando" };
    const pl = await ownPlayer(context.supabase as never, data.playerId, context.userId);
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    const { myMmr, tryPair } = await import("./x1.server");
    const { x1Ride } = await import("./x1-core");
    const { data: save } = await db.from("game_saves").select("data").eq("user_id", context.userId).eq("kind", `player:${data.playerId}`).maybeSingle();
    const ride = x1Ride(save?.data ?? null, data.distance, data.category);
    if (!ride.ok) return { status: "recusado" as const, motivo: ride.motivo };
    const m = await myMmr(db, context.userId);
    const since = new Date().toISOString();
    await db.from("x1_queue").upsert({ player_id: data.playerId, user_id: context.userId, mmr: m.mmr, calibrating: m.matches < CALIB_MATCHES, distance: data.distance, mode: data.mode, category: data.category, joined_at: since });
    const r = await tryPair(db, { userId: context.userId, playerId: data.playerId, name: pl.name });
    return { status: "fila" as const, since, matchId: r && "matchId" in r ? r.matchId : null, cancelado: r && "canceled" in r ? r.canceled : null };
  });

export const x1Poll = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Pid.extend({ since: z.string().datetime() }).parse(d))
  .handler(async ({ data, context }) => {
    const pl = await ownPlayer(context.supabase as never, data.playerId, context.userId);
    const { data: done } = await context.supabase.from("x1_matches").select("*").or(`a_player.eq.${data.playerId},b_player.eq.${data.playerId}`).gte("created_at", data.since).neq("status" as never, "cancelada" as never).order("created_at", { ascending: false }).limit(1);
    if (done?.[0]) return { status: "fim" as const, match: done[0] };
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    const { tryPair } = await import("./x1.server");
    const r = await tryPair(db, { userId: context.userId, playerId: data.playerId, name: pl.name });
    if (!r) return { status: "fora" as const };
    if ("matchId" in r) { const { data: m } = await context.supabase.from("x1_matches").select("*").eq("id", r.matchId).single(); return { status: "fim" as const, match: m }; }
    if ("canceled" in r) return { status: "fora" as const, motivo: r.canceled };
    return { status: "fila" as const, wait: r.wait };
  });

export const x1Leave = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Pid.parse(d))
  .handler(async ({ data, context }) => {
    await ownPlayer(context.supabase as never, data.playerId, context.userId);
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    await db.from("x1_queue").delete().eq("player_id", data.playerId).eq("user_id", context.userId);
    return { ok: true };
  });

export const x1Stats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase.from("player_mmr").select("category,mmr,matches,wins,losses").eq("user_id", context.userId).in("category", ["ranked_1x1", "casual_1x1"]);
    const z0 = { mmr: 0, matches: 0, wins: 0, losses: 0 };
    const r = data?.find((x) => x.category === "ranked_1x1") ?? z0, c = data?.find((x) => x.category === "casual_1x1") ?? z0;
    return { ranked: { mmr: r.mmr, matches: r.matches, wins: r.wins, losses: r.losses, calibrando: r.matches < CALIB_MATCHES ? r.matches : null }, casual: { matches: c.matches, wins: c.wins, losses: c.losses }, calibTotal: CALIB_MATCHES };
  });

/** Dados para a corrida visual: as duas motos do save do servidor e a hora da largada comum. */
export const x1Race = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Pid.extend({ matchId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await ownPlayer(context.supabase as never, data.playerId, context.userId);
    const { data: m } = await context.supabase.from("x1_matches").select("*").eq("id", data.matchId).maybeSingle();
    if (!m || (m.a_player !== data.playerId && m.b_player !== data.playerId)) throw new Error("partida não encontrada");
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    const { bikeModel, normalizeSetup } = await import("../physics");
    const load = async (user: string, player: string, name: string) => {
      const { data: s } = await db.from("game_saves").select("data").eq("user_id", user).eq("kind", `player:${player}`).maybeSingle();
      const p = (s?.data ?? {}) as { activeBike?: string; setup?: unknown; fuelL?: number };
      const b = bikeModel(p.activeBike);
      const fuel = typeof p.fuelL === "number" && Number.isFinite(p.fuelL) ? Math.max(0, Math.min(b.tank, p.fuelL)) : 0;
      return { name, bikeId: b.id, setup: normalizeSetup(p.setup as never), fuelL: fuel };
    };
    const [a, b] = await Promise.all([load(m.a_user, m.a_player, m.a_name), load(m.b_user, m.b_player, m.b_name)]);
    const iA = m.a_player === data.playerId;
    return { match: m, iAmA: iA, me: iA ? a : b, opp: iA ? b : a, serverNow: Date.now() };
  });

/** Aparelho terminou de carregar a pista: confirma no servidor e lê o estado da partida. */
export const x1Ready = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Pid.extend({ matchId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await ownPlayer(context.supabase as never, data.playerId, context.userId);
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    const { markReady } = await import("./x1.server");
    return view(await markReady(db, data.matchId, data.playerId), data.playerId);
  });

/** Estado do carregamento: pendente, ok (largada vale) ou cancelada (com o nome de quem falhou). */
export const x1Status = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Pid.extend({ matchId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await ownPlayer(context.supabase as never, data.playerId, context.userId);
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    const { settleMatch } = await import("./x1.server");
    const m = await settleMatch(db, data.matchId);
    if (!m || (m.a_player !== data.playerId && m.b_player !== data.playerId)) throw new Error("partida não encontrada");
    return view(m, data.playerId);
  });

function view(m: Awaited<ReturnType<typeof import("./x1.server")["settleMatch"]>>, playerId: string) {
  if (!m) throw new Error("partida não encontrada");
  const failedName = m.failed_player ? (m.failed_player === m.a_player ? m.a_name : m.b_name) : null;
  return { status: m.status as "pendente" | "ok" | "cancelada", failedName, iFailed: m.failed_player === playerId, match: m as unknown as Record<string, string | number | null>, serverNow: Date.now() };
}
