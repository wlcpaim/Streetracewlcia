import type { Setup } from "../physics";
/** Segundos entre o pareamento (created_at do servidor) e a largada comum dos dois pilotos. */
export const X1_START_DELAY_S = 15;
export interface OnlineRider { name: string; bikeId: string; setup: Setup; fuelL: number }
export interface OnlineRace {
  matchId: string;
  /** Lado A da partida (faixas espelhadas no outro aparelho). */
  iAmA: boolean;
  mode: "ranked" | "casual";
  me: OnlineRider;
  opp: OnlineRider;
  /** Instante da largada no relógio local (ms), já corrigido pelo relógio do servidor. */
  startAt: number;
  official: { myT: number | null; opT: number | null; result: number; delta: number | null; myTop: number; opTop: number };
}
/** Hora da largada no relógio local: created_at do servidor + atraso, menos a diferença entre os relógios. */
export const localStart = (createdAt: string, serverNow: number, clientNow: number) =>
  new Date(createdAt).getTime() + X1_START_DELAY_S * 1000 - (serverNow - clientNow);
/** Preparação na sala da corrida: segundos depois que o ÚLTIMO piloto confirmou estar conectado e carregado. */
export const X1_PREP_S = 5;
/** Largada comum da sala: só depois que os dois confirmaram (hora do servidor), mais a preparação. */
export function roomStart(aReadyAt: string, bReadyAt: string, serverNow: number, clientNow: number) {
  const last = Math.max(new Date(aReadyAt).getTime(), new Date(bReadyAt).getTime());
  return last + X1_PREP_S * 1000 - (serverNow - clientNow);
}
/** Faixas de largada iguais nos dois aparelhos: sorteio pelo id da partida, lado A e B espelhados. */
export function seededLanes(matchId: string, iAmA: boolean) {
  let h = 2166136261;
  for (const c of matchId) h = Math.imul(h ^ c.charCodeAt(0), 16777619);
  const L = [0, 0.25, 0.5, 0.75, 1];
  const a = L[(h >>> 0) % L.length]!;
  const rest = L.filter((l) => Math.abs(l - a) >= 0.5);
  const b = rest[((h >>> 8) >>> 0) % rest.length] ?? 1;
  return iAmA ? { m: a, o: b } : { m: b, o: a };
}
