// MMR Elo por categoria. Só habilidade: nunca usa dinheiro, peças ou potência da moto.
export type RankedCat = "ranked_1x1" | "ranked_arrancada" | "ranked_velocidade";
export type Resultado = 1 | 0 | 0.5;
export interface EloCfg { kNovato: number; kVeterano: number; kElite: number; partidasNovato: number; eliteMmr: number; piso: number; deltaMax: number; arredondar: boolean }
export const ELO_CFG: EloCfg = { kNovato: 40, kVeterano: 20, kElite: 15, partidasNovato: 30, eliteMmr: 2400, piso: 100, deltaMax: 60, arredondar: true };
export const MMR_INICIAL = 1500;

/** E(A) = 1 / (1 + 10^((B − A)/400)) */
export const expectativa = (a: number, b: number) => 1 / (1 + Math.pow(10, (b - a) / 400));

export function fatorK(mmr: number, partidas: number, c: EloCfg = ELO_CFG) {
  if (partidas < c.partidasNovato) return c.kNovato;
  return mmr > c.eliteMmr ? c.kElite : c.kVeterano;
}

export interface Piloto { mmr: number; partidas: number }
export interface Atualizacao { antes: number; adversario: number; expectativa: number; resultado: Resultado; k: number; delta: number; depois: number }

/** Atualiza os dois pilotos: novo = atual + K·(S − E). Empate só se a modalidade permitir. */
export function atualizar(a: Piloto, b: Piloto, sA: Resultado, opts: { empatePermitido?: boolean; k?: number } = {}, c: EloCfg = ELO_CFG): [Atualizacao, Atualizacao] {
  if (sA === 0.5 && !opts.empatePermitido) throw new Error("Empate não permitido nesta modalidade");
  const eA = expectativa(a.mmr, b.mmr), eB = 1 - eA, sB = (1 - sA) as Resultado;
  const one = (p: Piloto, o: Piloto, s: Resultado, e: number): Atualizacao => {
    const k = opts.k ?? fatorK(p.mmr, p.partidas, c);
    let d = k * (s - e);
    d = Math.max(-c.deltaMax, Math.min(c.deltaMax, d));
    if (c.arredondar) d = Math.round(d);
    const depois = Math.max(c.piso, p.mmr + d);
    return { antes: p.mmr, adversario: o.mmr, expectativa: e, resultado: s, k, delta: depois - p.mmr, depois };
  };
  return [one(a, b, sA, eA), one(b, a, sB, eB)];
}
