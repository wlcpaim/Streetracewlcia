import { atualizar } from "./elo";
import { faixa } from "./matchmaking";
import { CALIB_MATCHES, MMR_ONLINE_INICIAL, calibScore, x1Result, x1Ride } from "./x1-core";

type Db = Awaited<typeof import("@/integrations/supabase/client.server")>["supabaseAdmin"];
/** Depois deste tempo na fila, descalibrado pode cair com calibrado (só se não houver outro descalibrado). */
export const OPEN_AFTER_S = 30;
const CAT = { ranked: "ranked_1x1", casual: "casual_1x1" } as const;
type Row = { user_id: string; category: string; mmr: number; matches: number; wins: number; losses: number; calib_sum: number };

async function loadSave(db: Db, userId: string, playerId: string) {
  const { data } = await db.from("game_saves").select("data").eq("user_id", userId).eq("kind", `player:${playerId}`).maybeSingle();
  return data?.data ?? null;
}
async function rows(db: Db, cat: string, ids: string[]) {
  const { data } = await db.from("player_mmr").select("*").eq("category", cat).in("user_id", ids);
  return (id: string): Row => (data?.find((r) => r.user_id === id) as Row | undefined) ?? { user_id: id, category: cat, mmr: MMR_ONLINE_INICIAL, matches: 0, wins: 0, losses: 0, calib_sum: 0 };
}
const wl = (r: Row, s: number) => ({ matches: r.matches + 1, wins: r.wins + (s === 1 ? 1 : 0), losses: r.losses + (s === 0 ? 1 : 0) });

/** Tenta casar o jogador da fila; se casar, corre os dois no servidor e grava partida, W/L e MMR. */
export async function tryPair(db: Db, me: { userId: string; playerId: string; name: string }) {
  const { data: row } = await db.from("x1_queue").select("*").eq("player_id", me.playerId).maybeSingle();
  if (!row) return null;
  const wait = (Date.now() - new Date(row.joined_at).getTime()) / 1000;
  const { data: taken, error } = await db.rpc("x1_take_opponent_v2", { _player: me.playerId, _range: faixa(wait), _open: wait >= OPEN_AFTER_S });
  if (error) throw new Error("fila indisponível");
  const opp = taken?.[0];
  if (!opp) return { queued: true as const, wait: Math.round(wait) };
  const [saveA, saveB, oppRow] = await Promise.all([loadSave(db, me.userId, me.playerId), loadSave(db, opp.opponent_user, opp.opponent), db.from("players").select("name").eq("id", opp.opponent).maybeSingle()]);
  // categoria conferida de novo: quem trocou de moto na fila não entra numa categoria menor
  const cat = (row as { category?: "200" | "300" | "fl" }).category ?? "fl";
  const a = x1Ride(saveA, row.distance, cat), b = x1Ride(saveB, row.distance, cat);
  if (!a.ok || !b.ok) return { queued: false as const, canceled: !a.ok ? a.motivo : "adversário não pôde correr" };
  const res = x1Result(a.time, b.time);
  const mode = row.mode === "casual" ? "casual" : "ranked";
  // nota guardada para quem ainda calibra; o servidor decide no fechamento se ela entra
  const sa = mode === "ranked" ? calibScore(a.bikeId, row.distance, a.time) : null;
  const sb = mode === "ranked" ? calibScore(b.bikeId, row.distance, b.time) : null;
  const { data: match, error: insErr } = await db.from("x1_matches").insert({
    a_user: me.userId, b_user: opp.opponent_user, a_player: me.playerId, b_player: opp.opponent, a_name: me.name, b_name: oppRow.data?.name ?? "Piloto",
    distance: row.distance, a_time: a.time, b_time: b.time, a_hp: a.hp, b_hp: b.hp, a_top: a.top, b_top: b.top, result_a: res, mode, a_calib_score: sa, b_calib_score: sb,
    status: "pendente",
  } as never).select("id").single();
  if (insErr || !match) throw new Error("não foi possível registrar a partida");
  // Nada conta ainda: W/L e MMR só são gravados quando os dois aparelhos confirmam o carregamento (settleMatch).
  return { queued: false as const, matchId: match.id };
}

type M = { id: string; a_user: string; b_user: string; a_player: string; b_player: string; a_name: string; b_name: string; result_a: number; mode: string; distance: number;
  a_calib_score: number | null; b_calib_score: number | null; status: string; a_ready_at: string | null; b_ready_at: string | null; created_at: string; failed_player: string | null };

/** Prazo para os dois confirmarem o carregamento, contado do pareamento no servidor. */
export const READY_DEADLINE_S = 10;

/** Marca o lado do jogador como carregado (só antes do prazo). */
export async function markReady(db: Db, matchId: string, playerId: string) {
  const { data: m } = await db.from("x1_matches").select("*").eq("id", matchId).maybeSingle();
  const x = m as unknown as M | null;
  if (!x || (x.a_player !== playerId && x.b_player !== playerId)) throw new Error("partida não encontrada");
  if (x.status === "pendente" && Date.now() <= new Date(x.created_at).getTime() + READY_DEADLINE_S * 1000) {
    const col = x.a_player === playerId ? "a_ready_at" : "b_ready_at";
    await db.from("x1_matches").update({ [col]: new Date().toISOString() } as never).eq("id", matchId).eq("status" as never, "pendente" as never).is(col as never, null);
  }
  return settleMatch(db, matchId);
}

/** Fecha a partida: os dois carregaram → vale (W/L e MMR); prazo passou sem um deles → cancelada, nada conta. Idempotente. */
export async function settleMatch(db: Db, matchId: string) {
  const { data: m } = await db.from("x1_matches").select("*").eq("id", matchId).maybeSingle();
  const x = m as unknown as M | null;
  if (!x || x.status !== "pendente") return x;
  const both = !!x.a_ready_at && !!x.b_ready_at;
  const late = Date.now() > new Date(x.created_at).getTime() + READY_DEADLINE_S * 1000;
  if (!both && !late) return x;
  if (!both) {
    const failed = !x.a_ready_at ? x.a_player : x.b_player;
    await db.from("x1_matches").update({ status: "cancelada", failed_player: failed } as never).eq("id", matchId).eq("status" as never, "pendente" as never);
  } else {
    // só quem vira o status aplica o resultado (corrida entre os dois pedidos)
    const { data: won } = await db.from("x1_matches").update({ status: "ok" } as never).eq("id", matchId).eq("status" as never, "pendente" as never).select("id");
    if (won?.length) await applyResult(db, x);
  }
  const { data: f } = await db.from("x1_matches").select("*").eq("id", matchId).maybeSingle();
  return f as unknown as M | null;
}

async function applyResult(db: Db, x: M) {
  const res = x.result_a, mode = x.mode === "casual" ? "casual" : "ranked";
  const get = await rows(db, CAT[mode], [x.a_user, x.b_user]);
  const pa = get(x.a_user), pb = get(x.b_user);
  const now = new Date().toISOString();
  if (mode === "casual") {
    // Casual: só W/L, MMR nunca muda.
    await db.from("player_mmr").upsert([[pa, res], [pb, 1 - res]].map(([p, s]) => ({ user_id: (p as Row).user_id, category: CAT.casual, mmr: (p as Row).mmr, calib_sum: 0, ...wl(p as Row, s as number), updated_at: now })));
    return;
  }
  const matchId = `x1:${x.id}`;
  const { data: dup } = await db.from("mmr_history").select("id").eq("match_id", matchId).limit(1);
  if (dup?.length) return;
  const sa = pa.matches < CALIB_MATCHES ? x.a_calib_score : null, sb = pb.matches < CALIB_MATCHES ? x.b_calib_score : null;
  const effA = sa ?? pa.mmr, effB = sb ?? pb.mmr;
  const [ea, eb] = atualizar({ mmr: effA, partidas: pa.matches }, { mmr: effB, partidas: pb.matches }, res as never, { empatePermitido: true });
  const side = (p: Row, calib: number | null, elo: typeof ea, s: number, oppEff: number) => {
    if (calib === null) return { up: { mmr: elo.depois, calib_sum: p.calib_sum }, hist: { mmr_before: p.mmr, opponent_mmr: oppEff, expected: elo.expectativa, result: s, k: elo.k, delta: elo.delta, mmr_after: elo.depois } };
    const sum = p.calib_sum + calib, n = p.matches + 1, after = n >= CALIB_MATCHES ? Math.round(sum / n) : 0;
    return { up: { mmr: after, calib_sum: sum }, hist: { mmr_before: p.mmr, opponent_mmr: oppEff, expected: elo.expectativa, result: s, k: 0, delta: after - p.mmr, mmr_after: after } };
  };
  const A = side(pa, sa, ea, res, effB), B = side(pb, sb, eb, 1 - res, effA);
  const { error: hErr } = await db.from("mmr_history").insert([
    { match_id: matchId, user_id: x.a_user, opponent_id: x.b_user, category: CAT.ranked, ...A.hist },
    { match_id: matchId, user_id: x.b_user, opponent_id: x.a_user, category: CAT.ranked, ...B.hist },
  ]);
  if (hErr) return;
  await db.from("player_mmr").upsert([
    { user_id: x.a_user, category: CAT.ranked, ...A.up, ...wl(pa, res), updated_at: now },
    { user_id: x.b_user, category: CAT.ranked, ...B.up, ...wl(pb, 1 - res), updated_at: now },
  ]);
  await db.from("x1_matches").update({ a_mmr_delta: A.hist.delta, b_mmr_delta: B.hist.delta }).eq("id", x.id);
}

export async function myMmr(db: Db, userId: string) {
  const { data } = await db.from("player_mmr").select("mmr,matches").eq("user_id", userId).eq("category", CAT.ranked).maybeSingle();
  return data ?? { mmr: MMR_ONLINE_INICIAL, matches: 0 };
}
