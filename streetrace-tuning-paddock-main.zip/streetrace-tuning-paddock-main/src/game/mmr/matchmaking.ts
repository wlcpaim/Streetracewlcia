// Faixa de busca: começa estreita e abre com a espera. Entrar na fila nunca muda MMR.
export const FAIXA_INICIAL = 100, FAIXA_PASSO = 50, FAIXA_INTERVALO_S = 5, FAIXA_MAX = 600;
export const faixa = (esperaS: number) => Math.min(FAIXA_MAX, FAIXA_INICIAL + Math.floor(esperaS / FAIXA_INTERVALO_S) * FAIXA_PASSO);
export function melhorAdversario<T extends { mmr: number }>(meu: number, fila: T[], esperaS: number): T | null {
  const f = faixa(esperaS);
  return fila.filter((x) => Math.abs(x.mmr - meu) <= f).sort((x, y) => Math.abs(x.mmr - meu) - Math.abs(y.mmr - meu))[0] ?? null;
}
