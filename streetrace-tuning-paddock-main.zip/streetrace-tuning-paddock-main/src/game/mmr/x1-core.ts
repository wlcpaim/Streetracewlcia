// 1x1: o resultado oficial sai da mesma simulação determinística da corrida (physics.simulate), rodada no servidor
// com o save salvo de cada jogador. Nada do cliente (tempo, potência, velocidade) é aceito como resultado.
import { bikeModel, engine, normalizeSetup, simulate, TITAN_160 } from "../physics";
import { CLASSES, TRACKS, displacement, fitsClass, type ClassId } from "../records";
import type { Resultado } from "./elo";

/** Todas as pistas oficiais valem no Online (casual e competitivo). */
export const X1_DISTANCES = TRACKS.map((t) => t.m) as readonly number[];
export const X1_LABEL: Record<number, string> = Object.fromEntries(TRACKS.map((t) => [t.m, t.label]));
/** Categorias do Online/Competição: só se enfrentam motos da mesma categoria escolhida. */
export const X1_CLASSES = CLASSES.map((c) => c.id) as readonly ClassId[];
export interface X1Rider { ok: true; bikeId: string; time: number | null; top: number; hp: number }
export type X1Check = X1Rider | { ok: false; motivo: string };

/** Calibração: 10 partidas competitivas; MMR inicia em 0 e sai da média das notas por tempo. */
export const CALIB_MATCHES = 10, CALIB_MIN = 500, CALIB_MAX = 5000, MMR_ONLINE_INICIAL = 0;
/** Referência de moto acertada (nota 5000): Titan 220 cc completa no metanol. */
const CALIB_TOP = { slots: { cilindro: "cilindro-220", pistao: "pistao-forjado", biela: "biela-txk-racing", vira: "vira-forjado", escape: "escape-dore", modulo: "modulo-prog", bico: "bico-240" }, services: ["dutos", "dutos-escape", "valv-3ang", "brunimento", "pino-4", "tbi-36", "cavas-pistao", "balanceamento"], compression: 13.5, cam: "a72", fuel: "metanol" };
const refs = new Map<string, number>();
const ref = (key: string, f: () => number | null) => { if (!refs.has(key)) refs.set(key, f() ?? Infinity); return refs.get(key)!; };
/** Tempo base: moto original de fábrica (a própria Factor ou Titan) = 500. */
export const baseTime = (bikeId: string, d: number) => ref(`b:${bikeId}:${d}`, () => { const b = bikeModel(bikeId); return simulate(b, normalizeSetup({} as never), d, b.tank).finishT; });
export const topTime = (d: number) => ref(`t:${d}`, () => simulate(TITAN_160, normalizeSetup(CALIB_TOP as never), d, 2).finishT);
/** Nota da partida de calibração pelo tempo: original = 500, acertada = 5000, interpolado e limitado. */
export function calibScore(bikeId: string, d: number, t: number | null) {
  if (t === null) return CALIB_MIN;
  const lo = baseTime(bikeId, d), hi = topTime(d);
  if (!(lo > hi)) return CALIB_MIN;
  const f = Math.max(0, Math.min(1, (lo - t) / (lo - hi)));
  return Math.round(CALIB_MIN + f * (CALIB_MAX - CALIB_MIN));
}

/** Valida o save e corre sozinho na pista: tanque limitado ao da moto, moto quebrada ou sem moto não corre. */
export function x1Ride(save: unknown, distance: number, cat?: ClassId): X1Check {
  if (!save || typeof save !== "object") return { ok: false, motivo: "save do piloto não encontrado" };
  const p = save as { activeBike?: unknown; bikes?: unknown; setup?: unknown; fuelL?: unknown; broken?: unknown };
  if (typeof p.activeBike !== "string" || !Array.isArray(p.bikes) || !p.bikes.includes(p.activeBike)) return { ok: false, motivo: "piloto sem moto" };
  if (p.broken) return { ok: false, motivo: "motor quebrado" };
  const b = bikeModel(p.activeBike), s = normalizeSetup(p.setup as never);
  if (cat && !fitsClass(displacement(s, b.id), cat)) return { ok: false, motivo: `moto acima de ${CLASSES.find((c) => c.id === cat)!.label} (${displacement(s, b.id)} cc)` };
  const fuel = typeof p.fuelL === "number" && Number.isFinite(p.fuelL) ? Math.max(0, Math.min(b.tank, p.fuelL)) : 0;
  if (fuel <= 0) return { ok: false, motivo: "tanque vazio" };
  const st = simulate(b, s, distance, fuel);
  return { ok: true, bikeId: b.id, time: st.finishT === null ? null : Math.round(st.finishT * 1000) / 1000, top: Math.round(st.top * 10) / 10, hp: Math.round(engine(b, s).hp * 10) / 10 };
}

/** Resultado do piloto A: menor tempo vence; quem não chega perde; empate só no mesmo milésimo (ou ambos sem chegar). */
export function x1Result(a: number | null, b: number | null): Resultado {
  if (a === null && b === null) return 0.5;
  if (a === null) return 0;
  if (b === null) return 1;
  if (Math.abs(a - b) < 0.0005) return 0.5;
  return a < b ? 1 : 0;
}
