// Oficina "Acertar": the mechanic picks, from the player's stock, the fastest setup for a track length.
import { LIGHT_REMOVED, STOCK_FRONT, STOCK_REAR, STOCK_SETUP, bikeModel, simulate, type BikeModel, type Setup } from "./physics";
import { SLOTS, partById, type Slot } from "./parts";
import type { Player } from "./store";
import { swapSlot } from "./component-swap";

export const ACERTO_DISTANCES = [500, 5000, 10000] as const;
export const ACERTO_BASE: Record<number, number> = { 500: 800, 5000: 4000, 10000: 12000 };
/** Base price per track length; each job costs 120% more than the previous one. */
export const acertoPrice = (done: number, d = 500) => Math.round((ACERTO_BASE[d] ?? 800) * Math.pow(2.2, done) * 100) / 100;

const PSI = [18, 20, 22, 24, 26, 28, 30, 32, 34, 36];

function score(s: Setup, d: number, bike: BikeModel) {
  const st = simulate(bike, s, d, bike.tank);
  return st.finishT ?? 1e9 - st.x;
}

/** Coordinate descent over every option the player owns. */
export function bestSetup(p: Player, d: number): Setup {
  const bike = bikeModel(p.activeBike);
  const owned = p.parts.map(partById).filter((x) => !!x);
  const fronts = new Set([STOCK_FRONT, p.setup.front]);
  const rears = new Set([STOCK_REAR, p.setup.rear]);
  const pairs: [number, number][] = [];
  for (const x of owned) {
    if (x.kind === "kit") pairs.push([x.front!, x.rear!]);
    if (x.kind === "pinhao") fronts.add(x.front!);
    if (x.kind === "coroa") rears.add(x.rear!);
  }
  for (const f of fronts) for (const r of rears) pairs.push([f, r]);

  const slotOpts = (sl: Slot) => [`${sl}-original`, ...owned.filter((x) => x.kind === sl).map((x) => x.id)];
  const dims: ((s: Setup) => Setup)[][] = [
    pairs.map(([front, rear]) => (s) => ({ ...s, front, rear })),
    [STOCK_SETUP.removed, LIGHT_REMOVED].map((removed) => (s) => ({ ...s, removed: { ...removed } })),
    (["original", "sem", "caixa"] as const).map((airFilter) => (s) => ({ ...s, airFilter })),
    ...SLOTS.filter((sl) => sl !== "oleo").map((sl) => slotOpts(sl).map((id) => (s: Setup) => swapSlot(s, sl, id))),
    PSI.map((psi) => (s) => ({ ...s, psi })),
  ];

  let best = p.setup;
  let bestT = score(best, d, bike);
  for (let pass = 0; pass < 2; pass++) {
    for (const opts of dims) {
      if (opts.length < 2) continue;
      for (const apply of opts) {
        const c = apply(best);
        const t = score(c, d, bike);
        if (t < bestT - 1e-6) {
          best = c;
          bestT = t;
        }
      }
    }
  }
  return best;
}

/** Re-apply a saved preset, keeping only parts still in stock and the engine's physical state. */
export function applyPreset(p: Player, preset: Setup): Setup {
  const has = (id: string) => id.endsWith("-original") || p.parts.includes(id);
  let setup = p.setup;
  for (const sl of SLOTS) if (sl !== "oleo" && has(preset.slots[sl])) setup = swapSlot(setup, sl, preset.slots[sl]);
  const ownsF = preset.front === STOCK_FRONT || p.parts.some((id) => partById(id)?.front === preset.front);
  const ownsR = preset.rear === STOCK_REAR || p.parts.some((id) => partById(id)?.rear === preset.rear);
  return {
    ...setup,
    removed: { ...preset.removed },
    airFilter: preset.airFilter,
    psi: preset.psi,
    front: ownsF ? preset.front : p.setup.front,
    rear: ownsR ? preset.rear : p.setup.rear,
  };
}
