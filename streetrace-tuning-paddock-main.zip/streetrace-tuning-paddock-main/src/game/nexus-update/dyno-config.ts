// Editable dyno sweep parameters (NEXUS UPDATE). Mutated in place so the Dino screen reads current values.
export const DYNO = { rpmMin: 5000, rpmStep: 250, distances: [500, 5000, 10000] as number[] };
