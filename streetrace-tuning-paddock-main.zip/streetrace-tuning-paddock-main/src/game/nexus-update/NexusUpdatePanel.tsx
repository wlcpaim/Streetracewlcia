import { tapBack } from "@/game/ui/triple-tap";
import { useMemo, useState, useSyncExternalStore } from "react";
import { Pencil, RotateCcw, Search, X } from "lucide-react";
import { MecanicoDossier } from "./MecanicoDossier";
import { MemoriaTab } from "../mechanic-master/MemoriaTab";
import { applyNexusOverrides, categories, defaultOf, readOverrides, resetAll, resetItem, saveItem, subscribe, validate, version, type Item } from "./registry";

const fmt = (v: unknown) => (v === undefined || v === null || v === "" ? "—" : typeof v === "number" ? v.toLocaleString("pt-BR", { maximumFractionDigits: 3 }) : String(v));

export function NexusUpdatePanel() {
  useState(() => { applyNexusOverrides(); return 0; });
  useSyncExternalStore(subscribe, version, () => 0);
  const cats = categories();
  const ov = readOverrides();
  const [tab, setTab] = useState("visao");
  const [q, setQ] = useState("");
  const [edit, setEdit] = useState<Item | null>(null);
  const total = cats.reduce((a, c) => a + c.items.length, 0);
  const modified = Object.keys(ov).length;
  const cat = cats.find((c) => c.id === tab);
  const items = useMemo(() => (cat?.items ?? []).filter((i) => !q || `${i.name} ${i.group} ${i.key}`.toLowerCase().includes(q.toLowerCase())), [cat, q]);
  const groups = useMemo(() => { const m = new Map<string, Item[]>(); for (const i of items) m.set(i.group, [...(m.get(i.group) ?? []), i]); return [...m]; }, [items]);

  return (
    <div className="space-y-4 pb-24">
      <header className="rounded-2xl border border-border bg-card p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div><p className="text-xs uppercase tracking-widest text-muted-foreground">Painel de controle do jogo</p><h1 className="font-display text-3xl">NEXUS UPDATE</h1></div>
          <button onClick={() => { if (confirm("Restaurar todos os valores originais?")) resetAll(); }} className="flex items-center gap-1 rounded-lg border border-border px-3 py-1.5 text-xs font-bold"><RotateCcw className="h-3.5 w-3.5" /> Restaurar tudo</button>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2">
          {[["Itens no jogo", total], ["Modificados", modified], ["Categorias", cats.length]].map(([l, v]) => (
            <div key={l} className="rounded-xl bg-secondary p-3"><p className="text-[11px] text-muted-foreground">{l}</p><p className="font-mono text-2xl font-bold tabular-nums">{v}</p></div>
          ))}
        </div>
      </header>

      <nav className="sticky top-[52px] z-20 flex gap-1 overflow-x-auto rounded-xl border border-border bg-background/95 p-1 backdrop-blur">
        {[["visao", "Visão geral"], ["memoria", "Memória do Mecânico"], ...cats.map((c) => [c.id, c.label])].map(([id, l]) => (
          <button key={id} onClick={() => setTab(id!)} className={`whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-bold ${tab === id ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>{l}</button>
        ))}
      </nav>

      {tab === "visao" ? (
        <div className="grid gap-2 sm:grid-cols-2">
          {cats.map((c) => { const m = c.items.filter((i) => ov[i.key]).length; return (
            <button key={c.id} onClick={() => setTab(c.id)} className="rounded-xl border border-border bg-card p-4 text-left">
              <div className="flex items-center justify-between"><b>{c.label}</b><span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${m ? "bg-accent text-accent-foreground" : "bg-muted text-muted-foreground"}`}>{m ? `${m} modificado(s)` : "Padrão"}</span></div>
              <p className="text-xs text-muted-foreground">{c.desc}</p>
              <p className="mt-2 font-mono text-xl tabular-nums">{c.items.length} <span className="text-xs text-muted-foreground">itens</span></p>
            </button>); })}
        </div>
      ) : (
        <>
          {tab === "mecanico" && <MecanicoDossier key={version()} />}
          {tab === "memoria" && <MemoriaTab />}
          {tab !== "mecanico" && tab !== "memoria" && <>
          <label className="flex items-center gap-2 rounded-xl border border-border bg-card px-3 py-2"><Search className="h-4 w-4 text-muted-foreground" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder={`Buscar em ${cat?.label}…`} className="w-full bg-transparent text-sm outline-none" /></label>
          {groups.map(([g, list]) => (
            <section key={g} className="overflow-hidden rounded-xl border border-border bg-card">
              <h3 className="border-b border-border bg-secondary px-4 py-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">{g} · {list.length}</h3>
              <ul className="divide-y divide-border">
                {list.map((i) => (
                  <li key={i.key} className="flex items-center gap-3 px-4 py-2.5">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">{String(i.obj["name"] ?? i.obj["label"] ?? i.name)}</p>
                      <p className="truncate font-mono text-[11px] text-muted-foreground">{i.fields.filter((f) => f.type === "number").slice(0, 3).map((f) => `${f.label}: ${fmt(i.obj[f.k])}${f.unit && i.obj[f.k] !== undefined ? " " + f.unit : ""}`).join(" · ")}</p>
                    </div>
                    {ov[i.key] && <span className="rounded-full bg-accent px-2 py-0.5 text-[10px] font-bold text-accent-foreground">Modificado</span>}
                    <button onClick={() => setEdit(i)} aria-label={`Editar ${i.name}`} className="flex items-center gap-1 rounded-lg bg-primary px-2.5 py-1 text-xs font-bold text-primary-foreground"><Pencil className="h-3 w-3" /> Editar</button>
                  </li>
                ))}
              </ul>
            </section>
          ))}
          {!groups.length && <p className="text-center text-sm text-muted-foreground">Nada encontrado.</p>}
          </>}
        </>
      )}
      {edit && <Editor item={edit} onClose={() => setEdit(null)} />}
    </div>
  );
}

function Editor({ item, onClose }: { item: Item; onClose: () => void }) {
  const [vals, setVals] = useState<Record<string, string>>(() => Object.fromEntries(item.fields.map((f) => [f.k, item.obj[f.k] === undefined ? "" : String(item.obj[f.k])])));
  const checks = item.fields.map((f) => [f, validate(f, vals[f.k] ?? "")] as const);
  const bad = checks.some(([, r]) => r.err);
  const save = () => { saveItem(item.key, Object.fromEntries(checks.map(([f, r]) => [f.k, r.v]))); onClose(); };
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-background/70 backdrop-blur-sm sm:items-center" onClick={tapBack(onClose)}>
      <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-t-2xl border border-border bg-card p-5 sm:rounded-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="mb-3 flex items-start justify-between gap-2"><div><p className="text-[11px] uppercase tracking-widest text-muted-foreground">{item.group}</p><h2 className="text-lg font-bold">{item.name}</h2><p className="font-mono text-[10px] text-muted-foreground">{item.key}</p></div><button onClick={onClose} aria-label="Fechar"><X className="h-5 w-5" /></button></div>
        <div className="space-y-3">
          {checks.map(([f, r]) => { const d = defaultOf(item.key, f.k); const changed = (r.v ?? undefined) !== d; return (
            <label key={f.k} className="block rounded-xl border border-border p-3">
              <div className="flex items-center justify-between text-xs"><b>{f.label}{f.unit ? ` (${f.unit})` : ""}</b>{changed && <span className="text-accent-foreground">original: {fmt(d)}</span>}</div>
              <input value={vals[f.k]} inputMode={f.type === "number" ? "decimal" : "text"} placeholder={f.type === "number" ? "vazio = não usa" : ""} onChange={(e) => setVals({ ...vals, [f.k]: e.target.value })} className="mt-1 w-full rounded-lg border border-input bg-background px-2 py-1.5 font-mono text-sm tabular-nums" />
              {f.formula && <p className="mt-1 font-mono text-[10px] text-muted-foreground">ƒ {f.formula}</p>}
              {r.err && <p className="mt-1 text-xs text-destructive">{r.err}</p>}
            </label>); })}
        </div>
        <div className="mt-4 flex gap-2">
          <button onClick={() => { resetItem(item.key); onClose(); }} className="flex-1 rounded-lg border border-border py-2 text-sm font-bold">Restaurar padrão</button>
          <button disabled={bad} onClick={save} className="flex-1 rounded-lg bg-primary py-2 text-sm font-bold text-primary-foreground disabled:opacity-50">Salvar no jogo</button>
        </div>
      </div>
    </div>
  );
}
