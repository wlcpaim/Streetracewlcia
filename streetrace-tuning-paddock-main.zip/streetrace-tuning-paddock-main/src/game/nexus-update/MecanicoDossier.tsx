// MECÂNICO: ficha demonstrativa das motos e do kit 4MM calculada ao vivo pelas mesmas funções da corrida
// (engine, stats, stress, simulate, afinamento). Só leitura: não altera Setup nem a física.
import { useMemo, useState } from "react";
import { ChevronDown, Eye, MessageSquare, Pencil } from "lucide-react";
import { categories, defaultOf, readOverrides, resetItem, saveItem, validate, type Item } from "./registry";
import { CompetitionBench } from "../ui/CompetitionBench";
import { FACTOR_150, STOCK_SETUP, TITAN_160, engine, simulate, stats, stress, type BikeModel, type Setup, BIKE_MODELS } from "../physics";
import { PARTS_CATALOG, SLOT_LABEL, partById, type Slot } from "../parts";
import { KIT4, KIT4_LABOR, kit4Pieces } from "../workshop";
import { swapSlot } from "../component-swap";
import { afinamento } from "../tuning";

const BIKES = BIKE_MODELS;
const n = (v: number, d = 1) => v.toLocaleString("pt-BR", { maximumFractionDigits: d, minimumFractionDigits: d });

export function kitSetup(): Setup {
  const kit = partById(KIT4)!.bundle!;
  let s: Setup = STOCK_SETUP;
  for (const id of kit4Pieces()) { const k = partById(id)?.kind as Slot; if (k in s.slots) s = swapSlot(s, k, id); }
  return { ...s, cam: kit.cam, services: ["pino-2"] };
}

function sheet(b: BikeModel, s: Setup) {
  const e = engine(b, s), st = stats(b, s, b.tank), sr = stress(b, s), af = afinamento(b, s);
  const w = e.hp * 735.5, omega = (e.rpmPeak * 2 * Math.PI) / 60;
  const run402 = simulate(b, s, 402), run1k = simulate(b, s, 1000);
  return { e, st, sr, af, w, omega, tq: w / omega, pw: st.kg + 90 > 0 ? e.hp / (st.kg + 90) : 0, t402: run402.finishT, t1k: run1k.finishT, top: run1k.top };
}
type Sheet = ReturnType<typeof sheet>;


type O = "ficha" | "calculado" | "estimado";
const Ctx = { full: true };
const Row = ({ l, v, f, o }: { l: string; v: string; f?: string | undefined; o: O }) => (
  <div className="flex items-start justify-between gap-2 border-b border-border py-1 last:border-0">
    <div className="min-w-0"><p className="text-[11px] leading-tight">{l}</p>{Ctx.full && f && <p className="font-mono text-[9px] leading-tight text-muted-foreground">ƒ {f}</p>}</div>
    <div className="shrink-0 text-right"><p className="font-mono text-xs font-bold tabular-nums">{v}</p>{Ctx.full && <p className="text-[8px] uppercase tracking-wider text-muted-foreground">{o}</p>}</div>
  </div>
);
const Block = ({ t, children }: { t: string; children: React.ReactNode }) => (
  <section className="rounded-lg border border-border bg-background/40"><h4 className="border-b border-border bg-secondary px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{t}</h4><div className="px-2">{children}</div></section>
);

function SheetView({ b, x }: { b: BikeModel; x: Sheet }) {
  return (
    <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
      <Block t="Motor">
        <Row l="Cilindrada" v={`${n(b.cc)} cm³`} f="Vd = π/4 · D² · S" o="ficha" />
        <Row l="Potência" v={`${n(x.e.hp)} cv`} f="hp = base × Π peças × mistura × escape" o="calculado" />
        <Row l="Pico / corte" v={`${x.e.rpmPeak} / ${x.e.rpmLimit}`} f="rpmPeak = base + comando + Σ peças" o="calculado" />
        <Row l="Torque no pico" v={`${n(x.tq, 2)} N·m`} f="T = P / ω" o="calculado" />
        <Row l="ω no pico" v={`${n(x.omega)} rad/s`} f="ω = 2π·rpm/60" o="calculado" />
      </Block>
      <Block t="Chassi e peso">
        <Row l="Peso tanque cheio" v={`${n(x.st.kg)} kg`} f="moto + Σ peças + L × densidade" o="calculado" />
        <Row l="Tanque" v={`${n(b.tank)} L`} o="ficha" />
        <Row l="cv/t (piloto 90 kg)" v={n(x.pw * 1000)} f="hp / (kg + piloto)" o="calculado" />
        <Row l="Pneus" v={b.tires} o="ficha" />
      </Block>
      <Block t="Desempenho">
        <Row l="402 m" v={x.t402 ? `${n(x.t402, 2)} s` : "não completou"} f="step() a passo fixo" o="calculado" />
        <Row l="1000 m" v={x.t1k ? `${n(x.t1k, 2)} s` : "não completou"} o="calculado" />
        <Row l="Final 1000 m" v={`${n(x.top)} km/h`} o="calculado" />
      </Block>
      <Block t="Mecânico">
        <Row l="Afinamento" v={`${Math.round(x.af.pct)}%`} f="alimentação + ponto + escape + transmissão + segurança" o="calculado" />
        {x.af.sistemas.map((s) => <Row key={s.id} l={s.nome} v={`${Math.round(s.pts)}/${s.max}`} f={s.achado} o="calculado" />)}
        <Row l="Carga" v={n(x.sr.value)} f="stress() = Σ cargas − alívio" o="calculado" />
        <Row l="Risco/corrida" v={`${n(x.sr.risk * 100)}%`} f="(carga − 10) × 0,012 × desgaste" o="estimado" />
        {Ctx.full && <p className="py-1 text-[10px] text-muted-foreground">Próximo: {x.af.proxima}</p>}
      </Block>
    </div>
  );
}

function InlineEdit({ item }: { item: Item }) {
  const [vals, setVals] = useState<Record<string, string>>(() => Object.fromEntries(item.fields.map((f) => [f.k, item.obj[f.k] === undefined ? "" : String(item.obj[f.k])])));
  const checks = item.fields.map((f) => [f, validate(f, vals[f.k] ?? "")] as const);
  const bad = checks.some(([, r]) => r.err);
  const mod = !!readOverrides()[item.key];
  return (
    <div className="rounded-lg border border-border bg-background/40 p-2">
      <div className="mb-1 flex items-center justify-between"><b className="text-xs">{item.name}</b>{mod && <span className="rounded-full bg-accent px-2 text-[9px] font-bold text-accent-foreground">Modificado</span>}</div>
      <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3 lg:grid-cols-4">
        {checks.map(([f, r]) => { const d = defaultOf(item.key, f.k); return (
          <label key={f.k} className="block">
            <span className="block truncate text-[10px] text-muted-foreground">{f.label}{f.unit ? ` (${f.unit})` : ""}{(r.v ?? undefined) !== d ? ` · orig ${d ?? "—"}` : ""}</span>
            <input value={vals[f.k]} onChange={(e) => setVals({ ...vals, [f.k]: e.target.value })} inputMode={f.type === "number" ? "decimal" : "text"} className={`w-full rounded border bg-background px-1.5 py-1 font-mono text-xs ${r.err ? "border-destructive" : "border-input"}`} title={r.err ?? f.formula} />
          </label>); })}
      </div>
      <div className="mt-2 flex justify-end gap-1.5">
        {mod && <button onClick={() => resetItem(item.key)} className="rounded border border-border px-2 py-1 text-[11px] font-bold">Restaurar</button>}
        <button disabled={bad} onClick={() => saveItem(item.key, Object.fromEntries(checks.map(([f, r]) => [f.k, r.v])))} className="rounded bg-primary px-3 py-1 text-[11px] font-bold text-primary-foreground disabled:opacity-50">Salvar no jogo</button>
      </div>
    </div>
  );
}

function Card({ title, sub, chips, children, edit }: { title: string; sub: string; chips: [string, string][]; children: React.ReactNode; edit: Item[] }) {
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<"ler" | "editar">("ler");
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card">
      <button onClick={() => setOpen(!open)} className="flex w-full items-center gap-3 px-3 py-2 text-left">
        <div className="min-w-0 flex-1"><p className="truncate text-sm font-bold">{title}</p><p className="truncate text-[10px] text-muted-foreground">{sub}</p></div>
        <div className="hidden gap-1 sm:flex">{chips.map(([k, v]) => <span key={k} className="rounded bg-secondary px-1.5 py-0.5 font-mono text-[10px]"><span className="text-muted-foreground">{k} </span><b>{v}</b></span>)}</div>
        <ChevronDown className={`h-4 w-4 shrink-0 transition ${open ? "rotate-180" : ""}`} />
      </button>
      <div className="grid grid-cols-4 gap-1 px-3 pb-2 sm:hidden">{chips.map(([k, v]) => <div key={k} className="rounded bg-secondary px-1 py-0.5 text-center"><p className="text-[8px] text-muted-foreground">{k}</p><p className="font-mono text-[10px] font-bold">{v}</p></div>)}</div>
      {open && (
        <div className="space-y-2 border-t border-border p-2">
          <div className="flex gap-1">
            {([["ler", "Leitura", Eye], ["editar", "Edição", Pencil]] as const).map(([id, l, I]) => (
              <button key={id} onClick={() => setMode(id)} className={`flex items-center gap-1 rounded-md px-2.5 py-1 text-[11px] font-bold ${mode === id ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`}><I className="h-3 w-3" />{l}</button>))}
          </div>
          {mode === "ler" ? children : <div className="space-y-2">{edit.map((i) => <InlineEdit key={i.key} item={i} />)}</div>}
        </div>
      )}
    </div>
  );
}

export function MecanicoDossier() {
  const [full, setFull] = useState(true);
  const [chat, setChat] = useState(false);
  Ctx.full = full;
  const items = categories().find((c) => c.id === "mecanico")?.items ?? [];
  const stocks = useMemo(() => BIKES.map((b) => sheet(b, STOCK_SETUP)), []);
  const kitS = useMemo(() => kitSetup(), []);
  const kitX = useMemo(() => sheet(TITAN_160, kitS), [kitS]);
  const kit = PARTS_CATALOG.find((p) => p.id === KIT4)!;
  const pieces = [...kit4Pieces().map((id) => partById(id)).filter((p) => !!p), PARTS_CATALOG.find((p) => p.id === `comando-${kit.bundle!.cam}`)].filter((p): p is NonNullable<typeof p> => !!p);
  const bySys = new Map<string, typeof pieces>();
  for (const p of pieces) { const g = (SLOT_LABEL as Record<string, string>)[p.kind] ?? p.kind; bySys.set(g, [...(bySys.get(g) ?? []), p]); }
  const t0 = stocks[0]!;
  const d = (a: number, c: number) => `${c >= a ? "+" : ""}${n(c - a)}`;
  const kitItems = items.filter((i) => i.group.startsWith("Kits"));
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-center gap-1.5 rounded-xl border border-border bg-card p-2">
        <p className="mr-auto text-[11px] font-bold uppercase tracking-widest text-muted-foreground">Mecânico · motos e kits</p>
        <button onClick={() => setFull(!full)} className="rounded-md bg-secondary px-2.5 py-1 text-[11px] font-bold">{full ? "Compactar" : "Mostrar fórmulas"}</button>
        <button onClick={() => setChat(!chat)} className="flex items-center gap-1 rounded-md bg-primary px-2.5 py-1 text-[11px] font-bold text-primary-foreground"><MessageSquare className="h-3 w-3" /> Bancada</button>
      </div>
      {chat && <div className="relative h-[60vh] overflow-hidden rounded-xl border border-border"><div className="absolute inset-0 [&>div]:h-full">{<CompetitionBench />}</div></div>}
      <p className="px-1 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Motos</p>
      {BIKES.map((b, i) => { const x = stocks[i]!; return (
        <Card key={b.id} title={b.name} sub={`${b.engine} · ${b.cooling} · ${b.valves} · ${b.gears} marchas`} chips={[["cv", n(x.e.hp)], ["N·m", n(x.tq, 1)], ["kg", n(x.st.kg, 0)], ["402", x.t402 ? n(x.t402, 2) : "—"]]} edit={items.filter((it) => it.key === `bike:${b.id}`)}>
          <SheetView b={b} x={x} />
        </Card>); })}
      <p className="px-1 pt-1 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Kits</p>
      <Card title={kit.name} sub={`R$ ${n(kit.price, 0)} + montagem R$ ${n(KIT4_LABOR, 0)} · comando ${kit.bundle!.cam.toUpperCase()} · curso +2 mm`} chips={[["cv", `${n(kitX.e.hp)} (${d(t0.e.hp, kitX.e.hp)})`], ["corte", `${kitX.e.rpmLimit}`], ["402", n(kitX.t402 ?? 0, 2)], ["afin", `${Math.round(kitX.af.pct)}%`]]} edit={kitItems}>
        <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
          {[...bySys].map(([g, list]) => (
            <Block key={g} t={g}>{list.map((p) => <Row key={p.id} l={`${p.name}${p.brand ? " · " + p.brand : ""}`} v={p.price ? `R$ ${n(p.price, 0)}` : "—"} f={[p.spec, p.cc ? `${p.cc} cc` : "", p.flow ? `vazão ${p.flow}` : "", p.clutchNm ? `${p.clutchNm} N·m` : ""].filter(Boolean).join(" · ") || undefined} o="ficha" />)}</Block>))}
        </div>
        <p className="pt-1 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Titan 160 com o kit montado</p>
        <SheetView b={TITAN_160} x={kitX} />
      </Card>
    </div>
  );
}
