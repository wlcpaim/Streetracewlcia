// NEXUS UPDATE: catálogo vivo de tudo que está no jogo. Edições ficam em cloudStore e são aplicadas
// in-place nos objetos reais (peças, serviços, motos, mapa, trampos, dinamômetro), então valem em todas as telas.
import { cloudStore } from "@/game/cloud/cloud-store";
import { PARTS_CATALOG, SLOT_LABEL, type Part } from "../parts";
import { SERVICES, SERVICE_GROUPS, TITAN_160, FACTOR_150, PARTS as REMOVABLE, AIR_FILTER, AIRBOX, type BikeModel, BIKE_MODELS } from "../physics";
import { WORK_RATE, WORK_REQ, PAY_PER_KM, MAX_KM, MAX_TRIP_S, ACAI_MAX_KM } from "../trampo";
import { SPOTS, WORK_DESC } from "../screens/Mapa";
import { DYNO } from "./dyno-config";

export const NU_KEY = "streetrace-nexus-update-v1";
export type FieldType = "text" | "number";
export interface Field { k: string; label: string; type: FieldType; unit?: string; formula?: string; min?: number; max?: number }
export interface Item { key: string; name: string; group: string; obj: Record<string, unknown>; fields: Field[] }
export interface Category { id: string; label: string; desc: string; items: Item[] }
type Overrides = Record<string, Record<string, string | number>>;

const F = {
  name: { k: "name", label: "Nome", type: "text" } as Field,
  price: { k: "price", label: "Preço", type: "number", unit: "R$", min: 0, formula: "preço exibido = price × câmbio (economy.priceNow)" } as Field,
  hpMul: { k: "hpMul", label: "Multiplicador de potência", type: "number", unit: "×", min: 0.5, max: 3, formula: "engine().hp = base × Π hpMul" } as Field,
  rpmPeak: { k: "rpmPeak", label: "Desloc. do pico", type: "number", unit: "rpm", min: -3000, max: 3000, formula: "rpmPeak = base + Σ rpmPeak" } as Field,
  need: { k: "need", label: "Demanda de combustível", type: "number", min: 0, max: 2, formula: "demanda = 1 + Σ need → mistura (mixFactor)" } as Field,
  stress: { k: "stress", label: "Carga mecânica", type: "number", min: 0, max: 200, formula: "stress() soma carga → risco de quebra" } as Field,
  relief: { k: "relief", label: "Alívio de carga", type: "number", min: 0, max: 200, formula: "stress() subtrai relief" } as Field,
  kg: { k: "kg", label: "Peso vs original", type: "number", unit: "kg", min: -50, max: 50, formula: "stats().kg = moto + piloto + Σ kg + combustível" } as Field,
};

const partFields = (p: Part): Field[] => {
  const f: Field[] = [F.name, { k: "brand", label: "Marca", type: "text" }, { k: "spec", label: "Especificação", type: "text" }];
  if (!p.factory) f.push(F.price);
  f.push(F.kg, F.hpMul, F.stress, F.relief, F.need);
  if (p.rpm !== undefined) f.push({ k: "rpm", label: "Rotação extra", type: "number", unit: "rpm", formula: "rpmLimit/rpmPeak += rpm" });
  if (p.cc !== undefined) f.push({ k: "cc", label: "Cilindrada", type: "number", unit: "cc", min: 50, max: 400, formula: "fluxo de escape ∝ cilindrada × rpm" });
  if (p.flow !== undefined) f.push({ k: "flow", label: "Vazão", type: "number", formula: "fuelChain: vazão do bico/bomba" });
  if (p.grip !== undefined) f.push({ k: "grip", label: "Aderência", type: "number", formula: "força máx = μ × grip × carga traseira" });
  if (p.clutchNm !== undefined) f.push({ k: "clutchNm", label: "Capacidade embreagem", type: "number", unit: "N·m", formula: "patina se torque > clutchNm" });
  if (p.front !== undefined) f.push({ k: "front", label: "Dentes pinhão", type: "number", unit: "T", min: 10, max: 20, formula: "relação final = coroa / pinhão" });
  if (p.rear !== undefined) f.push({ k: "rear", label: "Dentes coroa", type: "number", unit: "T", min: 30, max: 60, formula: "relação final = coroa / pinhão" });
  return f;
};
const bikeFields: Field[] = [
  F.name, { k: "price", label: "Preço", type: "number", unit: "R$", min: 0 },
  { k: "hpGas", label: "Potência gasolina", type: "number", unit: "cv", min: 1, max: 60, formula: "engine().hp base (gasolina)" },
  { k: "hpEth", label: "Potência etanol", type: "number", unit: "cv", min: 1, max: 60, formula: "engine().hp base (etanol)" },
  { k: "rpmPeak", label: "Pico de potência", type: "number", unit: "rpm", min: 4000, max: 14000, formula: "powerShape(rpm, rpmPeak)" },
  { k: "rpmLimit", label: "Corte", type: "number", unit: "rpm", min: 5000, max: 16000, formula: "limitador = rpmLimit + extras" },
  { k: "dryWeight", label: "Peso seco", type: "number", unit: "kg", min: 60, max: 250, formula: "a = F / (moto + piloto + combustível)" },
  { k: "tank", label: "Tanque", type: "number", unit: "L", min: 3, max: 30, formula: "peso combustível = L × densidade" },
  { k: "stockExhaustKg", label: "Peso escape original", type: "number", unit: "kg", min: 0, max: 20 },
  { k: "torqueGas", label: "Torque gasolina", type: "number", unit: "kgf·m", min: 0.3, max: 5, formula: "T = P / ω" },
  { k: "torqueEth", label: "Torque etanol", type: "number", unit: "kgf·m", min: 0.3, max: 5, formula: "T = P / ω" },
  { k: "rpmTorque", label: "Rotação de torque máx.", type: "number", unit: "rpm", min: 3000, max: 12000 },
  { k: "cc", label: "Cilindrada de fábrica", type: "number", unit: "cc", min: 50, max: 400, formula: "Vd = π/4 · D² · S" },
  { k: "topSpeed", label: "Velocidade máx. ficha", type: "number", unit: "km/h", min: 50, max: 250 },
  { k: "engine", label: "Motor", type: "text" }, { k: "tires", label: "Pneus", type: "text" },
];

let cats: Category[] | null = null;
const defaults = new Map<string, Record<string, unknown>>();

export function categories(): Category[] {
  if (cats) return cats;
  const parts: Item[] = PARTS_CATALOG.map((p) => ({ key: `part:${p.id}`, name: p.name, group: (SLOT_LABEL as Record<string, string>)[p.kind] ?? p.kind, obj: p as unknown as Record<string, unknown>, fields: partFields(p) }));
  const gl = new Map(SERVICE_GROUPS.map((g) => [g.id, g.label]));
  const svc: Item[] = SERVICES.map((s) => ({ key: `svc:${s.id}`, name: s.name, group: gl.get(s.group) ?? s.group, obj: s as unknown as Record<string, unknown>, fields: [F.name, F.price, F.hpMul, F.rpmPeak, F.need, F.stress, F.relief] }));
  const bikes: Item[] = BIKE_MODELS.map((b: BikeModel) => ({ key: `bike:${b.id}`, name: b.name, group: "Motos", obj: b as unknown as Record<string, unknown>, fields: bikeFields }));
  const rem: Item = { key: "garage:removiveis", name: "Peças removíveis (alívio de peso)", group: "Desmonte", obj: REMOVABLE as unknown as Record<string, unknown>, fields: [
    { k: "mirrors", label: "Retrovisores", type: "number", unit: "kg", min: 0, max: 10, formula: "kg total −= mirrors" },
    { k: "rabeta", label: "Rabeta", type: "number", unit: "kg", min: 0, max: 10, formula: "kg total −= rabeta" },
    { k: "frontBrake", label: "Freio dianteiro", type: "number", unit: "kg", min: 0, max: 10, formula: "kg total −= frontBrake" }] };
  const air: Item[] = [
    { key: "garage:filtro", name: "Filtro de ar removido", group: "Admissão", obj: AIR_FILTER as unknown as Record<string, unknown>, fields: [{ k: "hp", label: "Ganho", type: "number", unit: "cv", min: 0, max: 5 }, { k: "kg", label: "Peso", type: "number", unit: "kg", min: 0, max: 5 }] },
    { key: "garage:airbox", name: "Caixa de ar removida", group: "Admissão", obj: AIRBOX as unknown as Record<string, unknown>, fields: [{ k: "hp", label: "Ganho", type: "number", unit: "cv", min: 0, max: 5 }, { k: "kg", label: "Peso", type: "number", unit: "kg", min: 0, max: 5 }, { k: "need", label: "Demanda extra", type: "number", min: 0, max: 1, formula: "empobrece a mistura" }] },
  ];
  const spots: Item[] = SPOTS.map((s, i) => ({ key: `spot:${i}`, name: s.label, group: "Locais do mapa", obj: s as unknown as Record<string, unknown>, fields: [
    { k: "label", label: "Nome", type: "text" },
    { k: "x", label: "Posição X", type: "number", unit: "%", min: 0, max: 100 }, { k: "y", label: "Posição Y", type: "number", unit: "%", min: 0, max: 100 },
    { k: "w", label: "Largura", type: "number", unit: "%", min: 1, max: 100 }, { k: "h", label: "Altura", type: "number", unit: "%", min: 1, max: 100 }] }));
  const jobs: Item[] = Object.keys(WORK_RATE).map((id) => {
    const o = { get rate() { return WORK_RATE[id] ?? 0; }, set rate(v: number) { WORK_RATE[id] = v; }, get req() { return WORK_REQ[id] ?? 1; }, set req(v: number) { WORK_REQ[id] = v; }, get desc() { return WORK_DESC[id] ?? ""; }, set desc(v: string) { WORK_DESC[id] = v; } };
    return { key: `job:${id}`, name: id[0]!.toUpperCase() + id.slice(1), group: "Trampos", obj: o as unknown as Record<string, unknown>, fields: [
      { k: "desc", label: "Descrição", type: "text" },
      { k: "rate", label: "Pagamento base", type: "number", unit: "R$", min: 0, max: 1000, formula: "payRange = rate × ticketMul(nível)" },
      { k: "req", label: "Nível exigido", type: "number", min: 1, max: 100, formula: "liberado se nível ≥ req" }] };
  });
  const rules: Item = { key: "map:rotas", name: "Regras de rota", group: "Trampos", obj: { get payEntrega() { return PAY_PER_KM.entrega; }, set payEntrega(v: number) { PAY_PER_KM.entrega = v; }, get payTaxi() { return PAY_PER_KM.taxi; }, set payTaxi(v: number) { PAY_PER_KM.taxi = v; }, get kmEntrega() { return MAX_KM.entrega; }, set kmEntrega(v: number) { MAX_KM.entrega = v; }, get kmTaxi() { return MAX_KM.taxi; }, set kmTaxi(v: number) { MAX_KM.taxi = v; }, get sEntrega() { return MAX_TRIP_S.entrega; }, set sEntrega(v: number) { MAX_TRIP_S.entrega = v; }, get sTaxi() { return MAX_TRIP_S.taxi; }, set sTaxi(v: number) { MAX_TRIP_S.taxi = v; } } as unknown as Record<string, unknown>, fields: [
    { k: "payEntrega", label: "R$/km entrega", type: "number", unit: "R$", min: 0, formula: "jobPay = km × R$/km" }, { k: "payTaxi", label: "R$/km táxi", type: "number", unit: "R$", min: 0, formula: "jobPay = km × R$/km" },
    { k: "kmEntrega", label: "Km máx. entrega", type: "number", unit: "km", min: 1 }, { k: "kmTaxi", label: "Km máx. táxi", type: "number", unit: "km", min: 1 },
    { k: "sEntrega", label: "Tempo máx. entrega", type: "number", unit: "s", min: 10, formula: "jobSeconds = km/kmMax × tempoMax" }, { k: "sTaxi", label: "Tempo máx. táxi", type: "number", unit: "s", min: 10 }] };
  void ACAI_MAX_KM;
  const dyno: Item = { key: "dyno:varredura", name: "Varredura do dinamômetro", group: "Puxada", obj: { get rpmMin() { return DYNO.rpmMin; }, set rpmMin(v: number) { DYNO.rpmMin = v; }, get rpmStep() { return DYNO.rpmStep; }, set rpmStep(v: number) { DYNO.rpmStep = v; }, get d1() { return DYNO.distances[0] ?? 0; }, set d1(v: number) { DYNO.distances[0] = v; }, get d2() { return DYNO.distances[1] ?? 0; }, set d2(v: number) { DYNO.distances[1] = v; }, get d3() { return DYNO.distances[2] ?? 0; }, set d3(v: number) { DYNO.distances[2] = v; } } as unknown as Record<string, unknown>, fields: [
    { k: "rpmMin", label: "Rotação inicial", type: "number", unit: "rpm", min: 1000, max: 9000, formula: "curva de rpmMin até rpmLimit" },
    { k: "rpmStep", label: "Passo da curva", type: "number", unit: "rpm", min: 50, max: 1000, formula: "hp(rpm) = hp × powerShape × mixFactor × exhaustShape; tq = hp·735,5/ω/9,81" },
    { k: "d1", label: "Distância 1", type: "number", unit: "m", min: 50, max: 50000 }, { k: "d2", label: "Distância 2", type: "number", unit: "m", min: 50, max: 50000 }, { k: "d3", label: "Distância 3", type: "number", unit: "m", min: 50, max: 50000 }] };
  const kitIds = PARTS_CATALOG.filter((p) => p.bundle && p.id.endsWith("-pino"));
  const kits: Item[] = kitIds.flatMap((k) => {
    const b = k.bundle!;
    const ids = [k.id, "cilindro-4mm", b.pistao, b.biela, b.bico, b.modulo, b.molas, b.bomba, "embreagem-p21-grau", `comando-${b.cam}`].filter((x): x is string => !!x);
    return [...new Set(ids)].map((id) => parts.find((x) => x.key === `part:${id}`)).filter((x): x is Item => !!x)
      .map((it) => ({ ...it, group: it.key === `part:${k.id}` ? "Kit completo" : "Peças que vêm no kit" }));
  });
  cats = [
    { id: "mecanico", label: "MECÂNICO", desc: "Motos cadastradas e kits completos com suas peças", items: [...bikes.map((i) => ({ ...i, group: `Motos · ${i.group}` })), ...kits.map((i) => ({ ...i, group: `Kits · ${i.group}` }))] },
    { id: "mapa", label: "Mapa", desc: "Locais, trampos e regras de rota", items: [...spots, ...jobs, rules] },
    { id: "garagem", label: "Garagem", desc: "Desmonte e admissão", items: [rem, ...air] },
    { id: "oficina", label: "Oficina", desc: "Serviços de usinagem e montagem", items: svc },
    { id: "dino", label: "Dinamômetro", desc: "Parâmetros da puxada e curva", items: [dyno] },
    { id: "pecas", label: "Peças", desc: "Todas as peças do jogo", items: parts },
  ];
  for (const c of cats) for (const it of c.items) defaults.set(it.key, Object.fromEntries(it.fields.map((f) => [f.k, it.obj[f.k]])));
  return cats;
}

export const defaultOf = (key: string, k: string) => defaults.get(key)?.[k];
export function readOverrides(): Overrides {
  if (typeof window === "undefined") return {};
  try { return JSON.parse(cloudStore.getItem(NU_KEY) ?? "{}") as Overrides; } catch { return {}; }
}
const listeners = new Set<() => void>();
export const subscribe = (f: () => void) => { listeners.add(f); return () => listeners.delete(f); };
let ver = 0;
export const version = () => ver;

/** Restores defaults then applies every stored override onto the live game objects. */
export function applyNexusOverrides() {
  const all = categories(); const ov = readOverrides();
  for (const c of all) for (const it of c.items) {
    const d = defaults.get(it.key)!;
    for (const f of it.fields) { const v = ov[it.key]?.[f.k] ?? d[f.k]; if (v === undefined) delete it.obj[f.k]; else it.obj[f.k] = v; }
  }
  ver++; listeners.forEach((l) => l());
}
export function saveItem(key: string, values: Record<string, string | number | undefined>) {
  const ov = readOverrides(); const d = defaults.get(key) ?? {}; const out: Record<string, string | number> = {};
  for (const [k, v] of Object.entries(values)) if (v !== undefined && v !== d[k]) out[k] = v;
  if (Object.keys(out).length) ov[key] = out; else delete ov[key];
  cloudStore.setItem(NU_KEY, JSON.stringify(ov)); applyNexusOverrides();
}
export function resetItem(key: string) { const ov = readOverrides(); delete ov[key]; cloudStore.setItem(NU_KEY, JSON.stringify(ov)); applyNexusOverrides(); }
export function resetAll() { cloudStore.removeItem(NU_KEY); applyNexusOverrides(); }
/** Validates a value against field limits; returns an error message or null. */
export function validate(f: Field, raw: string): { v?: string | number | undefined; err?: string } {
  if (f.type === "text") return raw.trim() ? { v: raw.trim() } : { err: "Não pode ficar vazio" };
  if (raw.trim() === "") return { v: undefined };
  const n = Number(raw.replace(",", "."));
  if (!Number.isFinite(n)) return { err: "Número inválido" };
  if (f.min !== undefined && n < f.min) return { err: `Mínimo ${f.min}` };
  if (f.max !== undefined && n > f.max) return { err: `Máximo ${f.max}` };
  return { v: n };
}
