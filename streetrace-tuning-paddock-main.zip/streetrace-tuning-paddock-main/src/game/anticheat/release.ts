// Versão de protocolo do jogo. Suba PROTOCOL quando cliente antigo e servidor novo não puderem jogar juntos
// (regras de corrida, formato de save). CRITICAL = true força atualização com prioridade (correção de segurança).
export const RELEASE = { protocol: 1, minProtocol: 1, critical: false } as const;
