// RealGear Anticheat: confere a versão oficial (consulta periódica + aviso em tempo real + foco da aba).
// Build novo → preload "Atualização detectada", salva na nuvem e recarrega sozinho em momento seguro.
import { useSyncExternalStore } from "react";
import { canApplyIn, classify, manifestSig, needsUpdate, parseManifest, UPDATE_POLL_MS, type Manifest } from "./update-rules";
import { RELEASE } from "./release";
import { flushNow } from "../cloud/cloud-store";

const TRIED_KEY = "realgear-update-tried";
const CHANNEL = "streetrace-version";
let pending: { build: string; critical: boolean } | null = null;
let applying = false;
const subs = new Set<() => void>();
const emit = () => subs.forEach((f) => f());
export const useUpdatePending = () => useSyncExternalStore((f) => (subs.add(f), () => subs.delete(f)), () => pending?.build ?? null, () => null);
export const isApplyingUpdate = () => applying;
/** Atualização crítica pendente: bloqueia entrar em novas corridas. */
export const isCriticalPending = () => !!pending?.critical;
const local = { build: __BUILD_ID__, builtAt: __BUILD_TIME__, protocol: RELEASE.protocol };
export const clientVersion = () => ({ build: local.build, protocol: local.protocol });

const tried = () => { try { return sessionStorage.getItem(TRIED_KEY); } catch { return null; } };
let announce: ((b: string) => void) | null = null;

/** Sempre confirma no servidor: um aviso em tempo real nunca é aceito sozinho. */
export async function check() {
  if (pending || applying) return;
  try {
    const r = await fetch(`/api/public/version?t=${Date.now()}`, { cache: "no-store" });
    if (!r.ok) return;
    const m = parseManifest(await r.json());
    const ok = !!m && (await manifestSig(m)) === m.sig;
    const v = classify(local, m as Manifest | null, ok);
    if (v === "invalido") { console.warn("[anticheat] manifesto inválido ignorado"); return; }
    if (v === "downgrade") { console.warn("[anticheat] build mais antigo no servidor, sem downgrade"); return; }
    if (v === "atual" || !needsUpdate(local.build, m!.build, tried())) return;
    pending = { build: m!.build, critical: v === "critica" }; emit();
    announce?.(m!.build);
  } catch { /* sem rede: tenta na próxima */ }
}

let started = false;
export function startUpdateWatch() {
  if (started || typeof window === "undefined") return;
  started = true;
  void check();
  setInterval(() => void check(), UPDATE_POLL_MS);
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible") void check(); });
  window.addEventListener("focus", () => void check());
  window.addEventListener("online", () => void check());
  // tempo real: quem vê o build novo avisa os outros; cada um reconfere no servidor
  void import("@/integrations/supabase/client").then(({ supabase }) => {
    const ch = supabase.channel(CHANNEL).on("broadcast", { event: "build" }, () => void check());
    ch.subscribe((st) => { if (st === "SUBSCRIBED") void check(); });
    announce = (b) => void ch.send({ type: "broadcast", event: "build", payload: { build: b } });
  }).catch(() => { /* sem realtime: fica a consulta periódica */ });
}

/** Aplica se a cena permitir: salva tudo e recarrega para o build novo (uma tentativa por build). */
export async function applyUpdate(scene: string, onStart?: () => void): Promise<boolean> {
  if (!pending || applying || !canApplyIn(scene)) return false;
  applying = true; emit();
  onStart?.();
  try { sessionStorage.setItem(TRIED_KEY, pending.build); } catch { /* sem storage */ }
  try { await flushNow(); } catch { /* salva o que der */ }
  await new Promise((r) => setTimeout(r, 1200));
  window.location.reload();
  return true;
}
