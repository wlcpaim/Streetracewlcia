// Regras puras da detecção de atualização do RealGear Anticheat (sem rede, testáveis).
export const UPDATE_POLL_MS = 30_000;
/** Cenas que atualização normal nunca interrompe. */
export const UPDATE_BLOCKED_SCENES = ["race", "dino"] as const;

export type Manifest = { build: string; builtAt: number; protocol: number; minProtocol: number; critical: boolean; sig: string };
export type Local = { build: string; builtAt: number; protocol: number };
export type Verdict = "atual" | "normal" | "critica" | "invalido" | "downgrade";

/** Assinatura de integridade do manifesto: SHA-256 dos campos em ordem fixa. */
export async function manifestSig(m: Omit<Manifest, "sig">): Promise<string> {
  const txt = `${m.build}|${m.builtAt}|${m.protocol}|${m.minProtocol}|${m.critical ? 1 : 0}`;
  const h = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(txt));
  return [...new Uint8Array(h)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

export function parseManifest(x: unknown): Omit<Manifest, "sig"> & { sig: string } | null {
  const m = x as Partial<Manifest> | null;
  if (!m || typeof m.build !== "string" || !/^[a-z0-9]{4,20}$/.test(m.build)) return null;
  if (typeof m.builtAt !== "number" || !Number.isFinite(m.builtAt) || m.builtAt <= 0) return null;
  if (!Number.isInteger(m.protocol) || !Number.isInteger(m.minProtocol) || typeof m.critical !== "boolean" || typeof m.sig !== "string") return null;
  return m as Manifest;
}

/** Compara o build rodando com o oficial. Build mais antigo no servidor = downgrade, ignorado. */
export function classify(local: Local, m: Manifest | null, sigOk: boolean): Verdict {
  if (!m || !sigOk) return "invalido";
  if (m.build === local.build) return "atual";
  if (m.builtAt < local.builtAt) return "downgrade";
  if (m.critical || local.protocol < m.minProtocol) return "critica";
  return "normal";
}

/** Tenta cada build novo uma só vez por aba: evita loop de recarga. */
export function needsUpdate(mine: string, server: string | null | undefined, lastTried: string | null): boolean {
  if (!server || server === mine) return false;
  return server !== lastTried;
}
export const canApplyIn = (scene: string) => !(UPDATE_BLOCKED_SCENES as readonly string[]).includes(scene);
/** Servidor: cliente pode entrar em partida protegida? Desatualizado ≠ trapaça: só recusa e pede atualização. */
export const clientCompatible = (clientProtocol: number | undefined, minProtocol: number) => (clientProtocol ?? 0) >= minProtocol;
