// Análise de compatibilidade/anticheat ao equipar: 2,5 s e então instala ou recusa.
import { useSyncExternalStore } from "react";
import { partById } from "./parts";
import { compatOf } from "./platform/compat";
import { notify } from "./jobrun";
import { getPlayer } from "./store";
import { pinDe } from "./pins/pins";

export const EQUIP_CHECK_MS = 2500;
export type EquipCheckState = { name: string; phase: "busy" | "ok" | "fail" };
let busy: EquipCheckState | null = null;
export const EQUIP_RESULT_MS = 900;
const subs = new Set<() => void>();
const emit = () => subs.forEach((f) => f());

/** Resultado da análise: null = compatível, string = motivo da recusa. */
export function equipVerdict(partId: string, bikeId: string, slots?: Partial<Record<string, string>>): string | null {
  const part = partById(partId);
  if (!part) return null;
  const c = compatOf(part, bikeId);
  if (c.c === "INCOMPATIVEL") return c.motivo;
  if (part.springRpm) return "molas e kit de válvula só são montados na Oficina (Montagem)";
  return pinVerdict(part.kind, partId, bikeId, slots ?? getPlayer()?.setup.slots);
}

/** Pistão e biela precisam do mesmo Ø de pino (olhal da biela = alojamento do pistão). */
export function pinVerdict(kind: string, partId: string, bikeId: string, slots?: Partial<Record<string, string>>): string | null {
  if (kind !== "pistao" && kind !== "biela") return null;
  const other = kind === "pistao" ? slots?.["biela"] : slots?.["pistao"];
  const mine = pinDe(partId, bikeId), theirs = pinDe(other ?? (kind === "pistao" ? "biela-original" : "pistao-original"), bikeId);
  if (mine == null || theirs == null || mine === theirs) return null;
  return kind === "pistao" ? `pino do pistão ${mine} mm não entra na biela montada (${theirs} mm)` : `olhal da biela ${mine} mm não serve no pino do pistão montado (${theirs} mm)`;
}

export function runEquipCheck(partId: string, bikeId: string, apply: () => void) {
  if (busy) return;
  const name = partById(partId)?.name ?? partId;
  busy = { name, phase: "busy" };
  emit();
  setTimeout(() => {
    const why = equipVerdict(partId, bikeId);
    busy = { name, phase: why ? "fail" : "ok" };
    emit();
    if (why) notify(`Peça incompatível · ${why}`);
    else { apply(); notify("Peça compatível · instalada", "ok"); }
    setTimeout(() => { busy = null; emit(); }, EQUIP_RESULT_MS);
  }, EQUIP_CHECK_MS);
}

export const useEquipCheck = () => useSyncExternalStore((f) => (subs.add(f), () => subs.delete(f)), () => busy, () => null);
