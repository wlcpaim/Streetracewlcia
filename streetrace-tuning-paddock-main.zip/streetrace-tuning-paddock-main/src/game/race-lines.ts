// Invisible race lines (Bololo). Track coordinates are metres: x = longitudinal (centre of the bike),
// l = lane position 0..1 (4 lines, LINE_SPACING_M apart). Hitbox = axle A (front) to axle B (rear), independent
// of the sprite size. The 4 m margin only steers lane decisions: it never changes speed (no invisible wall),
// so slipstream approach behind a leader is always allowed; only lateral moves into someone's box are refused.
import { AXLE_A_M, AXLE_B_M, DRAFT_GAP } from "./physics";

/** 8 operable lines; the space between them is only crossed smoothly (never a teleport). */
export const LINE_COUNT = 8;
export const LINES = [0, 1 / 7, 2 / 7, 3 / 7, 4 / 7, 5 / 7, 6 / 7, 1] as const;
/** Lane fraction of one line step. */
export const LINE_STEP = 1 / (LINE_COUNT - 1);
/** Lateral distance (m) between two neighbouring lines. */
export const LINE_SPACING_M = 5;
/** Safety margin (m) front, rear, left and right of every hitbox. */
export const MARGIN_M = 3;
export const SAFE_LATERAL_M = 5;
export const SAFE_AXLE_GAP_M = MARGIN_M;
/** Hitbox length (m): front axle A to rear axle B. */
export const HITBOX_M = AXLE_A_M - AXLE_B_M;
/** Same-line centre distance (m) that keeps MARGIN_M between the hitboxes. */
export const SAFE_GAP_M = SAFE_AXLE_GAP_M + HITBOX_M;
/** Bololo start hold: nobody leaves its line before this many seconds of racing. */
export const HOLD_S = 3;

export interface Rider { x: number; l: number; v?: number }

export const lateralM = (a: number, b: number) => Math.abs(a - b) * (LINE_COUNT - 1) * LINE_SPACING_M;
/** Lateral tolerance (m) for "100% aligned" on the same operable line (slipstream). */
export const ALIGN_M = 0.25;
/** Same lane for slipstream: both fully aligned on the same line; leaving it loses the draft at once. */
export const sameLane = (a: number, b: number) => lateralM(a, b) < ALIGN_M;

/** Inside each other's 3 m safety box (lateral AND longitudinal). */
export const touching = (a: Rider, b: Rider) =>
  lateralM(a.l, b.l) < SAFE_LATERAL_M - 1e-9 && Math.abs(a.x - b.x) < SAFE_GAP_M;
/** Real hitbox overlap (physical contact). */
export const overlap = (a: Rider, b: Rider) => lateralM(a.l, b.l) < 1 && Math.abs(a.x - b.x) < HITBOX_M;

export function released(t: number, riders: Rider[]): boolean {
  if (t < HOLD_S) return false;
  for (let i = 0; i < riders.length; i++) for (let j = i + 1; j < riders.length; j++) if (touching(riders[i]!, riders[j]!)) return false;
  return true;
}

/** Anti-collision guard: a lateral move is kept only if it enters nobody's safety box (moves are reserved in order). */
export function guard(prev: number[], next: number[], xs: number[]): number[] {
  const out = [...prev];
  next.forEach((l, i) => {
    if (l === prev[i]) return;
    // endpoint must be free AND the path may not cross a bike alongside (no sprite passes through another)
    const lo = Math.min(prev[i]!, l), hi = Math.max(prev[i]!, l);
    const ok = out.every((lj, j) => j === i || (!touching({ x: xs[i]!, l }, { x: xs[j]!, l: lj }) && !(lj > lo && lj < hi && Math.abs(xs[i]! - xs[j]!) < SAFE_GAP_M)));
    if (ok) out[i] = l;
  });
  return out;
}

/** Gap (m) from follower front axle A to leader rear axle B. */
export const axleGap = (f: Rider, lead: Rider) => lead.x + AXLE_B_M - (f.x + AXLE_A_M);

export interface DraftLink { leader: number; follower: number; gap: number }
/** Slipstream links: same lane, follower fully behind within DRAFT_GAP; each leader feeds only its closest follower. */
export function draftLinks(rs: Rider[]): DraftLink[] {
  const cand: DraftLink[] = [];
  rs.forEach((f, i) => rs.forEach((lead, j) => {
    if (i === j || !sameLane(f.l, lead.l)) return;
    const gap = axleGap(f, lead);
    if (gap >= 0 && gap <= DRAFT_GAP + 1e-9) cand.push({ leader: j, follower: i, gap });
  }));
  cand.sort((a, b) => a.gap - b.gap || a.leader - b.leader || a.follower - b.follower);
  const usedL = new Set<number>(), usedF = new Set<number>(), out: DraftLink[] = [];
  for (const c of cand) if (!usedL.has(c.leader) && !usedF.has(c.follower)) { usedL.add(c.leader); usedF.add(c.follower); out.push(c); }
  return out;
}

const free = (rs: Rider[], i: number, l: number, lanes: number[]) => rs.every((o, j) => j === i || !touching({ x: rs[i]!.x, l }, { x: o.x, l: lanes[j]! }));

/**
 * Cooperative lane plan: when a faster bike closes in behind a slower one in the same lane, the bike ahead
 * moves to the nearest safe line (never needed for the draft itself, which works behind). A bike beside the
 * follower that blocks it is also asked to move. No safe line = everybody keeps its line and waits.
 * Returns target lanes (reserved in order so two bikes never claim the same space).
 */
export function cooperate(rs: Rider[]): number[] {
  const lanes = rs.map((r) => r.l);
  const moved = new Set<number>();
  const relocate = (k: number) => {
    if (moved.has(k)) return false;
    const opts = LINES.filter((l) => !sameLane(l, lanes[k]!) && free(rs, k, l, lanes)).sort((a, b) => Math.abs(a - lanes[k]!) - Math.abs(b - lanes[k]!) || a - b);
    if (!opts.length) return false;
    lanes[k] = opts[0]!; moved.add(k); return true;
  };
  rs.forEach((f, i) => rs.forEach((lead, j) => {
    if (i === j || !sameLane(lanes[i]!, lanes[j]!)) return;
    const gap = axleGap({ ...f, l: lanes[i]! }, lead);
    const closing = (f.v ?? 0) > (lead.v ?? 0) + 0.3;
    if (gap >= 0 && gap <= DRAFT_GAP + 1e-9 && closing) {
      if (relocate(j)) return;
      // the leader is boxed in: a bike beside it may free a line first
      rs.forEach((_, k) => { if (k !== i && k !== j && !moved.has(k) && Math.abs(rs[k]!.x - lead.x) < SAFE_GAP_M && relocate(k)) relocate(j); });
    }
  }));
  return lanes;
}
