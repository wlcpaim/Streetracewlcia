// Admin lab: deterministic end-to-end test matrix over the real physics, with engine telemetry logs.
import { buildOf, mechStep, newMech } from "./mechlimits";
import { forensic } from "./mechanic";
import { collateral } from "./damage";
import { pericia, type Pericia } from "./pericia";
import { causaRaiz, fluxoWatcher, type CausaRaiz, type FluxoEvento } from "./rootcause";
import { DT, FACTOR_150, SERVICES, STOCK_ECU, STOCK_SETUP, TITAN_160, engine, exhaustShape, fuelFlow, mixFactor, newSim, powerShape, stalled, stats, step, stress, tireOf, type BikeModel, type Setup, BIKE_MODELS } from "./physics";
import { CAM_FX, CAM_LABEL, PARTS_CATALOG, SLOTS, TAXAS, partById, type Cam, type Slot } from "./parts";
import { TRACKS, displacement } from "./records";

export const BIKES: BikeModel[] = BIKE_MODELS;
export type LogPoint = { t: number; x: number; kmh: number; rpm: number; gear: number; hp: number; slip: number; spin: boolean; shifting: boolean; fuelL: number; flowLh: number; tucked: boolean };
export type RunResult = {
  id: string; group: string; label: string; bike: string; track: string; distanceM: number;
  setup: Setup; engine: ReturnType<typeof engine>; stats: ReturnType<typeof stats>; stress: ReturnType<typeof stress>; cc: number;
  result: { finishS: number | null; vmaxKmh: number; t0_60: number | null; t0_100: number | null; t100m: number | null; t500m: number | null; fuelUsedL: number; stalled: boolean; gearMaxKmh: number[]; spinS: number; slipS: number; shifts: number };
  engineLog?: LogPoint[];
  breakdown?: BreakReport | null;
  /** Real-time flow log: each moment a fuel/heat/rev limit was crossed, ending at the break. */
  fluxo?: FluxoEvento[];
  pericia?: Pericia | null;
};
export type BreakReport = {
  cause: string; fisica?: string; telemetria?: import("./mechlimits").MechTelemetry; riskPct: number; atM: number; atS: number; rpm: number; gear: number; kmh: number;
  oQueAconteceu: string; porQue: string; comoEvitar: string;
  fatores: { motivo: string; peso: number; pct: number; quebra: string }[];
  danos: ReturnType<typeof collateral>;
  causaRaiz: CausaRaiz;
};

const r3 = (n: number) => Math.round(n * 1000) / 1000;
const isSlot = (k: string): k is Slot => (SLOTS as string[]).includes(k);

/** Runs one race with the real step() and records the engine every `every` seconds. */
export function runTest(b: BikeModel, s: Setup, distance: number, meta: { id: string; group: string; label: string; track: string }, log = true, every = 0.1, maxPts = 400): RunResult {
  const st = newSim(b.tank);
  const e = engine(b, s);
  const pts: LogPoint[] = [];
  let next = 0, spinS = 0, slipS = 0, shifts = 0, gear = 1;
  const ms = newMech();
  const kb = buildOf(b, s);
  let broke: BreakReport | null = null;
  const flow = fluxoWatcher(b, s);
  while (st.finishT === null && !stalled(st) && st.t < 900) {
    const f0 = st.fuel;
    step(st, b, s, DT, distance);
    flow.tick(st.t, st.x, st.gear, st.rpm, st.shiftT > 0 ? 0 : 1 - st.slip * 0.5, DT);
    const bp = mechStep(ms, st, b, s, kb, DT);
    if (bp) {
      broke = { ...breakReport(b, s, bp.cause, st), fisica: bp.fisica, telemetria: bp.tel };
      flow.events.push({ t: r3(st.t), x: r3(st.x), gear: st.gear, rpm: Math.round(st.rpm), evento: `QUEBROU: ${bp.cause} · ${bp.fisica}` });
      break;
    }
    if (st.spin) spinS += DT;
    if (st.slip > 0) slipS += DT;
    if (st.gear !== gear) { shifts++; gear = st.gear; }
    if (log && st.t >= next) {
      const shape = powerShape(st.rpm, e.rpmPeak, b, s) * mixFactor(s, st.rpm, e.rpmPeak) * exhaustShape(b, s, st.rpm, e.rpmPeak);
      pts.push({ t: r3(st.t), x: r3(st.x), kmh: r3(st.v * 3.6), rpm: Math.round(st.rpm), gear: st.gear, hp: st.shiftT > 0 ? 0 : r3(e.hp * shape * (1 - st.slip)), slip: r3(st.slip), spin: !!st.spin, shifting: st.shiftT > 0, fuelL: r3(st.fuel), flowLh: r3(((f0 - st.fuel) / DT) * 3600), tucked: !!st.tucked });
      next += every;
    }
  }
  const thin = pts.length > maxPts ? pts.filter((_, i) => i % Math.ceil(pts.length / maxPts) === 0) : pts;
  return {
    ...meta, bike: b.name, distanceM: distance, setup: s, engine: e, stats: stats(b, s, b.tank), stress: stress(b, s), cc: displacement(s, b.id),
    result: { finishS: broke || st.finishT === null ? null : r3(st.finishT), vmaxKmh: r3(st.top), t0_60: st.t60 && r3(st.t60), t0_100: st.t100 && r3(st.t100), t100m: st.t100m && r3(st.t100m), t500m: st.t500m && r3(st.t500m), fuelUsedL: r3(b.tank - st.fuel), stalled: stalled(st), gearMaxKmh: st.gearMax.map(r3), spinS: r3(spinS), slipS: r3(slipS), shifts },
    ...(log ? { engineLog: thin } : {}),
    fluxo: flow.events,
    breakdown: broke,
    pericia: broke ? pericia(b, s, distance, { label: meta.label, cause: broke.cause, atM: broke.atM, rpm: broke.rpm, gear: broke.gear, fuelUsedL: r3(b.tank - st.fuel), tail: pts.slice(-20), fluxo: flow.events, calorPistao: flow.heat() }) : null,
  };
}

/** Plain-language laudo of a break: where, why, and which choices loaded the engine. */
export function breakReport(b: BikeModel, s: Setup, cause: string, st: ReturnType<typeof newSim>): BreakReport {
  const x = stress(b, s), f = forensic(cause), tot = x.causes.reduce((n, c) => n + c.load, 0) || 1;
  return {
    cause, riskPct: Math.round(x.risk * 100), atM: r3(st.x), atS: r3(st.t), rpm: Math.round(st.rpm), gear: st.gear, kmh: r3(st.v * 3.6),
    oQueAconteceu: f.found, porQue: f.why, comoEvitar: f.prevent,
    fatores: x.causes.map((c) => ({ motivo: c.src || c.cause, peso: c.load, pct: Math.round((c.load / tot) * 100), quebra: c.cause })),
    danos: collateral(cause, s.km),
    causaRaiz: causaRaiz(b, s, cause, st.rpm),
  };
}

const withSlot = (slot: Slot, id: string): Setup => ({ ...STOCK_SETUP, slots: { ...STOCK_SETUP.slots, [slot]: id } });
const PROG = { ...STOCK_ECU, rpm: 10500, timing: 2, launch: 7500, qs: 60, shift: [10200, 10200, 10200, 10200] };

/** Every scenario of the matrix: stock, each part alone, cams, heads, sprockets, fuels, psi, services, full stages. */
export function scenarios(): { id: string; group: string; label: string; setup: Setup }[] {
  const out: { id: string; group: string; label: string; setup: Setup }[] = [{ id: "stock", group: "Original", label: "Moto original", setup: STOCK_SETUP }];
  for (const p of PARTS_CATALOG) {
    if (isSlot(p.kind) && !p.id.endsWith("-original")) out.push({ id: `peca:${p.id}`, group: `Peça · ${p.kind}`, label: `${p.brand} ${p.name}`, setup: withSlot(p.kind, p.id) });
    if (p.kind === "pinhao" && p.front) out.push({ id: `peca:${p.id}`, group: "Relação", label: `Pinhão ${p.front}`, setup: { ...STOCK_SETUP, front: p.front } });
    if (p.kind === "coroa" && p.rear) out.push({ id: `peca:${p.id}`, group: "Relação", label: `Coroa ${p.rear}`, setup: { ...STOCK_SETUP, rear: p.rear } });
  }
  for (const c of Object.keys(CAM_FX) as Cam[]) if (c !== "original") out.push({ id: `cam:${c}`, group: "Comando", label: CAM_LABEL[c], setup: { ...STOCK_SETUP, cam: c } });
  for (const t of TAXAS) out.push({ id: `taxa:${t.taxa}`, group: "Cabeçote", label: `Taxa ${t.taxa}:1`, setup: { ...STOCK_SETUP, compression: t.taxa } });
  for (const sv of SERVICES) if (!sv.install && !sv.requires) out.push({ id: `serv:${sv.id}`, group: "Oficina", label: sv.name, setup: { ...STOCK_SETUP, services: [sv.id] } });
  for (const psi of [20, 24, 32, 36]) out.push({ id: `psi:${psi}`, group: "Pneu", label: `${psi} psi`, setup: { ...STOCK_SETUP, psi } });
  out.push({ id: "fuel:etanol", group: "Combustível", label: "Etanol", setup: { ...STOCK_SETUP, fuel: "etanol" } });
  out.push({ id: "fuel:podium", group: "Combustível", label: "Podium", setup: { ...STOCK_SETUP, blend: { podium: 1 } } });
  out.push({ id: "fuel:metanol50", group: "Combustível", label: "Etanol + 50% metanol", setup: { ...STOCK_SETUP, fuel: "etanol", blend: { etanol: 0.5, metanol: 0.5 } } });
  out.push({ id: "leve", group: "Chassi", label: "Desmontada + sem filtro", setup: { ...STOCK_SETUP, removed: { mirrors: true, rabeta: true, frontBrake: true }, airFilter: "sem" } });
  const has = (id: string) => (partById(id) ? id : undefined);
  const pick = (slot: Slot, ...ids: string[]) => ids.map(has).find(Boolean) ?? `${slot}-original`;
  const street: Setup = { ...STOCK_SETUP, airFilter: "sem", removed: { mirrors: true, rabeta: true, frontBrake: true }, slots: { ...STOCK_SETUP.slots, escape: pick("escape", "escape-dore") }, cam: "mb63", front: 15, rear: 46 };
  const k190: Setup = { ...street, fuel: "etanol", compression: 11.5, cam: "ma66", slots: { ...street.slots, cilindro: pick("cilindro", "cilindro-4mm"), pistao: pick("pistao", "pistao-forjado") }, services: ["dutos", "valv-3ang", "brunimento"] };
  const k220: Setup = { ...k190, compression: 12.5, cam: "a72", slots: { ...k190.slots, cilindro: pick("cilindro", "cilindro-220"), biela: pick("biela", "biela-vira"), molas: pick("molas", "molas-pratos") }, services: ["dutos", "dutos-escape", "valv-3ang", "brunimento", "pino-2", "tbi-36", "cavas-pistao", "balanceamento"] };
  const fl: Setup = { ...k220, compression: 13.5, cam: "a75", slots: { ...k220.slots, modulo: PARTS_CATALOG.find((p) => p.kind === "modulo" && /prog|athlon/i.test(p.id + p.name))?.id ?? k220.slots.modulo, tbi: pick("tbi", "tbi-36"), bico: pick("bico", "bico-alta") }, services: [...k220.services.filter((x) => x !== "pino-2"), "pino-4"], ecu: PROG };
  out.push({ id: "estagio:street", group: "Estágio", label: "Street leve", setup: street }, { id: "estagio:190", group: "Estágio", label: "Kit 190cc", setup: k190 }, { id: "estagio:220", group: "Estágio", label: "Kit 220cc + pino 2", setup: k220 }, { id: "estagio:fl", group: "Estágio", label: "Força Livre (pino 4, Athlon)", setup: fl });
  return out;
}

/** Full matrix: every scenario × every bike × every track. Engine log kept per run (thinned). */
export function runSuite(onProgress?: (done: number, total: number) => void, logPts = 60) {
  const sc = scenarios();
  const runs: RunResult[] = [];
  const total = sc.length * BIKES.length * TRACKS.length;
  for (const b of BIKES) for (const s of sc) for (const t of TRACKS) {
    runs.push(runTest(b, s.setup, t.m, { id: `${b.id}|${s.id}|${t.id}`, group: s.group, label: s.label, track: t.label }, true, 0.25, logPts));
    onProgress?.(runs.length, total);
  }
  const stockTie = TRACKS.map((t) => { const r = runs.filter((x) => x.id.endsWith(`|stock|${t.id}`)); return { track: t.label, times: r.map((x) => x.result.finishS) }; });
  return { generatedAt: new Date().toISOString(), engine: "src/game/physics.ts step() · DT 1/240 s · determinístico", total, checks: { stockByTrack: stockTie, stalled: runs.filter((r) => r.result.stalled).map((r) => r.id), slowerThanStock: runs.filter((r) => { const st = runs.find((x) => x.id === r.id.replace(/\|[^|]+\|/, "|stock|")); return st && r.result.finishS !== null && st.result.finishS !== null && r.result.finishS > st.result.finishS; }).map((r) => r.id) }, runs };
}

export const tireInfo = tireOf;
export const fuelFlowInfo = fuelFlow;
