// Kits Preparados: 4MM Stage 1/2/3 per bike, chosen by the real physics (stats/simulate) over released parts,
// workshop services, compression and final drive. No bike-specific multipliers: each recipe is a search result.
import { PARTS_CATALOG, partById, type Part, type Slot } from "../parts";
import { bikeModel, engine, serviceById, simulate, stats, stress, stockSetupOf, type Setup } from "../physics";
import { partReleased } from "../startgame";
import { compatOf } from "../platform/compat";
import { pinVerdict } from "../equip-check";
import { priceNow } from "../economy";
import type { Player } from "../store";
import RECIPES from "./recipes.json";
import { buildOf, physicalBreak } from "../mechlimits";
import { mixDiagnosis } from "../mech-identity";
import { geoOf, cycleAt, rodLoads } from "../enginephys";
import { CARB_STOCK } from "../alcool";

export type Stage = 1 | 2 | 3;
export const KIT_BIKES: [string, string][] = [["titan160", "Honda CG 160 Titan"], ["titan150", "Honda CG 150 Titan ESD"], ["factor150", "Yamaha Factor 150"], ["cg125", "Honda CG 125 Bolinha"]];
/** Mão de obra da montagem na hora (R$), somada aos serviços de oficina da receita. */
export const KIT_LABOR: Record<Stage, number> = { 1: 300, 2: 450, 3: 620 };
/** Faixa de potência alvo de cada stage (cv) — igual para as quatro motos. */
export const STAGE_TARGET: Record<Stage, [number, number]> = { 1: [18, 19], 2: [20, 22], 3: [24, 26] };
/** Velocidade de referência pedida para o Stage 3 (km/h). Só é declarada atingida se a física chegar lá. */
export const TOP_TARGET: [number, number] = [180, 183];
/** Distância do teste de pista do comparador (m). */
export const TEST_M = 1000;
/** Reta longa usada para escolher a relação de bololo (corte na última marcha). */
export const BOLOLO_M = 3000;
/** Vantagem (km/h) dada à relação que bate o corte na última marcha sobre uma relação longa que não corta. */
export const BOLOLO_BONUS = 8;
/** Redução de vento do Stage 3 sem carenagem nem bolha: moto enxuta de racha (postura e peças retiradas). */
export const AERO_KIT = "enxuta-racha";
/** Slots que cada stage pode trocar além do par cilindro+pistão 4MM. */
const STAGE_SLOTS: Record<Stage, (Slot | "comando")[]> = {
  1: ["escape", "biela", "comando"],
  2: ["escape", "comando", "biela", "molas"],
  3: ["escape", "comando", "biela", "molas", "modulo", "bico", "embreagem", "vela"],
};
/** Serviços de oficina permitidos por stage (preparação crescente). */
const STAGE_SVC: Record<Stage, string[]> = {
  1: ["polimento", "valv-3ang", "coletor", "limpeza-bico", "miolo-escape", "boca-escape", "dutos", "dutos-escape", "janelas", "lev-adm-03", "lev-esc-03"],
  2: ["polimento", "valv-3ang", "coletor", "limpeza-bico", "miolo-escape", "boca-escape", "dutos", "dutos-escape", "valv-maiores", "valv-32", "lev-adm-03", "lev-esc-03", "cruzamento", "janelas", "catalisador", "rebaixar-cabecote", "alivio-pistao", "alivio-biela", "alivio-volante"],
  3: ["polimento", "valv-3ang", "coletor", "limpeza-bico", "miolo-escape", "boca-escape", "dutos", "dutos-escape", "valv-maiores", "valv-32", "valv-33", "lev-adm-03", "lev-esc-03", "lev-adm-05", "lev-esc-05", "cruzamento", "janelas", "catalisador", "rebaixar-cabecote", "alivio-pistao", "alivio-biela", "alivio-volante", "balanceamento", "guias-bronze", "pino-3", "pino-4", "pino-5", "pino-6"],
};
const STAGE_CR: Record<Stage, number[]> = { 1: [9.5, 10, 10.5, 11], 2: [9.5, 10, 10.5, 11, 11.5], 3: [9.5, 10, 10.5, 11, 11.5, 12, 12.5] };

const fits = (x: Part, bike: string, slots: Setup["slots"]) =>
  partReleased(x.id) && compatOf(x, bike).c !== "INCOMPATIVEL" && !pinVerdict(x.kind, x.id, bike, slots);
const options = (k: Slot | "comando", bike: string, slots: Setup["slots"]) =>
  PARTS_CATALOG.filter((x) => x.kind === k && fits(x, bike, slots));

export interface KitPlan {
  bike: string; stage: Stage; setup: Setup; parts: string[]; services: string[]; compression: number; front: number; rear: number;
  hp: number; hpStock: number; torque: number; rpmPeak: number; rpmLimit: number; risk: number; price: number;
  /** Dentro da faixa de potência do stage. */
  onTarget: boolean;
}

function apply(s: Setup, id: string): Setup {
  const x = partById(id)!;
  if (x.kind === "gicle_alta" || x.kind === "gicle_lenta") return s;
  if (x.kind === "carenagem") return { ...s, aero: id };
  return x.kind === "comando" ? { ...s, cam: x.cam ?? s.cam } : { ...s, slots: { ...s.slots, [x.kind]: id } };
}
function addSvc(s: Setup, id: string): Setup {
  const ex = serviceById(id)?.exclusive;
  const keep = s.services.filter((o) => !ex || serviceById(o)?.exclusive !== ex);
  const cav = serviceById(id)?.needsCavas && !keep.includes("cavas-pistao") ? ["cavas-pistao"] : [];
  return { ...s, services: [...keep, ...cav, id] };
}
const hpOf = (bike: string, s: Setup) => { try { return stats(bikeModel(bike), s).hp; } catch { return -1; } };
const risk = (bike: string, s: Setup) => { const st = stress(bikeModel(bike), s) as unknown as { total?: number; risk?: number }; return Number(st.total ?? st.risk ?? 0); };

export interface Recipe { mount: string[]; services: string[]; compression: number; front: number; rear: number; aero?: string; jet?: number; ecu?: Partial<Setup["ecu"]> }
/** Giclê de alta montado (carburadas): ideal = giclê de fábrica na gasolina; a física escala a vazão pela área. */
function withJet(bike: string, s: Setup, jet: number | undefined): Setup {
  const c = CARB_STOCK[bike]; if (!c || !jet) return s;
  return { ...s, gicles: { alta: jet, lenta: c.lenta, altaIdeal: c.alta, lentaIdeal: c.lenta } };
}
const jetPart = (jet: number) => PARTS_CATALOG.find((x) => x.kind === "gicle_alta" && x.jet === jet)?.id;

/** Falhas mecânicas do kit: quanto menor, mais seguro. Mesmo critério do Laboratório de Kits. */
export function kitFaults(bike: string, s: Setup, mech = false) {
  const b = bikeModel(bike), st = stats(b, s), k = buildOf(b, s), str = stress(b, s);
  let f = 0;
  if (k.floatRpm < st.rpmLimit) f++;
  if (str.causes.some((c) => c.cause === "Válvula atropelada" || c.cause === "Biela quebrada")) f++;
  if (rodLoads(geoOf(b, s), cycleAt(b, s, st.rpmLimit, 1, 0, 0), st.rpmLimit, k.recKg).tensionN > k.rodLimitN * 1.002) f++;
  if (!s.services.includes("brunimento")) f++;
  if (mech) return { f, value: str.value, hp: st.hp };
  if (mixDiagnosis(b, s).estado !== "ideal") f++;
  if (str.risk > 0.05) f++;
  if (f === 0) for (const d of [402, BOLOLO_M]) if (physicalBreak(b, s, d, b.tank)) { f += 2; break; }
  return { f, value: str.value, hp: st.hp };
}
/** Fecha o motor: usinagem de segurança, biela, molas, cavas e alimentação até não quebrar (física real). */
export function harden(bike: string, s0: Setup, stage: Stage): { s: Setup; picks: Map<string, string>; jet?: number | undefined; ecu?: Partial<Setup["ecu"]> | undefined } {
  const picks = new Map<string, string>(); let s = s0, jet: number | undefined, ecu: Partial<Setup["ecu"]> | undefined;
  const [, hiCv] = STAGE_TARGET[stage];
  const carb = !!CARB_STOCK[bike];
  const key = (t: Setup) => { const r = kitFaults(bike, t); return r.f * 1000 + r.value - Math.min(r.hp, hiCv) * 3 + Math.max(0, r.hp - hiCv) * 20; };
  for (let pass = 0; pass < 14; pass++) {
    let best = key(s), pick: { t: Setup; slot?: string | undefined; id?: string | undefined; jet?: number | undefined; ecu?: Partial<Setup["ecu"]> | undefined } | null = null;
    for (const id of ["brunimento", "cavas-pistao", "molas-duplas", "parede-grossa", "balanceamento", "guias-bronze", "janelas"]) {
      if (s.services.includes(id) || !serviceById(id) || (serviceById(id)!.requires ?? []).some((r) => !partReleased(r))) continue;
      let t = s; for (const r of serviceById(id)!.requires ?? []) if (partById(r)) t = apply(t, r);
      t = addSvc(t, id); const v = key(t); if (v < best - 0.05) { best = v; pick = { t, slot: serviceById(id)!.requires?.[0] ? "molas" : undefined, id: serviceById(id)!.requires?.[0] }; }
    }
    for (const k of ["biela", "molas", ...(carb ? [] : ["bico"])] as Slot[]) for (const x of options(k, bike, s.slots)) {
      if (s.slots[k] === x.id) continue; const t = apply(s, x.id), v = key(t); if (v < best - 0.05) { best = v; pick = { t, slot: k, id: x.id }; }
    }
    for (const id of s.services) { if (id === "brunimento" || id === "cavas-pistao" || s0.services.includes(id) && !s.services.includes(id)) continue;
      const t = { ...s, services: s.services.filter((o) => o !== id) }, v = key(t); if (v < best - 0.05) { best = v; pick = { t }; } }
    for (const c of [s.compression - 0.5, s.compression - 1]) if (c >= 9) { const t = { ...s, compression: c }, v = key(t); if (v < best - 0.05) { best = v; pick = { t }; } }
    if (!carb) { const ath = options("modulo", bike, s.slots).find((x) => x.prog);
      if (ath) for (const rpm of [9000, 9500, 10000]) for (const tr of [0, 4, 8, 12, 16, 20, 24]) {
        const e = { rpm, trim: tr, leanCut: true }; const t = { ...s, slots: { ...s.slots, modulo: ath.id }, ecu: { ...s.ecu, ...e } }, v = key(t);
        if (v < best - 0.05) { best = v; pick = { t, slot: "modulo", id: ath.id, ecu: e }; } } }
    if (carb) for (const x of PARTS_CATALOG.filter((y) => y.kind === "gicle_alta" && y.jet && partReleased(y.id))) {
      const t = withJet(bike, s, x.jet), v = key(t); if (v < best - 0.05) { best = v; pick = { t, jet: x.jet }; }
    }
    if (!pick) break;
    s = pick.t; if (pick.slot && pick.id) picks.set(pick.slot, pick.id); if (pick.jet) jet = pick.jet; if (pick.ecu) ecu = pick.ecu;
  }
  return { s, picks, jet, ecu };
}
/** Receita do stage: subida coordenada (peças, serviços, taxa) que maximiza cv sem passar do teto do stage; depois a relação final que dá mais velocidade no teste de pista. */
export function searchRecipe(bike: string, stage: Stage): Recipe | null {
  const b = bikeModel(bike), base0 = stockSetupOf(bike);
  const cyl = `cilindro-4mm-${bike}`, pis = `pistao-4mm-${bike}`;
  if (!partById(cyl) || !partById(pis)) return null;
  const [lo, hi] = STAGE_TARGET[stage];
  const hpStock = stats(b, base0).hp;
  let s = apply(apply(base0, cyl), pis);
  const chosen = new Map<string, string>([["cilindro", cyl], ["pistao", pis]]);
  { const h0 = harden(bike, s, stage); s = h0.s; for (const [k, v] of h0.picks) chosen.set(k, v); if (h0.jet) chosen.set("jet", String(h0.jet)); }
  const raw = (t: Setup) => { const h = hpOf(bike, t); if (h > hi) return -1e4; return h - kitFaults(bike, t, true).f * 100; };
  // cada passo de preparação já vem com molas e biela que seguram o novo giro (passo composto, sem atalho)
  const fix = (t: Setup): Setup => {
    let u = t;
    for (const k of ["molas", "biela"] as Slot[]) { let bv = raw(u), bu = u; for (const x of options(k, bike, u.slots)) { if (u.slots[k] === x.id) continue; const w = apply(u, x.id), v = raw(w); if (v > bv + 0.05) { bv = v; bu = w; } } u = bu; }
    return u;
  };
  const score = (t: Setup) => raw(fix(t));
  const take = (t: Setup) => { const u = fix(t); for (const k of ["molas", "biela"] as Slot[]) if (u.slots[k] !== s.slots[k]) chosen.set(k, u.slots[k]); return u; };
  for (let pass = 0; pass < 5; pass++) {
    let changed = false;
    for (const k of STAGE_SLOTS[stage]) {
      let best = score(s), pick: string | null = null;
      for (const x of options(k, bike, s.slots)) { const v = score(apply(s, x.id)); if (v > best + 0.05) { best = v; pick = x.id; } }
      if (pick && chosen.get(k) !== pick) { s = take(apply(s, pick)); chosen.set(k, pick); changed = true; }
    }
    for (;;) { // serviço de maior ganho primeiro, até não caber mais nada sob o teto
      let best = score(s), pick: Setup | null = null;
      for (const id of STAGE_SVC[stage]) {
        if (s.services.includes(id) || !serviceById(id) || (serviceById(id)!.requires ?? []).some((r) => !partReleased(r))) continue;
        const t = addSvc(s, id), v = score(t);
        if (v > best + 0.05) { best = v; pick = t; }
      }
      if (!pick) break;
      s = take(pick); changed = true;
    }
    let bestCr = score(s), cr = s.compression;
    for (const c of STAGE_CR[stage]) { const v = score({ ...s, compression: c }); if (v > bestCr + 0.05) { bestCr = v; cr = c; } }
    if (cr !== s.compression) { s = take({ ...s, compression: cr }); changed = true; }
    if (!changed) break;
  }
  let hEcu: Partial<Setup["ecu"]> | undefined;
  { const h = harden(bike, s, stage); s = h.s; for (const [k, v] of h.picks) chosen.set(k, v); if (h.jet) chosen.set("jet", String(h.jet)); hEcu = h.ecu; }
  // subida final com o motor fechado: cada passo re-acerta a alimentação e só entra se continuar sem nenhuma falha
  {
    const carb = !!CARB_STOCK[bike];
    const jets = PARTS_CATALOG.filter((y) => y.kind === "gicle_alta" && y.jet && partReleased(y.id)).map((y) => y.jet!);
    const retune = (t: Setup): Setup[] => {
      if (carb) { const j = t.gicles?.alta ?? CARB_STOCK[bike]!.alta; return jets.filter((x) => Math.abs(x - j) <= 8).map((x) => withJet(bike, t, x)); }
      if (partById(t.slots.modulo)?.prog) return [0, 4, 8, 12, 16, 20].map((tr) => ({ ...t, ecu: { ...t.ecu, trim: tr } }));
      return [t];
    };
    let curHp = hpOf(bike, s);
    for (let pass = 0; pass < 8; pass++) {
      const cands: Setup[] = [];
      for (const k of STAGE_SLOTS[stage]) for (const x of options(k, bike, s.slots)) cands.push(apply(s, x.id));
      for (const id of STAGE_SVC[stage]) if (!s.services.includes(id) && serviceById(id) && !(serviceById(id)!.requires ?? []).some((r) => !partReleased(r))) cands.push(addSvc(s, id));
      for (const c of STAGE_CR[stage]) if (c !== s.compression) cands.push({ ...s, compression: c });
      let best: Setup | null = null, bestHp = curHp + 0.1;
      for (const c0 of cands) {
        const c = fix(c0);
        for (const t of retune(c)) { const h = hpOf(bike, t); if (h <= bestHp || h > hi + 0.05) continue; if (kitFaults(bike, t).f === 0) { best = t; bestHp = h; } }
      }
      if (!best) break;
      for (const k of STAGE_SLOTS[stage]) if (k !== "comando" && best.slots[k as Slot] !== s.slots[k as Slot]) chosen.set(k, best.slots[k as Slot]);
      if (best.cam !== s.cam) { const cp = PARTS_CATALOG.find((x) => x.kind === "comando" && x.cam === best!.cam); if (cp) chosen.set("comando", cp.id); }
      if (best.gicles?.alta && best.gicles.alta !== s.gicles?.alta) chosen.set("jet", String(best.gicles.alta));
      if (partById(best.slots.modulo)?.prog) hEcu = { ...(hEcu ?? {}), rpm: best.ecu.rpm, trim: best.ecu.trim, leanCut: true };
      s = best; curHp = bestHp;
    }
  }
  const jetN = chosen.has("jet") ? Number(chosen.get("jet")) : undefined; chosen.delete("jet");
  // módulo (stage 3) + relação final de cada moto: prefere a relação que BATE O CORTE na última marcha (bololo)
  // numa reta longa; entre elas, a de maior velocidade final; sem carenagem (moto pelada)
  const hEcuMod = hEcu ? s.slots.modulo : undefined;
  const mods = hEcu ? [s.slots.modulo] : stage === 3 ? [s.slots.modulo, ...options("modulo", bike, s.slots).filter((x) => !x.prog).map((x) => x.id)] : [s.slots.modulo];
  const aeros: (string | undefined)[] = stage === 3 ? [undefined, AERO_KIT] : [undefined];
  let bestKey = -Infinity, fr = [s.front, s.rear], bestMod = s.slots.modulo, bestAero: string | undefined;
  const okMods = mods.filter((m) => m === s.slots.modulo || kitFaults(bike, { ...s, slots: { ...s.slots, modulo: m } }).f === 0);
  // corte do Athlon (stage 3): sobe o giro só com molas e biela que seguram e motor sem falha
  const bases: Setup[] = [s];
  if (stage === 3 && hEcu && partById(s.slots.modulo)?.prog) for (const rpm of [9500, 10000, 10500, 11000]) {
    const t = fix({ ...s, ecu: { ...s.ecu, rpm } }); if (kitFaults(bike, t).f === 0) bases.push(t);
  }
  let bestBase = s;
  for (const base of bases) for (const ae of aeros) for (const m of okMods) for (let f = 13; f <= 18; f++) for (let r = 28; r <= 46; r += 2) {
    const t = { ...base, aero: ae, slots: { ...base.slots, modulo: m }, front: f, rear: r };
    const sim = simulate(b, t, BOLOLO_M, b.tank);
    const key = (sim.top >= TOP_TARGET[0] ? 100 : 0) + (sim.limiter && sim.gear === b.gears ? BOLOLO_BONUS : 0) + sim.top;
    if (key > bestKey + 0.3) { bestKey = key; fr = [f, r]; bestMod = m; bestAero = ae; bestBase = base; }
  }
  if (bestBase !== s) { for (const k of ["molas", "biela"] as Slot[]) if (bestBase.slots[k] !== s.slots[k]) chosen.set(k, bestBase.slots[k]); hEcu = { ...(hEcu ?? {}), rpm: bestBase.ecu.rpm }; s = bestBase; }
  if (bestMod && bestMod !== s.slots.modulo) { s = { ...s, slots: { ...s.slots, modulo: bestMod } }; chosen.set("modulo", bestMod); }
  return { mount: [...chosen.values()], services: s.services.filter((id) => !base0.services.includes(id)), compression: s.compression, front: fr[0]!, rear: fr[1]!, ...(bestAero ? { aero: bestAero } : {}), ...(jetN ? { jet: jetN } : {}), ...(hEcu && bestMod === hEcuMod ? { ecu: hEcu } : {}) };
}

const cache = new Map<string, KitPlan>();
/** Plano do stage a partir da receita gravada (gerada por searchRecipe, conferida no teste); mede tudo na física ao vivo. */
export function kitPlan(bike: string, stage: Stage): KitPlan | null {
  const key = `${bike}:${stage}`;
  if (cache.has(key)) return cache.get(key)!;
  const rec = (RECIPES as Record<string, Record<string, Recipe>>)[bike]?.[stage] ?? searchRecipe(bike, stage);
  if (!rec) return null;
  const b = bikeModel(bike), base0 = stockSetupOf(bike), [lo, hi] = STAGE_TARGET[stage], hpStock = stats(b, base0).hp;
  let s = [...rec.mount, ...(rec.aero ? [rec.aero] : [])].reduce(apply, base0);
  for (const id of rec.services) s = addSvc(s, id);
  s = withJet(bike, { ...s, compression: rec.compression, front: rec.front, rear: rec.rear, ...(rec.ecu ? { ecu: { ...s.ecu, ...rec.ecu } } : {}) }, rec.jet);
  const parts = [...rec.mount, ...(rec.aero ? [rec.aero] : []), ...(rec.jet && jetPart(rec.jet) ? [jetPart(rec.jet)!] : [])];
  for (const id of s.services) for (const r of serviceById(id)?.requires ?? []) if (partById(r) && !parts.includes(r)) parts.push(r);
  const services = s.services.filter((id) => !base0.services.includes(id));
  const st = stats(b, s), e = engine(b, s);
  const svcPrice = services.reduce((n, id) => n + (serviceById(id)?.price ?? 0), 0);
  const plan: KitPlan = {
    bike, stage, setup: s, parts, services, compression: s.compression, front: s.front, rear: s.rear,
    hp: st.hp, hpStock, torque: st.torque, rpmPeak: e.rpmPeak, rpmLimit: st.rpmLimit, risk: risk(bike, s),
    price: Math.round(parts.reduce((n, id) => n + priceNow(partById(id)!), 0) + priceNow({ price: svcPrice } as Part) + KIT_LABOR[stage]),
    onTarget: st.hp >= lo - 0.05 && st.hp <= hi + 0.05,
  };
  cache.set(key, plan);
  return plan;
}

/** Compra e monta na hora na moto ativa (precisa ser a moto do kit): peças, serviços, taxa e relação final. */
export function buyKit(p: Player, plan: KitPlan): Player {
  if (p.activeBike !== plan.bike || p.money < plan.price) return p;
  const cams = plan.parts.filter((id) => partById(id)!.kind === "comando").map((id) => partById(id)!.cam ?? "original");
  const loose = plan.parts.filter((id) => !["comando", "carenagem"].includes(partById(id)!.kind));
  const services = [...new Set([...(p.setup.services ?? []).filter((id) => !plan.setup.services.some((n) => serviceById(n)?.exclusive && serviceById(n)?.exclusive === serviceById(id)?.exclusive)), ...plan.setup.services])];
  return { ...p, money: Math.round((p.money - plan.price) * 100) / 100, parts: [...p.parts, ...loose], camStock: [...p.camStock, ...cams],
    setup: { ...p.setup, slots: { ...p.setup.slots, ...plan.setup.slots }, cam: plan.setup.cam, services, compression: plan.setup.compression, front: plan.setup.front, rear: plan.setup.rear, ...(plan.setup.aero ? { aero: plan.setup.aero } : {}), ...(plan.setup.gicles ? { gicles: plan.setup.gicles } : {}), ...(partById(plan.setup.slots.modulo)?.prog ? { ecu: plan.setup.ecu } : {}) } };
}
