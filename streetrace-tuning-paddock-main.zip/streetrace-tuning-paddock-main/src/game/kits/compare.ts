// Comparador competitivo das quatro motos com a mesma pista, piloto, tanque cheio e combustível de fábrica.
// Mede pela física (simulate/stats/stress); o índice composto tem pesos configuráveis e nunca altera a física.
import { bikeModel, simulate } from "../physics";
import { KIT_BIKES, kitPlan, TEST_M, TOP_TARGET, STAGE_TARGET, type KitPlan, type Stage } from "./preparado";

export interface KitRun { bike: string; name: string; plan: KitPlan; top: number; t60: number | null; t100: number | null; t402: number | null; t1000: number | null; retomada: number | null }
export const DEFAULT_WEIGHTS = { aceleracao: 0.3, velocidade: 0.25, retomada: 0.2, torque: 0.1, durabilidade: 0.15 };
export type Weights = typeof DEFAULT_WEIGHTS;

export function runKit(bike: string, stage: Stage): KitRun | null {
  const plan = kitPlan(bike, stage); if (!plan) return null;
  const b = bikeModel(bike), a = simulate(b, plan.setup, TEST_M, b.tank), q = simulate(b, plan.setup, 402, b.tank);
  return { bike, name: KIT_BIKES.find(([id]) => id === bike)![1], plan, top: a.top, t60: a.t60, t100: a.t100, t402: q.finishT, t1000: a.finishT, retomada: a.t100 != null && a.t60 != null ? a.t100 - a.t60 : null };
}

/** Índice 0–100 por critério relativo ao melhor das quatro; o composto é a soma ponderada. */
export function compareKits(stage: Stage, w: Weights = DEFAULT_WEIGHTS) {
  const runs = KIT_BIKES.map(([id]) => runKit(id, stage)).filter((r): r is KitRun => !!r);
  const best = (f: (r: KitRun) => number | null, low: boolean) => { const v = runs.map(f).filter((x): x is number => x != null); return low ? Math.min(...v) : Math.max(...v); };
  const rel = (v: number | null, ref: number, low: boolean) => v == null ? 0 : 100 * (low ? ref / v : v / ref);
  const bT = best((r) => r.t402, true), bV = best((r) => r.top, false), bR = best((r) => r.retomada, true), bQ = best((r) => r.plan.torque, false), bD = best((r) => r.plan.risk, true);
  const rows = runs.map((r) => {
    const c = { aceleracao: rel(r.t402, bT, true), velocidade: rel(r.top, bV, false), retomada: rel(r.retomada, bR, true), torque: rel(r.plan.torque, bQ, false), durabilidade: bD > 0 ? rel(r.plan.risk, bD, true) : 100 };
    const indice = (Object.keys(w) as (keyof Weights)[]).reduce((n, k) => n + c[k] * w[k], 0) / Object.values(w).reduce((a, b) => a + b, 0);
    const gargalos: string[] = [];
    if (!r.plan.onTarget) gargalos.push(`potência ${r.plan.hp.toFixed(1)} cv fora da faixa ${STAGE_TARGET[stage].join("–")} cv`);
    if (stage === 3 && r.top < TOP_TARGET[0]) gargalos.push(`velocidade ${r.top.toFixed(1)} km/h abaixo de ${TOP_TARGET[0]} km/h: arrasto aerodinâmico exige mais potência que a faixa permite`);
    return { ...r, criterios: c, indice, gargalos };
  });
  const spread = rows.length ? Math.max(...rows.map((r) => r.indice)) - Math.min(...rows.map((r) => r.indice)) : 0;
  const equilibrado = rows.every((r) => r.gargalos.length === 0) && spread <= 5;
  return { stage, rows, spread, equilibrado };
}
