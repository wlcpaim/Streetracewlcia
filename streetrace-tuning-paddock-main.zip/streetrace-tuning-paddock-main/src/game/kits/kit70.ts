/**
 * Kit 70mm (~220 cc+): ordem de preparação peça por peça, no mesmo padrão do Kit 4MM.
 * Só usa a física do jogo (ccOf, engine, fuelChain, clutchCapNm, ENGINE_CATALOG); nada é aprovado
 * sem medida. Itens sem ficha ficam DESCONHECIDO e bloqueiam a liberação da montagem.
 */
import { ccOf, engine, type BikeModel, type Setup } from "../physics";
import { fuelChain } from "../rootcause";
import { clutchCapNm, partById, type Slot } from "../parts";
import { ENGINE_CATALOG, strokeMmOf } from "../data/engine_catalog";

export type Classe = "COMPATÍVEL" | "EXIGE ADAPTAÇÃO" | "INCOMPATÍVEL" | "DESCONHECIDO";
export interface Item { grupo: string; peca: string; id: string | null; classe: Classe; motivo: string }
export const BORE70 = 70.0;
export const CAMISA_EXT = 74.0;
export const CYL70 = "cilindro-70mm";
export const CARCACA = "carcaca-74";
/** Serviços de preparação adicionados à ordem (ids existentes da Oficina quando há). */
export const SERVICOS_70 = ["Desmontagem completa do motor", "Medição e inspeção do bloco", `Usinar carcaça para camisa Ø ${CAMISA_EXT} mm (${CARCACA})`, "Conferir alojamento da camisa", "Folga pistão × cilindro", "Medir e ajustar taxa de compressão", "Conferir squish", "Interferência pistão × válvulas (cavas-pistao)", "Conferir curso e comprimento da biela", "Balanceamento do conjunto rotativo (balanceamento)", "Montagem do conjunto superior", "Comando e sincronismo", "Preparação do cabeçote", "Dimensionar alimentação", "Remapear injeção (módulo programável)", "Calibrar embreagem", "Dimensionar escapamento", "Conferir lubrificação", "Verificar arrefecimento", "Testes de compressão, funcionamento e temperatura", "Dinamômetro e validação final"];

const pinOf = (bikeId: string) => { const v = ENGINE_CATALOG[bikeId]?.p["pinoPistao"]?.valor; return typeof v === "number" ? v : null; };
const pinOfPart = (id: string | undefined) => { const x = partById(id ?? ""); if (x?.pinMm != null) return x.pinMm; const m = /pino (\d+) mm/.exec(x?.spec ?? ""); return m ? Number(m[1]) : null; };
/** Olhal do pé da biela montada: peça com pinMm, ou a original = pino da ficha da moto; outra sem ficha = null. */
const rodPinOf = (b: BikeModel, s: Setup) => { const id = s.slots.biela ?? "biela-original"; const x = partById(id); return x?.pinMm ?? (x?.factory || id === "biela-original" ? pinOf(b.id) : null); };
const r1 = (x: number) => Math.round(x * 10) / 10;

export interface Analise { bike: string; cc: number | null; strokeMm: number | null; vmpMs: number | null; torqueNm: number; clutchNm: number; dutyPct: number; lean: number; itens: Item[]; servicos: string[]; liberado: boolean; faltas: string[] }

/** Analisa um Setup com o cilindro 70 mm montado (ou proposto) sobre o modelo dado. */
export function analisar70(b: BikeModel, s0: Setup): Analise {
  const s: Setup = { ...s0, slots: { ...s0.slots, cilindro: CYL70 } };
  const S = strokeMmOf(b.id), e = engine(b, s), cc = S == null ? null : ccOf(b, s);
  const stroke = S == null ? null : S + (s.services.includes("pino-4") ? 4 : s.services.includes("pino-2") ? 2 : 0);
  const vmp = stroke == null ? null : r1((2 * stroke / 1000) * e.rpmLimit / 60);
  const torque = r1((e.hp * 735.5) / (e.rpmPeak * 2 * Math.PI / 60));
  const fc = fuelChain(b, s, e.rpmPeak), clutch = clutchCapNm(s);
  const it: Item[] = [];
  const has = (k: Slot, id: string) => s.slots[k] === id;
  it.push({ grupo: "Cilindro", peca: "Cilindro encamisado 70,0 mm", id: CYL70, classe: s.services.includes(CARCACA) ? "COMPATÍVEL" : "EXIGE ADAPTAÇÃO", motivo: s.services.includes(CARCACA) ? "Carcaça usinada para a camisa." : `Camisa Ø ${CAMISA_EXT} mm não entra na carcaça original: usinar (${CARCACA}).` });
  const pinB = rodPinOf(b, s), pinP = pinOfPart(s.slots.pistao), p70 = /^pistao-70mm/.test(s.slots.pistao ?? "");
  const rodName = partById(s.slots.biela ?? "biela-original")?.name ?? "biela";
  it.push({ grupo: "Cilindro", peca: "Pistão 70,0 mm", id: s.slots.pistao ?? null,
    classe: !p70 ? "INCOMPATÍVEL" : pinB == null ? "DESCONHECIDO" : pinP === pinB ? "COMPATÍVEL" : "INCOMPATÍVEL",
    motivo: !p70 ? "Pistão montado não é Ø 70 mm." : pinB == null ? `Ø do olhal da biela montada (${rodName}) sem ficha.` : pinP === pinB ? `Pino ${pinP} mm = olhal da biela ${rodName} ${pinB} mm.` : `Pino ${pinP} mm ≠ olhal ${pinB} mm da biela ${rodName}: usar pistão pino ${pinB} mm ou biela pino ${pinP} mm.` });
  for (const peca of ["Travas do pino", "Jogo de anéis 70 mm"]) it.push({ grupo: "Cilindro", peca, id: p70 ? s.slots.pistao! : null, classe: p70 ? "COMPATÍVEL" : "INCOMPATÍVEL", motivo: p70 ? "Acompanham o pistão 70 mm." : "Faltam com o pistão 70 mm." });
  for (const peca of ["Junta do cabeçote Ø 70", "Junta da base do cilindro", "Rolamentos C3 do virabrequim", "Retentores", "Corrente e tensor de comando"]) it.push({ grupo: "Motor", peca, id: null, classe: "DESCONHECIDO", motivo: "Sem ficha (espessura/medida do fabricante) no jogo: não é inventada; conferir na montagem." });
  it.push({ grupo: "Motor", peca: "Biela", id: s.slots.biela ?? null, classe: has("biela", "biela-original") ? "EXIGE ADAPTAÇÃO" : "COMPATÍVEL", motivo: has("biela", "biela-original") ? "Biela original com pistão maior: carga de combustão sobe com a área (π/4·70²); trocar por reforçada." : `${partById(s.slots.biela ?? "")?.name ?? "—"} montada.` });
  it.push({ grupo: "Motor", peca: "Virabrequim", id: s.slots.vira ?? null, classe: "COMPATÍVEL", motivo: `Curso ${stroke ?? "?"} mm (ficha ${S ?? "?"} mm${stroke !== S ? " + pino cursado" : ""}).` });
  it.push({ grupo: "Motor", peca: "Balanceamento", id: "balanceamento", classe: s.services.includes("balanceamento") ? "COMPATÍVEL" : "EXIGE ADAPTAÇÃO", motivo: "Pistão mais pesado muda a massa alternada." });
  it.push({ grupo: "Cabeçote", peca: "Cavas de válvula", id: "cavas-pistao", classe: s.services.includes("cavas-pistao") || partById(s.slots.pistao ?? "")?.cavas ? "COMPATÍVEL" : "EXIGE ADAPTAÇÃO", motivo: "Conferir interferência pistão × válvulas no cruzamento." });
  it.push({ grupo: "Cabeçote", peca: "Molas de válvula", id: s.slots.molas ?? null, classe: has("molas", "molas-original") ? "EXIGE ADAPTAÇÃO" : "COMPATÍVEL", motivo: `Corte ${e.rpmLimit} rpm.` });
  it.push({ grupo: "Alimentação", peca: "Bico injetor", id: s.slots.bico ?? null, classe: fc.lean > 0.02 ? "INCOMPATÍVEL" : fc.dutyPct > 85 ? "EXIGE ADAPTAÇÃO" : "COMPATÍVEL", motivo: `No pico (${e.rpmPeak} rpm) pede ${fc.need}× e recebe ${fc.supply}× · duty ${fc.dutyPct}% · bico necessário ${fc.bicoNeeded}×.` });
  it.push({ grupo: "Alimentação", peca: "Módulo / remapeamento", id: s.slots.modulo ?? null, classe: partById(s.slots.modulo ?? "")?.prog ? "COMPATÍVEL" : "EXIGE ADAPTAÇÃO", motivo: "Mistura por faixa só com módulo programável." });
  it.push({ grupo: "Transmissão", peca: "Embreagem", id: s.slots.embreagem ?? null, classe: clutch >= torque ? "COMPATÍVEL" : "INCOMPATÍVEL", motivo: `Capacidade ${r1(clutch)} N·m vs torque ${torque} N·m (T = P/ω no pico).` });
  it.push({ grupo: "Escapamento", peca: "Escapamento", id: s.slots.escape ?? null, classe: has("escape", "escape-original") ? "EXIGE ADAPTAÇÃO" : "COMPATÍVEL", motivo: `Vazão/ressonância avaliadas por exhaust.ts para ${cc ?? "?"} cc.` });
  const faltas = it.filter((x) => x.classe !== "COMPATÍVEL").map((x) => `${x.classe}: ${x.peca} — ${x.motivo}`);
  return { bike: b.name, cc, strokeMm: stroke, vmpMs: vmp, torqueNm: torque, clutchNm: r1(clutch), dutyPct: fc.dutyPct, lean: fc.lean, itens: it, servicos: SERVICOS_70, liberado: faltas.length === 0, faltas };
}
