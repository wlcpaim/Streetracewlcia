import { useMemo, useState } from "react";
import kpTitle from "@/assets/kp_title.png.asset.json";
import kpKit4 from "@/assets/kp_kit4.png.asset.json";
import kpKit3 from "@/assets/kp_kit3.png.asset.json";
import kpTurbo from "@/assets/kp_turbo.png.asset.json";
import kpComp from "@/assets/kp_comp.png.asset.json";
import kpVoltar from "@/assets/kp_voltar.png.asset.json";
import { partById } from "../parts";
import { shopName } from "../part-label";
import { brl, setPlayer, type Player } from "../store";
import { buyKit, KIT_BIKES, kitPlan, type Stage } from "./preparado";
import { compareKits } from "./compare";
import { serviceById } from "../physics";

const STAGE_NAME: Record<Stage, string> = { 1: "Stage 1 · Rua", 2: "Stage 2 · Forte", 3: "Stage 3 · Máximo 4MM" };

/** Kits Preparado: menu com a arte própria; só o Kit 4MM está à venda. */
export function KitsPreparado({ p, onExit }: { p: Player; onExit: () => void }) {
  const [lvl, setLvl] = useState<"root" | "4mm" | string>("root");
  const [busy, setBusy] = useState(false);
  const [cmpStage, setCmpStage] = useState<Stage>(3);
  const back = () => (lvl === "root" ? onExit() : setLvl(lvl === "4mm" ? "root" : "4mm"));
  const cmp = useMemo(() => (lvl === "cmp" ? compareKits(cmpStage) : null), [lvl, cmpStage]);
  const bike = KIT_BIKES.find(([b]) => b === lvl);
  const plans = useMemo(() => (bike ? ([1, 2, 3] as Stage[]).map((s) => kitPlan(bike[0], s)) : []), [bike]);
  const img = (src: string, alt: string, on?: () => void, off = false) => (
    <button type="button" onClick={on} disabled={off} aria-label={alt} className="block w-full transition active:scale-95 disabled:opacity-40 disabled:grayscale">
      <img src={src} alt={alt} draggable={false} className="w-full object-contain" />
    </button>
  );
  return (
    <div className="absolute inset-0 z-40 flex flex-col overflow-y-auto bg-background/95 p-3">
      <img src={kpTitle.url} alt="Kits Preparado" draggable={false} className="mx-auto w-4/5 max-w-sm object-contain" />
      <div className="mx-auto mt-1 text-xs text-muted-foreground">Saldo {brl(p.money)}</div>
      <div className="mx-auto mt-3 w-full max-w-md flex-1 space-y-2">
        {lvl === "root" && (
          <div className="grid grid-cols-2 gap-2">
            {img(kpKit4.url, "Kit 4mm", () => setLvl("4mm"))}
            {img(kpKit3.url, "Kit 3mm · em breve", undefined, true)}
            {img(kpTurbo.url, "Kit Turbo · em breve", undefined, true)}
            {img(kpComp.url, "Kit Competição · em breve", undefined, true)}
          </div>
        )}
        {lvl === "4mm" && <button onClick={() => setLvl("cmp")} className="w-full rounded-xl border border-primary bg-primary/15 px-4 py-3 text-left font-display text-base">Comparar as 4 motos</button>}
        {cmp && (
          <div className="space-y-2">
            <div className="grid grid-cols-3 gap-1">{([1, 2, 3] as Stage[]).map((st) => <button key={st} onClick={() => setCmpStage(st)} className={`rounded-lg py-1.5 text-sm font-bold ${cmpStage === st ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>Stage {st}</button>)}</div>
            <div className={`rounded-lg px-3 py-2 text-xs ${cmp.equilibrado ? "bg-success/20" : "bg-destructive/20"}`}>{cmp.equilibrado ? "Equilíbrio atingido" : "Equilíbrio NÃO concluído"} · diferença de índice {cmp.spread.toFixed(1)} pontos</div>
            {[...cmp.rows].sort((a, b) => b.indice - a.indice).map((r) => (
              <div key={r.bike} className="rounded-xl border border-border bg-secondary p-3 text-xs">
                <div className="flex items-baseline justify-between"><b className="font-display text-base">{r.name}</b><span className="font-display text-lg text-primary">{r.indice.toFixed(1)}</span></div>
                <div>{r.plan.hp.toLocaleString("pt-BR")} cv a {r.plan.rpmPeak} rpm · {r.plan.torque.toLocaleString("pt-BR")} kgf·m · máx {r.top.toFixed(1)} km/h</div>
                <div>402 m {r.t402?.toFixed(2) ?? "—"} s · 0–100 {r.t100?.toFixed(2) ?? "—"} s · retomada 60–100 {r.retomada?.toFixed(2) ?? "—"} s · relação {r.plan.front}×{r.plan.rear} · taxa {r.plan.compression}:1</div>
                <div className="text-muted-foreground">Aceleração {r.criterios.aceleracao.toFixed(0)} · Velocidade {r.criterios.velocidade.toFixed(0)} · Retomada {r.criterios.retomada.toFixed(0)} · Torque {r.criterios.torque.toFixed(0)} · Durabilidade {r.criterios.durabilidade.toFixed(0)}</div>
                {r.gargalos.map((g) => <div key={g} className="text-destructive">Gargalo: {g}</div>)}
              </div>
            ))}
          </div>
        )}
        {lvl === "4mm" && KIT_BIKES.map(([b, label]) => (
          <button key={b} onClick={() => setLvl(b)} className="flex w-full items-center justify-between rounded-xl border border-primary/50 bg-secondary px-4 py-3 text-left font-display text-base">
            {label}<span className="text-xs text-muted-foreground">{p.activeBike === b ? "sua moto" : ""}</span>
          </button>
        ))}
        {bike && plans.map((k) => k && (
          <div key={k.stage} className={`rounded-xl border bg-secondary p-3 ${k.stage === 3 ? "border-primary" : "border-border"}`}>
            <div className="flex items-baseline justify-between"><b className="font-display text-lg">{STAGE_NAME[k.stage]}</b><span className="font-display text-xl text-primary">{k.hp.toLocaleString("pt-BR")} cv</span></div>
            <div className="text-xs text-muted-foreground">Original {k.hpStock.toLocaleString("pt-BR")} cv · torque {k.torque.toLocaleString("pt-BR")} kgf·m · corte {k.rpmLimit} rpm</div>
            <div className="text-xs text-muted-foreground">Pico {k.rpmPeak} rpm · taxa {k.compression}:1 · relação {k.front}×{k.rear}{k.onTarget ? "" : " · fora da meta"}</div>
            <ul className="mt-1 list-disc pl-5 text-xs">{k.parts.map((id) => <li key={id}>{shopName(partById(id)!)}</li>)}{k.services.map((id) => <li key={id}>{serviceById(id)?.name ?? id}</li>)}<li>Montagem na hora</li></ul>
            <button
              disabled={busy || p.activeBike !== k.bike || p.money < k.price}
              onClick={() => { setBusy(true); setPlayer((pl) => buyKit(pl, k)); setTimeout(() => setBusy(false), 1000); }}
              className="mt-2 w-full rounded-lg bg-success py-2 text-sm font-bold text-success-foreground disabled:opacity-40">
              {p.activeBike !== k.bike ? "Selecione esta moto na garagem" : `Comprar e instalar · ${brl(k.price)}`}
            </button>
          </div>
        ))}
      </div>
      <div className="mx-auto mt-3 w-3/5 max-w-xs">{img(kpVoltar.url, "Voltar", back)}</div>
    </div>
  );
}
