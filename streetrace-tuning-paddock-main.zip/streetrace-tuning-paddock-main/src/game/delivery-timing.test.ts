import { describe, expect, it } from "vitest";
import { BOARD_SLOT_S } from "./delivery/board-core";
import { REFUSE_COOLDOWN_MS, TUTORIAL_OFFER_MS } from "./jobrun";

describe("delivery call timing", () => {
  it("a new call per workplace every 30 s", () => expect(BOARD_SLOT_S).toBe(30));
  it("refused workplace stays quiet for 60 s", () => expect(REFUSE_COOLDOWN_MS).toBe(60000));
  it("tutorial call disappears after 5 s", () => expect(TUTORIAL_OFFER_MS).toBe(5000));
});
