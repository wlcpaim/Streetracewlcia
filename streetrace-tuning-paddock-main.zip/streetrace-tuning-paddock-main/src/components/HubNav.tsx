import { Link } from "@tanstack/react-router";

const LINKS = [
  { to: "/WikiStreetrace", label: "Wikipedia StreetRace" },
  { to: "/realgear", label: "RealGear" },
  { to: "/nexus", label: "NEXUS" },
  { to: "/engenharia", label: "Engenharia" },
] as const;

export function HubNav() {
  return (
    <nav className="flex flex-wrap gap-1 border-b border-border bg-background p-2">
      {LINKS.map((l) => (
        <Link key={l.to} to={l.to} className="rounded-lg px-3 py-1.5 font-display text-sm" activeProps={{ className: "bg-primary text-primary-foreground" }} inactiveProps={{ className: "bg-secondary" }}>{l.label}</Link>
      ))}
    </nav>
  );
}
