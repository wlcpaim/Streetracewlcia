import type { ReactNode } from "react";
import { HubNav } from "./HubNav";

/** Scrollable page shell for the technical hubs (the game locks body scroll). Top menu stays fixed. */
export function HubPage({ children }: { children: ReactNode }) {
  return (
    <div id="hub-scroll" className="h-dvh w-full overflow-y-auto overscroll-contain bg-background text-foreground select-text" style={{ WebkitOverflowScrolling: "touch" }}>
      <div className="sticky top-0 z-30"><HubNav /></div>
      {children}
    </div>
  );
}

