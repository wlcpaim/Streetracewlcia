import { useEffect, useState, useSyncExternalStore } from "react";
import { supabase } from "@/integrations/supabase/client";
import { cloudStatus, onCloud, startCloudSync } from "@/game/cloud/save-sync";
import { loadSave } from "@/game/store";
import { engProgress, startEngBackground } from "@/game/engineering/bg-runner";

let snap = cloudStatus();
const sub = (f: () => void) => onCloud(() => { snap = cloudStatus(); f(); });

/** Chip flutuante: conta na nuvem (save do jogo + ENG IA) e progresso da ENG IA em segundo plano. */
/** Botão de abrir/fechar oculto de propósito. */
const SHOW_TOGGLE = false as boolean;

export function CloudSave() {
  const st = useSyncExternalStore(sub, () => snap, () => snap);
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [msg, setMsg] = useState("");
  const [eng, setEng] = useState<ReturnType<typeof engProgress>>(null);

  useEffect(() => {
    startCloudSync((kinds) => { if (kinds.includes("player")) loadSave(); if (kinds.includes("eng")) window.dispatchEvent(new Event("eng-change")); });
    startEngBackground();
    const f = () => setEng(engProgress()); f();
    window.addEventListener("eng-change", f); return () => window.removeEventListener("eng-change", f);
  }, []);

  const go = async (mode: "in" | "up") => {
    setMsg("...");
    const r = mode === "in"
      ? await supabase.auth.signInWithPassword({ email, password: pass })
      : await supabase.auth.signUp({ email, password: pass, options: { emailRedirectTo: window.location.origin } });
    setMsg(r.error ? r.error.message : mode === "up" && !r.data.session ? "Confira seu e-mail para confirmar a conta." : "Conectado.");
  };

  const label = st.userId ? (st.status === "erro" ? "Nuvem: erro" : st.status === "sincronizando" ? "Salvando…" : "Nuvem ✓") : "Salvar na nuvem";
  return (
    <div className="fixed bottom-2 left-2 z-[60] flex flex-col items-start gap-1 text-xs">
      {eng && <div className="rounded-full bg-card/90 px-2 py-1 font-bold text-foreground shadow">ENG IA: {eng.done}/{eng.total}</div>}
      {open && (
        <div className="w-64 space-y-2 rounded-xl border border-border bg-card p-3 text-foreground shadow-lg">
          {st.userId ? (
            <>
              <p>Seu jogo e a ENG IA estão salvos na nuvem.</p>
              <button className="rounded bg-secondary px-2 py-1" onClick={() => void supabase.auth.signOut()}>Sair</button>
            </>
          ) : (
            <>
              <input className="w-full rounded bg-background px-2 py-1" placeholder="e-mail" value={email} onChange={(e) => setEmail(e.target.value)} />
              <input className="w-full rounded bg-background px-2 py-1" type="password" placeholder="senha" value={pass} onChange={(e) => setPass(e.target.value)} />
              <div className="flex gap-2">
                <button className="rounded bg-primary px-2 py-1 font-bold text-primary-foreground" onClick={() => void go("in")}>Entrar</button>
                <button className="rounded bg-secondary px-2 py-1" onClick={() => void go("up")}>Criar conta</button>
              </div>
            </>
          )}
          {msg && <p className="text-muted-foreground">{msg}</p>}
        </div>
      )}
      {/* Botão "Salvar na nuvem" oculto até o jogo ficar online (pós-MVP). */}
      {SHOW_TOGGLE && <button onClick={() => setOpen(!open)} className="rounded-full bg-card/90 px-2 py-1 font-bold text-foreground shadow">{label}</button>}
    </div>
  );
}
