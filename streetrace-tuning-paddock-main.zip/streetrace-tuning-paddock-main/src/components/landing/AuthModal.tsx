import { tapBack } from "@/game/ui/triple-tap";
import { useEffect, useState } from "react";
import { Eye, EyeOff, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { generateGuestToken, loginWithToken } from "@/game/auth/token.functions";
import { Button } from "@/components/ui/button";
import { setEntering } from "@/game/cloud/cloud-store";

export type AuthMode = "in" | "up" | "forgot" | "token";
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
/** Senha segura: 8+ caracteres com letra e número. */
export const senhaSegura = (s: string) => s.length >= 8 && /[A-Za-z]/.test(s) && /\d/.test(s);

export function AuthModal({ mode, setMode, onClose }: { mode: AuthMode; setMode: (m: AuthMode) => void; onClose: () => void }) {
  const [nome, setNome] = useState(""), [email, setEmail] = useState(""), [pass, setPass] = useState(""), [pass2, setPass2] = useState("");
  const [show, setShow] = useState(false), [termos, setTermos] = useState(false), [priv, setPriv] = useState(false);
  const [msg, setMsg] = useState<{ t: string; ok?: boolean } | null>(null), [busy, setBusy] = useState(false);
  const [last, setLast] = useState(0);
  const [aguardando, setAguardando] = useState<string | null>(null);
  const [livre, setLivre] = useState<boolean | null>(null);
  const [tok, setTok] = useState("");
  // Token-only access requires no existing account credentials.
  const [tokTab, setTokTab] = useState<"entrar" | "gerar">("entrar");
  const [novo, setNovo] = useState<string | null>(null);
  const needCreds = mode !== "token";
  // Aguardando confirmação: tenta entrar sozinho a cada 5 s; entra assim que o e-mail for confirmado (em qualquer aparelho).
  useEffect(() => {
    if (!aguardando) return;
    const senha = pass; let vivo = true;
    const tentar = async () => {
      const { data } = await supabase.auth.getSession();
      if (data.session) return;
      const { error } = await supabase.auth.signInWithPassword({ email: aguardando, password: senha });
      if (!error && vivo) onClose();
    };
    const iv = setInterval(() => void tentar(), 5000);
    const { data: sub } = supabase.auth.onAuthStateChange((ev) => { if (ev === "SIGNED_IN" && vivo) onClose(); });
    return () => { vivo = false; clearInterval(iv); sub.subscription.unsubscribe(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [aguardando]);
  useEffect(() => {
    setLivre(null);
    const n = nome.trim();
    if (mode !== "up" || n.length < 2) return;
    const t = setTimeout(() => { void supabase.rpc("name_available", { _name: n.slice(0, 16) }).then(({ data, error }) => setLivre(error ? null : !!data)); }, 350);
    return () => clearTimeout(t);
  }, [nome, mode]);
  const [emailLivre, setEmailLivre] = useState<boolean | null>(null);
  useEffect(() => {
    setEmailLivre(null);
    const e = email.trim();
    if (mode !== "up" || !EMAIL.test(e)) return;
    const t = setTimeout(() => { void supabase.rpc("email_available", { _email: e }).then(({ data, error }) => setEmailLivre(error ? null : !!data)); }, 350);
    return () => clearTimeout(t);
  }, [email, mode]);
  const nomeErr = mode === "up" && nome && (nome.trim().length < 2 ? "Mínimo 2 letras" : !/^[\p{L}\p{N} ._-]+$/u.test(nome.trim()) ? "Use letras, números, espaço, . _ -" : nome.trim().length > 16 ? "Máximo 16 caracteres" : livre === false ? "Esse nome de piloto já existe" : "");
  const dom = email.split("@")[1]?.toLowerCase() ?? "";
  const typo: Record<string, string> = { "gmial.com": "gmail.com", "gmal.com": "gmail.com", "gmail.co": "gmail.com", "hotmal.com": "hotmail.com", "hotmail.co": "hotmail.com", "outlok.com": "outlook.com", "yahoo.co": "yahoo.com" };
  const emailErr = email && (!EMAIL.test(email.trim()) ? "E-mail inválido" : typo[dom] ? `Você quis dizer @${typo[dom]}?` : mode === "up" && emailLivre === false ? "Esse e-mail já possui uma conta. Faça login." : "");
  const hint = (e: string | false | "", ok: boolean) => e ? <p className="-mt-2 text-xs text-destructive">{e}</p> : ok ? <p className="-mt-2 text-xs text-accent">✓ OK</p> : null;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (Date.now() - last < 3000) return setMsg({ t: "Aguarde alguns segundos antes de tentar de novo." });
    if (mode === "token" && tokTab === "gerar") {
      if (novo) return onClose();
      setBusy(true); setLast(Date.now()); setMsg(null);
      try {
        const r = await generateGuestToken();
        setNovo(r.token); setTok(r.token);
        localStorage.setItem("realgear-access-token", r.token);
        localStorage.setItem("realgear-access-expires", r.expires_at);
        setEntering(true);
        const { error } = await supabase.auth.verifyOtp({ token_hash: r.hash, type: "magiclink" });
        if (error) setEntering(false);
        if (error) return setMsg({ t: "Token gerado, mas não foi possível entrar. Tente entrar com ele." });
        onClose();
      } catch (err) { setMsg({ t: err instanceof Error ? err.message : "Não foi possível gerar o token agora." }); } finally { setBusy(false); }
      return;
    }
    if (mode === "token") {
      if (!tok.trim()) return setMsg({ t: "Cole o seu token de acesso." });
      setBusy(true); setLast(Date.now()); setMsg(null);
      try {
        const r = await loginWithToken({ data: { token: tok } });
        if (!r.ok) return setMsg({ t: r.motivo });
        localStorage.setItem("realgear-access-token", tok.trim());
        localStorage.setItem("realgear-access-expires", r.expires_at);
        setEntering(true);
        const { error } = await supabase.auth.verifyOtp({ token_hash: r.hash, type: "magiclink" });
        if (error) { setEntering(false); setMsg({ t: "Não foi possível entrar agora." }); } else onClose();
      } catch { setMsg({ t: "Não foi possível entrar agora." }); } finally { setBusy(false); }
      return;
    }
    if (!EMAIL.test(email.trim())) return setMsg({ t: "Informe um e-mail válido." });
    if (mode === "up") {
      if (nome.trim().length < 2) return setMsg({ t: "Informe o nome do piloto." });
      if (livre === false) return setMsg({ t: "Esse nome de piloto já existe." });
      if (emailLivre === false) return setMsg({ t: "Esse e-mail já possui uma conta. Faça login." });
      if (livre === null || emailLivre === null) return setMsg({ t: "Verificando nome e e-mail, aguarde..." });
      if (!senhaSegura(pass)) return setMsg({ t: "A senha precisa de 8 caracteres, com letras e números." });
      if (pass !== pass2) return setMsg({ t: "As senhas não conferem." });
      if (!termos || !priv) return setMsg({ t: "Aceite os termos de uso e a política de privacidade." });
    }
    if (mode === "in" && !pass) return setMsg({ t: "Informe a senha." });
    setBusy(true); setLast(Date.now()); setMsg(null);
    try {
      if (mode === "in") {
        setEntering(true);
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password: pass });
        if (error) setEntering(false);
        if (error) setMsg({ t: /confirm/i.test(error.message) ? "Confirme seu e-mail antes de entrar." : "E-mail ou senha incorretos." });
      } else if (mode === "up") {
        const { data, error } = await supabase.auth.signUp({ email: email.trim(), password: pass, options: { emailRedirectTo: window.location.origin, data: { display_name: nome.trim().slice(0, 16) } } });
        if (error && /registered|exists/i.test(error.message)) setMsg({ t: "Esse e-mail já possui uma conta. Faça login." });
        else if (error && /duplicate|players_name|name_key/i.test(error.message)) setMsg({ t: "Esse nome de piloto já existe." });
        else if (error) setMsg({ t: /weak|pwned|leak/i.test(error.message) ? "Essa senha é fraca ou já vazou. Escolha outra." : "Não foi possível criar a conta agora." });
        else if (!data?.session) setAguardando(email.trim());
      } else {
        await supabase.auth.resetPasswordForEmail(email.trim(), { redirectTo: `${window.location.origin}/reset-password` });
        setMsg({ t: "Se houver uma conta com esse e-mail, enviamos um link para redefinir a senha.", ok: true });
      }
    } finally { setBusy(false); }
  };

  const inp = "w-full rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary";
  const title = { in: "Entrar", up: "Criar conta", forgot: "Recuperar senha", token: "Entrar com token" }[mode];
  if (aguardando) return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 p-4 backdrop-blur" onClick={tapBack(onClose)}>
      <div onClick={(e) => e.stopPropagation()} className="w-full max-w-sm space-y-3 rounded-2xl border border-border bg-card p-6 text-center text-foreground shadow-2xl">
        <h2 className="font-display text-2xl">Aguardando confirmação</h2>
        <p className="text-sm text-muted-foreground">Enviamos um link para <b className="text-foreground">{aguardando}</b>. Abra o e-mail (confira também o spam) e toque no link de confirmação. Assim que confirmar, você será redirecionado automaticamente.</p>
        <div className="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
        <button type="button" onClick={() => { setAguardando(null); setMode("in"); }} className="text-xs text-muted-foreground">Já confirmei · Entrar</button>
      </div>
    </div>
  );
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 p-4 backdrop-blur" onClick={tapBack(onClose)}>
      <form onSubmit={submit} onClick={(e) => e.stopPropagation()} className="relative w-full max-w-sm space-y-3 rounded-2xl border border-border bg-card p-6 text-foreground shadow-2xl" aria-label={title}>
        <button type="button" aria-label="Fechar" onClick={onClose} className="absolute right-3 top-3 text-muted-foreground"><X className="h-5 w-5" /></button>
        <h2 className="font-display text-2xl">{title}</h2>
        {mode === "token" && <div className="grid grid-cols-2 gap-1 rounded-lg bg-secondary p-1 text-xs">
          {(["entrar", "gerar"] as const).map((t) => <Button key={t} type="button" variant={tokTab === t ? "default" : "ghost"} disabled={busy} onClick={() => { setTokTab(t); setMsg(null); }}>{t === "entrar" ? "Entrar com token" : "Gerar token"}</Button>)}
        </div>}
        {mode === "token" && tokTab === "gerar" && novo && <div className="space-y-2 rounded-lg border border-border bg-background p-3">
          <code className="block break-all text-sm">{novo}</code>
          <button type="button" onClick={() => void navigator.clipboard?.writeText(novo)} className="text-xs text-primary">Copiar token</button>
        </div>}
        {mode === "token" && tokTab === "entrar" && <>
          <input className={inp} placeholder="SR-XXXXXXXX..." value={tok} onChange={(e) => setTok(e.target.value)} autoComplete="off" spellCheck={false} />
          <p className="text-xs text-muted-foreground">Validade: 24 horas.</p>
        </>}
        {mode === "up" && <input className={inp} placeholder="Nome do piloto" value={nome} onChange={(e) => setNome(e.target.value)} maxLength={16} />}
        {mode === "up" && nome && hint(nomeErr, livre === true)}
        {mode === "up" && nome && !nomeErr && livre === null && nome.trim().length >= 2 && <p className="-mt-2 text-xs text-muted-foreground">Verificando...</p>}
        {needCreds && !novo && <input className={inp} type="email" autoComplete="email" placeholder="E-mail" value={email} onChange={(e) => setEmail(e.target.value)} />}
        {needCreds && !novo && email && hint(emailErr, mode !== "up" ? !emailErr : emailLivre === true)}
        {mode === "up" && email && !emailErr && emailLivre === null && <p className="-mt-2 text-xs text-muted-foreground">Verificando...</p>}
        {mode !== "forgot" && needCreds && !novo && (
          <div className="relative">
            <input className={inp} type={show ? "text" : "password"} autoComplete={mode === "in" ? "current-password" : "new-password"} placeholder="Senha" value={pass} onChange={(e) => setPass(e.target.value)} />
            <button type="button" aria-label={show ? "Ocultar senha" : "Mostrar senha"} onClick={() => setShow(!show)} className="absolute right-2 top-2 text-muted-foreground">{show ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}</button>
          </div>
        )}
        {mode === "up" && <p className="text-xs text-muted-foreground">Depois de confirmar o e-mail, você pode gerar um token de acesso em "Entrar com token" para entrar sem senha.</p>}
        {mode === "up" && <>
          <input className={inp} type={show ? "text" : "password"} placeholder="Confirmar senha" value={pass2} onChange={(e) => setPass2(e.target.value)} />
          <label className="flex gap-2 text-xs"><input type="checkbox" checked={termos} onChange={(e) => setTermos(e.target.checked)} /> Aceito os termos de uso</label>
          <label className="flex gap-2 text-xs"><input type="checkbox" checked={priv} onChange={(e) => setPriv(e.target.checked)} /> Aceito a política de privacidade</label>
        </>}
        {mode === "in" && <p className="text-xs text-muted-foreground">Sua sessão fica mantida neste aparelho até você sair.</p>}
        <Button type="submit" disabled={busy} className="w-full font-display">{busy ? "Verificando…" : mode === "token" && tokTab === "gerar" ? (novo ? "Entrar no jogo" : "Gerar token") : mode === "in" || mode === "token" ? "Entrar" : mode === "up" ? "Criar conta" : "Enviar link"}</Button>
        {msg && <p role="status" className={`text-sm ${msg.ok ? "text-accent" : "text-destructive"}`}>{msg.t}</p>}
        <div className="flex justify-between text-xs text-muted-foreground">
          {mode !== "forgot" && <button type="button" onClick={() => { setMode("forgot"); setMsg(null); }}>Esqueci minha senha</button>}
          {mode !== "token" && <button type="button" onClick={() => { setMode("token"); setMsg(null); }}>Entrar com token</button>}
          {mode !== "in" ? <button type="button" onClick={() => { setMode("in"); setMsg(null); }}>Já tenho conta</button> : <button type="button" onClick={() => { setMode("up"); setMsg(null); }}>Criar conta</button>}
        </div>
      </form>
    </div>
  );
}
