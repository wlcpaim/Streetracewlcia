import { useState } from "react";
import { Wrench, Cog, Gauge, Cpu, Activity, ShieldAlert, Brain, Hammer, Trophy, Medal, Flag } from "lucide-react";
import { AuthModal, type AuthMode } from "./AuthModal";
import { ENGINE_CATALOG } from "@/game/data/engine_catalog";
import { velMediaPistao } from "@/game/pins/pins";
import oficina from "@/assets/bg_oficina.png.asset.json";
import dino from "@/assets/bg_dinamometro.png.asset.json";
import race from "@/assets/race_start.jpg.asset.json";
import garage from "@/assets/bg_garage.jpg.asset.json";

const NAV = [["inicio", "Início"], ["jogo", "O jogo"], ["engenharia", "Engenharia"], ["competicoes", "Competições"], ["recordes", "Recordes"], ["hall", "Hall da Fama"]] as const;
const ETAPAS = [
  [Wrench, "OFICINA", "Conheça as peças, ferramentas e componentes disponíveis."],
  [Hammer, "MONTAGEM", "Monte seu motor respeitando dimensões, compatibilidade e especificações."],
  [Cog, "PREPARAÇÃO", "Cilindrada, curso, pistão, biela, virabrequim, cabeçote e usinagem."],
  [Cpu, "ENGENHARIA", "Analise relações mecânicas, cálculos, desempenho e limites físicos."],
  [Activity, "REMAPEAMENTO", "Ajuste o módulo programável: mistura, ponto, corte e 2-step."],
  [Gauge, "TESTES", "Dinamômetro: potência, torque, temperatura e comportamento."],
  [ShieldAlert, "STRESSCHECK", "Divergências, sobrecargas e problemas físicos em tempo real."],
  [Brain, "REALGEAR / ENG IA", "Funil de engenharia e o Mecânico da Bancada de Competição."],
] as const;

export function Landing() {
  const [auth, setAuth] = useState<AuthMode | null>(null);
  const t = ENGINE_CATALOG["titan160"]!.p;
  const D = t["diametro"]!.valor as number, C = t["curso"]!.valor as number;
  const V = Math.PI * D * D / 4 * C / 1000;
  const go = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  const Sec = ({ id, k, title, children }: { id: string; k: string; title: string; children: React.ReactNode }) => (
    <section id={id} className="mx-auto max-w-6xl scroll-mt-20 px-5 py-16">
      <div className="font-display text-xs tracking-[0.3em] text-primary">{k}</div>
      <h2 className="mt-2 font-display text-3xl md:text-4xl">{title}</h2>
      <div className="mt-8">{children}</div>
    </section>
  );
  return (
    <div className="h-dvh w-full overflow-y-auto bg-background font-body text-foreground">
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/85 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-4 px-5 py-3">
          <button onClick={() => go("inicio")} className="flex items-center gap-2 font-display text-lg">STREET<span className="text-primary">RACE</span></button>
          <nav className="hidden flex-1 justify-center gap-5 text-sm text-muted-foreground lg:flex">{NAV.map(([id, l]) => <button key={id} onClick={() => go(id)} className="hover:text-foreground">{l}</button>)}</nav>
          <div className="ml-auto flex gap-2">
            <button onClick={() => setAuth("in")} className="rounded-lg border border-border px-3 py-1.5 text-sm font-bold">Entrar</button>
            <button onClick={() => setAuth("up")} className="rounded-lg bg-primary px-3 py-1.5 text-sm font-bold text-primary-foreground">Criar conta</button>
          </div>
        </div>
      </header>

      <section id="inicio" className="relative overflow-hidden">
        <img src={oficina.url} alt="Oficina do jogo" className="absolute inset-0 h-full w-full object-cover opacity-30" />
        <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/70 to-background" />
        <div className="relative mx-auto max-w-6xl px-5 py-24 md:py-36 animate-in fade-in slide-in-from-bottom-4 duration-700">
          <h1 className="max-w-3xl font-display text-4xl leading-tight md:text-6xl">NÃO É APENAS PREPARAÇÃO.<br /><span className="text-primary">É ENGENHARIA.</span></h1>
          <p className="mt-5 max-w-2xl text-lg">Construa seu protótipo, desenvolva seu motor, aplique conhecimentos de mecânica, física e matemática e descubra até onde sua engenharia pode chegar.</p>
          <p className="mt-2 max-w-2xl text-muted-foreground">Prepare, monte, ajuste e teste sua máquina em um ambiente onde cada componente influencia diretamente o resultado.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <button onClick={() => setAuth("up")} className="rounded-xl bg-primary px-6 py-3 font-display text-primary-foreground shadow-lg">CRIAR MINHA CONTA</button>
            <button onClick={() => go("jogo")} className="rounded-xl border border-border px-6 py-3 font-display">CONHECER O JOGO</button>
          </div>
        </div>
      </section>

      <Sec id="jogo" k="COMO FUNCIONA" title="Da oficina à pista">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{ETAPAS.map(([I, n, d]) => (
          <div key={n} className="rounded-2xl border border-border bg-card p-5 transition hover:border-primary"><I className="h-6 w-6 text-primary" /><div className="mt-3 font-display">{n}</div><p className="mt-1 text-sm text-muted-foreground">{d}</p></div>
        ))}</div>
      </Sec>

      <Sec id="engenharia" k="FÍSICA E MATEMÁTICA REAIS" title="Os mesmos cálculos da simulação">
        <div className="grid gap-3 md:grid-cols-2">
          <Formula f="V = π × (D²/4) × C × N" vars="D diâmetro (mm) · C curso (mm) · N cilindros" ex={`Titan 160: π × (${D}²/4) × ${C} × 1 = ${V.toFixed(1)} cm³`} />
          <Formula f="Vm = 2 × C × RPM / 60" vars="C curso (m) · RPM rotação · Vm em m/s" ex={`Curso ${C} mm a 8.000 rpm: ${velMediaPistao(C, 8000).toFixed(2)} m/s`} />
          <Formula f="a = r·ω²·(cos θ + (r/l)·cos 2θ)" vars="r raio do virabrequim · l biela · ω = 2π·RPM/60 (rad/s)" ex="Aproximação; a validação do pino usa a cinemática biela-manivela exata." />
          <Formula f="F = m × a" vars="m massa alternativa (kg) · a aceleração (m/s²) · F em N" ex="Comparada ao limite do pino em cisalhamento e flexão." />
          <Formula f="P = T × ω" vars="T torque (N·m) · ω (rad/s) · P em W (÷ 735,5 = cv)" ex="Curva do dinamômetro e corrida usam o mesmo motor." />
          <Formula f="i = Zcoroa / Zpinhão" vars="Z número de dentes" ex="Titan de fábrica: 44/15 = 2,933" />
        </div>
      </Sec>

      <section className="relative overflow-hidden">
        <img src={garage.url} alt="Garagem do jogo" className="absolute inset-0 h-full w-full object-cover opacity-25" />
        <div className="relative mx-auto max-w-6xl px-5 py-20">
          <h2 className="font-display text-3xl md:text-4xl">SUA ENGENHARIA. SUA MÁQUINA. SUA HISTÓRIA.</h2>
          <p className="mt-3 max-w-2xl text-muted-foreground">Crie seu protótipo, escolha seus componentes, desenvolva sua preparação e mostre o resultado nas competições.</p>
          <div className="mt-6 grid gap-3 sm:grid-cols-3">{[[oficina.url, "Oficina e montagem"], [dino.url, "Dinamômetro"], [race.url, "Largada"]].map(([u, l]) => (
            <figure key={l} className="overflow-hidden rounded-2xl border border-border bg-card"><img src={u} alt={l} className="aspect-video w-full object-cover" loading="lazy" /><figcaption className="p-3 font-display text-sm">{l}</figcaption></figure>
          ))}</div>
          <button onClick={() => setAuth("up")} className="mt-8 rounded-xl bg-primary px-6 py-3 font-display text-primary-foreground">CRIAR MEU PROTÓTIPO</button>
        </div>
      </section>

      <Sec id="competicoes" k="COMPETIÇÕES" title="PARTICIPE DE BOLOLO PELO BRASIL INTEIRO!">
        <p className="max-w-2xl text-muted-foreground">Desenvolva sua máquina, dispute as corridas de arrancada contra os adversários do jogo e mostre sua preparação.</p>
        <Empty icon={Flag} t="Nenhum evento oficial aberto no momento. Os eventos aparecem aqui quando forem criados." />
      </Sec>
      <Sec id="recordes" k="RECORDES" title="Maior velocidade, potência, torque e tempo">
        <Empty icon={Trophy} t="Nenhum recorde homologado ainda. Só entram resultados válidos medidos pela simulação." />
      </Sec>
      <Sec id="hall" k="HALL DA FAMA" title="SEU NOME PODE ENTRAR PARA A HISTÓRIA.">
        <Empty icon={Medal} t="O Hall da Fama começa vazio: os primeiros campeões ainda vão ser escritos." />
        <button onClick={() => setAuth("up")} className="mt-6 rounded-xl bg-primary px-6 py-3 font-display text-primary-foreground">CRIAR MINHA CONTA</button>
      </Sec>
      <footer className="border-t border-border py-8 text-center text-xs text-muted-foreground">StreetRace · simulador de preparação e engenharia</footer>
      {auth && <AuthModal mode={auth} setMode={setAuth} onClose={() => setAuth(null)} />}
    </div>
  );
}
function Formula({ f, vars, ex }: { f: string; vars: string; ex: string }) {
  return <div className="rounded-2xl border border-border bg-card p-5"><div className="font-mono text-lg text-accent">{f}</div><div className="mt-2 text-xs text-muted-foreground">{vars}</div><div className="mt-3 border-t border-border pt-2 text-sm">{ex}</div></div>;
}
function Empty({ icon: I, t }: { icon: typeof Trophy; t: string }) {
  return <div className="mt-6 flex items-center gap-3 rounded-2xl border border-dashed border-border p-6 text-muted-foreground"><I className="h-6 w-6 text-primary" />{t}</div>;
}
