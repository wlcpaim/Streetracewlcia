/** Id único do build (vite define), igual no servidor e no cliente. */
declare const __BUILD_ID__: string;
/** Horário (ms) em que o build foi gerado; impede downgrade. */
declare const __BUILD_TIME__: number;
