// Central de Administração — regras puras (sem banco). Testadas em src/test/admin-rules.test.ts.
// Permissões padrão de cada cargo vivem só no banco (public.tier_perms); aqui ficam rótulos e regras de negócio.

export const PERMS = [
  "players.view", "players.manage", "players.ban", "players.unban",
  "reports.view", "reports.manage", "bugs.view", "bugs.manage",
  "chat.moderate", "chat.configure", "security.view", "investigations.manage",
  "staff.manage", "settings.manage", "audit.view",
] as const;
export type Perm = (typeof PERMS)[number];
export const PERM_LABEL: Record<Perm, string> = {
  "players.view": "Consultar jogadores", "players.manage": "Gerenciar contas", "players.ban": "Banir e suspender",
  "players.unban": "Desbanir e remover suspensão", "reports.view": "Ver denúncias", "reports.manage": "Tratar denúncias",
  "bugs.view": "Ver bugs", "bugs.manage": "Tratar bugs", "chat.moderate": "Advertir e silenciar",
  "chat.configure": "Configurar filtro de palavras", "security.view": "Ver IPs e acessos",
  "investigations.manage": "Investigações", "staff.manage": "Gerenciar equipe",
  "settings.manage": "Configurações globais", "audit.view": "Consultar auditoria",
};

export const TIERS = ["moderador", "administrador", "superadministrador"] as const;
export type Tier = (typeof TIERS)[number];
export const TIER_LABEL: Record<Tier, string> = { moderador: "Moderador", administrador: "Administrador", superadministrador: "Superadministrador" };
export const tierRank = (t: Tier | null | undefined) => (t ? TIERS.indexOf(t) + 1 : 0);

/** Quem pode mudar o cargo/permissões de quem: nunca a si mesmo, nunca alguém de cargo igual ou maior, nunca dar cargo acima do próprio. */
export function canManageStaff(actor: { id: string; tier: Tier | null; perms: readonly string[] }, target: { id: string; tier: Tier | null }, newTier?: Tier | null): string | null {
  if (!actor.perms.includes("staff.manage")) return "sem permissão para gerenciar a equipe";
  if (actor.id === target.id) return "ninguém pode alterar os próprios privilégios";
  if (tierRank(target.tier) >= tierRank(actor.tier)) return "não é possível alterar alguém de cargo igual ou superior";
  if (newTier && tierRank(newTier) > tierRank(actor.tier)) return "não é possível conceder cargo acima do seu";
  return null;
}

// ── Punições ──
export const SANCTION_KINDS = ["advertencia", "silenciamento", "suspensao", "banimento"] as const;
export type SanctionKind = (typeof SANCTION_KINDS)[number];
export const SANCTION_LABEL: Record<SanctionKind, string> = { advertencia: "Advertência", silenciamento: "Silenciamento", suspensao: "Suspensão", banimento: "Banimento permanente" };
/** Durações em minutos oferecidas no formulário (personalizável). */
export const DURATIONS = [
  { min: 5, label: "5 minutos" }, { min: 15, label: "15 minutos" }, { min: 60, label: "1 hora" },
  { min: 1440, label: "24 horas" }, { min: 10080, label: "7 dias" }, { min: 43200, label: "30 dias" },
] as const;
export const SANCTION_CATEGORIES = ["chat", "comportamento", "trapaca", "fraude", "nome", "outros"] as const;

export type SanctionRow = { kind: SanctionKind; starts_at: string; ends_at: string | null; revoked_at: string | null };
/** Punição está valendo agora: não revogada e (permanente ou ainda não expirou). Advertência nunca bloqueia. */
export function isActive(s: SanctionRow, now = Date.now()): boolean {
  if (s.revoked_at) return false;
  if (s.kind === "advertencia") return false;
  if (Date.parse(s.starts_at) > now) return false;
  return s.ends_at == null || Date.parse(s.ends_at) > now;
}
export type Standing = { blocked: boolean; muted: boolean; until: string | null; kind: SanctionKind | null; reason: string | null };
/** Situação da conta: banimento/suspensão bloqueiam o jogo; silenciamento só o chat. */
export function standingOf<T extends SanctionRow & { reason: string }>(list: T[], now = Date.now()): Standing {
  const act = list.filter((s) => isActive(s, now));
  const block = act.filter((s) => s.kind === "banimento" || s.kind === "suspensao");
  const pick = (xs: T[]) => xs.find((s) => s.ends_at == null) ?? [...xs].sort((a, b) => Date.parse(b.ends_at!) - Date.parse(a.ends_at!))[0];
  if (block.length) { const b = pick(block)!; return { blocked: true, muted: true, until: b.ends_at, kind: b.kind, reason: b.reason }; }
  const mute = act.filter((s) => s.kind === "silenciamento");
  if (mute.length) { const m = pick(mute)!; return { blocked: false, muted: true, until: m.ends_at, kind: m.kind, reason: m.reason }; }
  return { blocked: false, muted: false, until: null, kind: null, reason: null };
}

// ── Chat ──
export const CHAT_CATEGORIES = ["palavrao", "ofensa", "discriminacao", "ameaca", "assedio", "spam", "flood", "proibida"] as const;
export const CHAT_CAT_LABEL: Record<(typeof CHAT_CATEGORIES)[number], string> = {
  palavrao: "Palavrão", ofensa: "Ofensa", discriminacao: "Discriminação", ameaca: "Ameaça", assedio: "Assédio",
  spam: "Spam", flood: "Flood", proibida: "Expressão proibida",
};
const LEET: Record<string, string> = { "0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t", "8": "b", "9": "g", "@": "a", "$": "s", "!": "i", "|": "i", "€": "e" };
/** Normaliza para o filtro: minúsculas, sem acentos, números/símbolos trocados por letras, sem separadores e sem letras repetidas. */
export function normalize(s: string): string {
  const base = s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  let out = "";
  for (const ch of base) {
    const c = LEET[ch] ?? ch;
    if (/[a-z]/.test(c)) out += c;
  }
  return out.replace(/(.)\1+/g, "$1");
}
export type Filter = { id: string; term: string; normalized: string; category: string; severity: number; active: boolean };
/** Termos curtos (até SHORT_TERM letras) só valem como palavra inteira (com plural/diminutivo), para não pegar
 *  palavras normais: "cu" em "curva", "trans" em "transmissão", "viado" em "enviado". Termos longos valem em qualquer
 *  posição do texto colado, o que pega "p.o.r.r.a" e frases sem espaço. */
export const SHORT_TERM = 5;
const SUFFIXES = ["", "s", "es", "inho", "inha", "inhos", "inhas", "zinho", "zinha", "zao", "zona", "ona"];
/** Palavras normalizadas da mensagem; letras soltas seguidas ("p o r r a") viram uma palavra só. */
export function chatTokens(body: string): string[] {
  const raw = body.split(/[\s,;:!?()"'[\]{}<>/\\-]+/).map(normalize).filter(Boolean);
  const out: string[] = [];
  let run = "";
  for (const t of raw) {
    if (t.length === 1) { run += t; continue; }
    if (run) { out.push(normalize(run)); run = ""; }
    out.push(t);
  }
  if (run) out.push(normalize(run));
  return out;
}
export function termHits(f: { normalized: string }, n: string, tokens: string[]): boolean {
  const t = f.normalized;
  if (t.length < 2) return false;
  if (t.length > SHORT_TERM) return n.includes(t);
  return tokens.some((w) => SUFFIXES.some((x) => w === normalize(t + x)));
}
/** Primeiro termo proibido presente na mensagem (o mais grave, se houver vários). */
export function matchFilter(body: string, filters: Filter[]): Filter | null {
  const n = normalize(body), tokens = chatTokens(body);
  const hits = filters.filter((f) => f.active && termHits(f, n, tokens));
  return hits.sort((a, b) => b.severity - a.severity)[0] ?? null;
}
export type LadderStep = { kind: SanctionKind; minutes: number | null };
/** Regra progressiva padrão (configurável em Configurações): 1ª advertência, 2ª 5 min, 3ª 15 min, 4ª+ 1 h. */
export const DEFAULT_LADDER: LadderStep[] = [
  { kind: "advertencia", minutes: 0 }, { kind: "suspensao", minutes: 5 },
  { kind: "suspensao", minutes: 15 }, { kind: "suspensao", minutes: 60 },
];
/** Gravidade da palavra: 1 leve (palavrão), 2 média (xingamento a alguém), 3 grave (homofobia, assédio), 4 gravíssima (racismo, ameaça, nazismo). */
export const SEVERITY_LABEL = ["", "Leve", "Média", "Grave", "Gravíssima"] as const;
/** Média: começa suspendendo. */
export const LADDER_MEDIUM: LadderStep[] = [
  { kind: "suspensao", minutes: 30 }, { kind: "suspensao", minutes: 180 },
  { kind: "suspensao", minutes: 720 }, { kind: "suspensao", minutes: 1440 },
];
/** Grave: 1ª vez = DEFAULT_SEVERE (24 h, configurável), depois 7 dias e 30 dias. */
export const DEFAULT_SEVERE: LadderStep = { kind: "suspensao", minutes: 1440 };
export const LADDER_GRAVE_NEXT: LadderStep[] = [{ kind: "suspensao", minutes: 10080 }, { kind: "suspensao", minutes: 43200 }];
/** Gravíssima (racismo, ameaça de morte, nazismo): banimento permanente instantâneo já na 1ª vez (Anticheat). */
export const LADDER_EXTREME: LadderStep[] = [{ kind: "banimento", minutes: null }];
const at = (l: LadderStep[], offense: number) => l[Math.min(Math.max(offense, 1), l.length) - 1]!;
export function ladderStep(offense: number, severity: number, ladder = DEFAULT_LADDER, severe = DEFAULT_SEVERE): LadderStep {
  if (severity >= 4) return at(LADDER_EXTREME, offense);
  if (severity === 3) return offense <= 1 ? severe : at(LADDER_GRAVE_NEXT, offense - 1);
  if (severity === 2) return at(LADDER_MEDIUM, offense);
  return at(ladder, offense);
}
/** Texto da punição para o jogador. */
export function stepText(s: LadderStep): string {
  if (s.kind === "advertencia") return "Você recebeu uma advertência.";
  if (s.kind === "banimento") return "Conta banida permanentemente.";
  const m = s.minutes ?? 0;
  const d = m >= 1440 ? `${Math.round(m / 1440)} dia${m >= 2880 ? "s" : ""}` : m >= 60 ? `${Math.round(m / 60)} h` : `${m} min`;
  return `Conta suspensa por ${d}.`;
}
/** Flood: mais de `max` mensagens em `windowS` segundos, ou a mesma mensagem repetida 3 vezes seguidas. */
export const DEFAULT_FLOOD = { max: 5, windowS: 10, repeat: 3 };
export function isFlood(recent: { body: string; created_at: string }[], body: string, now = Date.now(), cfg = DEFAULT_FLOOD): "flood" | "spam" | null {
  const inWin = recent.filter((m) => now - Date.parse(m.created_at) <= cfg.windowS * 1000);
  if (inWin.length >= cfg.max) return "flood";
  const n = normalize(body);
  const last = [...recent].sort((a, b) => Date.parse(b.created_at) - Date.parse(a.created_at)).slice(0, cfg.repeat - 1);
  if (n && last.length === cfg.repeat - 1 && last.every((m) => normalize(m.body) === n)) return "spam";
  return null;
}

// ── Denúncias ──
export const REPORT_CATEGORIES = ["ofensas", "discriminacao", "assedio", "ameacas", "spam", "trapaca", "exploracao_bug", "programas_ilegais", "fraude", "antidesportivo", "nome_inadequado", "falsidade", "outros"] as const;
export const REPORT_CAT_LABEL: Record<(typeof REPORT_CATEGORIES)[number], string> = {
  ofensas: "Ofensas e insultos", discriminacao: "Racismo e discriminação", assedio: "Assédio e perseguição", ameacas: "Ameaças",
  spam: "Spam e flood", trapaca: "Trapaças", exploracao_bug: "Exploração de bugs", programas_ilegais: "Uso de programas ilegais",
  fraude: "Fraudes", antidesportivo: "Comportamento antidesportivo", nome_inadequado: "Nome inadequado", falsidade: "Falsidade ideológica", outros: "Outros",
};
export const REPORT_STATUS = ["recebida", "pendente", "em_analise", "aguardando_evidencias", "procedente", "improcedente", "encaminhada", "encerrada"] as const;
export const REPORT_STATUS_LABEL: Record<(typeof REPORT_STATUS)[number], string> = {
  recebida: "Recebida", pendente: "Pendente", em_analise: "Em análise", aguardando_evidencias: "Aguardando evidências",
  procedente: "Procedente", improcedente: "Improcedente", encaminhada: "Encaminhada para revisão", encerrada: "Encerrada",
};
export const PRIORITIES = ["baixa", "media", "alta", "critica"] as const;
export const PRIORITY_LABEL: Record<(typeof PRIORITIES)[number], string> = { baixa: "Baixa", media: "Média", alta: "Alta", critica: "Crítica" };
/** Prioridade inicial da denúncia pela categoria (nunca pune ninguém, só ordena a fila). */
export function reportPriority(cat: string): (typeof PRIORITIES)[number] {
  if (["discriminacao", "ameacas"].includes(cat)) return "critica";
  if (["assedio", "programas_ilegais", "fraude", "trapaca"].includes(cat)) return "alta";
  return "media";
}

// ── Bugs ──
export const BUG_CATEGORIES = ["visual", "jogabilidade", "desempenho", "login", "conexao", "conta", "interface", "outros"] as const;
export const BUG_CAT_LABEL: Record<(typeof BUG_CATEGORIES)[number], string> = {
  visual: "Erro visual", jogabilidade: "Jogabilidade", desempenho: "Desempenho", login: "Login", conexao: "Conexão", conta: "Conta", interface: "Interface", outros: "Outros",
};
export const BUG_STATUS = ["recebido", "em_analise", "bugfix", "resolvido", "nao_reproduzido", "duplicado"] as const;
export const BUG_STATUS_LABEL: Record<(typeof BUG_STATUS)[number], string> = {
  recebido: "Recebido", em_analise: "Em análise", bugfix: "Bugfix", resolvido: "Resolvido", nao_reproduzido: "Não reproduzido", duplicado: "Duplicado",
};

export const INV_STATUS = ["aberta", "em_andamento", "aguardando", "concluida", "arquivada"] as const;
export const INV_STATUS_LABEL: Record<(typeof INV_STATUS)[number], string> = { aberta: "Aberta", em_andamento: "Em andamento", aguardando: "Aguardando", concluida: "Concluída", arquivada: "Arquivada" };

// ── Reputação ──
export const DEFAULT_REP_WEIGHTS = { advertencia: 5, silenciamento: 10, suspensao: 20, banimento: 50, violacao: 2 };
export type RepClass = "sem_ocorrencias" | "atencao" | "historico" | "reincidente" | "acompanhamento";
export const REP_LABEL: Record<RepClass, string> = { sem_ocorrencias: "Sem ocorrências", atencao: "Atenção", historico: "Histórico de infrações", reincidente: "Reincidente", acompanhamento: "Em acompanhamento" };
/**
 * Pontuação 0–100 só com infrações confirmadas: punições não revogadas e violações do filtro.
 * Denúncias não confirmadas nunca entram. Nunca bane: é apoio à análise.
 */
export function reputation(sanctions: { kind: SanctionKind; revoked_at: string | null; created_at: string }[], violations: number, openInvestigation = false, w = DEFAULT_REP_WEIGHTS) {
  const valid = sanctions.filter((s) => !s.revoked_at);
  const lost = valid.reduce((t, s) => t + w[s.kind], 0) + violations * w.violacao;
  const score = Math.max(0, 100 - lost);
  const confirmed = valid.filter((s) => s.kind !== "advertencia").length;
  const cls: RepClass = openInvestigation ? "acompanhamento"
    : valid.length === 0 && violations === 0 ? "sem_ocorrencias"
    : confirmed >= 2 ? "reincidente"
    : confirmed === 1 ? "historico" : "atencao";
  const last = [...valid].sort((a, b) => Date.parse(b.created_at) - Date.parse(a.created_at))[0]?.created_at ?? null;
  return { score, cls, confirmed, warnings: valid.filter((s) => s.kind === "advertencia").length, last };
}

// ── Evidências ──
export const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
export const MAX_IMAGES = 3;
/** Tipo real do arquivo pelos primeiros bytes (não confia no nome nem no tipo enviado). */
export function sniffImage(b: Uint8Array): "image/png" | "image/jpeg" | "image/webp" | null {
  if (b.length >= 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return "image/png";
  if (b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
  if (b.length >= 12 && b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return "image/webp";
  return null;
}

/** Endereço do cliente: só o cabeçalho que a Cloudflare escreve; nunca X-Forwarded-For enviado pelo cliente. */
export function clientIp(h: { get(n: string): string | null }): string | null {
  const ip = h.get("cf-connecting-ip")?.trim();
  return ip && /^[0-9a-f.:]{3,45}$/i.test(ip) ? ip : null;
}
export function platformOf(ua: string): string {
  if (/android/i.test(ua)) return "Android";
  if (/iphone|ipad|ipod/i.test(ua)) return "iOS";
  if (/windows/i.test(ua)) return "Windows";
  if (/mac os/i.test(ua)) return "macOS";
  if (/linux/i.test(ua)) return "Linux";
  return "Outro";
}

// ── Abuso de contas por IP (indício automático; a equipe confirma) ──
export const ABUSE_WINDOW_H = 24;
export const MULTI_ACCOUNT_MIN = 4;      // contas distintas no mesmo IP em 24 h → alerta
export const AUTO_BLOCK_MIN = 10;        // contas distintas no mesmo IP em 24 h → bloqueio automático de 24 h
export const AUTO_BLOCK_HOURS = 24;
export type AbuseFlag = { kind: "multicontas_ip" | "evasao_banimento" | "fazenda_contas"; severity: "media" | "alta" | "critica" };
export const ABUSE_LABEL: Record<AbuseFlag["kind"], string> = { multicontas_ip: "Várias contas no mesmo IP", evasao_banimento: "Possível fuga de banimento", fazenda_contas: "Criação em massa de contas" };
export function abuseVerdict(accounts: number, blockedAmong: number): { flags: AbuseFlag[]; autoBlock: boolean } {
  const flags: AbuseFlag[] = [];
  if (accounts >= MULTI_ACCOUNT_MIN) flags.push({ kind: "multicontas_ip", severity: "media" });
  if (blockedAmong > 0 && accounts > blockedAmong) flags.push({ kind: "evasao_banimento", severity: "alta" });
  const autoBlock = accounts >= AUTO_BLOCK_MIN;
  if (autoBlock) flags.push({ kind: "fazenda_contas", severity: "critica" });
  return { flags, autoBlock };
}
export function ipBlocked(row: { expires_at: string | null } | null | undefined, now = Date.now()): boolean {
  return !!row && (!row.expires_at || Date.parse(row.expires_at) > now);
}
