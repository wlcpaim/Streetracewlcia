import { Fragment, useState } from "react";
import { UserPlus } from "lucide-react";
import { adminStaff, adminSetStaff, adminPlayers, adminReputation, adminNotifications, adminAudit, adminSettings, adminSaveSetting, adminIntegrations } from "../admin.functions";
import { PERMS, PERM_LABEL, TIERS, TIER_LABEL, REP_LABEL, SANCTION_KINDS, SANCTION_LABEL, type Tier } from "../rules";
import { Badge, Kpi, Pager, Panel, ReasonDialog, Section, Select, State, Table, act, btnGhost, btnPrimary, fmt, input, td, toneOf, useLoad } from "./kit";
import { PlayerProfile, must } from "./Players";

export function Staff({ can, me }: { can: (p: string) => boolean; me: { userId: string; tier: string | null } }) {
  const { data, err, loading, reload } = useLoad(() => adminStaff(), []);
  const [add, setAdd] = useState(false), [q, setQ] = useState(""), [found, setFound] = useState<{ user_id: string; name: string; tag: string }[]>([]), [pick, setPick] = useState<string | null>(null), [tier, setTier] = useState<Tier>("moderador");
  const [chg, setChg] = useState<null | { userId: string; tier?: Tier | null; perm?: { name: (typeof PERMS)[number]; allowed: boolean | null }; label: string }>(null);
  const manage = can("staff.manage");
  const o = data?.ops;
  return (
    <Section title="Equipe administrativa" desc="Ninguém altera os próprios privilégios nem os de alguém do mesmo cargo ou acima." actions={manage && <button onClick={() => setAdd(true)} className={btnPrimary}><UserPlus className="h-4 w-4" />Adicionar membro</button>}>
      {o && <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-7">
        <Kpi label="Casos abertos" value={o.casosAbertos} /><Kpi label="Denúncias pendentes" value={o.denunciasPendentes} tone="warn" /><Kpi label="Bugs pendentes" value={o.bugsPendentes} />
        <Kpi label="Investigações críticas" value={o.investigacoesCriticas} tone={o.investigacoesCriticas ? "bad" : "default"} /><Kpi label="Sem responsável" value={o.semResponsavel} tone={o.semResponsavel ? "warn" : "default"} />
        <Kpi label="Aguardando evidências" value={o.aguardandoEvidencias} /><Kpi label="Tempo médio" value={o.tempoMedioHoras == null ? "—" : `${o.tempoMedioHoras.toFixed(1)} h`} hint="denúncias encerradas" />
      </div>}
      <State loading={loading} err={err} empty={!data?.members.length} retry={reload}>
        <div className="grid gap-3 lg:grid-cols-2">
          {data?.members.map((m) => (
            <Panel key={m.userId} title={<span className="normal-case tracking-normal text-foreground">{m.name}{m.userId === me.userId ? " (você)" : ""}</span>} right={<Badge tone="info">{TIER_LABEL[m.tier]}</Badge>}>
              <p className="text-xs text-muted-foreground">{m.openCases} caso(s) em aberto atribuídos{m.legacyRole ? " · cargo vindo do papel antigo" : ""}</p>
              {manage && m.userId !== me.userId && (
                <div className="mt-2 flex flex-wrap gap-2">
                  <Select value={m.tier} onChange={(v) => setChg({ userId: m.userId, tier: v, label: `Mudar ${m.name} para ${TIER_LABEL[v]}` })} options={TIERS.map((t) => [t, TIER_LABEL[t]] as const)} />
                  <button onClick={() => setChg({ userId: m.userId, tier: null, label: `Remover ${m.name} da equipe` })} className={btnGhost}>Remover da equipe</button>
                </div>
              )}
              <div className="mt-3 flex flex-wrap gap-1">
                {PERMS.map((p) => {
                  const on = m.perms.includes(p); const ov = m.overrides.find((x) => x.permission === p);
                  const el = <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ring-1 ${on ? "bg-primary/15 text-primary ring-primary/40" : "bg-secondary text-muted-foreground ring-border line-through"}`}>{p}{ov ? " *" : ""}</span>;
                  return manage && m.userId !== me.userId ? <button key={p} title={`${PERM_LABEL[p]} — clique para ${on ? "revogar" : "conceder"}${ov ? " (clique direito: voltar ao padrão)" : ""}`} onContextMenu={(e) => { e.preventDefault(); if (ov) setChg({ userId: m.userId, perm: { name: p, allowed: null }, label: `Voltar ${p} ao padrão do cargo` }); }} onClick={() => setChg({ userId: m.userId, perm: { name: p, allowed: !on }, label: `${on ? "Revogar" : "Conceder"} ${PERM_LABEL[p]} para ${m.name}` })}>{el}</button> : <span key={p} title={PERM_LABEL[p]}>{el}</span>;
                })}
              </div>
              <p className="mt-1 text-[10px] text-muted-foreground">* permissão individual diferente do padrão do cargo</p>
            </Panel>
          ))}
        </div>
      </State>
      <ReasonDialog open={!!chg} title={chg?.label ?? ""} onClose={() => setChg(null)} onConfirm={(reason) => must(adminSetStaff({ data: { userId: chg!.userId, ...(chg!.tier !== undefined ? { tier: chg!.tier } : {}), ...(chg!.perm ? { perm: chg!.perm } : {}), reason } }), "Equipe atualizada").then(reload)} />
      <ReasonDialog open={add} title="Adicionar membro" onClose={() => { setAdd(false); setPick(null); setFound([]); }} confirm="Adicionar" onConfirm={async (reason) => { if (!pick) throw new Error("escolha"); await must(adminSetStaff({ data: { userId: pick, tier, reason } }), "Membro adicionado"); reload(); }}>
        <form className="flex gap-2" onSubmit={async (e) => { e.preventDefault(); const r = await act(adminPlayers({ data: { q, filter: "todos", page: 0 } }), "Busca concluída"); setFound(r?.rows ?? []); }}><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Nome do piloto ou e-mail" className={input} /><button className={btnGhost}>Buscar</button></form>
        <div className="flex flex-wrap gap-1">{found.map((p) => <button key={p.user_id + p.tag} onClick={() => setPick(p.user_id)} className={`${btnGhost} py-1 text-xs ${pick === p.user_id ? "ring-2 ring-ring" : ""}`}>{p.name}</button>)}</div>
        <Select label="Cargo" value={tier} onChange={setTier} options={TIERS.map((t) => [t, TIER_LABEL[t]] as const)} />
      </ReasonDialog>
    </Section>
  );
}

export function Reputation({ can }: { can: (p: string) => boolean }) {
  const [page, setPage] = useState(0), [open, setOpen] = useState<string | null>(null);
  const { data, err, loading, reload } = useLoad(() => adminReputation({ data: { page } }), [page]);
  return (
    <Section title="Reputação e reincidência" desc="Só infrações confirmadas contam; punições revogadas saem da conta. É apoio à análise: nunca bane sozinho.">
      <Panel>
        <State loading={loading} err={err} empty={!data?.rows.length} retry={reload}>
          <Table head={["Jogador", "Pontuação", "Classificação", "Advertências", "Infrações confirmadas", "Bloqueios no chat", "Última ocorrência", ""]}>
            {data?.rows.map((r) => (
              <tr key={r.userId}>
                <td className={td}><b>{r.name}</b></td>
                <td className={td}><div className="flex items-center gap-2"><div className="h-1.5 w-20 overflow-hidden rounded-full bg-secondary"><div className="h-full bg-primary" style={{ width: `${r.score}%` }} /></div><span className="tabular-nums">{r.score}</span></div></td>
                <td className={td}><Badge tone={toneOf(r.cls)}>{REP_LABEL[r.cls]}</Badge></td>
                <td className={td}>{r.warnings}</td><td className={td}>{r.confirmed}</td><td className={td}>{r.violations}</td><td className={td}>{fmt(r.last)}</td>
                <td className={td}><button onClick={() => setOpen(r.userId)} className={btnGhost}>Perfil</button></td>
              </tr>
            ))}
          </Table>
          {data && <Pager page={page} total={data.total} size={data.pageSize} onPage={setPage} />}
        </State>
      </Panel>
      {open && <PlayerProfile userId={open} can={can} onClose={() => setOpen(null)} />}
    </Section>
  );
}

export function Notifications({ onGo }: { onGo: (section: string) => void }) {
  const { data, err, loading, reload } = useLoad(() => adminNotifications({ data: {} }), []);
  const unread = (data ?? []).filter((n) => !n.read_at).map((n) => n.id);
  const go = (k: string | null) => (k === "denuncia" ? "denuncias" : k === "bug" ? "bugs" : k === "violacao" ? "chat" : null);
  return (
    <Section title="Notificações" desc="Avisos para a equipe: novas denúncias, novos bugs e reincidentes no chat." actions={unread.length > 0 && <button onClick={() => void act(adminNotifications({ data: { markRead: unread } }), "Marcadas como lidas").then(reload)} className={btnGhost}>Marcar todas como lidas</button>}>
      <Panel>
        <State loading={loading} err={err} empty={!data?.length} retry={reload}>
          <ul className="divide-y divide-border/60">{data?.map((n) => (
            <li key={n.id} className="flex items-start justify-between gap-3 py-2">
              <div><div className="flex items-center gap-2 text-sm font-bold">{!n.read_at && <span className="h-2 w-2 rounded-full bg-primary" />}{n.title}</div>{n.body && <div className="text-xs text-muted-foreground">{n.body}</div>}</div>
              <div className="flex shrink-0 items-center gap-2 text-xs text-muted-foreground">{fmt(n.created_at)}{go(n.ref_kind) && <button onClick={() => onGo(go(n.ref_kind)!)} className={`${btnGhost} py-1 text-xs`}>Ver</button>}</div>
            </li>
          ))}</ul>
        </State>
      </Panel>
    </Section>
  );
}

export function Audit() {
  const [q, setQ] = useState(""), [qq, setQQ] = useState(""), [action, setAction] = useState(""), [page, setPage] = useState(0), [show, setShow] = useState<number | null>(null);
  const { data, err, loading, reload } = useLoad(() => adminAudit({ data: { q: qq, action, page } }), [qq, action, page]);
  return (
    <Section title="Logs e auditoria" desc="Registro imutável: nenhuma conta, nem superadministrador, apaga ou altera.">
      <Panel>
        <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); setPage(0); setQQ(q); }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Administrador, motivo, referência ou ID" className={`${input} flex-1`} />
          <Select value={action} onChange={(v) => { setAction(v); setPage(0); }} options={[["", "Todas as ações"], ["punicao", "Punições"], ["conta", "Contas"], ["consulta", "Consultas sensíveis"], ["denuncia", "Denúncias"], ["bug", "Bugs"], ["filtro", "Filtro"], ["chat", "Chat"], ["equipe", "Equipe"], ["config", "Configurações"], ["investigacao", "Investigações"]]} />
          <button className={btnPrimary}>Buscar</button>
        </form>
        <div className="mt-3">
          <State loading={loading} err={err} empty={!data?.rows.length} retry={reload}>
            <Table head={["Quando", "Administrador", "Ação", "Referência", "Motivo", ""]}>
              {data?.rows.map((r) => (
                <Fragment key={r.id}>
                  <tr>
                    <td className={td}>{fmt(r.created_at)}</td><td className={td}><b>{r.actor_name ?? "Sistema"}</b></td><td className={`${td} font-mono text-xs`}>{r.action}</td>
                    <td className={`${td} text-xs`}>{r.ref_kind ? `${r.ref_kind} ${String(r.ref_id ?? "").slice(0, 8)}` : "—"}</td><td className={`${td} max-w-[280px] text-xs`}>{r.reason ?? "—"}</td>
                    <td className={td}>{(r.before || r.after) && <button onClick={() => setShow(show === r.id ? null : r.id)} className={`${btnGhost} py-1 text-xs`}>Antes/depois</button>}</td>
                  </tr>
                  {show === r.id && <tr><td colSpan={6} className="p-2"><div className="grid gap-2 md:grid-cols-2"><pre className="max-h-64 overflow-auto rounded-lg bg-secondary/50 p-2 text-[11px]">{JSON.stringify(r.before, null, 1)}</pre><pre className="max-h-64 overflow-auto rounded-lg bg-secondary/50 p-2 text-[11px]">{JSON.stringify(r.after, null, 1)}</pre></div></td></tr>}
                </Fragment>
              ))}
            </Table>
            {data && <Pager page={page} total={data.total} size={data.pageSize} onPage={setPage} />}
          </State>
        </div>
      </Panel>
    </Section>
  );
}

type Step = { kind: (typeof SANCTION_KINDS)[number]; minutes: number | null };
export function Settings({ can }: { can: (p: string) => boolean }) {
  const { data, err, loading, reload } = useLoad(() => adminSettings(), []);
  const [draft, setDraft] = useState<Record<string, unknown>>({});
  const [saving, setSaving] = useState<string | null>(null);
  const edit = can("settings.manage");
  const val = <T,>(k: string): T => (draft[k] ?? data?.[k]?.value) as T;
  const set = (k: string, v: unknown) => setDraft((d) => ({ ...d, [k]: v }));
  const KEYS = ["ladder", "severe", "flood", "reputation", "geo", "reports", "bugs"] as const;
  const num = (k: string, f: string) => <label key={f} className="text-xs text-muted-foreground">{f}<input type="number" disabled={!edit} value={String((val<Record<string, number>>(k))?.[f] ?? "")} onChange={(e) => set(k, { ...val<Record<string, number>>(k), [f]: Number(e.target.value) })} className={`${input} mt-0.5 py-1.5`} /></label>;
  return (
    <Section title="Configurações gerais" desc={edit ? "Tudo fica salvo no banco e cada alteração vai para a auditoria." : "Somente leitura: falta a permissão settings.manage."}>
      <State loading={loading} err={err} empty={!data} retry={reload}>
        <div className="grid gap-4 lg:grid-cols-2">
          <Panel title="Regra progressiva do chat">
            {(val<Step[]>("ladder") ?? []).map((s, i) => (
              <div key={i} className="mb-2 grid grid-cols-[auto_1fr_1fr] items-end gap-2"><span className="pb-2 text-sm font-bold">{i + 1}ª</span>
                <Select value={s.kind} onChange={(v) => { const l = [...val<Step[]>("ladder")]; l[i] = { ...s, kind: v }; set("ladder", l); }} options={SANCTION_KINDS.map((k) => [k, SANCTION_LABEL[k]] as const)} />
                <label className="text-xs text-muted-foreground">Minutos<input type="number" disabled={!edit} value={s.minutes ?? ""} onChange={(e) => { const l = [...val<Step[]>("ladder")]; l[i] = { ...s, minutes: e.target.value ? Number(e.target.value) : null }; set("ladder", l); }} className={`${input} mt-0.5 py-1.5`} /></label>
              </div>
            ))}
            {edit && <div className="flex gap-2"><button onClick={() => set("ladder", [...val<Step[]>("ladder"), { kind: "suspensao", minutes: 60 }])} className={`${btnGhost} py-1 text-xs`}>+ etapa</button><button onClick={() => set("ladder", val<Step[]>("ladder").slice(0, -1))} className={`${btnGhost} py-1 text-xs`}>− etapa</button></div>}
            <h3 className="mt-3 text-xs font-bold uppercase text-muted-foreground">Infração grave (gravidade 3)</h3>
            <div className="grid grid-cols-2 gap-2"><Select value={val<Step>("severe")?.kind ?? "suspensao"} onChange={(v) => set("severe", { ...val<Step>("severe"), kind: v })} options={SANCTION_KINDS.map((k) => [k, SANCTION_LABEL[k]] as const)} />{num("severe", "minutes")}</div>
          </Panel>
          <Panel title="Anti-flood e limites de envio">
            <div className="grid grid-cols-3 gap-2">{num("flood", "max")}{num("flood", "windowS")}{num("flood", "repeat")}</div>
            <p className="mt-1 text-[11px] text-muted-foreground">max mensagens em windowS segundos; repeat = mesma mensagem seguida.</p>
            <div className="mt-3 grid grid-cols-2 gap-2">{num("reports", "perHour")}{num("bugs", "perHour")}</div>
            <p className="mt-1 text-[11px] text-muted-foreground">Denúncias e reports de bug por hora, por conta.</p>
          </Panel>
          <Panel title="Pontuação de reputação (pontos perdidos)"><div className="grid grid-cols-3 gap-2">{["advertencia", "silenciamento", "suspensao", "banimento", "violacao"].map((f) => num("reputation", f))}</div></Panel>
          <Panel title="Geolocalização por IP">
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" disabled={!edit} checked={!!val<{ enabled: boolean }>("geo")?.enabled} onChange={(e) => set("geo", { ...val<object>("geo"), enabled: e.target.checked })} />Consultar local aproximado dos IPs</label>
            <div className="mt-2 w-40">{num("geo", "ttlDays")}</div>
            <p className="mt-1 text-[11px] text-muted-foreground">Validade do cache em dias, para não repetir consultas.</p>
          </Panel>
        </div>
        {edit && Object.keys(draft).length > 0 && <div className="sticky bottom-3 flex justify-end"><button onClick={() => setSaving("x")} className={btnPrimary}>Salvar alterações ({Object.keys(draft).length})</button></div>}
        <ReasonDialog open={!!saving} title="Salvar configurações" onClose={() => setSaving(null)} onConfirm={async (reason) => { for (const k of KEYS) if (k in draft) await must(adminSaveSetting({ data: { key: k, value: draft[k], reason } }), `"${k}" salvo`); setDraft({}); reload(); }} />
      </State>
    </Section>
  );
}

export function Integrations() {
  const { data, err, loading, reload } = useLoad(() => adminIntegrations(), []);
  return (
    <Section title="Integrações do sistema" desc="Estado verificado agora, não um valor salvo." actions={<button onClick={reload} className={btnGhost}>Verificar de novo</button>}>
      <State loading={loading} err={err} empty={!data?.length} retry={reload}>
        <div className="grid gap-3 md:grid-cols-2">{data?.map((i) => <Panel key={i.nome} title={i.nome} right={<Badge tone={toneOf(i.estado)}>{i.estado}</Badge>}><p className="text-sm text-muted-foreground">{i.detalhe}</p></Panel>)}</div>
      </State>
    </Section>
  );
}
