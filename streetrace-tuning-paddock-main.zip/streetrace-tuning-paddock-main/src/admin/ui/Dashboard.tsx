import { useState } from "react";
import { ResponsiveContainer, AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend, LineChart, Line } from "recharts";
import { adminDashboard } from "../admin.functions";
import { Kpi, Panel, Section, Select, State, useLoad, fmt } from "./kit";

const C = { a: "var(--chart-1)", b: "var(--chart-2)", c: "var(--chart-3)", d: "var(--chart-4)", e: "var(--chart-5)" };
const axis = { stroke: "var(--muted-foreground)", fontSize: 11 };
const tip = { contentStyle: { background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 12, color: "var(--foreground)" } };

export function Dashboard() {
  const [days, setDays] = useState<"7" | "30" | "90">("30");
  const { data, err, loading, reload } = useLoad(() => adminDashboard({ data: { days: Number(days) } }), [days]);
  const k = data?.kpi;
  return (
    <Section title="Visão geral" desc="Números reais do banco do jogo." actions={<Select value={days} onChange={setDays} options={[["7", "Últimos 7 dias"], ["30", "Últimos 30 dias"], ["90", "Últimos 90 dias"]]} />}>
      <State loading={loading} err={err} empty={!data} retry={reload}>
        {k && data && (
          <>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
              <Kpi label="Pilotos cadastrados" value={k.players} hint={`${k.accounts} contas`} />
              <Kpi label="Online agora" value={k.online} tone="good" />
              <Kpi label="Offline" value={k.offline} />
              <Kpi label="Novos no período" value={k.newP} />
              <Kpi label="Ativos 24h" value={k.recent} />
              <Kpi label="Banidos" value={k.banned} tone={k.banned ? "bad" : "default"} />
              <Kpi label="Suspensos" value={k.suspended} tone={k.suspended ? "warn" : "default"} />
              <Kpi label="Denúncias no período" value={k.repAll} />
              <Kpi label="Denúncias pendentes" value={k.repPend} tone={k.repPend ? "warn" : "default"} />
              <Kpi label="Investigações abertas" value={k.invOpen} />
              <Kpi label="Bugs no período" value={k.bugsAll} />
              <Kpi label="Bugs em análise" value={k.bugsAna} tone={k.bugsAna ? "warn" : "default"} />
              <Kpi label="Bugs resolvidos" value={k.bugsRes} tone="good" />
              <Kpi label="Mensagens bloqueadas" value={k.blocked} />
              <Kpi label="Infrações registradas" value={k.infr} />
            </div>
            <div className="grid gap-4 lg:grid-cols-2">
              <Panel title="Crescimento de pilotos">
                <ResponsiveContainer width="100%" height={220}><AreaChart data={data.series}><CartesianGrid stroke="var(--border)" strokeDasharray="3 3" /><XAxis dataKey="dia" {...axis} /><YAxis {...axis} allowDecimals={false} /><Tooltip {...tip} /><Area dataKey="total" name="Total" stroke={C.a} fill={C.a} fillOpacity={0.2} /></AreaChart></ResponsiveContainer>
              </Panel>
              <Panel title="Cadastros e pilotos ativos por dia">
                <ResponsiveContainer width="100%" height={220}><BarChart data={data.series}><CartesianGrid stroke="var(--border)" strokeDasharray="3 3" /><XAxis dataKey="dia" {...axis} /><YAxis {...axis} allowDecimals={false} /><Tooltip {...tip} /><Legend /><Bar dataKey="cadastros" name="Cadastros" fill={C.a} /><Bar dataKey="ativos" name="Contas que entraram" fill={C.b} /></BarChart></ResponsiveContainer>
              </Panel>
              <Panel title="Denúncias e punições">
                <ResponsiveContainer width="100%" height={220}><LineChart data={data.series}><CartesianGrid stroke="var(--border)" strokeDasharray="3 3" /><XAxis dataKey="dia" {...axis} /><YAxis {...axis} allowDecimals={false} /><Tooltip {...tip} /><Legend /><Line dataKey="denuncias" name="Denúncias" stroke={C.c} dot={false} /><Line dataKey="punicoes" name="Punições" stroke={C.d} dot={false} /></LineChart></ResponsiveContainer>
              </Panel>
              <Panel title="Bugs: recebidos x resolvidos e atividade da moderação">
                <ResponsiveContainer width="100%" height={220}><BarChart data={data.series}><CartesianGrid stroke="var(--border)" strokeDasharray="3 3" /><XAxis dataKey="dia" {...axis} /><YAxis {...axis} allowDecimals={false} /><Tooltip {...tip} /><Legend /><Bar dataKey="bugs" name="Bugs" fill={C.e} /><Bar dataKey="resolvidos" name="Resolvidos" fill={C.b} /><Bar dataKey="moderacao" name="Ações da equipe" fill={C.a} /></BarChart></ResponsiveContainer>
              </Panel>
            </div>
            <p className="text-[11px] text-muted-foreground">"Contas que entraram" conta acessos registrados por dia; o histórico de online minuto a minuto não é guardado.</p>
            {data.recentAudit.length > 0 && (
              <Panel title="Atividades administrativas recentes">
                <ul className="space-y-1 text-sm">{data.recentAudit.map((r) => <li key={r.id} className="flex justify-between gap-2"><span><b>{r.actor_name ?? "Sistema"}</b> · {r.action}{r.reason ? ` — ${r.reason}` : ""}</span><span className="shrink-0 text-xs text-muted-foreground">{fmt(r.created_at)}</span></li>)}</ul>
              </Panel>
            )}
          </>
        )}
      </State>
    </Section>
  );
}
