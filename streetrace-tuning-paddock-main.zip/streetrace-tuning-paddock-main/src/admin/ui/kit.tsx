import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { ChevronLeft, ChevronRight, Loader2, Inbox } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";

export const fmt = (s: string | null | undefined) => (s ? new Date(s).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" }) : "—");
export const errText = (e: unknown) => (e instanceof Error ? e.message : String(e ?? "Erro"));

/** Carrega dados de uma função do servidor; recarrega quando `deps` mudam. */
export function useLoad<T>(fn: () => Promise<T>, deps: unknown[]) {
  const [data, setData] = useState<T | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const ref = useRef(fn); ref.current = fn;
  const seq = useRef(0);
  const reload = useCallback(() => {
    const n = ++seq.current; setLoading(true); setErr(null);
    ref.current().then((d) => { if (n === seq.current) setData(d); }).catch((e) => { if (n === seq.current) setErr(errText(e)); }).finally(() => { if (n === seq.current) setLoading(false); });
  }, []);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(reload, deps);
  return { data, err, loading, reload };
}

/** Executa uma ação com toast de sucesso/erro. */
export async function act<T>(p: Promise<T>, ok: string): Promise<T | null> {
  try { const r = await p; toast.success(ok); return r; } catch (e) { toast.error(errText(e)); return null; }
}

export function Section({ title, desc, actions, children }: { title: string; desc?: string; actions?: ReactNode; children: ReactNode }) {
  return (
    <section className="space-y-4">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div><h1 className="font-display text-2xl tracking-wide md:text-3xl">{title}</h1>{desc && <p className="text-sm text-muted-foreground">{desc}</p>}</div>
        {actions}
      </header>
      {children}
    </section>
  );
}
export function Panel({ title, right, children, className = "" }: { title?: ReactNode; right?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <div className={`rounded-2xl border border-border bg-card/80 p-4 shadow-[0_20px_40px_-20px_oklch(0_0_0/0.6)] ${className}`}>
      {(title || right) && <div className="mb-3 flex items-center justify-between gap-2"><h2 className="text-sm font-bold uppercase tracking-[0.18em] text-muted-foreground">{title}</h2>{right}</div>}
      {children}
    </div>
  );
}
export function Kpi({ label, value, tone = "default", hint }: { label: string; value: ReactNode; tone?: "default" | "good" | "warn" | "bad"; hint?: string }) {
  const c = { default: "text-foreground", good: "text-success", warn: "text-mission-ready", bad: "text-destructive" }[tone];
  return (
    <div className="rounded-2xl border border-border bg-gradient-to-br from-card to-secondary/40 p-3">
      <div className="text-[10px] font-bold uppercase tracking-[0.18em] text-muted-foreground">{label}</div>
      <div className={`mt-1 font-display text-2xl tabular-nums ${c}`}>{value}</div>
      {hint && <div className="text-[11px] text-muted-foreground">{hint}</div>}
    </div>
  );
}
const TONE = {
  bad: "bg-destructive/15 text-destructive ring-destructive/40", warn: "bg-mission-ready/15 text-mission-ready ring-mission-ready/40",
  good: "bg-success/15 text-success ring-success/40", info: "bg-primary/15 text-primary ring-primary/40", mute: "bg-secondary text-muted-foreground ring-border",
} as const;
export type Tone = keyof typeof TONE;
export function Badge({ children, tone = "mute" }: { children: ReactNode; tone?: Tone }) {
  return <span className={`inline-flex items-center whitespace-nowrap rounded-full px-2 py-0.5 text-[11px] font-bold ring-1 ${TONE[tone]}`}>{children}</span>;
}
export const toneOf = (s: string): Tone =>
  /critica|banido|banimento|^procedente$|falha|suspens/.test(s) ? "bad"
  : /alta|aguardando|silenc|em_analise|bugfix|pendente|atencao|historico|reincidente|em_andamento|advert/.test(s) ? "warn"
  : /resolvido|regular|^ok$|improcedente|concluida|sem_ocorrencias|online/.test(s) ? "good"
  : /recebid|aberta|media|acompanhamento/.test(s) ? "info" : "mute";

export function Loading({ what = "Carregando" }: { what?: string }) {
  return <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" />{what}…</div>;
}
export function Empty({ children = "Nada por aqui ainda." }: { children?: ReactNode }) {
  return <div className="flex flex-col items-center gap-2 py-10 text-sm text-muted-foreground"><Inbox className="h-6 w-6" />{children}</div>;
}
export function ErrorBox({ msg, retry }: { msg: string; retry?: () => void }) {
  return <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">{msg} {retry && <button onClick={retry} className="ml-2 underline">Tentar de novo</button>}</div>;
}
/** Estado padrão de uma lista: carregando, erro ou vazio. */
export function State({ loading, err, empty, retry, children }: { loading: boolean; err: string | null; empty: boolean; retry: () => void; children: ReactNode }) {
  if (err) return <ErrorBox msg={err} retry={retry} />;
  if (loading && empty) return <Loading />;
  if (empty) return <Empty />;
  return <>{children}</>;
}
export function Pager({ page, total, size, onPage }: { page: number; total: number; size: number; onPage: (p: number) => void }) {
  const pages = Math.max(1, Math.ceil(total / size));
  return (
    <div className="flex items-center justify-between gap-2 pt-3 text-xs text-muted-foreground">
      <span>{total} registro(s)</span>
      <div className="flex items-center gap-1">
        <button disabled={page === 0} onClick={() => onPage(page - 1)} className="rounded-lg border border-border p-1.5 disabled:opacity-40" aria-label="Página anterior"><ChevronLeft className="h-4 w-4" /></button>
        <span className="px-2 tabular-nums">{page + 1} / {pages}</span>
        <button disabled={page + 1 >= pages} onClick={() => onPage(page + 1)} className="rounded-lg border border-border p-1.5 disabled:opacity-40" aria-label="Próxima página"><ChevronRight className="h-4 w-4" /></button>
      </div>
    </div>
  );
}
export function Table({ head, children }: { head: ReactNode[]; children: ReactNode }) {
  return (
    <div className="-mx-4 overflow-x-auto px-4">
      <table className="w-full min-w-[640px] text-left text-sm">
        <thead><tr className="border-b border-border text-[10px] uppercase tracking-[0.16em] text-muted-foreground">{head.map((h, i) => <th key={i} className="px-2 py-2 font-bold">{h}</th>)}</tr></thead>
        <tbody className="divide-y divide-border/60">{children}</tbody>
      </table>
    </div>
  );
}
export const td = "px-2 py-2 align-top";
export const input = "w-full rounded-xl border border-input bg-background/60 px-3 py-2 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring";
export const btn = "inline-flex items-center justify-center gap-1.5 rounded-xl px-3 py-2 text-sm font-bold transition active:scale-[0.98] disabled:opacity-50";
export const btnPrimary = `${btn} bg-primary text-primary-foreground hover:brightness-110`;
export const btnGhost = `${btn} border border-border bg-secondary/60 hover:bg-secondary`;
export const btnDanger = `${btn} bg-destructive text-destructive-foreground hover:brightness-110`;

export function Select<T extends string>({ value, onChange, options, label }: { value: T; onChange: (v: T) => void; options: readonly (readonly [T, string])[]; label?: string }) {
  return (
    <label className="text-xs text-muted-foreground">{label}
      <select value={value} onChange={(e) => onChange(e.target.value as T)} className={`${input} mt-0.5 py-1.5`}>{options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
    </label>
  );
}

/** Confirmação com motivo obrigatório (toda ação administrativa fica justificada na auditoria). */
export function ReasonDialog({ open, title, desc, confirm = "Confirmar", danger, onClose, onConfirm, children, needReason = true }: { open: boolean; title: string; desc?: string; confirm?: string; danger?: boolean; onClose: () => void; onConfirm: (reason: string) => Promise<unknown>; children?: ReactNode; needReason?: boolean }) {
  const [reason, setReason] = useState(""); const [busy, setBusy] = useState(false);
  useEffect(() => { if (open) setReason(""); }, [open]);
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="admin-theme max-h-[90dvh] overflow-y-auto border-border bg-popover text-foreground">
        <DialogHeader><DialogTitle>{title}</DialogTitle>{desc && <DialogDescription>{desc}</DialogDescription>}</DialogHeader>
        {children}
        {needReason && (
          <label className="text-xs text-muted-foreground">Motivo (obrigatório, vai para a auditoria)
            <textarea value={reason} onChange={(e) => setReason(e.target.value)} rows={3} maxLength={500} className={`${input} mt-1`} />
          </label>
        )}
        <DialogFooter className="gap-2">
          <button onClick={onClose} className={btnGhost}>Cancelar</button>
          <button disabled={(needReason && reason.trim().length < 5) || busy} onClick={async () => { setBusy(true); try { await onConfirm(reason.trim()); onClose(); } catch { /* toast já mostrou */ } finally { setBusy(false); } }} className={danger ? btnDanger : btnPrimary}>{busy ? "Aguarde…" : confirm}</button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
