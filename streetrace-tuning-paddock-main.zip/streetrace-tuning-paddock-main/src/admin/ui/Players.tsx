import { useState } from "react";
import { Search, Gavel, Undo2, LogOut, KeyRound } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { adminPlayers, adminPlayer, adminSanction, adminRevokeSanction, adminAccountAction } from "../admin.functions";
import { SANCTION_KINDS, SANCTION_LABEL, SANCTION_CATEGORIES, DURATIONS, REP_LABEL, REPORT_STATUS_LABEL, BUG_STATUS_LABEL, isActive, type SanctionKind } from "../rules";
import { Badge, Kpi, Pager, Panel, ReasonDialog, Section, Select, State, Table, act, btnDanger, btnGhost, btnPrimary, fmt, input, td, toneOf, useLoad } from "./kit";

type Filter = "todos" | "online" | "banidos" | "suspensos" | "silenciados" | "novos";
export const must = async <T,>(p: Promise<T>, ok: string) => { const r = await act(p, ok); if (r === null) throw new Error("falhou"); return r; };

export function Players({ preset = "todos", title = "Jogadores", desc, can, onOpen }: { preset?: Filter; title?: string; desc?: string; can: (p: string) => boolean; onOpen?: (uid: string) => void }) {
  const [q, setQ] = useState(""), [qq, setQQ] = useState(""), [filter, setFilter] = useState<Filter>(preset), [page, setPage] = useState(0);
  const [open, setOpen] = useState<string | null>(null);
  const { data, err, loading, reload } = useLoad(() => adminPlayers({ data: { q: qq, filter, page } }), [qq, filter, page]);
  return (
    <Section title={title} desc={desc ?? "Busque por nome, STR#tag, ID ou e-mail."}>
      <Panel>
        <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); setPage(0); setQQ(q); }}>
          <div className="relative min-w-[200px] flex-1"><Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Nome, STR#123456, ID ou e-mail" className={`${input} pl-9`} /></div>
          <Select value={filter} onChange={(v) => { setFilter(v); setPage(0); }} options={[["todos", "Todos"], ["online", "Online agora"], ["novos", "Novos (7 dias)"], ["silenciados", "Silenciados"], ["suspensos", "Suspensos"], ["banidos", "Banidos"]]} />
          <button className={btnPrimary}>Buscar</button>
        </form>
        <div className="mt-3">
          <State loading={loading} err={err} empty={!data?.rows.length} retry={reload}>
            <Table head={["Piloto", "ID", "Cadastro", "Status", "Situação", ""]}>
              {data?.rows.map((r) => (
                <tr key={r.id} className="hover:bg-secondary/40">
                  <td className={td}><b>{r.name}</b> <span className="text-xs text-primary">STR#{r.tag}</span></td>
                  <td className={`${td} font-mono text-[11px] text-muted-foreground`}>{r.user_id.slice(0, 8)}…</td>
                  <td className={td}>{fmt(r.created_at)}</td>
                  <td className={td}>{r.online ? <Badge tone="good">online</Badge> : <span className="text-xs text-muted-foreground">visto {fmt(r.lastSeen)}</span>}</td>
                  <td className={td}><Badge tone={toneOf(r.situacao)}>{r.situacao}</Badge></td>
                  <td className={td}><button onClick={() => (onOpen ? onOpen(r.user_id) : setOpen(r.user_id))} className={btnGhost}>Abrir</button></td>
                </tr>
              ))}
            </Table>
            {data && <Pager page={page} total={data.total} size={data.pageSize} onPage={setPage} />}
          </State>
        </div>
      </Panel>
      {open && <PlayerProfile userId={open} can={can} onClose={() => { setOpen(null); reload(); }} />}
    </Section>
  );
}

export function PlayerProfile({ userId, can, onClose }: { userId: string; can: (p: string) => boolean; onClose: () => void }) {
  const { data, err, loading, reload } = useLoad(() => adminPlayer({ data: { userId } }), [userId]);
  const [dlg, setDlg] = useState<null | "sancao" | "sessoes" | "senha" | { revoke: string }>(null);
  const [kind, setKind] = useState<SanctionKind>("advertencia"), [mins, setMins] = useState("60"), [custom, setCustom] = useState(""), [cat, setCat] = useState<string>("comportamento"), [note, setNote] = useState("");
  const minutes = custom ? Number(custom) : Number(mins);
  const canKind = (k: SanctionKind) => (k === "advertencia" || k === "silenciamento" ? can("chat.moderate") : can("players.ban"));
  return (
    <Sheet open onOpenChange={(o) => !o && onClose()}>
      <SheetContent side="right" className="admin-theme w-full overflow-y-auto border-border bg-background text-foreground sm:max-w-2xl">
        <SheetHeader><SheetTitle className="font-display text-2xl">{data?.players[0]?.name ?? "Perfil do jogador"}</SheetTitle></SheetHeader>
        <State loading={loading} err={err} empty={!data} retry={reload}>
          {data && (
            <div className="mt-4 space-y-4">
              <div className="flex flex-wrap gap-2">
                <Badge tone={data.online ? "good" : "mute"}>{data.online ? "online" : "offline"}</Badge>
                <Badge tone={data.standing.blocked ? "bad" : data.standing.muted ? "warn" : "good"}>{data.standing.blocked ? `${data.standing.kind} ${data.standing.until ? `até ${fmt(data.standing.until)}` : "permanente"}` : data.standing.muted ? `silenciado até ${fmt(data.standing.until)}` : "conta regular"}</Badge>
                <Badge tone={toneOf(data.reputation.cls)}>{REP_LABEL[data.reputation.cls]} · {data.reputation.score} pts</Badge>
              </div>
              <Panel title="Conta">
                <dl className="grid grid-cols-2 gap-x-3 gap-y-1.5 text-sm">
                  <dt className="text-muted-foreground">ID</dt><dd className="break-all font-mono text-xs">{data.account.id}</dd>
                  <dt className="text-muted-foreground">E-mail</dt><dd className="break-all">{data.account.emailHidden ? <i className="text-muted-foreground">oculto (sem permissão)</i> : data.account.tokenAccount ? <i className="text-muted-foreground">conta por token</i> : data.account.email}</dd>
                  <dt className="text-muted-foreground">Cadastro</dt><dd>{fmt(data.account.createdAt)}</dd>
                  <dt className="text-muted-foreground">Último login</dt><dd>{fmt(data.account.lastSignIn)}</dd>
                  <dt className="text-muted-foreground">Última atividade</dt><dd>{fmt(data.lastSeen)}</dd>
                  <dt className="text-muted-foreground">Plataforma / versão</dt><dd>{data.lastAccess ? `${data.lastAccess.platform ?? "?"} · ${data.lastAccess.game_version ?? "?"}` : "—"}</dd>
                  <dt className="text-muted-foreground">Sessões encerradas em</dt><dd>{fmt(data.account.sessionsRevokedAt)}</dd>
                  <dt className="text-muted-foreground">Senha</dt><dd className="text-xs">Nunca exibida (guardada só como hash pelo sistema de contas){data.account.resetRequestedAt ? ` · redefinição pedida ${fmt(data.account.resetRequestedAt)}` : ""}</dd>
                </dl>
                <div className="mt-3 text-xs text-muted-foreground">Pilotos da conta: {data.players.map((p) => `${p.name} (STR#${p.tag})`).join(", ") || "nenhum"}</div>
                <div className="mt-3 flex flex-wrap gap-2">
                  {(can("chat.moderate") || can("players.ban")) && <button onClick={() => setDlg("sancao")} className={btnDanger}><Gavel className="h-4 w-4" />Aplicar punição</button>}
                  {can("players.manage") && <button onClick={() => setDlg("sessoes")} className={btnGhost}><LogOut className="h-4 w-4" />Revogar sessões</button>}
                  {can("players.manage") && !data.account.tokenAccount && <button onClick={() => setDlg("senha")} className={btnGhost}><KeyRound className="h-4 w-4" />Pedir redefinição de senha</button>}
                </div>
              </Panel>
              <div className="grid grid-cols-3 gap-2">
                <Kpi label="Advertências" value={data.reputation.warnings} />
                <Kpi label="Infrações confirmadas" value={data.reputation.confirmed} tone={data.reputation.confirmed ? "warn" : "default"} />
                <Kpi label="Bloqueios no chat" value={data.violations} />
              </div>
              <Panel title="Histórico de punições">
                {data.sanctions.length === 0 ? <p className="text-sm text-muted-foreground">Nenhuma punição.</p> : (
                  <ul className="space-y-2">{data.sanctions.map((s) => (
                    <li key={s.id} className="rounded-xl border border-border p-2 text-sm">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="flex items-center gap-2"><Badge tone={s.revoked_at ? "mute" : toneOf(s.kind)}>{SANCTION_LABEL[s.kind]}</Badge>{s.source === "automatica" && <Badge>automática</Badge>}{s.revoked_at && <Badge>revogada</Badge>}</span>
                        <span className="text-xs text-muted-foreground">{fmt(s.created_at)}{s.ends_at && s.kind !== "advertencia" ? ` → ${fmt(s.ends_at)}` : ""}</span>
                      </div>
                      <p className="mt-1">{s.reason}</p>
                      {s.note && <p className="text-xs text-muted-foreground">Obs.: {s.note}</p>}
                      {s.revoked_at && <p className="text-xs text-muted-foreground">Revogada {fmt(s.revoked_at)}: {s.revoke_reason}</p>}
                      {!s.revoked_at && (isActive(s) || s.kind === "advertencia") && (s.kind === "advertencia" || s.kind === "silenciamento" ? can("chat.moderate") : can("players.unban")) && (
                        <button onClick={() => setDlg({ revoke: s.id })} className={`${btnGhost} mt-2 py-1 text-xs`}><Undo2 className="h-3.5 w-3.5" />{s.kind === "banimento" ? "Desbanir" : s.kind === "suspensao" ? "Remover suspensão" : "Revogar"}</button>
                      )}
                    </li>
                  ))}</ul>
                )}
              </Panel>
              <div className="grid gap-4 md:grid-cols-2">
                <Panel title="Denúncias recebidas">{data.reportsReceived.length ? <ul className="space-y-1 text-sm">{data.reportsReceived.map((r) => <li key={r.id} className="flex justify-between gap-2"><span>{r.protocol} · {r.category}</span><Badge tone={toneOf(r.status)}>{REPORT_STATUS_LABEL[r.status as keyof typeof REPORT_STATUS_LABEL]}</Badge></li>)}</ul> : <p className="text-sm text-muted-foreground">Nenhuma.</p>}</Panel>
                <Panel title="Denúncias feitas">{data.reportsMade.length ? <ul className="space-y-1 text-sm">{data.reportsMade.map((r) => <li key={r.id} className="flex justify-between gap-2"><span>{r.protocol} → {r.target_name}</span><Badge tone={toneOf(r.status)}>{REPORT_STATUS_LABEL[r.status as keyof typeof REPORT_STATUS_LABEL]}</Badge></li>)}</ul> : <p className="text-sm text-muted-foreground">Nenhuma.</p>}</Panel>
                <Panel title="Reports de bug" className="md:col-span-2">{data.bugs.length ? <ul className="space-y-1 text-sm">{data.bugs.map((b) => <li key={b.id} className="flex justify-between gap-2"><span>{b.protocol} · {b.title}</span><Badge tone={toneOf(b.status)}>{BUG_STATUS_LABEL[b.status as keyof typeof BUG_STATUS_LABEL]}</Badge></li>)}</ul> : <p className="text-sm text-muted-foreground">Nenhum.</p>}</Panel>
              </div>
            </div>
          )}
        </State>
        <ReasonDialog open={dlg === "sancao"} title="Aplicar punição" danger confirm="Aplicar" onClose={() => setDlg(null)}
          onConfirm={(reason) => must(adminSanction({ data: { userId, kind, minutes: kind === "banimento" || kind === "advertencia" ? null : minutes, category: cat, reason, note: note || null } }), "Punição aplicada").then(reload)}>
          <div className="grid grid-cols-2 gap-2">
            <Select label="Tipo" value={kind} onChange={setKind} options={SANCTION_KINDS.filter(canKind).map((k) => [k, SANCTION_LABEL[k]] as const)} />
            <Select label="Categoria" value={cat} onChange={setCat} options={SANCTION_CATEGORIES.map((c) => [c, c] as const)} />
            {(kind === "suspensao" || kind === "silenciamento") && <>
              <Select label="Duração" value={mins} onChange={(v) => { setMins(v); setCustom(""); }} options={DURATIONS.map((d) => [String(d.min), d.label] as const)} />
              <label className="text-xs text-muted-foreground">Ou minutos personalizados<input type="number" min={1} value={custom} onChange={(e) => setCustom(e.target.value)} className={`${input} mt-0.5 py-1.5`} /></label>
            </>}
          </div>
          <label className="text-xs text-muted-foreground">Observação administrativa (interna)<input value={note} onChange={(e) => setNote(e.target.value)} maxLength={1000} className={`${input} mt-1`} /></label>
          {kind === "banimento" && <p className="text-xs text-destructive">Banimento permanente: a conta não entra mais até alguém desbanir.</p>}
        </ReasonDialog>
        <ReasonDialog open={dlg === "sessoes"} title="Revogar sessões" desc="O jogador sai de todos os aparelhos e precisa entrar de novo." onClose={() => setDlg(null)}
          onConfirm={(reason) => must(adminAccountAction({ data: { userId, action: "revogar_sessoes", reason } }), "Sessões encerradas").then(reload)} />
        <ReasonDialog open={dlg === "senha"} title="Pedir redefinição de senha" desc="Envia para o e-mail da conta um link para criar uma nova senha." onClose={() => setDlg(null)}
          onConfirm={(reason) => must(adminAccountAction({ data: { userId, action: "redefinir_senha", reason, redirectTo: `${location.origin}/reset-password` } }), "E-mail enviado").then(reload)} />
        <ReasonDialog open={typeof dlg === "object" && dlg !== null} title="Revogar punição" desc="A reputação volta a contar sem esta punição." onClose={() => setDlg(null)}
          onConfirm={(reason) => must(adminRevokeSanction({ data: { id: (dlg as { revoke: string }).revoke, reason } }), "Punição revogada").then(reload)} />
      </SheetContent>
    </Sheet>
  );
}
