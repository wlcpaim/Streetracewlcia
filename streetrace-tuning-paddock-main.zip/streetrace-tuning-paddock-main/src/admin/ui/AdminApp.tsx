import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { LayoutDashboard, Users, Radio, UserCog, ShieldCheck, History, Gavel, MessagesSquare, Filter, Flag, ScanSearch, Bug, UsersRound, Gauge, Bell, ScrollText, Settings as Cog, Plug, Ban, Siren, Menu, Search, ChevronsLeft, Lock } from "lucide-react";
import { Toaster } from "@/components/ui/sonner";
import { supabase } from "@/integrations/supabase/client";
import { adminMe, adminSearch, adminNotifications } from "../admin.functions";
import { TIER_LABEL, type Tier } from "../rules";
import { Dashboard } from "./Dashboard";
import { Players, PlayerProfile } from "./Players";
import { AccessLog, Sanctions } from "./Security";
import { ChatModeration, WordFilter } from "./ChatMod";
import { Reports } from "./Reports";
import { Bugs } from "./Bugs";
import { BlockedIps, AbuseFlags } from "./Abuse";
import { Investigations } from "./Investigations";
import { Staff, Reputation, Notifications, Audit, Settings, Integrations } from "./Team";
import { Loading, act, btnPrimary, errText, input } from "./kit";

type Me = Awaited<ReturnType<typeof adminMe>>;
const SECTIONS = [
  { id: "geral", label: "Visão geral", icon: LayoutDashboard, perm: null },
  { id: "jogadores", label: "Jogadores", icon: Users, perm: "players.view" },
  { id: "online", label: "Jogadores online", icon: Radio, perm: "players.view" },
  { id: "contas", label: "Gerenciamento de contas", icon: UserCog, perm: "players.manage" },
  { id: "seguranca", label: "Segurança", icon: ShieldCheck, perm: "security.view" },
  { id: "ipbloq", label: "IPs bloqueados", icon: Ban, perm: "security.view" },
  { id: "abuso", label: "Abuso de contas", icon: Siren, perm: "security.view" },
  { id: "acessos", label: "Histórico de acessos", icon: History, perm: "security.view" },
  { id: "punicoes", label: "Banimentos e punições", icon: Gavel, perm: "players.view" },
  { id: "chat", label: "Moderação de chat", icon: MessagesSquare, perm: "chat.moderate" },
  { id: "filtro", label: "Filtro de palavras", icon: Filter, perm: "chat.moderate" },
  { id: "denuncias", label: "Central de denúncias", icon: Flag, perm: "reports.view" },
  { id: "investigacao", label: "Central de investigação", icon: ScanSearch, perm: "investigations.manage" },
  { id: "bugs", label: "Report de bugs", icon: Bug, perm: "bugs.view" },
  { id: "equipe", label: "Central de equipe", icon: UsersRound, perm: null },
  { id: "reputacao", label: "Reputação e reincidência", icon: Gauge, perm: "players.view" },
  { id: "notificacoes", label: "Notificações", icon: Bell, perm: null },
  { id: "auditoria", label: "Logs e auditoria", icon: ScrollText, perm: "audit.view" },
  { id: "config", label: "Configurações", icon: Cog, perm: null },
  { id: "integracoes", label: "Integrações do sistema", icon: Plug, perm: null },
] as const;
type SectionId = (typeof SECTIONS)[number]["id"];

export function AdminApp() {
  const [me, setMe] = useState<Me | null>(null), [err, setErr] = useState<string | null>(null);
  const load = () => { setErr(null); adminMe().then(setMe).catch((e) => setErr(errText(e))); };
  useEffect(() => { load(); }, []);
  if (err) return <div className="admin-theme grid h-dvh w-full place-items-center bg-background p-6 text-foreground"><div className="w-full max-w-md rounded-3xl border border-border bg-card p-6 text-center"><p className="text-sm text-destructive">{err}</p><button onClick={load} className={`${btnPrimary} mt-3`}>Tentar de novo</button></div></div>;
  if (!me) return <div className="admin-theme h-dvh bg-background text-foreground"><Loading what="Abrindo administração" /></div>;
  return <Console me={me} />;
}

function Console({ me }: { me: Me }) {
  const can = useMemo(() => (p: string) => me.perms.includes(p), [me.perms]);
  const [sec, setSec] = useState<SectionId>("geral");
  const [collapsed, setCollapsed] = useState(false), [mobile, setMobile] = useState(false);
  const [q, setQ] = useState(""), [res, setRes] = useState<Awaited<ReturnType<typeof adminSearch>> | null>(null), [profile, setProfile] = useState<string | null>(null);
  const [unread, setUnread] = useState(0);
  useEffect(() => { const t = () => adminNotifications({ data: {} }).then((n) => setUnread(n.filter((x) => !x.read_at).length)).catch(() => {}); t(); const i = setInterval(t, 60_000); return () => clearInterval(i); }, []);
  const visible = SECTIONS.filter((s) => !s.perm || can(s.perm));
  const go = (s: string) => { setSec(s as SectionId); setMobile(false); setRes(null); };
  const body = (() => {
    switch (sec) {
      case "geral": return <Dashboard />;
      case "jogadores": return <Players can={can} />;
      case "online": return <Players can={can} preset="online" title="Jogadores online" desc="Presença real pelo sinal do jogo (some depois de 70 s sem sinal)." />;
      case "contas": return <Players can={can} title="Gerenciamento de contas" desc="Abra a conta para revogar sessões, pedir redefinição de senha ou ver o histórico." />;
      case "seguranca": return <Sanctions can={can} title="Segurança" desc="Contas bloqueadas agora. Sessões de contas suspensas são encerradas e recusadas pelo servidor." />;
      case "ipbloq": return <BlockedIps can={can} />;
      case "abuso": return <AbuseFlags can={can} />;
      case "acessos": return <AccessLog can={can} />;
      case "punicoes": return <Sanctions can={can} />;
      case "chat": return <ChatModeration can={can} />;
      case "filtro": return <WordFilter can={can} />;
      case "denuncias": return <Reports can={can} me={me.userId} />;
      case "investigacao": return <Investigations can={can} />;
      case "bugs": return <Bugs can={can} me={me.userId} />;
      case "equipe": return <Staff can={can} me={me} />;
      case "reputacao": return <Reputation can={can} />;
      case "notificacoes": return <Notifications onGo={go} />;
      case "auditoria": return <Audit />;
      case "config": return <Settings can={can} />;
      case "integracoes": return <Integrations />;
    }
  })();
  const nav = (
    <nav className="flex flex-col gap-0.5 p-2">
      {visible.map((s) => { const I = s.icon; const on = sec === s.id; return (
        <button key={s.id} onClick={() => go(s.id)} title={s.label} className={`group flex items-center gap-3 rounded-xl px-3 py-2 text-left text-sm font-semibold transition ${on ? "bg-primary/15 text-primary ring-1 ring-primary/40" : "text-muted-foreground hover:bg-secondary hover:text-foreground"}`}>
          <I className="h-4 w-4 shrink-0" />{!collapsed && <span className="truncate">{s.label}</span>}
          {s.id === "notificacoes" && unread > 0 && <span className="ml-auto grid h-5 min-w-5 place-items-center rounded-full bg-primary px-1 text-[10px] text-primary-foreground">{unread}</span>}
        </button>); })}
    </nav>
  );
  return (
    <div className="admin-theme flex h-dvh w-full overflow-hidden bg-background text-foreground select-text">
      <Toaster position="top-right" />
      <aside className={`hidden shrink-0 flex-col border-r border-border bg-card/60 transition-all md:flex ${collapsed ? "w-16" : "w-64"}`}>
        <div className="flex items-center justify-between gap-2 border-b border-border p-3">
          {!collapsed && <div><div className="font-display text-lg leading-none tracking-wider">ADMINISTRAÇÃO</div><div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">StreetRace</div></div>}
          <button onClick={() => setCollapsed((c) => !c)} aria-label="Recolher menu" className="rounded-lg p-1.5 text-muted-foreground hover:bg-secondary"><ChevronsLeft className={`h-4 w-4 transition ${collapsed ? "rotate-180" : ""}`} /></button>
        </div>
        <div className="flex-1 overflow-y-auto">{nav}</div>
        {!collapsed && <div className="border-t border-border p-3 text-xs"><b>{me.name}</b><div className="text-muted-foreground">{TIER_LABEL[me.tier as Tier]}</div></div>}
      </aside>
      {mobile && <div className="fixed inset-0 z-50 flex md:hidden" onClick={() => setMobile(false)}><div className="h-full w-72 overflow-y-auto border-r border-border bg-card" onClick={(e) => e.stopPropagation()}><div className="border-b border-border p-3 font-display text-lg">ADMINISTRAÇÃO</div>{nav}</div><div className="flex-1 bg-scrim" /></div>}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center gap-2 border-b border-border bg-card/40 px-3 py-2 backdrop-blur">
          <button onClick={() => setMobile(true)} className="rounded-lg p-2 md:hidden" aria-label="Abrir menu"><Menu className="h-5 w-5" /></button>
          <form className="relative flex-1" onSubmit={async (e) => { e.preventDefault(); if (q.trim().length >= 2) setRes(await adminSearch({ data: { q } }).catch(() => null)); }}>
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Pesquisa global: jogador, e-mail, IP, protocolo, caso…" className={`${input} pl-9`} />
            {res && (
              <div className="absolute left-0 right-0 top-full z-40 mt-1 max-h-[60dvh] overflow-y-auto rounded-2xl border border-border bg-popover p-2 shadow-2xl">
                {[...res.players.map((p) => ({ k: `p${p.id}`, t: `${p.name} · STR#${p.tag}`, s: "Jogador", f: () => setProfile(p.user_id) })),
                  ...res.reports.map((r) => ({ k: `r${r.id}`, t: `${r.protocol} · ${r.target_name}`, s: "Denúncia", f: () => go("denuncias") })),
                  ...res.bugs.map((b) => ({ k: `b${b.id}`, t: `${b.protocol} · ${b.title}`, s: "Bug", f: () => go("bugs") })),
                  ...res.cases.map((c) => ({ k: `c${c.id}`, t: `${c.code} · ${c.title}`, s: "Caso", f: () => go("investigacao") })),
                  ...res.ips.map((i, n) => ({ k: `i${n}`, t: `${i.ip}`, s: "IP", f: () => setProfile(i.user_id) }))].map((x) => (
                  <button key={x.k} type="button" onClick={() => { x.f(); setRes(null); }} className="flex w-full items-center justify-between gap-2 rounded-lg px-2 py-1.5 text-left text-sm hover:bg-secondary"><span>{x.t}</span><span className="text-[10px] uppercase text-muted-foreground">{x.s}</span></button>
                ))}
                {!res.players.length && !res.reports.length && !res.bugs.length && !res.cases.length && !res.ips.length && <p className="p-2 text-sm text-muted-foreground">Nada encontrado.</p>}
              </div>
            )}
          </form>
          <button onClick={() => go("notificacoes")} className="relative rounded-lg p-2 hover:bg-secondary" aria-label="Notificações"><Bell className="h-5 w-5" />{unread > 0 && <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-primary" />}</button>
          <Link to="/" className="hidden rounded-lg px-3 py-2 text-sm text-muted-foreground hover:bg-secondary sm:block">Voltar ao jogo</Link>
        </header>
        <main className="flex-1 overflow-y-auto p-4 md:p-6" onClick={() => res && setRes(null)}><div className="mx-auto max-w-7xl">{body}</div></main>
      </div>
      {profile && <PlayerProfile userId={profile} can={can} onClose={() => setProfile(null)} />}
    </div>
  );
}
