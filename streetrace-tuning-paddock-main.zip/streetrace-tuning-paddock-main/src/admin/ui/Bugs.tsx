import { useState } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { adminBugs, adminBug, adminUpdateBug } from "../admin.functions";
import { BUG_STATUS, BUG_STATUS_LABEL, BUG_CAT_LABEL, PRIORITIES, PRIORITY_LABEL } from "../rules";
import { Badge, Kpi, Pager, Panel, Section, Select, State, Table, act, btnGhost, btnPrimary, fmt, input, td, toneOf, useLoad } from "./kit";

export function Bugs({ can, me }: { can: (p: string) => boolean; me: string }) {
  const [status, setStatus] = useState<"todos" | "abertos" | (typeof BUG_STATUS)[number]>("abertos"), [prio, setPrio] = useState<"todas" | (typeof PRIORITIES)[number]>("todas");
  const [q, setQ] = useState(""), [qq, setQQ] = useState(""), [page, setPage] = useState(0), [open, setOpen] = useState<string | null>(null);
  const { data, err, loading, reload } = useLoad(() => adminBugs({ data: { status, priority: prio, q: qq, page } }), [status, prio, qq, page]);
  const s = data?.stats ?? {};
  return (
    <Section title="Central de bug reports" desc="Cada mudança de status avisa o jogador dentro do jogo.">
      <div className="grid grid-cols-3 gap-2 sm:grid-cols-7">
        <Kpi label="Total" value={s["total"] ?? 0} />{BUG_STATUS.map((x) => <Kpi key={x} label={BUG_STATUS_LABEL[x]} value={s[x] ?? 0} tone={x === "resolvido" ? "good" : x === "em_analise" || x === "bugfix" ? "warn" : "default"} />)}
      </div>
      <Panel>
        <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); setPage(0); setQQ(q); }}>
          <Select label="Status" value={status} onChange={(v) => { setStatus(v); setPage(0); }} options={[["abertos", "Em aberto"], ["todos", "Todos"], ...BUG_STATUS.map((x) => [x, BUG_STATUS_LABEL[x]] as const)]} />
          <Select label="Prioridade" value={prio} onChange={(v) => { setPrio(v); setPage(0); }} options={[["todas", "Todas"], ...PRIORITIES.map((x) => [x, PRIORITY_LABEL[x]] as const)]} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Protocolo, título ou piloto" className={`${input} flex-1`} /><button className={btnPrimary}>Buscar</button>
        </form>
        <div className="mt-3">
          <State loading={loading} err={err} empty={!data?.rows.length} retry={reload}>
            <Table head={["Nº", "Jogador", "Título", "Categoria", "Data", "Prioridade", "Status", "Responsável", ""]}>
              {data?.rows.map((b) => (
                <tr key={b.id} className="hover:bg-secondary/40">
                  <td className={`${td} font-mono text-xs`}>{b.protocol}</td><td className={td}>{b.player_name ?? "—"}</td><td className={td}><b>{b.title}</b></td>
                  <td className={td}>{BUG_CAT_LABEL[b.category as keyof typeof BUG_CAT_LABEL]}</td><td className={td}>{fmt(b.created_at)}</td>
                  <td className={td}><Badge tone={toneOf(b.priority)}>{PRIORITY_LABEL[b.priority as keyof typeof PRIORITY_LABEL]}</Badge></td>
                  <td className={td}><Badge tone={toneOf(b.status)}>{BUG_STATUS_LABEL[b.status as keyof typeof BUG_STATUS_LABEL]}</Badge></td>
                  <td className={td}>{b.assignee ? (b.assignee === me ? "você" : "atribuído") : "—"}</td>
                  <td className={td}><button onClick={() => setOpen(b.id)} className={btnGhost}>Abrir</button></td>
                </tr>
              ))}
            </Table>
            {data && <Pager page={page} total={data.total} size={data.pageSize} onPage={setPage} />}
          </State>
        </div>
      </Panel>
      {open && <BugDetail id={open} can={can} me={me} onClose={() => { setOpen(null); reload(); }} />}
    </Section>
  );
}

function BugDetail({ id, can, me, onClose }: { id: string; can: (p: string) => boolean; me: string; onClose: () => void }) {
  const { data, err, loading, reload } = useLoad(() => adminBug({ data: { id } }), [id]);
  const [resp, setResp] = useState<string | null>(null), [note, setNote] = useState(""), [dup, setDup] = useState("");
  const b = data?.bug; const manage = can("bugs.manage");
  const upd = (patch: NonNullable<Parameters<typeof adminUpdateBug>[0]>["data"], ok: string) => act(adminUpdateBug({ data: patch }), ok).then(reload);
  const tech = (b?.tech ?? {}) as Record<string, string>;
  return (
    <Sheet open onOpenChange={(o) => !o && onClose()}>
      <SheetContent side="right" className="admin-theme w-full overflow-y-auto border-border bg-background text-foreground sm:max-w-2xl">
        <SheetHeader><SheetTitle className="font-display text-2xl">{b?.protocol ?? "Bug"}</SheetTitle></SheetHeader>
        <State loading={loading} err={err} empty={!data} retry={reload}>
          {b && data && (
            <div className="mt-4 space-y-4">
              <Panel title={b.title}>
                <div className="mb-2 flex flex-wrap gap-2 text-xs"><Badge tone="info">{BUG_CAT_LABEL[b.category as keyof typeof BUG_CAT_LABEL]}</Badge><Badge tone={toneOf(b.status)}>{BUG_STATUS_LABEL[b.status as keyof typeof BUG_STATUS_LABEL]}</Badge><span className="text-muted-foreground">{b.player_name ?? "?"} · {fmt(b.created_at)}</span></div>
                <p className="whitespace-pre-wrap text-sm">{b.description}</p>
                {b.steps && <><h3 className="mt-3 text-xs font-bold uppercase text-muted-foreground">Passos</h3><p className="whitespace-pre-wrap text-sm">{b.steps}</p></>}
                <div className="mt-3 grid grid-cols-2 gap-2 text-sm"><div><h3 className="text-xs font-bold uppercase text-muted-foreground">Esperado</h3>{b.expected ?? "—"}</div><div><h3 className="text-xs font-bold uppercase text-muted-foreground">Obtido</h3>{b.actual ?? "—"}</div></div>
                {b.extra && <p className="mt-2 text-sm text-muted-foreground">{b.extra}</p>}
                <p className="mt-3 text-[11px] text-muted-foreground">Versão {b.game_version ?? "?"} · {b.platform ?? "?"} · tela {tech["viewport"] ?? "?"} · cena {tech["scene"] ?? "?"}</p>
                {data.images.map((u) => <a key={u} href={u} target="_blank" rel="noreferrer"><img src={u} alt="Captura enviada pelo jogador" className="mt-2 max-h-64 rounded-lg" /></a>)}
              </Panel>
              {manage && (
                <Panel title="Tratamento">
                  <div className="grid grid-cols-2 gap-2">
                    <Select label="Status" value={b.status as (typeof BUG_STATUS)[number]} onChange={(v) => void upd({ id, status: v }, v === "resolvido" ? "Marcado como resolvido" : "Status atualizado")} options={BUG_STATUS.map((x) => [x, BUG_STATUS_LABEL[x]] as const)} />
                    <Select label="Prioridade" value={b.priority as (typeof PRIORITIES)[number]} onChange={(v) => void upd({ id, priority: v }, "Prioridade atualizada")} options={PRIORITIES.map((x) => [x, PRIORITY_LABEL[x]] as const)} />
                  </div>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {b.assignee !== me && <button onClick={() => void upd({ id, assignee: me }, "Atribuído a você")} className={btnGhost}>Assumir</button>}
                    {b.status === "resolvido" && <button onClick={() => void upd({ id, status: "em_analise" }, "Reaberto")} className={btnGhost}>Reabrir</button>}
                  </div>
                  <div className="mt-2 flex gap-2"><input value={dup} onChange={(e) => setDup(e.target.value)} placeholder="Duplicado de BUG-2026-000001" className={input} /><button disabled={!dup} onClick={() => void upd({ id, duplicateOf: dup }, "Marcado como duplicado")} className={btnGhost}>Marcar duplicado</button></div>
                  <label className="mt-3 block text-xs text-muted-foreground">Resposta ao jogador<textarea defaultValue={b.response ?? ""} onChange={(e) => setResp(e.target.value)} rows={2} className={`${input} mt-1`} /></label>
                  <label className="mt-2 block text-xs text-muted-foreground">Observação interna<textarea value={note} onChange={(e) => setNote(e.target.value)} rows={2} className={`${input} mt-1`} /></label>
                  <button onClick={() => void upd({ id, ...(resp !== null ? { response: resp } : {}), ...(note ? { note } : {}) }, "Salvo").then(() => setNote(""))} className={`${btnPrimary} mt-2`}>Salvar</button>
                </Panel>
              )}
              <Panel title="Histórico"><ul className="space-y-1 text-sm">{data.history.map((h) => <li key={h.id}><span className="text-xs text-muted-foreground">{fmt(h.created_at)}</span> · <b>{h.actor_name ?? "Sistema"}</b> {h.action}{h.to_status ? ` → ${BUG_STATUS_LABEL[h.to_status as keyof typeof BUG_STATUS_LABEL] ?? h.to_status}` : ""}{h.note ? `: ${h.note}` : ""}{h.internal ? <span className="ml-1 text-[10px] text-muted-foreground">(interno)</span> : null}</li>)}</ul></Panel>
            </div>
          )}
        </State>
      </SheetContent>
    </Sheet>
  );
}
