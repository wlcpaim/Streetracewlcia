import { useState } from "react";
import { Ban, Undo2, Check, X } from "lucide-react";
import { adminBlockedIps, adminBlockIp, adminUnblockIp, adminAbuseFlags, adminResolveAbuse } from "../admin.functions";
import { ABUSE_LABEL, type AbuseFlag } from "../rules";
import { Badge, Panel, ReasonDialog, Section, Select, State, Table, btnDanger, btnGhost, fmt, input, td, useLoad } from "./kit";
import { PlayerProfile, must } from "./Players";

const DUR = [["24", "24 horas"], ["168", "7 dias"], ["720", "30 dias"], ["0", "Permanente"]] as const;

export function BlockedIps({ can }: { can: (p: string) => boolean }) {
  const { data, err, loading, reload } = useLoad(() => adminBlockedIps(), []);
  const [ip, setIp] = useState(""), [hours, setHours] = useState<string>("24"), [dlg, setDlg] = useState<null | "block" | { unblock: string }>(null);
  return (
    <Section title="IPs bloqueados" desc="Redes bloqueadas não conseguem gerar token, entrar nem jogar. Bloqueios automáticos vêm da detecção de abuso e expiram sozinhos.">
      {can("players.ban") && (
        <Panel title="Bloquear IP">
          <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); if (ip.trim()) setDlg("block"); }}>
            <input value={ip} onChange={(e) => setIp(e.target.value)} placeholder="Ex.: 177.10.20.30" className={`${input} max-w-xs font-mono`} />
            <Select value={hours} onChange={setHours} options={DUR} />
            <button className={btnDanger}><Ban className="h-4 w-4" />Bloquear</button>
          </form>
          <p className="mt-2 text-[11px] text-muted-foreground">Atenção: IP de operadora móvel ou wi-fi público pode ser dividido por vários jogadores inocentes.</p>
        </Panel>
      )}
      <Panel>
        <State loading={loading} err={err} empty={!data?.length} retry={reload}>
          <Table head={["IP", "Local", "Motivo", "Origem", "Até", "Tentativas barradas", ""]}>
            {data?.map((r) => (
              <tr key={r.ip}>
                <td className={`${td} font-mono text-xs`}>{r.ip}</td>
                <td className={`${td} text-xs`}>{r.geo ? [r.geo["cidade"], r.geo["regiao"], r.geo["pais"]].filter(Boolean).join(", ") : "—"}</td>
                <td className={td}>{r.reason}</td>
                <td className={td}><Badge tone={r.source === "automatico" ? "warn" : "mute"}>{r.source === "automatico" ? "automático" : "manual"}</Badge></td>
                <td className={td}>{r.active ? (r.expires_at ? fmt(r.expires_at) : "permanente") : <Badge>expirado</Badge>}</td>
                <td className={td}>{r.hits}</td>
                <td className={td}>{can("players.unban") && <button onClick={() => setDlg({ unblock: r.ip })} className={btnGhost}><Undo2 className="h-4 w-4" />Desbloquear</button>}</td>
              </tr>
            ))}
          </Table>
        </State>
      </Panel>
      <ReasonDialog open={dlg === "block"} danger title={`Bloquear ${ip.trim()}`} confirm="Bloquear" onClose={() => setDlg(null)}
        onConfirm={(reason) => must(adminBlockIp({ data: { ip: ip.trim(), hours: Number(hours) || null, reason } }), "IP bloqueado").then(() => { setIp(""); reload(); })} />
      <ReasonDialog open={typeof dlg === "object" && dlg !== null} title="Desbloquear IP" onClose={() => setDlg(null)}
        onConfirm={(reason) => must(adminUnblockIp({ data: { ip: (dlg as { unblock: string }).unblock, reason } }), "IP desbloqueado").then(reload)} />
    </Section>
  );
}

export function AbuseFlags({ can }: { can: (p: string) => boolean }) {
  const [status, setStatus] = useState<"aberto" | "confirmado" | "descartado">("aberto");
  const { data, err, loading, reload } = useLoad(() => adminAbuseFlags({ data: { status } }), [status]);
  const [open, setOpen] = useState<string | null>(null), [dlg, setDlg] = useState<null | { id: string; status: "confirmado" | "descartado"; ip: string }>(null);
  return (
    <Section title="Abuso de contas" desc="Detecção automática a cada acesso: várias contas no mesmo IP em 24 h, conta nova na rede de um jogador banido e criação em massa (bloqueia o IP por 24 h). É indício, não prova: confira antes de punir.">
      <Panel right={<Select value={status} onChange={setStatus} options={[["aberto", "Abertos"], ["confirmado", "Confirmados"], ["descartado", "Descartados"]]} />}>
        <State loading={loading} err={err} empty={!data?.length} retry={reload}>
          <ul className="space-y-2">{data?.map((f) => (
            <li key={f.id} className="rounded-xl border border-border p-3 text-sm">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="flex flex-wrap items-center gap-2"><Badge tone={f.severity === "critica" || f.severity === "alta" ? "bad" : "warn"}>{ABUSE_LABEL[f.kind as AbuseFlag["kind"]] ?? f.kind}</Badge><span className="font-mono text-xs">{f.ip}</span>{f.blocked && <Badge tone="bad">IP bloqueado</Badge>}</span>
                <span className="text-xs text-muted-foreground">atualizado {fmt(f.updated_at)}</span>
              </div>
              <div className="mt-2 flex flex-wrap gap-1.5">{f.contas.map((c) => <button key={c.userId} onClick={() => setOpen(c.userId)} className="rounded-lg bg-secondary px-2 py-0.5 text-xs font-semibold text-primary hover:underline">{c.nome}</button>)}</div>
              {status === "aberto" && can("players.manage") && (
                <div className="mt-2 flex gap-2">
                  <button onClick={() => setDlg({ id: f.id, status: "confirmado", ip: f.ip })} className={btnDanger}><Check className="h-4 w-4" />Confirmar abuso</button>
                  <button onClick={() => setDlg({ id: f.id, status: "descartado", ip: f.ip })} className={btnGhost}><X className="h-4 w-4" />Descartar</button>
                </div>
              )}
            </li>
          ))}</ul>
        </State>
      </Panel>
      <ReasonDialog open={!!dlg} title={dlg?.status === "confirmado" ? `Confirmar abuso em ${dlg.ip}` : "Descartar alerta"} desc={dlg?.status === "confirmado" ? "Para bloquear a rede, use a aba IPs bloqueados; para punir, abra cada conta." : "O alerta sai da lista de abertos."} onClose={() => setDlg(null)}
        onConfirm={(reason) => must(adminResolveAbuse({ data: { id: dlg!.id, status: dlg!.status, reason } }), "Alerta atualizado").then(reload)} />
      {open && <PlayerProfile userId={open} can={can} onClose={() => setOpen(null)} />}
    </Section>
  );
}
