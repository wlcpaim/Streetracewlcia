import { useState } from "react";
import { Plus, Search } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { adminInvestigations, adminInvestigation, adminSaveInvestigation, adminTimeline, adminPlayers } from "../admin.functions";
import { INV_STATUS, INV_STATUS_LABEL, PRIORITIES, PRIORITY_LABEL } from "../rules";
import { Badge, Pager, Panel, ReasonDialog, Section, Select, State, Table, act, btnGhost, btnPrimary, fmt, input, td, toneOf, useLoad } from "./kit";
import { PlayerProfile, must } from "./Players";

const ICON: Record<string, string> = { acesso: "🔑", chat: "💬", denuncia_recebida: "🚩", denuncia_feita: "📝", punicao: "⚖️", bug: "🐞", admin: "🛡️" };

export function Timeline({ userId }: { userId: string }) {
  const { data, err, loading, reload } = useLoad(() => adminTimeline({ data: { userId } }), [userId]);
  return (
    <State loading={loading} err={err} empty={!data?.length} retry={reload}>
      <ol className="relative space-y-2 border-l border-border pl-4">
        {data?.map((e, i) => (
          <li key={i} className="relative">
            <span className="absolute -left-[22px] top-0.5 grid h-4 w-4 place-items-center rounded-full bg-secondary text-[9px]">{ICON[e.tipo] ?? "•"}</span>
            <div className="text-xs text-muted-foreground">{fmt(e.at)}</div>
            <div className="text-sm font-bold">{e.titulo}</div>
            {e.detalhe && <div className="break-words text-xs text-muted-foreground">{e.detalhe}</div>}
          </li>
        ))}
      </ol>
    </State>
  );
}

export function Investigations({ can }: { can: (p: string) => boolean }) {
  const [status, setStatus] = useState<"abertas" | "todas" | (typeof INV_STATUS)[number]>("abertas"), [page, setPage] = useState(0), [open, setOpen] = useState<string | null>(null);
  const [q, setQ] = useState(""), [found, setFound] = useState<{ user_id: string; name: string; tag: string }[]>([]), [tl, setTl] = useState<{ id: string; name: string } | null>(null);
  const [creating, setCreating] = useState(false), [title, setTitle] = useState(""), [prio, setPrio] = useState<(typeof PRIORITIES)[number]>("media");
  const { data, err, loading, reload } = useLoad(() => adminInvestigations({ data: { status, page } }), [status, page]);
  const search = async () => { const r = await act(adminPlayers({ data: { q, filter: "todos", page: 0 } }), "Busca concluída"); setFound(r?.rows ?? []); };
  return (
    <Section title="Central de investigação" desc="Pesquise um jogador para ver a linha do tempo unificada, ou acompanhe os casos abertos." actions={<button onClick={() => setCreating(true)} className={btnPrimary}><Plus className="h-4 w-4" />Novo caso</button>}>
      <Panel title="Pesquisar jogador">
        <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); void search(); }}><div className="relative flex-1"><Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Nome, STR#tag, ID ou e-mail" className={`${input} pl-9`} /></div><button className={btnPrimary}>Buscar</button></form>
        <div className="mt-2 flex flex-wrap gap-2">{found.map((p) => <button key={p.user_id + p.tag} onClick={() => setTl({ id: p.user_id, name: p.name })} className={btnGhost}>{p.name} <span className="text-xs text-primary">STR#{p.tag}</span></button>)}</div>
        {tl && <div className="mt-4"><div className="mb-2 flex items-center justify-between"><h3 className="font-bold">Linha do tempo — {tl.name}</h3><button onClick={() => void act(adminSaveInvestigation({ data: { title: `Investigação — ${tl.name}`, targetUser: tl.id } }), "Caso aberto").then(reload)} className={btnGhost}>Abrir caso para este jogador</button></div><Timeline userId={tl.id} /></div>}
      </Panel>
      <Panel title="Casos" right={<Select value={status} onChange={(v) => { setStatus(v); setPage(0); }} options={[["abertas", "Em aberto"], ["todas", "Todos"], ...INV_STATUS.map((x) => [x, INV_STATUS_LABEL[x]] as const)]} />}>
        <State loading={loading} err={err} empty={!data?.rows.length} retry={reload}>
          <Table head={["Caso", "Título", "Alvo", "Prioridade", "Status", "Prazo", "Atualizado", ""]}>
            {data?.rows.map((c) => (
              <tr key={c.id}>
                <td className={`${td} font-mono text-xs`}>{c.code}</td><td className={td}><b>{c.title}</b></td><td className={td}>{c.target_name ?? "—"}</td>
                <td className={td}><Badge tone={toneOf(c.priority)}>{PRIORITY_LABEL[c.priority as keyof typeof PRIORITY_LABEL]}</Badge></td>
                <td className={td}><Badge tone={toneOf(c.status)}>{INV_STATUS_LABEL[c.status as keyof typeof INV_STATUS_LABEL]}</Badge></td>
                <td className={td}>{fmt(c.due_at)}</td><td className={td}>{fmt(c.updated_at)}</td>
                <td className={td}><button onClick={() => setOpen(c.id)} className={btnGhost}>Abrir</button></td>
              </tr>
            ))}
          </Table>
          {data && <Pager page={page} total={data.total} size={data.pageSize} onPage={setPage} />}
        </State>
      </Panel>
      <ReasonDialog open={creating} title="Novo caso" needReason={false} confirm="Abrir caso" onClose={() => setCreating(false)} onConfirm={() => must(adminSaveInvestigation({ data: { title, priority: prio } }), "Caso aberto").then(() => { setTitle(""); reload(); })}>
        <label className="text-xs text-muted-foreground">Título<input value={title} onChange={(e) => setTitle(e.target.value)} className={`${input} mt-1`} /></label>
        <Select label="Prioridade" value={prio} onChange={setPrio} options={PRIORITIES.map((x) => [x, PRIORITY_LABEL[x]] as const)} />
      </ReasonDialog>
      {open && <CaseDetail id={open} can={can} onClose={() => { setOpen(null); reload(); }} />}
    </Section>
  );
}

function CaseDetail({ id, can, onClose }: { id: string; can: (p: string) => boolean; onClose: () => void }) {
  const { data, err, loading, reload } = useLoad(() => adminInvestigation({ data: { id } }), [id]);
  const [note, setNote] = useState(""), [summary, setSummary] = useState<string | null>(null), [link, setLink] = useState(""), [kind, setKind] = useState<"denuncia" | "bug" | "punicao" | "violacao">("denuncia"), [profile, setProfile] = useState(false);
  const inv = data?.inv;
  const save = (patch: Omit<NonNullable<Parameters<typeof adminSaveInvestigation>[0]>["data"], "id">, ok: string) => act(adminSaveInvestigation({ data: { id, ...patch } }), ok).then(reload);
  return (
    <Sheet open onOpenChange={(o) => !o && onClose()}>
      <SheetContent side="right" className="admin-theme w-full overflow-y-auto border-border bg-background text-foreground sm:max-w-3xl">
        <SheetHeader><SheetTitle className="font-display text-2xl">{inv ? `${inv.code} · ${inv.title}` : "Caso"}</SheetTitle></SheetHeader>
        <State loading={loading} err={err} empty={!data} retry={reload}>
          {inv && data && (
            <div className="mt-4 space-y-4">
              <Panel title="Caso">
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                  <Select label="Status" value={inv.status as (typeof INV_STATUS)[number]} onChange={(v) => void save({ status: v }, "Status atualizado")} options={INV_STATUS.map((x) => [x, INV_STATUS_LABEL[x]] as const)} />
                  <Select label="Prioridade" value={inv.priority as (typeof PRIORITIES)[number]} onChange={(v) => void save({ priority: v }, "Prioridade atualizada")} options={PRIORITIES.map((x) => [x, PRIORITY_LABEL[x]] as const)} />
                  <label className="text-xs text-muted-foreground">Prazo interno<input type="date" defaultValue={inv.due_at?.slice(0, 10) ?? ""} onBlur={(e) => void save({ dueAt: e.target.value ? new Date(e.target.value).toISOString() : null }, "Prazo salvo")} className={`${input} mt-0.5 py-1.5`} /></label>
                </div>
                {inv.target_user && <p className="mt-2 text-sm">Jogador: <button onClick={() => setProfile(true)} className="font-bold text-primary hover:underline">{inv.target_name}</button></p>}
                <label className="mt-2 block text-xs text-muted-foreground">Resumo / conclusões<textarea defaultValue={inv.summary ?? ""} onChange={(e) => setSummary(e.target.value)} rows={3} className={`${input} mt-1`} /></label>
                <label className="mt-2 block text-xs text-muted-foreground">Nota privada<textarea value={note} onChange={(e) => setNote(e.target.value)} rows={2} className={`${input} mt-1`} /></label>
                <button onClick={() => void save({ ...(summary !== null ? { summary } : {}), ...(note ? { note } : {}) }, "Salvo").then(() => setNote(""))} className={`${btnPrimary} mt-2`}>Salvar</button>
              </Panel>
              <Panel title="Registros relacionados">
                <ul className="space-y-1 text-sm">{data.links.map((l) => <li key={l.id}><Badge tone="info">{l.kind}</Badge> {l.label}</li>)}{!data.links.length && <li className="text-muted-foreground">Nenhum registro ligado.</li>}</ul>
                <div className="mt-2 flex flex-wrap gap-2"><Select value={kind} onChange={setKind} options={[["denuncia", "Denúncia"], ["bug", "Bug"], ["punicao", "Punição"], ["violacao", "Violação do chat"]]} /><input value={link} onChange={(e) => setLink(e.target.value)} placeholder="ID do registro" className={`${input} flex-1`} /><button disabled={!/^[0-9a-f-]{36}$/i.test(link)} onClick={() => void save({ link: { kind, refId: link } }, "Registro relacionado").then(() => setLink(""))} className={btnGhost}>Relacionar</button></div>
              </Panel>
              <Panel title="Histórico do caso"><ul className="space-y-1 text-sm">{data.history.map((h) => <li key={h.id}><span className="text-xs text-muted-foreground">{fmt(h.created_at)}</span> · <b>{h.actor_name}</b> {h.action}{h.to_status ? ` → ${h.to_status}` : ""}{h.note ? `: ${h.note}` : ""}</li>)}</ul></Panel>
              {inv.target_user && <Panel title="Linha do tempo do jogador"><Timeline userId={inv.target_user} /></Panel>}
            </div>
          )}
        </State>
        {profile && inv?.target_user && <PlayerProfile userId={inv.target_user} can={can} onClose={() => setProfile(false)} />}
      </SheetContent>
    </Sheet>
  );
}
