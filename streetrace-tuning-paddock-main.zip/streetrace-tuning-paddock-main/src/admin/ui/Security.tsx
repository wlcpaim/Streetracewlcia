import { useState } from "react";
import { adminAccess, adminSanctions } from "../admin.functions";
import { SANCTION_KINDS, SANCTION_LABEL } from "../rules";
import { Badge, Pager, Panel, Section, Select, State, Table, btnGhost, btnPrimary, fmt, input, td, toneOf, useLoad } from "./kit";
import { PlayerProfile } from "./Players";

type Geo = { pais?: string; regiao?: string; cidade?: string; fuso?: string; provedor?: string } | null;

export function AccessLog({ can, title = "Histórico de acessos", desc }: { can: (p: string) => boolean; title?: string; desc?: string }) {
  const [q, setQ] = useState(""), [qq, setQQ] = useState(""), [page, setPage] = useState(0), [open, setOpen] = useState<string | null>(null);
  const { data, err, loading, reload } = useLoad(() => adminAccess({ data: { q: qq, userId: null, page } }), [qq, page]);
  return (
    <Section title={title} desc={desc ?? "IP visto pelo servidor (cabeçalho da Cloudflare, não o que o aparelho diz). Localização aproximada; IP compartilhado não prova identidade."}>
      <Panel>
        <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); setPage(0); setQQ(q); }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="IP (início) ou ID da conta" className={input} /><button className={btnPrimary}>Buscar</button>
        </form>
        <div className="mt-3">
          <State loading={loading} err={err} empty={!data?.rows.length} retry={reload}>
            <Table head={["Quando", "Piloto", "IP", "Local aproximado", "Provedor", "Plataforma / versão", "Contas no IP"]}>
              {data?.rows.map((r) => { const g = r.geo as Geo; return (
                <tr key={r.id}>
                  <td className={td}>{fmt(r.created_at)}</td>
                  <td className={td}><button onClick={() => setOpen(r.user_id)} className="font-bold text-primary hover:underline">{r.nome ?? r.user_id.slice(0, 8)}</button></td>
                  <td className={`${td} font-mono text-xs`}>{r.ip ?? "—"}</td>
                  <td className={td}>{g ? [g.cidade, g.regiao, g.pais].filter(Boolean).join(", ") : "—"}{g?.fuso ? <div className="text-[10px] text-muted-foreground">{g.fuso}</div> : null}</td>
                  <td className={`${td} text-xs`}>{g?.provedor ?? "—"}</td>
                  <td className={`${td} text-xs`}>{r.platform ?? "?"} · {r.game_version ?? "?"}</td>
                  <td className={td}>{r.contasNoIp > 1 ? <Badge tone="warn">{r.contasNoIp} contas</Badge> : <span className="text-xs text-muted-foreground">1</span>}</td>
                </tr>); })}
            </Table>
            {data && <Pager page={page} total={data.total} size={data.pageSize} onPage={setPage} />}
          </State>
        </div>
        <p className="mt-2 text-[11px] text-muted-foreground">Dados pessoais (LGPD): só quem tem a permissão de segurança vê; cada consulta fica na auditoria.</p>
      </Panel>
      {open && <PlayerProfile userId={open} can={can} onClose={() => setOpen(null)} />}
    </Section>
  );
}

export function Sanctions({ can, title = "Banimentos e punições", desc = "Suspensões expiram sozinhas; o servidor recusa a entrada enquanto valem." }: { can: (p: string) => boolean; title?: string; desc?: string }) {
  const [filter, setFilter] = useState<"ativas" | "todas" | "revogadas">("ativas"), [kind, setKind] = useState<"todas" | (typeof SANCTION_KINDS)[number]>("todas"), [page, setPage] = useState(0), [open, setOpen] = useState<string | null>(null);
  const { data, err, loading, reload } = useLoad(() => adminSanctions({ data: { filter, kind, page } }), [filter, kind, page]);
  return (
    <Section title={title} desc={desc}>
      <Panel right={<div className="flex gap-2"><Select value={filter} onChange={(v) => { setFilter(v); setPage(0); }} options={[["ativas", "Valendo agora"], ["todas", "Todas"], ["revogadas", "Revogadas"]]} /><Select value={kind} onChange={(v) => { setKind(v); setPage(0); }} options={[["todas", "Todos os tipos"], ...SANCTION_KINDS.map((k) => [k, SANCTION_LABEL[k]] as const)]} /></div>}>
        <State loading={loading} err={err} empty={!data?.rows.length} retry={reload}>
          <Table head={["Aplicada", "Jogador", "Tipo", "Motivo", "Termina", "Origem", ""]}>
            {data?.rows.map((s) => (
              <tr key={s.id}>
                <td className={td}>{fmt(s.created_at)}</td>
                <td className={td}><b>{s.player_name ?? s.user_id.slice(0, 8)}</b></td>
                <td className={td}><Badge tone={s.revoked_at ? "mute" : toneOf(s.kind)}>{SANCTION_LABEL[s.kind as keyof typeof SANCTION_LABEL]}</Badge></td>
                <td className={`${td} max-w-[260px]`}>{s.reason}</td>
                <td className={td}>{s.kind === "advertencia" ? "—" : s.ends_at ? fmt(s.ends_at) : "permanente"}{s.revoked_at ? <div className="text-[10px] text-muted-foreground">revogada {fmt(s.revoked_at)}</div> : null}</td>
                <td className={td}><Badge>{s.source}</Badge></td>
                <td className={td}><button onClick={() => setOpen(s.user_id)} className={btnGhost}>Perfil</button></td>
              </tr>
            ))}
          </Table>
          {data && <Pager page={page} total={data.total} size={data.pageSize} onPage={setPage} />}
        </State>
      </Panel>
      {open && <PlayerProfile userId={open} can={can} onClose={() => { setOpen(null); reload(); }} />}
    </Section>
  );
}
