import { useState } from "react";
import { Trash2, Plus, Pencil } from "lucide-react";
import { adminChat, adminChatFilters, adminDeleteFilter, adminDeleteMessage, adminSaveFilter } from "../admin.functions";
import { CHAT_CATEGORIES, CHAT_CAT_LABEL, normalize } from "../rules";
import { Badge, Pager, Panel, ReasonDialog, Section, Select, State, Table, act, btnDanger, btnGhost, btnPrimary, fmt, input, td, useLoad } from "./kit";
import { PlayerProfile, must } from "./Players";

export function ChatModeration({ can }: { can: (p: string) => boolean }) {
  const [view, setView] = useState<"mensagens" | "bloqueadas">("bloqueadas"), [q, setQ] = useState(""), [qq, setQQ] = useState(""), [page, setPage] = useState(0);
  const [del, setDel] = useState<string | null>(null), [open, setOpen] = useState<string | null>(null);
  const { data, err, loading, reload } = useLoad(() => adminChat({ data: { view, q: qq, page } }), [view, qq, page]);
  type Row = { id: string; created_at: string; body: string; player_name?: string | null; sender_name?: string; user_id?: string; sender_user?: string; kind?: string; category?: string | null; term?: string | null; offense_number?: number };
  const rows = (data?.rows ?? []) as Row[];
  return (
    <Section title="Moderação de chat" desc="Mensagens bloqueadas nunca chegam ao chat. Conversas privadas só são vistas pela denúncia.">
      <Panel>
        <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); setPage(0); setQQ(q); }}>
          <Select value={view} onChange={(v) => { setView(v); setPage(0); }} options={[["bloqueadas", "Mensagens bloqueadas"], ["mensagens", "Chat do servidor"]]} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Piloto ou palavra" className={`${input} flex-1`} /><button className={btnPrimary}>Buscar</button>
        </form>
        <div className="mt-3">
          <State loading={loading} err={err} empty={!rows.length} retry={reload}>
            <Table head={view === "bloqueadas" ? ["Quando", "Piloto", "Mensagem", "Motivo", "Infração", ""] : ["Quando", "Piloto", "Mensagem", ""]}>
              {rows.map((r) => (
                <tr key={r.id}>
                  <td className={td}>{fmt(r.created_at)}</td>
                  <td className={td}><button onClick={() => setOpen((r.user_id ?? r.sender_user)!)} className="font-bold text-primary hover:underline">{r.player_name ?? r.sender_name}</button></td>
                  <td className={`${td} max-w-[320px] break-words`}>{r.body}</td>
                  {view === "bloqueadas" && <><td className={td}><Badge tone="warn">{r.kind}{r.category ? ` · ${r.category}` : ""}</Badge>{r.term && <div className="text-[10px] text-muted-foreground">termo: {r.term}</div>}</td><td className={td}>{r.offense_number}ª</td></>}
                  <td className={td}>{view === "mensagens" && <button onClick={() => setDel(r.id)} className={btnGhost} aria-label="Excluir mensagem"><Trash2 className="h-4 w-4" /></button>}</td>
                </tr>
              ))}
            </Table>
            {data && <Pager page={page} total={data.total} size={data.pageSize} onPage={setPage} />}
          </State>
        </div>
      </Panel>
      <ReasonDialog open={!!del} title="Excluir mensagem" desc="A mensagem sai do chat; uma cópia fica na auditoria." danger confirm="Excluir" onClose={() => setDel(null)} onConfirm={(reason) => must(adminDeleteMessage({ data: { id: del!, reason } }), "Mensagem excluída").then(reload)} />
      {open && <PlayerProfile userId={open} can={can} onClose={() => setOpen(null)} />}
    </Section>
  );
}

export function WordFilter({ can }: { can: (p: string) => boolean }) {
  const { data, err, loading, reload } = useLoad(() => adminChatFilters(), []);
  const [edit, setEdit] = useState<{ id?: string; term: string; category: (typeof CHAT_CATEGORIES)[number]; severity: number; active: boolean } | null>(null);
  const [cat, setCat] = useState<"todas" | (typeof CHAT_CATEGORIES)[number]>("todas");
  const conf = can("chat.configure");
  const rows = (data ?? []).filter((f) => cat === "todas" || f.category === cat);
  return (
    <Section title="Filtro de palavras" desc="O texto é normalizado (acentos, números no lugar de letras, espaços e símbolos) antes de comparar." actions={conf && <button onClick={() => setEdit({ term: "", category: "palavrao", severity: 1, active: true })} className={btnPrimary}><Plus className="h-4 w-4" />Nova palavra</button>}>
      <Panel right={<Select value={cat} onChange={setCat} options={[["todas", "Todas as categorias"], ...CHAT_CATEGORIES.map((c) => [c, CHAT_CAT_LABEL[c]] as const)]} />}>
        <State loading={loading} err={err} empty={!rows.length} retry={reload}>
          <Table head={["Termo", "Normalizado", "Categoria", "Gravidade", "Ocorrências", "Ativo", ""]}>
            {rows.map((f) => (
              <tr key={f.id}>
                <td className={td}><b>{f.term}</b></td>
                <td className={`${td} font-mono text-xs text-muted-foreground`}>{f.normalized}</td>
                <td className={td}>{CHAT_CAT_LABEL[f.category as keyof typeof CHAT_CAT_LABEL]}</td>
                <td className={td}><Badge tone={f.severity >= 3 ? "bad" : f.severity === 2 ? "warn" : "mute"}>{["", "leve", "média", "grave", "gravíssima"][f.severity]}</Badge></td>
                <td className={td}>{f.hits}</td>
                <td className={td}>{f.active ? <Badge tone="good">sim</Badge> : <Badge>não</Badge>}</td>
                <td className={td}>{conf && <div className="flex gap-1">
                  <button onClick={() => setEdit({ id: f.id, term: f.term, category: f.category as (typeof CHAT_CATEGORIES)[number], severity: f.severity, active: f.active })} className={btnGhost} aria-label="Editar"><Pencil className="h-4 w-4" /></button>
                  <button onClick={() => { if (confirm(`Remover "${f.term}" do filtro?`)) void act(adminDeleteFilter({ data: { id: f.id } }), "Termo removido").then(reload); }} className={btnDanger} aria-label="Remover"><Trash2 className="h-4 w-4" /></button>
                </div>}</td>
              </tr>
            ))}
          </Table>
        </State>
        <p className="mt-3 text-xs text-muted-foreground">Gravidade grave aplica a punição imediata definida em Configurações. As demais seguem a regra progressiva (1ª advertência, 2ª 5 min, 3ª 15 min, 4ª 1 h por padrão).</p>
      </Panel>
      {edit && (
        <ReasonDialog open title={edit.id ? "Editar termo" : "Novo termo proibido"} needReason={false} confirm="Salvar" onClose={() => setEdit(null)}
          onConfirm={() => must(adminSaveFilter({ data: { id: edit.id ?? null, term: edit.term, category: edit.category, severity: edit.severity, active: edit.active } }), "Filtro salvo").then(reload)}>
          <label className="text-xs text-muted-foreground">Palavra ou expressão<input value={edit.term} onChange={(e) => setEdit({ ...edit, term: e.target.value })} maxLength={60} className={`${input} mt-1`} /></label>
          <p className="text-[11px] text-muted-foreground">Vai comparar como: <span className="font-mono">{normalize(edit.term) || "—"}</span></p>
          <div className="grid grid-cols-2 gap-2">
            <Select label="Categoria" value={edit.category} onChange={(v) => setEdit({ ...edit, category: v })} options={CHAT_CATEGORIES.map((c) => [c, CHAT_CAT_LABEL[c]] as const)} />
            <Select label="Gravidade" value={String(edit.severity) as "1" | "2" | "3" | "4"} onChange={(v) => setEdit({ ...edit, severity: Number(v) })} options={[["1", "Leve — advertência, depois 5 min, 15 min, 1 h"], ["2", "Média — 30 min, 3 h, 12 h, 24 h"], ["3", "Grave — 24 h, 7 dias, 30 dias"], ["4", "Gravíssima — 7 dias, depois banimento"]]} />
          </div>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={edit.active} onChange={(e) => setEdit({ ...edit, active: e.target.checked })} />Ativo</label>
        </ReasonDialog>
      )}
    </Section>
  );
}
