import { useState } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { adminReports, adminReport, adminUpdateReport, adminSanction, adminSaveInvestigation } from "../admin.functions";
import { REPORT_STATUS, REPORT_STATUS_LABEL, REPORT_CAT_LABEL, PRIORITIES, PRIORITY_LABEL, SANCTION_LABEL, DURATIONS, type SanctionKind } from "../rules";
import { Badge, Kpi, Pager, Panel, ReasonDialog, Section, Select, State, Table, act, btnDanger, btnGhost, btnPrimary, fmt, input, td, toneOf, useLoad } from "./kit";
import { PlayerProfile, must } from "./Players";

type St = "todas" | "abertas" | (typeof REPORT_STATUS)[number];
export function Reports({ can, me }: { can: (p: string) => boolean; me: string }) {
  const [status, setStatus] = useState<St>("abertas"), [prio, setPrio] = useState<"todas" | (typeof PRIORITIES)[number]>("todas"), [q, setQ] = useState(""), [qq, setQQ] = useState(""), [page, setPage] = useState(0);
  const [mine, setMine] = useState(false), [unassigned, setUnassigned] = useState(false);
  const [open, setOpen] = useState<string | null>(null);
  const { data, err, loading, reload } = useLoad(() => adminReports({ data: { status, priority: prio, q: qq, mine, unassigned, page } }), [status, prio, qq, mine, unassigned, page]);
  const s = data?.stats ?? {};
  return (
    <Section title="Central de denúncias" desc="Ninguém é punido automaticamente por receber denúncias.">
      <div className="grid grid-cols-3 gap-2 sm:grid-cols-5 lg:grid-cols-9">
        <Kpi label="Total" value={s["total"] ?? 0} /><Kpi label="Recebidas" value={s["recebida"] ?? 0} /><Kpi label="Pendentes" value={s["pendente"] ?? 0} /><Kpi label="Em análise" value={s["em_analise"] ?? 0} tone="warn" />
        <Kpi label="Aguard. evidências" value={s["aguardando_evidencias"] ?? 0} /><Kpi label="Procedentes" value={s["procedente"] ?? 0} tone="bad" /><Kpi label="Improcedentes" value={s["improcedente"] ?? 0} tone="good" />
        <Kpi label="Prioridade alta" value={s["p_alta"] ?? 0} tone="warn" /><Kpi label="Crítica" value={s["p_critica"] ?? 0} tone="bad" />
      </div>
      <Panel>
        <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); setPage(0); setQQ(q); }}>
          <Select label="Status" value={status} onChange={(v) => { setStatus(v); setPage(0); }} options={[["abertas", "Em aberto"], ["todas", "Todas"], ...REPORT_STATUS.map((x) => [x, REPORT_STATUS_LABEL[x]] as const)]} />
          <Select label="Prioridade" value={prio} onChange={(v) => { setPrio(v); setPage(0); }} options={[["todas", "Todas"], ...PRIORITIES.map((x) => [x, PRIORITY_LABEL[x]] as const)]} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Protocolo ou nome" className={`${input} min-w-[160px] flex-1`} />
          <label className="flex items-center gap-1 text-xs"><input type="checkbox" checked={mine} onChange={(e) => setMine(e.target.checked)} />Meus casos</label>
          <label className="flex items-center gap-1 text-xs"><input type="checkbox" checked={unassigned} onChange={(e) => setUnassigned(e.target.checked)} />Sem responsável</label>
          <button className={btnPrimary}>Buscar</button>
        </form>
        <div className="mt-3">
          <State loading={loading} err={err} empty={!data?.rows.length} retry={reload}>
            <Table head={["Protocolo", "Denunciante", "Denunciado", "Categoria", "Data", "Prioridade", "Status", "Responsável", ""]}>
              {data?.rows.map((r) => (
                <tr key={r.id} className="hover:bg-secondary/40">
                  <td className={`${td} font-mono text-xs`}>{r.protocol}</td><td className={td}>{r.reporter_name}</td><td className={td}><b>{r.target_name}</b></td>
                  <td className={td}>{REPORT_CAT_LABEL[r.category as keyof typeof REPORT_CAT_LABEL]}</td><td className={td}>{fmt(r.created_at)}</td>
                  <td className={td}><Badge tone={toneOf(r.priority)}>{PRIORITY_LABEL[r.priority as keyof typeof PRIORITY_LABEL]}</Badge></td>
                  <td className={td}><Badge tone={toneOf(r.status)}>{REPORT_STATUS_LABEL[r.status as keyof typeof REPORT_STATUS_LABEL]}</Badge></td>
                  <td className={td}>{r.assignee ? (r.assignee === me ? "você" : "atribuído") : <span className="text-muted-foreground">—</span>}</td>
                  <td className={td}><button onClick={() => setOpen(r.id)} className={btnGhost}>Investigar</button></td>
                </tr>
              ))}
            </Table>
            {data && <Pager page={page} total={data.total} size={data.pageSize} onPage={setPage} />}
          </State>
        </div>
      </Panel>
      {open && <ReportDetail id={open} can={can} me={me} onClose={() => { setOpen(null); reload(); }} />}
    </Section>
  );
}

function ReportDetail({ id, can, me, onClose }: { id: string; can: (p: string) => boolean; me: string; onClose: () => void }) {
  const { data, err, loading, reload } = useLoad(() => adminReport({ data: { id } }), [id]);
  const [note, setNote] = useState(""), [conclusion, setConclusion] = useState<string | null>(null), [pub, setPub] = useState<string | null>(null);
  const [punish, setPunish] = useState<SanctionKind | null>(null), [mins, setMins] = useState("60"), [profile, setProfile] = useState(false);
  const r = data?.report;
  const manage = can("reports.manage");
  const upd = (patch: NonNullable<Parameters<typeof adminUpdateReport>[0]>["data"], ok: string) => act(adminUpdateReport({ data: patch }), ok).then(reload);
  return (
    <Sheet open onOpenChange={(o) => !o && onClose()}>
      <SheetContent side="right" className="admin-theme w-full overflow-y-auto border-border bg-background text-foreground sm:max-w-3xl">
        <SheetHeader><SheetTitle className="font-display text-2xl">{r?.protocol ?? "Denúncia"}</SheetTitle></SheetHeader>
        <State loading={loading} err={err} empty={!data} retry={reload}>
          {r && data && (
            <div className="mt-4 space-y-4">
              <Panel title="Informações">
                <dl className="grid grid-cols-2 gap-x-3 gap-y-1.5 text-sm">
                  <dt className="text-muted-foreground">Denunciante</dt><dd>{r.reporter_name}</dd>
                  <dt className="text-muted-foreground">Denunciado</dt><dd><button onClick={() => setProfile(true)} className="font-bold text-primary hover:underline">{r.target_name}</button></dd>
                  <dt className="text-muted-foreground">Categoria</dt><dd>{REPORT_CAT_LABEL[r.category as keyof typeof REPORT_CAT_LABEL]}</dd>
                  <dt className="text-muted-foreground">Enviada</dt><dd>{fmt(r.created_at)}</dd>
                  <dt className="text-muted-foreground">Quando ocorreu</dt><dd>{fmt(r.occurred_at)}</dd>
                  <dt className="text-muted-foreground">Local</dt><dd>{r.location ?? "—"}</dd>
                  <dt className="text-muted-foreground">Testemunhas</dt><dd>{r.witnesses ?? "—"}</dd>
                  <dt className="text-muted-foreground">Versão / sessão</dt><dd className="break-all text-xs">{r.game_version ?? "?"} · {r.session_id?.slice(0, 8) ?? "?"}</dd>
                </dl>
                <p className="mt-3 whitespace-pre-wrap rounded-xl bg-secondary/50 p-3 text-sm">{r.description}</p>
                {r.extra && <p className="mt-2 text-sm text-muted-foreground">Adicional: {r.extra}</p>}
              </Panel>
              {manage && (
                <Panel title="Tratamento">
                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                    <Select label="Status" value={r.status as (typeof REPORT_STATUS)[number]} onChange={(v) => void upd({ id, status: v }, "Status atualizado")} options={REPORT_STATUS.map((x) => [x, REPORT_STATUS_LABEL[x]] as const)} />
                    <Select label="Prioridade" value={r.priority as (typeof PRIORITIES)[number]} onChange={(v) => void upd({ id, priority: v }, "Prioridade atualizada")} options={PRIORITIES.map((x) => [x, PRIORITY_LABEL[x]] as const)} />
                    <label className="text-xs text-muted-foreground">Prazo interno<input type="date" defaultValue={r.due_at?.slice(0, 10) ?? ""} onBlur={(e) => void upd({ id, dueAt: e.target.value ? new Date(e.target.value).toISOString() : null }, "Prazo salvo")} className={`${input} mt-0.5 py-1.5`} /></label>
                  </div>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {r.assignee !== me && <button onClick={() => void upd({ id, assignee: me, status: r.status === "recebida" ? "em_analise" : undefined }, "Caso atribuído a você")} className={btnGhost}>Assumir caso</button>}
                    {r.assignee && <button onClick={() => void upd({ id, assignee: null }, "Responsável removido")} className={btnGhost}>Tirar responsável</button>}
                    <button onClick={() => void upd({ id, status: "aguardando_evidencias", publicResult: "Precisamos de mais informações. Responda pelo suporte com capturas de tela." }, "Pedido de informações enviado")} className={btnGhost}>Solicitar mais informações</button>
                    <button onClick={() => void upd({ id, status: "improcedente", publicResult: "Analisamos e não encontramos violação das regras." }, "Encerrada sem punição")} className={btnGhost}>Encerrar sem punição</button>
                    {can("investigations.manage") && <button onClick={() => void act(adminSaveInvestigation({ data: { title: `Denúncia ${r.protocol} — ${r.target_name}`, targetUser: r.target_user, priority: r.priority as (typeof PRIORITIES)[number], link: { kind: "denuncia", refId: r.id } } }), "Caso de investigação aberto").then(reload)} className={btnGhost}>Abrir investigação</button>}
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {can("chat.moderate") && <button onClick={() => setPunish("advertencia")} className={btnDanger}>Advertir</button>}
                    {can("chat.moderate") && <button onClick={() => setPunish("silenciamento")} className={btnDanger}>Silenciar</button>}
                    {can("players.ban") && <button onClick={() => setPunish("suspensao")} className={btnDanger}>Suspender</button>}
                    {can("players.ban") && <button onClick={() => setPunish("banimento")} className={btnDanger}>Banir</button>}
                  </div>
                  <label className="mt-3 block text-xs text-muted-foreground">Conclusão interna<textarea defaultValue={r.conclusion ?? ""} onChange={(e) => setConclusion(e.target.value)} rows={2} className={`${input} mt-1`} /></label>
                  <label className="mt-2 block text-xs text-muted-foreground">Resultado mostrado ao denunciante (sem dados privados)<input defaultValue={r.public_result ?? ""} onChange={(e) => setPub(e.target.value)} maxLength={500} className={`${input} mt-1`} /></label>
                  <label className="mt-2 block text-xs text-muted-foreground">Observação interna<textarea value={note} onChange={(e) => setNote(e.target.value)} rows={2} className={`${input} mt-1`} /></label>
                  <button onClick={() => void upd({ id, ...(conclusion !== null ? { conclusion } : {}), ...(pub !== null ? { publicResult: pub } : {}), ...(note ? { note } : {}) }, "Salvo").then(() => setNote(""))} className={`${btnPrimary} mt-2`}>Salvar anotações</button>
                </Panel>
              )}
              <Panel title={`Evidências (${data.evidence.length})`}>
                <ul className="space-y-2 text-sm">{data.evidence.map((e) => (
                  <li key={e.id} className="rounded-xl border border-border p-2">
                    <div className="flex justify-between gap-2 text-xs text-muted-foreground"><span><Badge tone="info">{e.kind}</Badge> origem: {e.source}{e.ref_id ? ` · ref ${e.ref_id.slice(0, 8)}` : ""}</span><span>{fmt(e.created_at)}</span></div>
                    {e.kind === "imagem" && e.url && <a href={e.url} target="_blank" rel="noreferrer"><img src={e.url} alt="Evidência enviada" className="mt-2 max-h-64 rounded-lg" /></a>}
                    {e.kind === "chat" && <p className="mt-1">{(e.content as { body?: string; created_at?: string; privado?: boolean })?.body} <span className="text-[10px] text-muted-foreground">({fmt((e.content as { created_at?: string })?.created_at)}{(e.content as { privado?: boolean })?.privado ? ", privada com o denunciante" : ", chat do servidor"})</span></p>}
                    {e.kind === "tecnico" && <pre className="mt-1 overflow-x-auto text-[11px] text-muted-foreground">{JSON.stringify(e.content, null, 1)}</pre>}
                  </li>
                ))}</ul>
              </Panel>
              <div className="grid gap-4 md:grid-cols-2">
                <Panel title="Denúncias anteriores contra ele">{data.previous.length ? <ul className="space-y-1 text-sm">{data.previous.map((p) => <li key={p.id} className="flex justify-between"><span>{p.protocol} · {p.category}</span><Badge tone={toneOf(p.status)}>{REPORT_STATUS_LABEL[p.status as keyof typeof REPORT_STATUS_LABEL]}</Badge></li>)}</ul> : <p className="text-sm text-muted-foreground">Nenhuma.</p>}</Panel>
                <Panel title="Punições do denunciado">{data.sanctions.length ? <ul className="space-y-1 text-sm">{data.sanctions.map((p) => <li key={p.id} className="flex justify-between gap-2"><span>{SANCTION_LABEL[p.kind]}{p.revoked_at ? " (revogada)" : ""}</span><span className="text-xs text-muted-foreground">{fmt(p.created_at)}</span></li>)}</ul> : <p className="text-sm text-muted-foreground">Nenhuma.</p>}</Panel>
              </div>
              <Panel title="Histórico">
                <ul className="space-y-1 text-sm">{data.history.map((h) => <li key={h.id}><span className="text-xs text-muted-foreground">{fmt(h.created_at)}</span> · <b>{h.actor_name ?? "Sistema"}</b> {h.action}{h.to_status ? ` → ${REPORT_STATUS_LABEL[h.to_status as keyof typeof REPORT_STATUS_LABEL] ?? h.to_status}` : ""}{h.note ? `: ${h.note}` : ""}{h.internal ? <span className="ml-1 text-[10px] text-muted-foreground">(interno)</span> : null}</li>)}</ul>
              </Panel>
            </div>
          )}
        </State>
        {r && punish && (
          <ReasonDialog open title={`${SANCTION_LABEL[punish]} — ${r.target_name}`} danger confirm="Aplicar" onClose={() => setPunish(null)}
            onConfirm={async (reason) => { await must(adminSanction({ data: { userId: r.target_user, playerId: r.target_player, kind: punish, minutes: punish === "suspensao" || punish === "silenciamento" ? Number(mins) : null, category: r.category, reason, reportId: r.id, evidence: r.protocol } }), "Punição aplicada"); await adminUpdateReport({ data: { id, status: "procedente", publicResult: "Denúncia procedente. Medidas foram tomadas." } }); reload(); }}>
            {(punish === "suspensao" || punish === "silenciamento") && <Select label="Duração" value={mins} onChange={setMins} options={DURATIONS.map((d) => [String(d.min), d.label] as const)} />}
            <p className="text-xs text-muted-foreground">A denúncia fica como procedente e o denunciante é avisado.</p>
          </ReasonDialog>
        )}
        {profile && r && <PlayerProfile userId={r.target_user} can={can} onClose={() => setProfile(false)} />}
      </SheetContent>
    </Sheet>
  );
}
