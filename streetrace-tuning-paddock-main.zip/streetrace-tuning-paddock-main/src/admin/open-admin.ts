// Painel aberto (sem login) em todos os endereços, inclusive o site publicado (pedido do dono).
import { createMiddleware } from "@tanstack/react-start";

export const OPEN_ADMIN_ID = "00000000-0000-0000-0000-000000000000";

export function isDevHost(host: string): boolean {
  const h = host.toLowerCase();
  if (h === "localhost" || h === "127.0.0.1" || h.endsWith(".lovableproject.com")) return true;
  // Versão de testes: id-preview--<id>.lovable.app, preview--<nome>.lovable.app e project--<id>-dev.lovable.app.
  if (!h.endsWith(".lovable.app")) return false;
  return h.startsWith("id-preview--") || h.startsWith("preview--") || (h.startsWith("project--") && h.endsWith("-dev.lovable.app"));
}

export const openAdmin = createMiddleware({ type: "function" }).server(async ({ next }) => {
  return next({ context: { userId: OPEN_ADMIN_ID, supabase: null as unknown, claims: {} as Record<string, unknown> } });
});
