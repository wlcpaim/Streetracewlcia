// Central de Administração — utilidades só do servidor (cliente com service role carregado sob demanda).
import { getRequest } from "@tanstack/react-start/server";
import type { Tables } from "@/integrations/supabase/types";
import { standingOf, isActive, DEFAULT_LADDER, DEFAULT_SEVERE, DEFAULT_FLOOD, DEFAULT_REP_WEIGHTS, type Perm, type SanctionKind, clientIp, platformOf, PERMS, abuseVerdict, ipBlocked, ABUSE_WINDOW_H, AUTO_BLOCK_HOURS, ABUSE_LABEL } from "./rules";
import { OPEN_ADMIN_ID } from "./open-admin";

export async function db() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

type Rpc = { rpc: (fn: string, a: Record<string, unknown>) => PromiseLike<{ data: unknown; error: unknown }> };
export type Ctx = { userId: string; supabase: unknown; claims?: Record<string, unknown> };

/** Permissão verificada no banco com a sessão do próprio usuário (has_perm); nunca pelo cliente. */
export async function requirePerm(ctx: Ctx, perm: Perm): Promise<void> {
  if (ctx.userId === OPEN_ADMIN_ID) return;
  const { data, error } = await (ctx.supabase as Rpc).rpc("has_perm", { _uid: ctx.userId, _perm: perm });
  if (error || data !== true) throw new Error(`Sem permissão: ${perm}`);
}
export async function myPerms(ctx: Ctx): Promise<{ tier: string | null; perms: string[] }> {
  if (ctx.userId === OPEN_ADMIN_ID) return { tier: "superadministrador", perms: [...PERMS] };
  const { data } = await (ctx.supabase as Rpc).rpc("my_staff", {});
  const d = (data ?? {}) as { tier?: string | null; perms?: string[] };
  return { tier: d.tier ?? null, perms: d.perms ?? [] };
}
export async function requireStaff(ctx: Ctx) {
  const me = await myPerms(ctx);
  if (!me.tier) throw new Error("Acesso restrito à equipe administrativa");
  return me;
}

/** Nome para exibir de uma conta: jogador ativo, senão o primeiro jogador, senão o e-mail. */
export async function nameOf(userId: string | null | undefined): Promise<string> {
  if (!userId) return "Sistema";
  if (userId === OPEN_ADMIN_ID) return "Administrador do Painel";
  const a = await db();
  const { data: st } = await a.from("account_state").select("active_player_id").eq("user_id", userId).maybeSingle();
  const { data: ps } = await a.from("players").select("id,name").eq("user_id", userId).order("created_at");
  const p = ps?.find((x) => x.id === st?.active_player_id) ?? ps?.[0];
  if (p) return p.name;
  const { data } = await a.auth.admin.getUserById(userId);
  return data.user?.email ?? userId.slice(0, 8);
}

export async function audit(e: { actor: string | null; action: string; target?: string | null | undefined; refKind?: string | undefined; refId?: string | undefined; before?: unknown; after?: unknown; reason?: string | null | undefined }) {
  const a = await db();
  const actor_name = await nameOf(e.actor);
  await a.from("admin_audit_logs").insert({
    actor: e.actor, actor_name, action: e.action, target_user: e.target ?? null, ref_kind: e.refKind ?? null, ref_id: e.refId ?? null,
    before: (e.before ?? null) as never, after: (e.after ?? null) as never, reason: e.reason ?? null,
  });
}

export async function notify(n: { userId: string | null; audience: "jogador" | "equipe"; kind: string; title: string; body?: string | null | undefined; refKind?: string | undefined; refId?: string | null | undefined }) {
  const a = await db();
  await a.from("notifications").insert({ user_id: n.userId, audience: n.audience, kind: n.kind, title: n.title, body: n.body ?? null, ref_kind: n.refKind ?? null, ref_id: n.refId ?? null });
}

export const SETTING_DEFAULTS = {
  ladder: DEFAULT_LADDER,
  severe: DEFAULT_SEVERE,
  flood: DEFAULT_FLOOD,
  reputation: DEFAULT_REP_WEIGHTS,
  geo: { enabled: true, ttlDays: 30 },
  reports: { perHour: 5 },
  bugs: { perHour: 5 },
} as const;
export type SettingKey = keyof typeof SETTING_DEFAULTS;
export async function setting<K extends SettingKey>(key: K): Promise<(typeof SETTING_DEFAULTS)[K]> {
  const a = await db();
  const { data } = await a.from("system_settings").select("value").eq("key", key).maybeSingle();
  return (data?.value ?? SETTING_DEFAULTS[key]) as (typeof SETTING_DEFAULTS)[K];
}

export async function sanctionsOf(userId: string) {
  const a = await db();
  const { data } = await a.from("player_sanctions").select("*").eq("user_id", userId).order("created_at", { ascending: false }).limit(500);
  return (data ?? []) as (Tables<"player_sanctions"> & { kind: SanctionKind })[];
}
export async function standingFor(userId: string) {
  return standingOf(await sanctionsOf(userId));
}

/** Encerra sessões: apaga refresh tokens e marca o instante; tokens emitidos antes disso são recusados no servidor. */
export async function revokeAllSessions(userId: string) {
  const a = await db();
  await a.from("account_security").upsert({ user_id: userId, sessions_revoked_at: new Date().toISOString(), updated_at: new Date().toISOString() });
  await a.rpc("admin_revoke_sessions", { _uid: userId });
}

/** Mantém o bloqueio de login do Auth igual às punições ativas (expira sozinho com a suspensão). */
export async function syncAuthBan(userId: string) {
  const a = await db();
  const s = await standingFor(userId);
  let ban_duration = "none";
  if (s.blocked) {
    const hours = s.until ? Math.max(1 / 60, (Date.parse(s.until) - Date.now()) / 3_600_000) : 876_000;
    ban_duration = `${Math.ceil(hours * 60)}m`;
  }
  await a.auth.admin.updateUserById(userId, { ban_duration });
  if (s.blocked) await revokeAllSessions(userId);
  return s;
}

export async function applySanction(i: {
  actor: string | null; userId: string; playerId?: string | null | undefined; kind: SanctionKind; minutes: number | null;
  category: string; reason: string; note?: string | null | undefined; evidence?: string | null | undefined; reportId?: string | null | undefined; violationId?: string | null | undefined; source?: "manual" | "automatica" | undefined;
}) {
  const a = await db();
  const now = new Date();
  const ends_at = i.kind === "advertencia" ? now.toISOString() : i.kind === "banimento" || i.minutes == null ? null : new Date(now.getTime() + i.minutes * 60_000).toISOString();
  const player_name = i.playerId ? (await a.from("players").select("name").eq("id", i.playerId).maybeSingle()).data?.name ?? null : await nameOf(i.userId);
  const { data, error } = await a.from("player_sanctions").insert({
    user_id: i.userId, player_id: i.playerId ?? null, player_name, kind: i.kind, category: i.category, reason: i.reason,
    note: i.note ?? null, evidence: i.evidence ?? null, starts_at: now.toISOString(), ends_at, source: i.source ?? "manual",
    report_id: i.reportId ?? null, violation_id: i.violationId ?? null, created_by: i.actor,
  }).select("*").single();
  if (error || !data) throw new Error("Não foi possível registrar a punição");
  if (i.kind === "suspensao" || i.kind === "banimento") await syncAuthBan(i.userId);
  await audit({ actor: i.actor, action: `punicao.${i.kind}`, target: i.userId, refKind: "punicao", refId: data.id, after: data, reason: i.reason });
  const LBL: Record<SanctionKind, string> = { advertencia: "Advertência", silenciamento: "Chat silenciado", suspensao: "Conta suspensa", banimento: "Conta banida" };
  const quando = ends_at && i.kind !== "advertencia" ? ` até ${new Date(ends_at).toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" })}` : "";
  await notify({ userId: i.userId, audience: "jogador", kind: `punicao.${i.kind}`, title: LBL[i.kind] + quando, body: `Motivo: ${i.reason}`, refKind: "punicao", refId: data.id });
  return data;
}

export async function revokeSanction(actor: string, id: string, reason: string) {
  const a = await db();
  const { data: before } = await a.from("player_sanctions").select("*").eq("id", id).maybeSingle();
  if (!before) throw new Error("Punição não encontrada");
  if (before.revoked_at) throw new Error("Punição já revogada");
  const { data: after } = await a.from("player_sanctions").update({ revoked_at: new Date().toISOString(), revoked_by: actor, revoke_reason: reason }).eq("id", id).select("*").single();
  await syncAuthBan(before.user_id);
  await audit({ actor, action: "punicao.revogada", target: before.user_id, refKind: "punicao", refId: id, before, after, reason });
  await notify({ userId: before.user_id, audience: "jogador", kind: "punicao.revogada", title: "Punição removida", body: reason, refKind: "punicao", refId: id });
  return after;
}

// ── Geolocalização por IP (aproximada; cache com validade) ──
const PRIVATE = /^(10\.|127\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|::1|fc|fd|fe80)/i;
export async function geoOf(ip: string | null): Promise<Record<string, unknown> | null> {
  if (!ip || PRIVATE.test(ip)) return null;
  const cfg = await setting("geo");
  if (!cfg.enabled) return null;
  const a = await db();
  const { data: hit } = await a.from("ip_geo").select("data,fetched_at").eq("ip", ip).maybeSingle();
  if (hit && Date.now() - Date.parse(hit.fetched_at) < cfg.ttlDays * 86_400_000) return hit.data as Record<string, unknown>;
  try {
    const r = await fetch(`https://ipwho.is/${encodeURIComponent(ip)}?fields=success,country,country_code,region,city,timezone,connection`, { signal: AbortSignal.timeout(4000) });
    const j = (await r.json()) as { success?: boolean; country?: string; country_code?: string; region?: string; city?: string; timezone?: { id?: string }; connection?: { isp?: string; org?: string; asn?: number } };
    if (!j.success) return null;
    const geo = { pais: j.country ?? null, codigo: j.country_code ?? null, regiao: j.region ?? null, cidade: j.city ?? null, fuso: j.timezone?.id ?? null, provedor: j.connection?.isp ?? j.connection?.org ?? null, asn: j.connection?.asn ?? null, fonte: "ipwho.is", aproximado: true };
    await a.from("ip_geo").upsert({ ip, data: geo, fetched_at: new Date().toISOString() });
    return geo;
  } catch { return hit ? (hit.data as Record<string, unknown>) : null; }
}

/** Registra um acesso (no máximo um por conta+IP a cada 30 min). */
export async function recordAccess(userId: string, playerId: string | null, gameVersion: string | null, sessionId: string | null) {
  const req = getRequest();
  const ip = clientIp(req.headers);
  const ua = (req.headers.get("user-agent") ?? "").slice(0, 300);
  const a = await db();
  const since = new Date(Date.now() - 30 * 60_000).toISOString();
  let q = a.from("access_log").select("id").eq("user_id", userId).gte("created_at", since).limit(1);
  q = ip ? q.eq("ip", ip) : q.is("ip", null);
  const { data: recent } = await q;
  if (recent?.length) return { recorded: false };
  const geo = await geoOf(ip);
  await a.from("access_log").insert({ user_id: userId, player_id: playerId, ip, user_agent: ua, platform: platformOf(ua), game_version: gameVersion, session_id: sessionId, geo: geo as never });
  if (ip) await detectAbuse(ip).catch((e) => console.error("detectAbuse", e));
  return { recorded: true };
}

/** IP bloqueado agora? (manual ou automático, com validade). */
export async function isIpBlocked(ip: string | null): Promise<boolean> {
  if (!ip) return false;
  const a = await db();
  const { data } = await a.from("blocked_ips").select("expires_at,hits").eq("ip", ip).maybeSingle();
  if (!ipBlocked(data)) return false;
  await a.from("blocked_ips").update({ hits: (data?.hits ?? 0) + 1 }).eq("ip", ip);
  return true;
}

/** Detecção automática: contas distintas no mesmo IP em 24 h, fuga de banimento e criação em massa. */
export async function detectAbuse(ip: string) {
  const a = await db();
  const since = new Date(Date.now() - ABUSE_WINDOW_H * 3_600_000).toISOString();
  const { data: rows } = await a.from("access_log").select("user_id").eq("ip", ip).gte("created_at", since).limit(2000);
  const users = [...new Set((rows ?? []).map((r) => r.user_id))];
  if (users.length < 2) return;
  const { data: sx } = await a.from("player_sanctions").select("user_id,kind,ends_at,revoked_at,starts_at").in("user_id", users).in("kind", ["banimento", "suspensao"]).is("revoked_at", null);
  const blocked = new Set((sx ?? []).filter((s) => isActive(s as never)).map((s) => s.user_id));
  const { flags, autoBlock } = abuseVerdict(users.length, blocked.size);
  const now = new Date().toISOString();
  for (const f of flags) {
    const detail = { contas: users.length, contasPunidas: blocked.size, janelaHoras: ABUSE_WINDOW_H };
    const { data: open } = await a.from("abuse_flags").select("id").eq("ip", ip).eq("kind", f.kind).eq("status", "aberto").maybeSingle();
    if (open) await a.from("abuse_flags").update({ user_ids: users, detail, severity: f.severity, updated_at: now }).eq("id", open.id);
    else {
      await a.from("abuse_flags").insert({ ip, kind: f.kind, severity: f.severity, user_ids: users, detail });
      await notify({ userId: null, audience: "equipe", kind: "abuso.detectado", title: `${ABUSE_LABEL[f.kind]} (${users.length} contas)`, body: `IP ${ip}` });
    }
  }
  if (autoBlock) {
    const { data: cur } = await a.from("blocked_ips").select("ip").eq("ip", ip).maybeSingle();
    if (!cur) {
      await a.from("blocked_ips").insert({ ip, reason: `Automático: ${users.length} contas em ${ABUSE_WINDOW_H} h`, source: "automatico", expires_at: new Date(Date.now() + AUTO_BLOCK_HOURS * 3_600_000).toISOString() });
      await audit({ actor: null, action: "ip.bloqueio_automatico", reason: `${ip}: ${users.length} contas` });
    }
  }
}

export { isActive };
