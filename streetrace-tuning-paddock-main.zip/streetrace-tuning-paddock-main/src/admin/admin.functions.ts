// Central de Administração — funções da equipe. Toda chamada: sessão válida + permissão conferida no banco (has_perm).
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { openAdmin } from "./open-admin";
import type { Json } from "@/integrations/supabase/types";
import { SANCTION_KINDS, REPORT_STATUS, BUG_STATUS, INV_STATUS, PRIORITIES, CHAT_CATEGORIES, TIERS, PERMS, normalize, reputation, canManageStaff, type Tier } from "./rules";

const S = () => import("./admin.server");
const uuid = z.string().uuid();
const PAGE = 20;
const page = z.number().int().min(0).max(10_000).default(0);
type C = Parameters<Awaited<ReturnType<typeof S>>["requirePerm"]>[0];
const ctxOf = (c: unknown) => c as C;
const ONLINE_S = 70;

// ── Acesso ──
/** Quem sou na equipe. Cargos só existem quando um administrador os atribui pelo painel (adminSetStaff); ninguém se promove sozinho. */
export const adminMe = createServerFn({ method: "GET" })
  .middleware([openAdmin])
  .handler(async ({ context }) => {
    const { myPerms, nameOf } = await S();
    const me = await myPerms(ctxOf(context));
    return { userId: context.userId, name: await nameOf(context.userId), tier: me.tier, perms: me.perms };
  });

// ── Dashboard ──
export const adminDashboard = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ days: z.number().int().min(1).max(365).default(30) }).parse(d))
  .handler(async ({ data, context }) => {
    const { requireStaff, db } = await S();
    const me = await requireStaff(ctxOf(context));
    const a = await db();
    const since = new Date(Date.now() - data.days * 86_400_000).toISOString();
    const nowIso = new Date().toISOString();
    const cnt = async (q: PromiseLike<{ count: number | null }>) => (await q).count ?? 0;
    const head = { count: "exact" as const, head: true };
    const [players, accounts, online, recent, newP, repAll, repPend, invOpen, bugsAll, bugsAna, bugsRes, blocked, infr] = await Promise.all([
      cnt(a.from("players").select("id", head)),
      cnt(a.from("account_state").select("user_id", head)),
      cnt(a.from("player_presence").select("player_id", head).neq("state", "offline").gte("last_seen", new Date(Date.now() - ONLINE_S * 1000).toISOString())),
      cnt(a.from("player_presence").select("player_id", head).gte("last_seen", new Date(Date.now() - 86_400_000).toISOString())),
      cnt(a.from("players").select("id", head).gte("created_at", since)),
      cnt(a.from("player_reports").select("id", head).gte("created_at", since)),
      cnt(a.from("player_reports").select("id", head).in("status", ["recebida", "pendente", "em_analise", "aguardando_evidencias"])),
      cnt(a.from("investigations").select("id", head).in("status", ["aberta", "em_andamento", "aguardando"])),
      cnt(a.from("bug_reports").select("id", head).gte("created_at", since)),
      cnt(a.from("bug_reports").select("id", head).in("status", ["recebido", "em_analise", "bugfix"])),
      cnt(a.from("bug_reports").select("id", head).eq("status", "resolvido").gte("resolved_at", since)),
      cnt(a.from("chat_violations").select("id", head).gte("created_at", since)),
      cnt(a.from("player_sanctions").select("id", head).gte("created_at", since).is("revoked_at", null)),
    ]);
    const { data: act } = await a.from("player_sanctions").select("user_id,kind,ends_at").is("revoked_at", null).in("kind", ["suspensao", "banimento"]).or(`ends_at.is.null,ends_at.gt.${nowIso}`);
    const banned = new Set((act ?? []).filter((s) => s.kind === "banimento").map((s) => s.user_id)).size;
    const suspended = new Set((act ?? []).filter((s) => s.kind === "suspensao").map((s) => s.user_id)).size;
    // séries diárias reais
    const days: string[] = [];
    for (let i = data.days - 1; i >= 0; i--) days.push(new Date(Date.now() - i * 86_400_000).toISOString().slice(0, 10));
    const bucket = (rows: { created_at?: string | null; resolved_at?: string | null }[] | null, k: "created_at" | "resolved_at" = "created_at") => {
      const m = new Map<string, number>(); for (const r of rows ?? []) { const d = (r[k] ?? "").slice(0, 10); if (d) m.set(d, (m.get(d) ?? 0) + 1); }
      return days.map((d) => m.get(d) ?? 0);
    };
    const lim = 5000;
    const [pc, rc, sc, bc, br, ac, au] = await Promise.all([
      a.from("players").select("created_at").gte("created_at", since).limit(lim),
      a.from("player_reports").select("created_at").gte("created_at", since).limit(lim),
      a.from("player_sanctions").select("created_at").gte("created_at", since).limit(lim),
      a.from("bug_reports").select("created_at").gte("created_at", since).limit(lim),
      a.from("bug_reports").select("resolved_at").gte("resolved_at", since).limit(lim),
      a.from("access_log").select("created_at,user_id").gte("created_at", since).limit(lim),
      a.from("admin_audit_logs").select("created_at").gte("created_at", since).limit(lim),
    ]);
    const activeByDay = (() => { const m = new Map<string, Set<string>>(); for (const r of ac.data ?? []) { const d = r.created_at.slice(0, 10); if (!m.has(d)) m.set(d, new Set()); m.get(d)!.add(r.user_id); } return days.map((d) => m.get(d)?.size ?? 0); })();
    const { count: before } = await a.from("players").select("id", head).lt("created_at", since);
    const signups = bucket(pc.data);
    let run = before ?? 0; const growth = signups.map((n) => (run += n));
    const series = days.map((d, i) => ({ dia: d.slice(5), cadastros: signups[i], total: growth[i], ativos: activeByDay[i], denuncias: bucket(rc.data)[i], punicoes: bucket(sc.data)[i], bugs: bucket(bc.data)[i], resolvidos: bucket(br.data, "resolved_at")[i], moderacao: bucket(au.data)[i] }));
    const recentAudit = me.perms.includes("audit.view") ? (await a.from("admin_audit_logs").select("id,actor_name,action,reason,created_at").order("created_at", { ascending: false }).limit(8)).data ?? [] : [];
    return { kpi: { players, accounts, online, offline: Math.max(0, players - online), recent, newP, banned, suspended, repAll, repPend, invOpen, bugsAll, bugsAna, bugsRes, blocked, infr }, series, recentAudit };
  });

// ── Jogadores ──
export const adminPlayers = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ q: z.string().max(120).default(""), filter: z.enum(["todos", "online", "banidos", "suspensos", "silenciados", "novos"]).default("todos"), page }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, myPerms, db } = await S();
    await requirePerm(ctxOf(context), "players.view");
    const me = await myPerms(ctxOf(context));
    const a = await db();
    const q = data.q.trim();
    let userIds: string[] | null = null;
    if (q.includes("@")) {
      if (!me.perms.includes("players.manage") && !me.perms.includes("security.view")) throw new Error("Sem permissão para pesquisar por e-mail");
      const { data: us } = await a.auth.admin.listUsers({ page: 1, perPage: 1000 });
      userIds = (us?.users ?? []).filter((u) => (u.email ?? "").toLowerCase().includes(q.toLowerCase())).map((u) => u.id);
    }
    if (data.filter === "online") {
      const { data: pr } = await a.from("player_presence").select("user_id").neq("state", "offline").gte("last_seen", new Date(Date.now() - ONLINE_S * 1000).toISOString());
      userIds = [...new Set((pr ?? []).map((r) => r.user_id))].filter((u) => !userIds || userIds.includes(u));
    }
    if (["banidos", "suspensos", "silenciados"].includes(data.filter)) {
      const kind = data.filter === "banidos" ? "banimento" : data.filter === "suspensos" ? "suspensao" : "silenciamento";
      const { data: s } = await a.from("player_sanctions").select("user_id").eq("kind", kind).is("revoked_at", null).or(`ends_at.is.null,ends_at.gt.${new Date().toISOString()}`);
      userIds = [...new Set((s ?? []).map((r) => r.user_id))].filter((u) => !userIds || userIds.includes(u));
    }
    let pq = a.from("players").select("id,user_id,name,tag,created_at", { count: "exact" }).order("created_at", { ascending: false }).range(data.page * PAGE, data.page * PAGE + PAGE - 1);
    if (userIds) pq = pq.in("user_id", userIds.length ? userIds : ["00000000-0000-0000-0000-000000000000"]);
    if (q && !q.includes("@")) {
      if (/^[0-9a-f-]{36}$/i.test(q)) pq = pq.or(`id.eq.${q},user_id.eq.${q}`);
      else { const t = q.replace(/^STR#/i, ""); pq = /^\d{4,8}$/.test(t) ? pq.eq("tag", t) : pq.ilike("name", `%${q.replace(/[%_,()]/g, "")}%`); }
    }
    if (data.filter === "novos") pq = pq.gte("created_at", new Date(Date.now() - 7 * 86_400_000).toISOString());
    const { data: rows, count } = await pq;
    const uids = [...new Set((rows ?? []).map((r) => r.user_id))];
    const pids = (rows ?? []).map((r) => r.id);
    const [{ data: pres }, { data: sanc }] = await Promise.all([
      pids.length ? a.from("player_presence").select("player_id,state,last_seen").in("player_id", pids) : Promise.resolve({ data: [] as { player_id: string; state: string; last_seen: string }[] }),
      uids.length ? a.from("player_sanctions").select("user_id,kind,ends_at,starts_at,revoked_at,reason").in("user_id", uids) : Promise.resolve({ data: [] as never[] }),
    ]);
    const { standingOf } = await import("./rules");
    return {
      total: count ?? 0, pageSize: PAGE,
      rows: (rows ?? []).map((r) => {
        const p = pres?.find((x) => x.player_id === r.id);
        const on = !!p && p.state !== "offline" && Date.now() - Date.parse(p.last_seen) < ONLINE_S * 1000;
        const st = standingOf(((sanc ?? []) as { user_id: string; kind: never; ends_at: string | null; starts_at: string; revoked_at: string | null; reason: string }[]).filter((s) => s.user_id === r.user_id));
        return { ...r, online: on, lastSeen: p?.last_seen ?? null, situacao: st.blocked ? (st.kind === "banimento" ? "banido" : "suspenso") : st.muted ? "silenciado" : "regular" };
      }),
    };
  });

export const adminPlayer = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ userId: uuid }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, myPerms, db, sanctionsOf, audit } = await S();
    await requirePerm(ctxOf(context), "players.view");
    const me = await myPerms(ctxOf(context));
    const a = await db();
    const { standingOf } = await import("./rules");
    const { data: au } = await a.auth.admin.getUserById(data.userId);
    const u = au.user;
    if (!u) throw new Error("Conta não encontrada");
    const showEmail = me.perms.includes("players.manage") || me.perms.includes("security.view");
    const [{ data: players }, sanc, { data: repRec }, { data: repMade }, { data: bugs }, { count: viol }, { data: lastAcc }, { data: guest }, { data: sec }, { data: inv }] = await Promise.all([
      a.from("players").select("id,name,tag,created_at").eq("user_id", data.userId).order("created_at"),
      sanctionsOf(data.userId),
      a.from("player_reports").select("id,protocol,category,status,created_at,reporter_name").eq("target_user", data.userId).order("created_at", { ascending: false }).limit(50),
      a.from("player_reports").select("id,protocol,category,status,created_at,target_name").eq("reporter_user", data.userId).order("created_at", { ascending: false }).limit(50),
      a.from("bug_reports").select("id,protocol,title,status,created_at").eq("user_id", data.userId).order("created_at", { ascending: false }).limit(50),
      a.from("chat_violations").select("id", { count: "exact", head: true }).eq("user_id", data.userId),
      a.from("access_log").select("platform,game_version,created_at").eq("user_id", data.userId).order("created_at", { ascending: false }).limit(1),
      a.from("token_guest_accounts").select("expires_at").eq("user_id", data.userId).maybeSingle(),
      a.from("account_security").select("*").eq("user_id", data.userId).maybeSingle(),
      a.from("investigations").select("id").eq("target_user", data.userId).in("status", ["aberta", "em_andamento", "aguardando"]),
    ]);
    const pids = (players ?? []).map((p) => p.id);
    const { data: pres } = pids.length ? await a.from("player_presence").select("player_id,state,last_seen").in("player_id", pids) : { data: [] };
    const last = (pres ?? []).sort((x, y) => Date.parse(y.last_seen) - Date.parse(x.last_seen))[0];
    const online = !!last && last.state !== "offline" && Date.now() - Date.parse(last.last_seen) < ONLINE_S * 1000;
    if (showEmail) await audit({ actor: context.userId, action: "consulta.dados_sensiveis", target: data.userId, reason: "Perfil administrativo aberto (e-mail visível)" });
    return {
      account: {
        id: u.id, email: showEmail ? u.email ?? null : null, emailHidden: !showEmail, createdAt: u.created_at, lastSignIn: u.last_sign_in_at ?? null,
        confirmed: !!u.email_confirmed_at, provider: (u.app_metadata as { provider?: string })?.provider ?? null, tokenAccount: !!guest, tokenExpires: guest?.expires_at ?? null,
        bannedUntil: (u as { banned_until?: string }).banned_until ?? null, sessionsRevokedAt: sec?.sessions_revoked_at ?? null, resetRequestedAt: sec?.password_reset_requested_at ?? null,
      },
      players: (players ?? []).map((p) => ({ ...p, presence: pres?.find((x) => x.player_id === p.id) ?? null })),
      online, lastSeen: last?.last_seen ?? null, lastAccess: lastAcc?.[0] ?? null,
      standing: standingOf(sanc as never), sanctions: sanc, reportsReceived: repRec ?? [], reportsMade: repMade ?? [], bugs: bugs ?? [], violations: viol ?? 0,
      reputation: reputation(sanc as never, viol ?? 0, (inv ?? []).length > 0),
    };
  });

export const adminSanction = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({
    userId: uuid, playerId: uuid.nullable().optional(), kind: z.enum(SANCTION_KINDS), minutes: z.number().int().min(1).max(525_600).nullable(),
    category: z.string().min(2).max(40), reason: z.string().trim().min(5).max(500), note: z.string().max(1000).nullable().optional(),
    evidence: z.string().max(1000).nullable().optional(), reportId: uuid.nullable().optional(),
  }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, applySanction } = await S();
    await requirePerm(ctxOf(context), data.kind === "advertencia" || data.kind === "silenciamento" ? "chat.moderate" : "players.ban");
    if (data.userId === context.userId) throw new Error("Você não pode punir a própria conta.");
    if ((data.kind === "suspensao" || data.kind === "silenciamento") && !data.minutes) throw new Error("Informe a duração.");
    const s = await applySanction({ actor: context.userId, ...data, minutes: data.kind === "banimento" ? null : data.minutes });
    return { id: s.id };
  });

export const adminRevokeSanction = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ id: uuid, reason: z.string().trim().min(5).max(500) }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, revokeSanction, db } = await S();
    const { data: s } = await (await db()).from("player_sanctions").select("kind").eq("id", data.id).maybeSingle();
    if (!s) throw new Error("Punição não encontrada");
    await requirePerm(ctxOf(context), s.kind === "advertencia" || s.kind === "silenciamento" ? "chat.moderate" : "players.unban");
    await revokeSanction(context.userId, data.id, data.reason);
    return { ok: true };
  });

export const adminSanctions = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ filter: z.enum(["ativas", "todas", "revogadas"]).default("ativas"), kind: z.enum(["todas", ...SANCTION_KINDS]).default("todas"), page }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db } = await S();
    await requirePerm(ctxOf(context), "players.view");
    const a = await db();
    let q = a.from("player_sanctions").select("*", { count: "exact" }).order("created_at", { ascending: false }).range(data.page * PAGE, data.page * PAGE + PAGE - 1);
    if (data.kind !== "todas") q = q.eq("kind", data.kind);
    if (data.filter === "ativas") q = q.is("revoked_at", null).neq("kind", "advertencia").or(`ends_at.is.null,ends_at.gt.${new Date().toISOString()}`);
    if (data.filter === "revogadas") q = q.not("revoked_at", "is", null);
    const { data: rows, count } = await q;
    return { rows: rows ?? [], total: count ?? 0, pageSize: PAGE };
  });

export const adminAccountAction = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ userId: uuid, action: z.enum(["revogar_sessoes", "redefinir_senha"]), reason: z.string().trim().min(5).max(500), redirectTo: z.string().url().max(300).optional() }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db, revokeAllSessions, audit, notify } = await S();
    await requirePerm(ctxOf(context), "players.manage");
    const a = await db();
    if (data.action === "revogar_sessoes") {
      await revokeAllSessions(data.userId);
      await audit({ actor: context.userId, action: "conta.sessoes_revogadas", target: data.userId, reason: data.reason });
      return { ok: true, msg: "Sessões encerradas. O jogador precisa entrar de novo." };
    }
    const { data: u } = await a.auth.admin.getUserById(data.userId);
    const email = u.user?.email;
    if (!email || /@token\./.test(email)) throw new Error("Esta conta não tem e-mail próprio (conta por token).");
    const { error } = await a.auth.resetPasswordForEmail(email, data.redirectTo ? { redirectTo: data.redirectTo } : {});
    if (error) throw new Error("Não foi possível enviar o e-mail de redefinição.");
    await a.from("account_security").upsert({ user_id: data.userId, password_reset_requested_at: new Date().toISOString(), updated_at: new Date().toISOString() });
    await audit({ actor: context.userId, action: "conta.redefinicao_senha", target: data.userId, reason: data.reason });
    await notify({ userId: data.userId, audience: "jogador", kind: "conta.atualizada", title: "Redefinição de senha solicitada", body: "Enviamos um link para o seu e-mail." });
    return { ok: true, msg: "E-mail de redefinição enviado." };
  });

// ── Segurança ──
export const adminAccess = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ q: z.string().max(80).default(""), userId: uuid.nullable().default(null), page }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db, audit } = await S();
    await requirePerm(ctxOf(context), "security.view");
    const a = await db();
    let q = a.from("access_log").select("*", { count: "exact" }).order("created_at", { ascending: false }).range(data.page * PAGE, data.page * PAGE + PAGE - 1);
    if (data.userId) q = q.eq("user_id", data.userId);
    const t = data.q.trim();
    if (t) q = /^[0-9a-f-]{36}$/i.test(t) ? q.eq("user_id", t) : q.ilike("ip", `${t.replace(/[%_,()]/g, "")}%`);
    const { data: rows, count } = await q;
    const uids = [...new Set((rows ?? []).map((r) => r.user_id))];
    const { data: ps } = uids.length ? await a.from("players").select("id,user_id,name").in("user_id", uids) : { data: [] };
    // contas que compartilham o mesmo IP (indício, nunca prova)
    const ips = [...new Set((rows ?? []).map((r) => r.ip).filter(Boolean))] as string[];
    const { data: shared } = ips.length ? await a.from("access_log").select("ip,user_id").in("ip", ips).limit(2000) : { data: [] };
    const share = (ip: string | null) => (ip ? new Set((shared ?? []).filter((s) => s.ip === ip).map((s) => s.user_id)).size : 0);
    await audit({ actor: context.userId, action: "consulta.seguranca", target: data.userId, reason: t ? `Busca: ${t}` : "Histórico de acessos" });
    return { total: count ?? 0, pageSize: PAGE, rows: (rows ?? []).map((r) => ({ ...r, nome: ps?.find((p) => p.user_id === r.user_id && (!r.player_id || p.id === r.player_id))?.name ?? null, contasNoIp: share(r.ip) })) };
  });

// ── Chat ──
export const adminChatFilters = createServerFn({ method: "GET" })
  .middleware([openAdmin])
  .handler(async ({ context }) => {
    const { requirePerm, db } = await S();
    await requirePerm(ctxOf(context), "chat.moderate");
    const a = await db();
    const { data } = await a.from("chat_filters").select("*").order("category").order("term");
    const { data: v } = await a.from("chat_violations").select("filter_id").not("filter_id", "is", null).limit(5000);
    return (data ?? []).map((f) => ({ ...f, hits: (v ?? []).filter((x) => x.filter_id === f.id).length }));
  });

export const adminSaveFilter = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ id: uuid.nullable().optional(), term: z.string().trim().min(2).max(60), category: z.enum(CHAT_CATEGORIES), severity: z.number().int().min(1).max(4), active: z.boolean().default(true) }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db, audit } = await S();
    await requirePerm(ctxOf(context), "chat.configure");
    const a = await db();
    const n = normalize(data.term);
    if (n.length < 2) throw new Error("Termo curto demais depois da normalização.");
    const row = { term: data.term, normalized: n, category: data.category, severity: data.severity, active: data.active, updated_at: new Date().toISOString() };
    const before = data.id ? (await a.from("chat_filters").select("*").eq("id", data.id).maybeSingle()).data : null;
    const r = data.id ? await a.from("chat_filters").update(row).eq("id", data.id).select("*").single() : await a.from("chat_filters").insert({ ...row, created_by: context.userId }).select("*").single();
    if (r.error) throw new Error(/duplicate|unique/i.test(r.error.message) ? "Esse termo já está no filtro." : "Não foi possível salvar.");
    await audit({ actor: context.userId, action: data.id ? "filtro.editado" : "filtro.criado", refKind: "filtro", refId: r.data.id, before, after: r.data });
    return r.data;
  });

export const adminDeleteFilter = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ id: uuid }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db, audit } = await S();
    await requirePerm(ctxOf(context), "chat.configure");
    const a = await db();
    const { data: before } = await a.from("chat_filters").select("*").eq("id", data.id).maybeSingle();
    await a.from("chat_filters").delete().eq("id", data.id);
    await audit({ actor: context.userId, action: "filtro.removido", refKind: "filtro", refId: data.id, before });
    return { ok: true };
  });

export const adminChat = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ view: z.enum(["mensagens", "bloqueadas"]), q: z.string().max(80).default(""), page }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db } = await S();
    await requirePerm(ctxOf(context), "chat.moderate");
    const a = await db();
    const t = data.q.trim().replace(/[%_,()]/g, "");
    if (data.view === "bloqueadas") {
      let q = a.from("chat_violations").select("*", { count: "exact" }).order("created_at", { ascending: false }).range(data.page * PAGE, data.page * PAGE + PAGE - 1);
      if (t) q = q.or(`player_name.ilike.%${t}%,body.ilike.%${t}%`);
      const { data: rows, count } = await q;
      return { rows: rows ?? [], total: count ?? 0, pageSize: PAGE };
    }
    // só o canal público: conversas privadas não são abertas pela moderação sem denúncia
    let q = a.from("chat_messages").select("id,sender_player,sender_user,sender_name,body,created_at", { count: "exact" }).is("to_player", null).order("created_at", { ascending: false }).range(data.page * PAGE, data.page * PAGE + PAGE - 1);
    if (t) q = q.or(`sender_name.ilike.%${t}%,body.ilike.%${t}%`);
    const { data: rows, count } = await q;
    return { rows: rows ?? [], total: count ?? 0, pageSize: PAGE };
  });

export const adminDeleteMessage = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ id: uuid, reason: z.string().trim().min(5).max(300) }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db, audit } = await S();
    await requirePerm(ctxOf(context), "chat.moderate");
    const a = await db();
    const { data: before } = await a.from("chat_messages").select("*").eq("id", data.id).maybeSingle();
    if (!before) throw new Error("Mensagem não encontrada");
    await a.from("chat_messages").delete().eq("id", data.id);
    await audit({ actor: context.userId, action: "chat.mensagem_excluida", target: before.sender_user, refKind: "mensagem", refId: data.id, before, reason: data.reason });
    return { ok: true };
  });

// ── Denúncias ──
export const adminReports = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ status: z.enum(["todas", "abertas", ...REPORT_STATUS]).default("abertas"), priority: z.enum(["todas", ...PRIORITIES]).default("todas"), q: z.string().max(80).default(""), mine: z.boolean().default(false), unassigned: z.boolean().default(false), page }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db } = await S();
    await requirePerm(ctxOf(context), "reports.view");
    const a = await db();
    let q = a.from("player_reports").select("id,protocol,reporter_name,target_name,target_user,category,created_at,priority,status,assignee,updated_at", { count: "exact" }).order("created_at", { ascending: false }).range(data.page * PAGE, data.page * PAGE + PAGE - 1);
    if (data.status === "abertas") q = q.in("status", ["recebida", "pendente", "em_analise", "aguardando_evidencias", "encaminhada"]);
    else if (data.status !== "todas") q = q.eq("status", data.status);
    if (data.priority !== "todas") q = q.eq("priority", data.priority);
    if (data.mine) q = q.eq("assignee", context.userId);
    if (data.unassigned) q = q.is("assignee", null);
    const t = data.q.trim().replace(/[%_,()]/g, "");
    if (t) q = q.or(`protocol.ilike.%${t}%,reporter_name.ilike.%${t}%,target_name.ilike.%${t}%`);
    const [{ data: rows, count }, { data: all }] = await Promise.all([q, a.from("player_reports").select("status,priority").limit(10_000)]);
    const stats: Record<string, number> = { total: all?.length ?? 0 };
    for (const r of all ?? []) { stats[r.status] = (stats[r.status] ?? 0) + 1; if (r.priority === "alta" || r.priority === "critica") stats[`p_${r.priority}`] = (stats[`p_${r.priority}`] ?? 0) + 1; }
    return { rows: rows ?? [], total: count ?? 0, pageSize: PAGE, stats };
  });

async function signed(paths: string[]) {
  const { db } = await S();
  const a = await db();
  const out: Record<string, string> = {};
  for (const p of paths) { const { data } = await a.storage.from("evidencias").createSignedUrl(p, 600); if (data?.signedUrl) out[p] = data.signedUrl; }
  return out;
}

export const adminReport = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ id: uuid }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db, sanctionsOf } = await S();
    await requirePerm(ctxOf(context), "reports.view");
    const a = await db();
    const { data: r } = await a.from("player_reports").select("*").eq("id", data.id).maybeSingle();
    if (!r) throw new Error("Denúncia não encontrada");
    const [{ data: ev }, { data: hist }, { data: prev }, sanc, { data: links }] = await Promise.all([
      a.from("report_evidence").select("*").eq("report_id", r.id).order("created_at"),
      a.from("case_history").select("*").eq("entity", "denuncia").eq("entity_id", r.id).order("created_at"),
      a.from("player_reports").select("id,protocol,category,status,created_at").eq("target_user", r.target_user).neq("id", r.id).order("created_at", { ascending: false }).limit(30),
      sanctionsOf(r.target_user),
      a.from("investigation_links").select("investigation_id").eq("kind", "denuncia").eq("ref_id", r.id),
    ]);
    const urls = await signed((ev ?? []).filter((e) => e.storage_path).map((e) => e.storage_path!));
    return { report: r, evidence: (ev ?? []).map((e) => ({ ...e, url: e.storage_path ? urls[e.storage_path] ?? null : null })), history: hist ?? [], previous: prev ?? [], sanctions: sanc, investigations: (links ?? []).map((l) => l.investigation_id) };
  });

export const adminUpdateReport = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({
    id: uuid, status: z.enum(REPORT_STATUS).optional(), priority: z.enum(PRIORITIES).optional(), assignee: uuid.nullable().optional(), dueAt: z.string().datetime().nullable().optional(),
    conclusion: z.string().max(3000).nullable().optional(), publicResult: z.string().max(500).nullable().optional(), note: z.string().max(3000).nullable().optional(),
  }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db, audit, notify, nameOf } = await S();
    await requirePerm(ctxOf(context), "reports.manage");
    const a = await db();
    const { data: before } = await a.from("player_reports").select("*").eq("id", data.id).maybeSingle();
    if (!before) throw new Error("Denúncia não encontrada");
    const patch: Record<string, unknown> = { updated_at: new Date().toISOString() };
    if (data.status) patch["status"] = data.status;
    if (data.priority) patch["priority"] = data.priority;
    if (data.assignee !== undefined) patch["assignee"] = data.assignee;
    if (data.dueAt !== undefined) patch["due_at"] = data.dueAt;
    if (data.conclusion !== undefined) patch["conclusion"] = data.conclusion;
    if (data.publicResult !== undefined) patch["public_result"] = data.publicResult;
    const { data: after } = await a.from("player_reports").update(patch as never).eq("id", data.id).select("*").single();
    const actor_name = await nameOf(context.userId);
    const changed = data.status && data.status !== before.status;
    if (changed) await a.from("case_history").insert({ entity: "denuncia", entity_id: data.id, actor: context.userId, actor_name, action: "status", from_status: before.status, to_status: data.status ?? null, internal: false, note: data.publicResult ?? null });
    if (data.note) await a.from("case_history").insert({ entity: "denuncia", entity_id: data.id, actor: context.userId, actor_name, action: "nota", note: data.note, internal: true });
    if (data.assignee !== undefined && data.assignee !== before.assignee) await a.from("case_history").insert({ entity: "denuncia", entity_id: data.id, actor: context.userId, actor_name, action: "responsavel", note: data.assignee ? await nameOf(data.assignee) : "sem responsável", internal: true });
    if (data.priority && data.priority !== before.priority) await a.from("case_history").insert({ entity: "denuncia", entity_id: data.id, actor: context.userId, actor_name, action: "prioridade", from_status: before.priority, to_status: data.priority, internal: true });
    await audit({ actor: context.userId, action: "denuncia.atualizada", target: before.target_user, refKind: "denuncia", refId: data.id, before, after });
    if (changed) {
      const { REPORT_STATUS_LABEL } = await import("./rules");
      await notify({ userId: before.reporter_user, audience: "jogador", kind: "denuncia.atualizada", title: `Denúncia ${before.protocol}: ${REPORT_STATUS_LABEL[data.status!]}`, body: data.publicResult ?? undefined, refKind: "denuncia", refId: data.id });
    }
    return after;
  });

// ── Bugs ──
export const adminBugs = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ status: z.enum(["todos", "abertos", ...BUG_STATUS]).default("abertos"), priority: z.enum(["todas", ...PRIORITIES]).default("todas"), q: z.string().max(80).default(""), page }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db } = await S();
    await requirePerm(ctxOf(context), "bugs.view");
    const a = await db();
    let q = a.from("bug_reports").select("id,protocol,player_name,title,category,created_at,priority,status,assignee,updated_at", { count: "exact" }).order("created_at", { ascending: false }).range(data.page * PAGE, data.page * PAGE + PAGE - 1);
    if (data.status === "abertos") q = q.in("status", ["recebido", "em_analise", "bugfix"]);
    else if (data.status !== "todos") q = q.eq("status", data.status);
    if (data.priority !== "todas") q = q.eq("priority", data.priority);
    const t = data.q.trim().replace(/[%_,()]/g, "");
    if (t) q = q.or(`protocol.ilike.%${t}%,title.ilike.%${t}%,player_name.ilike.%${t}%`);
    const [{ data: rows, count }, { data: all }] = await Promise.all([q, a.from("bug_reports").select("status").limit(10_000)]);
    const stats: Record<string, number> = { total: all?.length ?? 0 };
    for (const r of all ?? []) stats[r.status] = (stats[r.status] ?? 0) + 1;
    return { rows: rows ?? [], total: count ?? 0, pageSize: PAGE, stats };
  });

export const adminBug = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ id: uuid }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db } = await S();
    await requirePerm(ctxOf(context), "bugs.view");
    const a = await db();
    const { data: b } = await a.from("bug_reports").select("*").eq("id", data.id).maybeSingle();
    if (!b) throw new Error("Report não encontrado");
    const { data: hist } = await a.from("case_history").select("*").eq("entity", "bug").eq("entity_id", b.id).order("created_at");
    const urls = await signed(b.attachments ?? []);
    return { bug: b, history: hist ?? [], images: (b.attachments ?? []).map((p) => urls[p]).filter(Boolean) };
  });

export const adminUpdateBug = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({
    id: uuid, status: z.enum(BUG_STATUS).optional(), priority: z.enum(PRIORITIES).optional(), assignee: uuid.nullable().optional(),
    response: z.string().max(2000).nullable().optional(), duplicateOf: z.string().max(40).nullable().optional(), note: z.string().max(3000).nullable().optional(),
  }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db, audit, notify, nameOf } = await S();
    await requirePerm(ctxOf(context), "bugs.manage");
    const a = await db();
    const { data: before } = await a.from("bug_reports").select("*").eq("id", data.id).maybeSingle();
    if (!before) throw new Error("Report não encontrado");
    const patch: Record<string, unknown> = { updated_at: new Date().toISOString() };
    if (data.status) { patch["status"] = data.status; patch["resolved_at"] = data.status === "resolvido" ? new Date().toISOString() : null; }
    if (data.priority) patch["priority"] = data.priority;
    if (data.assignee !== undefined) patch["assignee"] = data.assignee;
    if (data.response !== undefined) patch["response"] = data.response;
    if (data.duplicateOf) {
      const { data: orig } = await a.from("bug_reports").select("id").or(`protocol.eq.${data.duplicateOf.replace(/[^A-Z0-9-]/gi, "")}`).maybeSingle();
      if (!orig || orig.id === data.id) throw new Error("Protocolo original não encontrado.");
      patch["duplicate_of"] = orig.id; patch["status"] = "duplicado";
    }
    const { data: after } = await a.from("bug_reports").update(patch as never).eq("id", data.id).select("*").single();
    const actor_name = await nameOf(context.userId);
    const newStatus = (patch["status"] as string | undefined) ?? before.status;
    if (newStatus !== before.status) await a.from("case_history").insert({ entity: "bug", entity_id: data.id, actor: context.userId, actor_name, action: before.status === "resolvido" ? "reaberto" : "status", from_status: before.status, to_status: newStatus, internal: false, note: data.response ?? null });
    else if (data.response && data.response !== before.response) await a.from("case_history").insert({ entity: "bug", entity_id: data.id, actor: context.userId, actor_name, action: "resposta", note: data.response, internal: false });
    if (data.note) await a.from("case_history").insert({ entity: "bug", entity_id: data.id, actor: context.userId, actor_name, action: "nota", note: data.note, internal: true });
    await audit({ actor: context.userId, action: "bug.atualizado", target: before.user_id, refKind: "bug", refId: data.id, before, after });
    if (newStatus !== before.status || (data.response && data.response !== before.response)) {
      const { BUG_STATUS_LABEL } = await import("./rules");
      await notify({ userId: before.user_id, audience: "jogador", kind: `bug.${newStatus}`, title: `Report ${before.protocol}: ${BUG_STATUS_LABEL[newStatus as keyof typeof BUG_STATUS_LABEL]}`, body: data.response ?? undefined, refKind: "bug", refId: data.id });
    }
    return after;
  });

// ── Investigação ──
export const adminTimeline = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ userId: uuid }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, myPerms, db } = await S();
    await requirePerm(ctxOf(context), "investigations.manage");
    const me = await myPerms(ctxOf(context));
    const a = await db();
    const sec = me.perms.includes("security.view");
    const [acc, vio, rr, rm, sa, bu, au] = await Promise.all([
      a.from("access_log").select("id,ip,platform,game_version,geo,created_at").eq("user_id", data.userId).order("created_at", { ascending: false }).limit(200),
      a.from("chat_violations").select("id,kind,category,body,offense_number,created_at").eq("user_id", data.userId).limit(200),
      a.from("player_reports").select("id,protocol,category,status,reporter_name,created_at").eq("target_user", data.userId).limit(200),
      a.from("player_reports").select("id,protocol,category,status,target_name,created_at").eq("reporter_user", data.userId).limit(200),
      a.from("player_sanctions").select("id,kind,reason,ends_at,revoked_at,source,created_at").eq("user_id", data.userId).limit(200),
      a.from("bug_reports").select("id,protocol,title,status,created_at").eq("user_id", data.userId).limit(200),
      a.from("admin_audit_logs").select("id,action,actor_name,reason,created_at").eq("target_user", data.userId).limit(200),
    ]);
    type Ev = { at: string; tipo: string; titulo: string; detalhe?: string | null; ref?: string; refKind?: string };
    const ev: Ev[] = [
      ...(acc.data ?? []).map((r) => ({ at: r.created_at, tipo: "acesso", titulo: `Entrou no jogo (${r.platform ?? "?"})`, detalhe: sec ? `${r.ip ?? "IP desconhecido"}${(r.geo as { cidade?: string } | null)?.cidade ? ` · ${(r.geo as { cidade?: string }).cidade} (aprox.)` : ""}` : null, ref: r.id, refKind: "acesso" })),
      ...(vio.data ?? []).map((r) => ({ at: r.created_at, tipo: "chat", titulo: `Mensagem bloqueada (${r.kind} · ${r.category}) — ${r.offense_number}ª`, detalhe: r.body, ref: r.id, refKind: "violacao" })),
      ...(rr.data ?? []).map((r) => ({ at: r.created_at, tipo: "denuncia_recebida", titulo: `Denúncia recebida ${r.protocol} (${r.category})`, detalhe: `por ${r.reporter_name} · ${r.status}`, ref: r.id, refKind: "denuncia" })),
      ...(rm.data ?? []).map((r) => ({ at: r.created_at, tipo: "denuncia_feita", titulo: `Denunciou ${r.target_name} — ${r.protocol}`, detalhe: r.status, ref: r.id, refKind: "denuncia" })),
      ...(sa.data ?? []).map((r) => ({ at: r.created_at, tipo: "punicao", titulo: `${r.kind}${r.source === "automatica" ? " automática" : ""}${r.revoked_at ? " (revogada)" : ""}`, detalhe: r.reason, ref: r.id, refKind: "punicao" })),
      ...(bu.data ?? []).map((r) => ({ at: r.created_at, tipo: "bug", titulo: `Reportou bug ${r.protocol}`, detalhe: r.title, ref: r.id, refKind: "bug" })),
      ...(au.data ?? []).map((r) => ({ at: r.created_at, tipo: "admin", titulo: `Ação administrativa: ${r.action}`, detalhe: `${r.actor_name ?? ""}${r.reason ? ` — ${r.reason}` : ""}` })),
    ];
    return ev.sort((x, y) => Date.parse(y.at) - Date.parse(x.at)).slice(0, 500);
  });

export const adminInvestigations = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ status: z.enum(["abertas", "todas", ...INV_STATUS]).default("abertas"), page }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db } = await S();
    await requirePerm(ctxOf(context), "investigations.manage");
    const a = await db();
    let q = a.from("investigations").select("*", { count: "exact" }).order("updated_at", { ascending: false }).range(data.page * PAGE, data.page * PAGE + PAGE - 1);
    if (data.status === "abertas") q = q.in("status", ["aberta", "em_andamento", "aguardando"]);
    else if (data.status !== "todas") q = q.eq("status", data.status);
    const { data: rows, count } = await q;
    return { rows: rows ?? [], total: count ?? 0, pageSize: PAGE };
  });

export const adminSaveInvestigation = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({
    id: uuid.nullable().optional(), title: z.string().trim().min(4).max(160).optional(), targetUser: uuid.nullable().optional(), status: z.enum(INV_STATUS).optional(),
    priority: z.enum(PRIORITIES).optional(), assignee: uuid.nullable().optional(), dueAt: z.string().datetime().nullable().optional(), summary: z.string().max(5000).nullable().optional(),
    link: z.object({ kind: z.enum(["denuncia", "bug", "punicao", "violacao", "acesso"]), refId: uuid, note: z.string().max(300).nullable().optional() }).optional(),
    note: z.string().max(3000).optional(),
  }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db, audit, nameOf } = await S();
    await requirePerm(ctxOf(context), "investigations.manage");
    const a = await db();
    let id = data.id ?? null;
    const actor_name = await nameOf(context.userId);
    if (!id) {
      if (!data.title) throw new Error("Informe o título do caso.");
      const target_name = data.targetUser ? await nameOf(data.targetUser) : null;
      const { data: inv, error } = await a.from("investigations").insert({ title: data.title, target_user: data.targetUser ?? null, target_name, priority: data.priority ?? "media", assignee: data.assignee ?? context.userId, due_at: data.dueAt ?? null, summary: data.summary ?? null, created_by: context.userId }).select("*").single();
      if (error || !inv) throw new Error("Não foi possível abrir o caso.");
      id = inv.id;
      await a.from("case_history").insert({ entity: "investigacao", entity_id: id, actor: context.userId, actor_name, action: "aberta", to_status: "aberta" });
      await audit({ actor: context.userId, action: "investigacao.aberta", target: data.targetUser ?? null, refKind: "investigacao", refId: id, after: inv });
    } else {
      const { data: before } = await a.from("investigations").select("*").eq("id", id).maybeSingle();
      if (!before) throw new Error("Caso não encontrado");
      const patch: Record<string, unknown> = { updated_at: new Date().toISOString() };
      for (const [k, col] of [["title", "title"], ["status", "status"], ["priority", "priority"], ["assignee", "assignee"], ["dueAt", "due_at"], ["summary", "summary"]] as const) if (data[k] !== undefined) patch[col] = data[k];
      const { data: after } = await a.from("investigations").update(patch as never).eq("id", id).select("*").single();
      if (data.status && data.status !== before.status) await a.from("case_history").insert({ entity: "investigacao", entity_id: id, actor: context.userId, actor_name, action: "status", from_status: before.status, to_status: data.status });
      if (Object.keys(patch).length > 1) await audit({ actor: context.userId, action: "investigacao.atualizada", target: before.target_user, refKind: "investigacao", refId: id, before, after });
    }
    if (data.link) {
      const { error } = await a.from("investigation_links").insert({ investigation_id: id, kind: data.link.kind, ref_id: data.link.refId, note: data.link.note ?? null, created_by: context.userId });
      if (error && !/duplicate|unique/i.test(error.message)) throw new Error("Não foi possível relacionar o registro.");
      await a.from("case_history").insert({ entity: "investigacao", entity_id: id, actor: context.userId, actor_name, action: "vinculo", note: `${data.link.kind} ${data.link.refId}` });
    }
    if (data.note) await a.from("case_history").insert({ entity: "investigacao", entity_id: id, actor: context.userId, actor_name, action: "nota", note: data.note });
    return { id };
  });

export const adminInvestigation = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ id: uuid }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db } = await S();
    await requirePerm(ctxOf(context), "investigations.manage");
    const a = await db();
    const { data: inv } = await a.from("investigations").select("*").eq("id", data.id).maybeSingle();
    if (!inv) throw new Error("Caso não encontrado");
    const [{ data: links }, { data: hist }] = await Promise.all([
      a.from("investigation_links").select("*").eq("investigation_id", inv.id).order("created_at"),
      a.from("case_history").select("*").eq("entity", "investigacao").eq("entity_id", inv.id).order("created_at"),
    ]);
    const ids = (k: string) => (links ?? []).filter((l) => l.kind === k).map((l) => l.ref_id);
    const none = Promise.resolve({ data: [] as Record<string, unknown>[] });
    const [rp, bg, sc, vl] = await Promise.all([
      ids("denuncia").length ? a.from("player_reports").select("id,protocol,category,status,target_name").in("id", ids("denuncia")) : none,
      ids("bug").length ? a.from("bug_reports").select("id,protocol,title,status").in("id", ids("bug")) : none,
      ids("punicao").length ? a.from("player_sanctions").select("id,kind,reason,created_at,revoked_at").in("id", ids("punicao")) : none,
      ids("violacao").length ? a.from("chat_violations").select("id,body,category,created_at").in("id", ids("violacao")) : none,
    ]);
    const label = (l: { kind: string; ref_id: string }) => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const f = (xs: unknown[] | null): any => (xs as { id: string }[] | null)?.find((x) => x.id === l.ref_id);
      if (l.kind === "denuncia") { const r = f(rp.data); return r ? `${r.protocol} · ${r.category} · ${r.status}` : l.ref_id; }
      if (l.kind === "bug") { const r = f(bg.data); return r ? `${r.protocol} · ${r.title}` : l.ref_id; }
      if (l.kind === "punicao") { const r = f(sc.data); return r ? `${r.kind} · ${r.reason}${r.revoked_at ? " (revogada)" : ""}` : l.ref_id; }
      if (l.kind === "violacao") { const r = f(vl.data); return r ? `${r.category}: ${r.body}` : l.ref_id; }
      return l.ref_id;
    };
    return { inv, links: (links ?? []).map((l) => ({ ...l, label: label(l) })), history: hist ?? [] };
  });

// ── Equipe ──
export const adminStaff = createServerFn({ method: "GET" })
  .middleware([openAdmin])
  .handler(async ({ context }) => {
    const { requireStaff, db, nameOf } = await S();
    await requireStaff(ctxOf(context));
    const a = await db();
    const [{ data: st }, { data: roles }, { data: perms }] = await Promise.all([
      a.from("staff_members").select("*"), a.from("user_roles").select("user_id,role").in("role", ["admin", "moderator"]), a.from("staff_permissions").select("*"),
    ]);
    const ids = [...new Set([...(st ?? []).map((s) => s.user_id), ...(roles ?? []).map((r) => r.user_id)])];
    const members = await Promise.all(ids.map(async (id) => {
      const s = st?.find((x) => x.user_id === id);
      const tier: Tier = (s?.tier as Tier) ?? (roles?.some((r) => r.user_id === id && r.role === "admin") ? "administrador" : "moderador");
      const { data: eff } = await a.rpc("staff_perms", { _uid: id });
      const { data: open } = await a.from("player_reports").select("id", { count: "exact", head: false }).eq("assignee", id).in("status", ["recebida", "pendente", "em_analise", "aguardando_evidencias", "encaminhada"]);
      return { userId: id, name: await nameOf(id), tier, legacyRole: !s, overrides: (perms ?? []).filter((p) => p.user_id === id), perms: (eff ?? []) as string[], openCases: open?.length ?? 0 };
    }));
    // painel operacional
    const [{ data: reps }, { data: bugs }, { data: closed }] = await Promise.all([
      a.from("player_reports").select("status,assignee,priority").in("status", ["recebida", "pendente", "em_analise", "aguardando_evidencias", "encaminhada"]),
      a.from("bug_reports").select("status").in("status", ["recebido", "em_analise", "bugfix"]),
      a.from("player_reports").select("created_at,updated_at").in("status", ["procedente", "improcedente", "encerrada"]).limit(500),
    ]);
    const { data: inv } = await a.from("investigations").select("priority,status,assignee").in("status", ["aberta", "em_andamento", "aguardando"]);
    const avgH = closed?.length ? closed.reduce((t, r) => t + (Date.parse(r.updated_at) - Date.parse(r.created_at)), 0) / closed.length / 3_600_000 : null;
    const ops = {
      casosAbertos: (reps?.length ?? 0) + (inv?.length ?? 0), denunciasPendentes: reps?.length ?? 0, bugsPendentes: bugs?.length ?? 0,
      investigacoesCriticas: (inv ?? []).filter((i) => i.priority === "critica").length, semResponsavel: (reps ?? []).filter((r) => !r.assignee).length + (inv ?? []).filter((i) => !i.assignee).length,
      aguardandoEvidencias: (reps ?? []).filter((r) => r.status === "aguardando_evidencias").length, tempoMedioHoras: avgH,
    };
    return { members, ops };
  });

export const adminSetStaff = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ userId: uuid, tier: z.enum(TIERS).nullable().optional(), perm: z.object({ name: z.enum(PERMS), allowed: z.boolean().nullable() }).optional(), reason: z.string().trim().min(3).max(300) }).parse(d))
  .handler(async ({ data, context }) => {
    const { myPerms, db, audit, notify } = await S();
    const me = await myPerms(ctxOf(context));
    const a = await db();
    const { data: tt } = await a.rpc("staff_perms", { _uid: data.userId });
    const { data: sm } = await a.from("staff_members").select("tier").eq("user_id", data.userId).maybeSingle();
    const { data: ur } = await a.from("user_roles").select("role").eq("user_id", data.userId);
    const targetTier: Tier | null = (sm?.tier as Tier) ?? (ur?.some((r) => r.role === "admin") ? "administrador" : ur?.some((r) => r.role === "moderator") ? "moderador" : null);
    const err = canManageStaff({ id: context.userId, tier: me.tier as Tier, perms: me.perms }, { id: data.userId, tier: targetTier }, data.tier ?? null);
    if (err) throw new Error(err);
    const before = { tier: targetTier, perms: tt };
    if (data.tier !== undefined) {
      if (data.tier === null) { await a.from("staff_members").delete().eq("user_id", data.userId); await a.from("staff_permissions").delete().eq("user_id", data.userId); }
      else await a.from("staff_members").upsert({ user_id: data.userId, tier: data.tier, added_by: context.userId, updated_at: new Date().toISOString() });
    }
    if (data.perm) {
      if (data.perm.allowed === null) await a.from("staff_permissions").delete().eq("user_id", data.userId).eq("permission", data.perm.name);
      else await a.from("staff_permissions").upsert({ user_id: data.userId, permission: data.perm.name, allowed: data.perm.allowed, granted_by: context.userId });
    }
    const { data: after } = await a.rpc("staff_perms", { _uid: data.userId });
    await audit({ actor: context.userId, action: data.perm ? "equipe.permissao" : "equipe.cargo", target: data.userId, before, after: { tier: data.tier ?? targetTier, perms: after }, reason: data.reason });
    if (data.tier !== undefined) await notify({ userId: data.userId, audience: "jogador", kind: "conta.atualizada", title: data.tier ? `Você agora faz parte da equipe (${data.tier})` : "Você saiu da equipe administrativa" });
    return { ok: true };
  });

// ── Notificações da equipe ──
export const adminNotifications = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ markRead: z.array(uuid).max(200).optional() }).parse(d))
  .handler(async ({ data, context }) => {
    const { requireStaff, db } = await S();
    await requireStaff(ctxOf(context));
    const a = await db();
    if (data.markRead?.length) await a.from("notifications").update({ read_at: new Date().toISOString() }).in("id", data.markRead).eq("audience", "equipe");
    const { data: rows } = await a.from("notifications").select("*").eq("audience", "equipe").order("created_at", { ascending: false }).limit(100);
    return rows ?? [];
  });

// ── Auditoria ──
export const adminAudit = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ q: z.string().max(80).default(""), action: z.string().max(60).default(""), page }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db } = await S();
    await requirePerm(ctxOf(context), "audit.view");
    const a = await db();
    let q = a.from("admin_audit_logs").select("*", { count: "exact" }).order("created_at", { ascending: false }).range(data.page * PAGE, data.page * PAGE + PAGE - 1);
    const t = data.q.trim().replace(/[%_,()]/g, "");
    if (t) q = /^[0-9a-f-]{36}$/i.test(t) ? q.or(`target_user.eq.${t},actor.eq.${t}`) : q.or(`actor_name.ilike.%${t}%,reason.ilike.%${t}%,ref_id.ilike.%${t}%`);
    if (data.action) q = q.ilike("action", `${data.action.replace(/[%_,()]/g, "")}%`);
    const { data: rows, count } = await q;
    return { rows: rows ?? [], total: count ?? 0, pageSize: PAGE };
  });

// ── Configurações ──
export const adminSettings = createServerFn({ method: "GET" })
  .middleware([openAdmin])
  .handler(async ({ context }) => {
    const { requireStaff, db, SETTING_DEFAULTS } = await S();
    await requireStaff(ctxOf(context));
    const { data } = await (await db()).from("system_settings").select("*");
    return Object.fromEntries(Object.entries(SETTING_DEFAULTS).map(([k, v]) => [k, { value: (data?.find((r) => r.key === k)?.value ?? v) as Json, custom: !!data?.find((r) => r.key === k), updatedAt: data?.find((r) => r.key === k)?.updated_at ?? null }])) as Record<string, { value: Json; custom: boolean; updatedAt: string | null }>;
  });

export const adminSaveSetting = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ key: z.enum(["ladder", "severe", "flood", "reputation", "geo", "reports", "bugs"]), value: z.unknown(), reason: z.string().trim().min(3).max(300) }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db, audit } = await S();
    await requirePerm(ctxOf(context), "settings.manage");
    const step = z.object({ kind: z.enum(SANCTION_KINDS), minutes: z.number().int().min(0).max(525_600).nullable() });
    const schema = {
      ladder: z.array(step).min(1).max(10), severe: step,
      flood: z.object({ max: z.number().int().min(2).max(60), windowS: z.number().int().min(2).max(600), repeat: z.number().int().min(2).max(20) }),
      reputation: z.object({ advertencia: z.number().min(0).max(100), silenciamento: z.number().min(0).max(100), suspensao: z.number().min(0).max(100), banimento: z.number().min(0).max(100), violacao: z.number().min(0).max(100) }),
      geo: z.object({ enabled: z.boolean(), ttlDays: z.number().int().min(1).max(365) }),
      reports: z.object({ perHour: z.number().int().min(1).max(100) }), bugs: z.object({ perHour: z.number().int().min(1).max(100) }),
    }[data.key];
    const value = schema.parse(data.value);
    const a = await db();
    const { data: before } = await a.from("system_settings").select("value").eq("key", data.key).maybeSingle();
    await a.from("system_settings").upsert({ key: data.key, value: value as never, updated_by: context.userId, updated_at: new Date().toISOString() });
    await audit({ actor: context.userId, action: "config.alterada", refKind: "config", refId: data.key, before: before?.value ?? null, after: value, reason: data.reason });
    return { ok: true };
  });

// ── Pesquisa global ──
export const adminSearch = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ q: z.string().trim().min(2).max(80) }).parse(d))
  .handler(async ({ data, context }) => {
    const { requireStaff, db } = await S();
    const me = await requireStaff(ctxOf(context));
    const a = await db();
    const t = data.q.replace(/[%_,()]/g, "");
    const has = (p: string) => me.perms.includes(p);
    const none = Promise.resolve({ data: [] as never[] });
    const isId = /^[0-9a-f-]{36}$/i.test(t);
    const [pl, rp, bg, iv, ip] = await Promise.all([
      has("players.view") ? a.from("players").select("id,user_id,name,tag").or(isId ? `id.eq.${t},user_id.eq.${t}` : `name.ilike.%${t}%,tag.eq.${t.replace(/^STR#/i, "").replace(/\D/g, "") || "0"}`).limit(8) : none,
      has("reports.view") ? a.from("player_reports").select("id,protocol,target_name,status").or(`protocol.ilike.%${t}%,target_name.ilike.%${t}%,description.ilike.%${t}%`).limit(8) : none,
      has("bugs.view") ? a.from("bug_reports").select("id,protocol,title,status").or(`protocol.ilike.%${t}%,title.ilike.%${t}%`).limit(8) : none,
      has("investigations.manage") ? a.from("investigations").select("id,code,title,status").or(`code.ilike.%${t}%,title.ilike.%${t}%`).limit(8) : none,
      has("security.view") && /^[0-9a-f.:]{3,}$/i.test(t) && !isId ? a.from("access_log").select("ip,user_id,created_at").ilike("ip", `${t}%`).limit(8) : none,
    ]);
    return { players: pl.data ?? [], reports: rp.data ?? [], bugs: bg.data ?? [], cases: iv.data ?? [], ips: ip.data ?? [] };
  });

// ── Integrações ──
export const adminIntegrations = createServerFn({ method: "GET" })
  .middleware([openAdmin])
  .handler(async ({ context }) => {
    const { requireStaff, db, setting } = await S();
    await requireStaff(ctxOf(context));
    const a = await db();
    const [{ data: lastGeo }, { count: geoCache }, bucket, geo] = await Promise.all([
      a.from("ip_geo").select("fetched_at").order("fetched_at", { ascending: false }).limit(1),
      a.from("ip_geo").select("ip", { count: "exact", head: true }),
      a.storage.getBucket("evidencias"),
      setting("geo"),
    ]);
    let geoOk: boolean | null = null;
    try { const r = await fetch("https://ipwho.is/8.8.8.8?fields=success", { signal: AbortSignal.timeout(3000) }); geoOk = ((await r.json()) as { success?: boolean }).success === true; } catch { geoOk = false; }
    return [
      { nome: "Geolocalização por IP (ipwho.is)", estado: !geo.enabled ? "desligada" : geoOk ? "ok" : "falha", detalhe: `${geoCache ?? 0} IPs em cache · validade ${geo.ttlDays} dias · última consulta ${lastGeo?.[0]?.fetched_at ?? "nunca"}` },
      { nome: "Armazenamento de evidências", estado: bucket.data ? "ok" : "falha", detalhe: bucket.data ? `privado · limite ${Math.round((bucket.data.file_size_limit ?? 0) / 1048576)} MB · PNG/JPG/WEBP` : "bucket não encontrado" },
      { nome: "Bloqueio de login (Auth)", estado: "ok", detalhe: "suspensões e banimentos bloqueiam a entrada e expiram sozinhos" },
      { nome: "E-mail de redefinição de senha", estado: "ok", detalhe: "enviado pelo sistema de contas; contas por token não têm e-mail" },
      { nome: "Chat moderado", estado: "ok", detalhe: "envio só pelo servidor: filtro, flood, silenciamento e punição progressiva" },
    ];
  });

// ── Reputação ──
export const adminReputation = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ page }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db, setting, nameOf } = await S();
    await requirePerm(ctxOf(context), "players.view");
    const a = await db();
    const [{ data: sanc }, { data: vio }, { data: inv }, w] = await Promise.all([
      a.from("player_sanctions").select("user_id,kind,revoked_at,created_at").limit(10_000),
      a.from("chat_violations").select("user_id").limit(10_000),
      a.from("investigations").select("target_user").in("status", ["aberta", "em_andamento", "aguardando"]),
      setting("reputation"),
    ]);
    const users = [...new Set([...(sanc ?? []).map((s) => s.user_id), ...(vio ?? []).map((v) => v.user_id)])];
    const all = users.map((u) => ({ userId: u, ...reputation((sanc ?? []).filter((s) => s.user_id === u) as never, (vio ?? []).filter((v) => v.user_id === u).length, (inv ?? []).some((i) => i.target_user === u), w as never), violations: (vio ?? []).filter((v) => v.user_id === u).length }))
      .sort((x, y) => x.score - y.score);
    const slice = all.slice(data.page * PAGE, data.page * PAGE + PAGE);
    return { total: all.length, pageSize: PAGE, rows: await Promise.all(slice.map(async (r) => ({ ...r, name: await nameOf(r.userId) }))) };
  });

// ── IPs bloqueados e abuso de contas ──
const ipStr = z.string().trim().regex(/^[0-9a-f.:]{3,45}$/i, "IP inválido");
export const adminBlockedIps = createServerFn({ method: "GET" })
  .middleware([openAdmin])
  .handler(async ({ context }) => {
    const { requirePerm, db } = await S();
    await requirePerm(ctxOf(context), "security.view");
    const a = await db();
    const { data } = await a.from("blocked_ips").select("*").order("created_at", { ascending: false }).limit(500);
    const ips = (data ?? []).map((r) => r.ip);
    const { data: geo } = ips.length ? await a.from("ip_geo").select("ip,data").in("ip", ips) : { data: [] };
    return (data ?? []).map((r) => ({ ...r, active: !r.expires_at || Date.parse(r.expires_at) > Date.now(), geo: (geo?.find((g) => g.ip === r.ip)?.data ?? null) as Record<string, string> | null }));
  });

export const adminBlockIp = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ ip: ipStr, hours: z.number().int().min(1).max(87600).nullable(), reason: z.string().trim().min(5).max(500) }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db, audit } = await S();
    await requirePerm(ctxOf(context), "players.ban");
    const a = await db();
    const expires_at = data.hours ? new Date(Date.now() + data.hours * 3_600_000).toISOString() : null;
    const { error } = await a.from("blocked_ips").upsert({ ip: data.ip, reason: data.reason, source: "manual", created_by: context.userId, expires_at, created_at: new Date().toISOString() });
    if (error) throw new Error("Não foi possível bloquear o IP.");
    await audit({ actor: context.userId, action: "ip.bloqueio", reason: `${data.ip}: ${data.reason}`, after: { expires_at } });
    return { ok: true };
  });

export const adminUnblockIp = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ ip: ipStr, reason: z.string().trim().min(5).max(500) }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db, audit } = await S();
    await requirePerm(ctxOf(context), "players.unban");
    const { error } = await (await db()).from("blocked_ips").delete().eq("ip", data.ip);
    if (error) throw new Error("Não foi possível desbloquear.");
    await audit({ actor: context.userId, action: "ip.desbloqueio", reason: `${data.ip}: ${data.reason}` });
    return { ok: true };
  });

export const adminAbuseFlags = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ status: z.enum(["aberto", "confirmado", "descartado"]).default("aberto") }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db } = await S();
    await requirePerm(ctxOf(context), "security.view");
    const a = await db();
    const { data: rows } = await a.from("abuse_flags").select("*").eq("status", data.status).order("updated_at", { ascending: false }).limit(200);
    const uids = [...new Set((rows ?? []).flatMap((r) => r.user_ids))];
    const { data: ps } = uids.length ? await a.from("players").select("user_id,name,tag").in("user_id", uids) : { data: [] };
    const { data: bl } = rows?.length ? await a.from("blocked_ips").select("ip,expires_at").in("ip", rows.map((r) => r.ip)) : { data: [] };
    return (rows ?? []).map((r) => ({ ...r, blocked: !!bl?.find((b) => b.ip === r.ip && (!b.expires_at || Date.parse(b.expires_at) > Date.now())), contas: r.user_ids.map((u) => ({ userId: u, nome: ps?.filter((p) => p.user_id === u).map((p) => `${p.name} (STR#${p.tag})`).join(", ") || u.slice(0, 8) })) }));
  });

export const adminResolveAbuse = createServerFn({ method: "POST" })
  .middleware([openAdmin])
  .inputValidator((d: unknown) => z.object({ id: uuid, status: z.enum(["confirmado", "descartado"]), reason: z.string().trim().min(5).max(500) }).parse(d))
  .handler(async ({ data, context }) => {
    const { requirePerm, db, audit } = await S();
    await requirePerm(ctxOf(context), "players.manage");
    const now = new Date().toISOString();
    const { error } = await (await db()).from("abuse_flags").update({ status: data.status, resolved_by: context.userId, resolved_at: now, updated_at: now }).eq("id", data.id);
    if (error) throw new Error("Não foi possível atualizar o alerta.");
    await audit({ actor: context.userId, action: `abuso.${data.status}`, refKind: "abuse_flag", refId: data.id, reason: data.reason });
    return { ok: true };
  });
