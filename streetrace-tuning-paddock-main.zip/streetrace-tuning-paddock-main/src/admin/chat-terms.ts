// Lista base do filtro de palavras do chat (gravada no banco; a equipe edita pelo painel em Filtro de palavras).
// Fora da lista de propósito: gírias de rua e de preparação ("pau a pau", "macaco" de oficina, "foda" elogio, "socado", "rola um x1").
export type SeedTerm = { term: string; category: "palavrao" | "ofensa" | "discriminacao" | "ameaca" | "assedio" | "proibida"; severity: 1 | 2 | 3 | 4 };
const T = (category: SeedTerm["category"], severity: SeedTerm["severity"], ...terms: string[]): SeedTerm[] => terms.map((term) => ({ term, category, severity }));
export const SEED_TERMS: SeedTerm[] = [
  ...T("palavrao", 1, "Porra", "Caralho", "Merda", "Bosta", "Cacete", "Foda-se", "Puta", "Puta que pariu", "Buceta", "Piroca", "Xoxota", "Cuzão"),
  ...T("ofensa", 1, "Idiota", "Imbecil", "Babaca"),
  ...T("ofensa", 2, "Filho da puta", "FDP", "Vai se foder", "Vai tomar no cu", "Tomar no cu", "Arrombado", "Arrombada", "Vagabundo", "Vagabunda", "Desgraçado", "Desgraçada", "Corno", "Lixo humano", "Retardado", "Retardada"),
  ...T("discriminacao", 3, "Viado", "Viadinho", "Viadão", "Bichinha", "Boiola", "Baitola", "Sapatão", "Traveco", "Gayzinho", "Mongoloide", "Aleijado"),
  ...T("assedio", 3, "Manda nudes", "Manda foto pelada", "Chupa meu pau", "Senta no meu colo"),
  ...T("discriminacao", 4, "Macaco imundo", "Seu macaco", "Volta pra senzala", "Crioulo", "Negro sujo", "Preto sujo", "Tiziu", "Picolé de asfalto", "Cabelo de bombril", "Judeu sujo", "Volta pra jaula"),
  ...T("ameaca", 4, "Vou te matar", "Vai se matar", "Se mata logo", "Sei onde você mora"),
  ...T("proibida", 4, "Heil Hitler", "Sieg Heil"),
];
