// Funções do jogador ligadas à administração: situação da conta, acesso, chat moderado, denúncias, bugs e "meus casos".
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { REPORT_CATEGORIES, BUG_CATEGORIES, MAX_IMAGES, MAX_IMAGE_BYTES, matchFilter, isFlood, ladderStep, stepText, normalize, reportPriority, sniffImage, type Filter } from "./rules";

const S = () => import("./admin.server");
const uuid = z.string().uuid();
const sid = (claims: unknown) => ((claims as { session_id?: string } | undefined)?.session_id ?? null);

export const myStanding = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { standingFor } = await S();
    return standingFor(context.userId);
  });

export const pingAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ playerId: uuid.nullable(), gameVersion: z.string().max(80).nullable() }).parse(d))
  .handler(async ({ data, context }) => {
    const { recordAccess, db } = await S();
    let pid = data.playerId;
    if (pid) { const own = await (await db()).from("players").select("id").eq("id", pid).eq("user_id", context.userId).maybeSingle(); if (!own.data) pid = null; }
    return recordAccess(context.userId, pid, data.gameVersion, sid(context.claims));
  });

/** Chat moderado: silenciamento, flood, filtro de palavras e punição progressiva antes de publicar. */
export const sendChat = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ senderPlayer: uuid, toPlayer: uuid.nullable(), body: z.string().trim().min(1).max(300) }).parse(d))
  .handler(async ({ data, context }) => {
    const { db, standingFor, setting, applySanction, notify } = await S();
    const a = await db();
    const { data: me } = await a.from("players").select("id,name").eq("id", data.senderPlayer).eq("user_id", context.userId).maybeSingle();
    if (!me) return { ok: false as const, motivo: "Piloto inválido." };
    if (data.toPlayer) { const t = await a.from("players").select("id").eq("id", data.toPlayer).maybeSingle(); if (!t.data) return { ok: false as const, motivo: "Destinatário não existe." }; }
    const st = await standingFor(context.userId);
    if (st.muted) return { ok: false as const, motivo: st.until ? `Chat silenciado até ${new Date(st.until).toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" })}.` : "Chat silenciado." };

    const block = async (kind: "filtro" | "flood" | "spam", f: Filter | null) => {
      const { count } = await a.from("chat_violations").select("id", { count: "exact", head: true }).eq("user_id", context.userId);
      const offense = (count ?? 0) + 1;
      const { data: v } = await a.from("chat_violations").insert({
        user_id: context.userId, player_id: me.id, player_name: me.name, body: data.body, normalized: normalize(data.body), kind,
        filter_id: f?.id ?? null, term: f?.term ?? null, category: f?.category ?? kind, severity: f?.severity ?? 1, offense_number: offense,
      }).select("id").single();
      const [ladder, severe] = await Promise.all([setting("ladder"), setting("severe")]);
      const step = ladderStep(offense, f?.severity ?? 1, ladder as never, severe as never);
      const s = await applySanction({ actor: null, userId: context.userId, playerId: me.id, kind: step.kind, minutes: step.minutes, category: "chat", reason: kind === "filtro" ? `Mensagem bloqueada pelo filtro (${f?.category})` : kind === "flood" ? "Flood no chat" : "Spam no chat", source: "automatica", violationId: v?.id ?? null });
      if (v) await a.from("chat_violations").update({ sanction_id: s.id }).eq("id", v.id);
      if ((f?.severity ?? 1) >= 3 || offense >= 4) await notify({ userId: null, audience: "equipe", kind: "chat.reincidente", title: `${me.name}: ${offense}ª infração no chat`, body: data.body.slice(0, 120), refKind: "violacao", refId: v?.id });
      return { ok: false as const, motivo: `Mensagem bloqueada. ${stepText(step)}`, banned: step.kind === "banimento" || step.kind === "suspensao" };
    };

    const { data: recent } = await a.from("chat_messages").select("body,created_at").eq("sender_user", context.userId).order("created_at", { ascending: false }).limit(10);
    const flood = isFlood(recent ?? [], data.body, Date.now(), (await setting("flood")) as never);
    if (flood) return block(flood, null);
    const { data: filters } = await a.from("chat_filters").select("id,term,normalized,category,severity,active").eq("active", true);
    const hit = matchFilter(data.body, (filters ?? []) as Filter[]);
    if (hit) return block("filtro", hit);

    const { error } = await a.from("chat_messages").insert({ sender_player: me.id, sender_user: context.userId, sender_name: me.name, to_player: data.toPlayer, body: data.body });
    if (error) return { ok: false as const, motivo: /slow/.test(error.message) ? "Calma, uma mensagem por segundo." : "Não foi possível enviar." };
    return { ok: true as const, motivo: null };
  });

const imgs = z.array(z.object({ name: z.string().max(120), b64: z.string().max(Math.ceil(MAX_IMAGE_BYTES * 1.4)) })).max(MAX_IMAGES).default([]);
async function storeImages(prefix: string, list: { name: string; b64: string }[]) {
  const { db } = await S();
  const a = await db();
  const out: string[] = [];
  for (const [i, f] of list.entries()) {
    const bytes = Uint8Array.from(atob(f.b64), (c) => c.charCodeAt(0));
    if (bytes.length > MAX_IMAGE_BYTES) throw new Error("Imagem maior que 5 MB.");
    const mime = sniffImage(bytes);
    if (!mime) throw new Error("Arquivo inválido: envie PNG, JPG ou WEBP.");
    const path = `${prefix}/${Date.now()}-${i}.${mime.split("/")[1]}`;
    const { error } = await a.storage.from("evidencias").upload(path, bytes, { contentType: mime, upsert: false });
    if (error) throw new Error("Falha ao guardar a imagem.");
    out.push(path);
  }
  return out;
}

export const submitReport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    reporterPlayer: uuid, targetPlayer: uuid, category: z.enum(REPORT_CATEGORIES), description: z.string().trim().min(10).max(3000),
    occurredAt: z.string().datetime().nullable().optional(), location: z.string().max(200).nullable().optional(), witnesses: z.string().max(500).nullable().optional(),
    extra: z.string().max(1000).nullable().optional(), matchId: uuid.nullable().optional(), gameVersion: z.string().max(80).nullable().optional(), images: imgs,
  }).parse(d))
  .handler(async ({ data, context }) => {
    const { db, notify, setting } = await S();
    const a = await db();
    const { data: me } = await a.from("players").select("id,name").eq("id", data.reporterPlayer).eq("user_id", context.userId).maybeSingle();
    if (!me) throw new Error("Piloto inválido.");
    const { data: tgt } = await a.from("players").select("id,name,user_id").eq("id", data.targetPlayer).maybeSingle();
    if (!tgt) throw new Error("Jogador denunciado não existe.");
    if (tgt.user_id === context.userId) throw new Error("Você não pode denunciar a própria conta.");
    const hourAgo = new Date(Date.now() - 3_600_000).toISOString();
    const { count } = await a.from("player_reports").select("id", { count: "exact", head: true }).eq("reporter_user", context.userId).gte("created_at", hourAgo);
    if ((count ?? 0) >= (await setting("reports")).perHour) throw new Error("Limite de denúncias por hora atingido. Tente mais tarde.");
    const { data: dup } = await a.from("player_reports").select("protocol").eq("reporter_user", context.userId).eq("target_player", tgt.id).eq("category", data.category).gte("created_at", new Date(Date.now() - 600_000).toISOString()).maybeSingle();
    if (dup) throw new Error(`Você já denunciou este jogador por isso agora há pouco (${dup.protocol}).`);
    const paths = await storeImages(`denuncias/${context.userId}`, data.images);
    const { data: rep, error } = await a.from("player_reports").insert({
      reporter_user: context.userId, reporter_player: me.id, reporter_name: me.name, target_user: tgt.user_id, target_player: tgt.id, target_name: tgt.name,
      category: data.category, description: data.description, occurred_at: data.occurredAt ?? null, location: data.location ?? null, witnesses: data.witnesses ?? null,
      extra: data.extra ?? null, session_id: sid(context.claims), match_id: data.matchId ?? null, game_version: data.gameVersion ?? null, priority: reportPriority(data.category),
    }).select("id,protocol").single();
    if (error || !rep) throw new Error("Não foi possível registrar a denúncia.");
    // evidências automáticas: mensagens recentes do denunciado (públicas ou trocadas com o denunciante), com referência ao registro original
    const { data: msgs } = await a.from("chat_messages").select("id,body,created_at,to_player,sender_player").eq("sender_player", tgt.id).or(`to_player.is.null,to_player.eq.${me.id}`).order("created_at", { ascending: false }).limit(20);
    const ev = [
      ...(msgs ?? []).map((m) => ({ report_id: rep.id, kind: "chat", source: "chat_messages", ref_id: m.id, content: { body: m.body, created_at: m.created_at, privado: !!m.to_player } })),
      ...paths.map((p) => ({ report_id: rep.id, kind: "imagem", source: "jogador", storage_path: p, added_by: context.userId })),
      { report_id: rep.id, kind: "tecnico", source: "servidor", content: { versao: data.gameVersion ?? null, sessao: sid(context.claims), partida: data.matchId ?? null, user_agent: null } },
    ];
    await a.from("report_evidence").insert(ev as never);
    await a.from("case_history").insert({ entity: "denuncia", entity_id: rep.id, actor: context.userId, actor_name: me.name, action: "criada", to_status: "recebida", internal: false, note: "Denúncia recebida" });
    await notify({ userId: context.userId, audience: "jogador", kind: "denuncia.recebida", title: `Denúncia ${rep.protocol} recebida`, refKind: "denuncia", refId: rep.id });
    await notify({ userId: null, audience: "equipe", kind: "denuncia.nova", title: `Nova denúncia ${rep.protocol}`, body: `${me.name} → ${tgt.name}`, refKind: "denuncia", refId: rep.id });
    return { protocol: rep.protocol };
  });

export const submitBug = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    playerId: uuid.nullable(), title: z.string().trim().min(4).max(120), category: z.enum(BUG_CATEGORIES), description: z.string().trim().min(10).max(3000),
    steps: z.string().max(2000).nullable().optional(), expected: z.string().max(1000).nullable().optional(), actual: z.string().max(1000).nullable().optional(),
    extra: z.string().max(1000).nullable().optional(), gameVersion: z.string().max(80).nullable().optional(),
    tech: z.object({ screen: z.string().max(40).optional(), viewport: z.string().max(40).optional(), scene: z.string().max(40).optional() }).optional(), images: imgs,
  }).parse(d))
  .handler(async ({ data, context }) => {
    const { db, notify, setting } = await S();
    const { platformOf } = await import("./rules");
    const { getRequest } = await import("@tanstack/react-start/server");
    const a = await db();
    const me = data.playerId ? (await a.from("players").select("id,name").eq("id", data.playerId).eq("user_id", context.userId).maybeSingle()).data : null;
    const hourAgo = new Date(Date.now() - 3_600_000).toISOString();
    const { count } = await a.from("bug_reports").select("id", { count: "exact", head: true }).eq("user_id", context.userId).gte("created_at", hourAgo);
    if ((count ?? 0) >= (await setting("bugs")).perHour) throw new Error("Limite de reports por hora atingido. Tente mais tarde.");
    const paths = await storeImages(`bugs/${context.userId}`, data.images);
    const ua = getRequest().headers.get("user-agent") ?? "";
    const { data: bug, error } = await a.from("bug_reports").insert({
      user_id: context.userId, player_id: me?.id ?? null, player_name: me?.name ?? null, title: data.title, category: data.category, description: data.description,
      steps: data.steps ?? null, expected: data.expected ?? null, actual: data.actual ?? null, extra: data.extra ?? null, attachments: paths,
      game_version: data.gameVersion ?? null, platform: platformOf(ua), tech: { ...(data.tech ?? {}), user_agent: ua.slice(0, 300) },
    }).select("id,protocol").single();
    if (error || !bug) throw new Error("Não foi possível registrar o report.");
    await a.from("case_history").insert({ entity: "bug", entity_id: bug.id, actor: context.userId, actor_name: me?.name ?? null, action: "criado", to_status: "recebido", internal: false, note: "Report recebido" });
    await notify({ userId: context.userId, audience: "jogador", kind: "bug.recebido", title: `Report ${bug.protocol} recebido`, refKind: "bug", refId: bug.id });
    await notify({ userId: null, audience: "equipe", kind: "bug.novo", title: `Novo bug ${bug.protocol}`, body: data.title, refKind: "bug", refId: bug.id });
    return { protocol: bug.protocol };
  });

/** Minhas denúncias e meus reports: só os próprios, sem dados internos da investigação nem do denunciado. */
export const myCases = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { db } = await S();
    const a = await db();
    const [{ data: reps }, { data: bugs }] = await Promise.all([
      a.from("player_reports").select("id,protocol,target_name,category,created_at,status,updated_at,public_result").eq("reporter_user", context.userId).order("created_at", { ascending: false }).limit(100),
      a.from("bug_reports").select("id,protocol,title,category,created_at,status,updated_at,resolved_at,response").eq("user_id", context.userId).order("created_at", { ascending: false }).limit(100),
    ]);
    const ids = [...(reps ?? []).map((r) => r.id), ...(bugs ?? []).map((b) => b.id)];
    const { data: hist } = ids.length ? await a.from("case_history").select("entity_id,action,to_status,note,created_at").in("entity_id", ids).eq("internal", false).order("created_at") : { data: [] };
    const h = (id: string) => (hist ?? []).filter((x) => x.entity_id === id).map(({ entity_id: _e, ...r }) => r);
    return {
      reports: (reps ?? []).map((r) => ({ ...r, history: h(r.id) })),
      bugs: (bugs ?? []).map((b) => ({ ...b, history: h(b.id) })),
    };
  });
