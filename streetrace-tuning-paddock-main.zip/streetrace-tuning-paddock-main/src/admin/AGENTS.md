# Admin center

- Admin center (/administracao, src/admin): every admin server function checks staff permissions server-side via staff_members/has_perm; private admin tables are service-role only; chat inserts go only through the moderated sendChat server function; ended sessions are enforced in src/start.ts via account_security.sessions_revoked_at. Why: no admin action or chat write may bypass server checks.

- Admin panel is open without login on every host, including published (src/admin/open-admin.ts openAdmin middleware, fixed OPEN_ADMIN_ID actor). Why: owner explicitly accepted the risk and wants an account-independent panel for now.

- Staff roles are granted only through adminSetStaff in the panel (no self-claim/bootstrap endpoint; user_roles and staff_members have no client write path). Why: no player may obtain moderation powers on their own.

- IP blocks (blocked_ips) and automatic abuse flags (abuse_flags) are service-role only; detection runs in admin.server detectAbuse after recordAccess with thresholds in rules.abuseVerdict, and blocks are enforced in token generation/login and the start.ts bearer middleware (Central requests exempt). Why: abuse checks must be server-side and the admin must never lock themselves out.

- Severity-4 chat terms ban permanently on the first offense (rules.LADDER_EXTREME) and the client StandingGate re-checks instantly on the anticheat:ban event. Why: zero tolerance for racism, death threats and nazism.
- Chat filter matching (rules.matchFilter): terms up to SHORT_TERM letters match only as whole words (plus plural/diminutive suffixes), longer terms match anywhere in the normalized text; punishment length comes from ladderStep by word severity 1–4. The base word list lives in src/admin/chat-terms.ts and is checked against street/tuning slang in chat-filter.test.ts. Why: block real slurs without blocking words like transmissão, curva or enviado.
