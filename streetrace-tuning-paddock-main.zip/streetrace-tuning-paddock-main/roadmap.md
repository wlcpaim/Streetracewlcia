# Roadmap

## Vácuo e margem das motos (17/11)
- [x] Reduzir janela do vácuo para 3,5 m; 42 testes passaram
- [x] Centralizar motos e remover limite indevido de largura; pés conferidos em corrida local no celular e computador (sem sessão da conta)

## Edição de textos das peças (16/11)
- [x] Peças categorizadas com nome, chave do piloto, inventário e descrição, lápis por item
- [x] Menu Edições: prompt para o chat, apagar item por item, baixar MD/TXT/JSON

## Reorganização do STARTGAME (16/11)
- [x] Inventário dos sistemas existentes e reorganização em /startgame com 13 menus ligados a eles
- [x] Corrigido teste de peças liberadas desatualizado
- [ ] Velocidade final diverge: Corridas (reta curta) 150–159 km/h x Laboratório (3000 m) 172–177 km/h — falta decidir qual pista é a referência

## Laboratório de Kits (16/11, 01:02)
- [x] Teste cruzado de ponta a ponta dos 12 kits (usinagem, biela, mistura, molas, quebra, stress, desempenho)
- [x] Kits refeitos para não quebrar: 0 reprovados, 6 aprovados, 6 com atenção; 21 testes passaram
- [x] Aba Laboratório de Kits no NEXUS Start Game com relatório e TXT (conferida no navegador)
- [x] Remix: atualizar PYTHON_WORKER_TOKEN pelo formulário seguro
- [ ] Faltas com motor seguro: Bolinha 18,5/19,8/20,4 cv, Factor S3 23,6 cv, Titans S3 172–177 km/h — aguardando decisão do usuário

## Válvulas e card da corrida (15/11, 06:43)
- [x] Kits de válvula: nível 1 kit 4MM, nível 2 300–400cc, nível 3 Força Livre
- [x] Oficina › Válvulas: assentamento de válvula que ajuda a não atropelar
- [x] Botão SAIR da arte nova no lugar de Abandonar no card da corrida, compacto

## Reparo e montagem original (15/11, 06:23)
- [x] Refazer motor conserva todas as usinagens e gravações, reparando o conjunto como estava
- [x] Montagem original limpa as gravações; peças aproveitáveis vão a Peças e as inutilizáveis viram sucata
- [x] Kit de válvula montado mantém acesso em Montagem para voltar ao original
- [x] 50 testes passaram, incluindo a opção visível de remoção e a ausência de duplicatas

## Fluidez do dinamômetro (15/11, 06:08)
- [x] Dividir simulações e auditorias em blocos curtos sem alterar passos físicos
- [x] Evitar cálculos repetidos durante a animação, reduzir custo visual e cancelar trabalho ao sair
- [x] Puxada real conferida: quadros acima de 50 ms caíram de 39 para 10; resultados iguais; ainda há pausas nas análises externas ao dinamômetro

## Montagem original e curso (15/11, 05:59)
- [x] Limpar gravações e preparação das peças na montagem original, sem duplicar estoque
- [x] Mostrar curso aplicado e curso total do virabrequim na Oficina
- [x] 18 testes passaram; curso original e total conferidos na Oficina com sessão real; conserto validado por teste, sem gastar saldo da conta

## Fadiga da biela, NEXUS e garagem (15/11, 02:29)
- [x] Conferir no código e testar 11.000–12.500 rpm com pistão STD e 4MM (fadiga real no mechStep)
- [x] Uma falha física = um registro no NEXUS (fim dos 200 repetidos); teste passou
- [x] Explicar a diferença de folga das válvulas entre as duas passadas
- [x] Pneu comprado aparece no Fuçar; menu não fecha mais ao equipar (não conferido na tela: sem conta de teste)
- [x] Remix: atualizar PYTHON_WORKER_TOKEN pelo formulário seguro

## Pistão e remix (14/11, 11:33)
- [x] Taxa no pistão 1/2/3/4 mm e cava das válvulas 0,5/1,0/1,5/2,0 mm; 5 testes passaram
- [x] Remix: atualizar PYTHON_WORKER_TOKEN pelo formulário seguro
- [x] Remix: migrações conferidas, conjunto vazio, banco preservado

## Mecânico STARTGAME e giclês (14/11, 09:34)
- [x] Restringir conselhos ao STARTGAME e bloquear preparação automática/usinagem não liberada; cinco testes e chat autenticado conferidos
- [x] Disponibilizar Giclê 123 de alta e Giclê 49 de baixa na Auto Peças sem mudar a fórmula de mistura
- [x] Catálogo conferido com sessão real nas duas categorias; montagem verificada por teste, 19 testes passaram

## Oficina — indicadores e organização (14/11, 09:25)
- [x] Reservar Bomba ao risco extremo; mostrar os demais estados do motor sem alterar risco físico
- [x] Organizar Montagem, Preparação, Diagnóstico e Dinamômetro com as imagens enviadas
- [x] Conferir abertura dos três menus com sessão real, computador e celular; 14 testes passaram, sem erros na tela

## Otimização dos travamentos (14/11, 06:15)
- [x] Remover cálculos e gravações repetidos sem mudar física, aderência ou progressão
- [x] Movimento da pista por transformação; tela até 30 atualizações/s, passos físicos intactos; teste local 917 → 473 renderizações em 16 s
- [x] 26 testes passaram; corrida local de quatro motos até relatório final, sem erros; nenhuma alteração no banco
- [x] Conferir fluidez com a conta do solicitante — sessão indisponível; precisa entrar na prévia

## Compatibilidade das peças (14/11, 06:13)
- [x] Usar a mesma tela do preload na análise de equipar, mantendo os 2,5 s e a recusa de peças incompatíveis
- [x] 3 testes existentes passaram; tela compartilhada conferida no celular em teste isolado, instalação só após análise (fluxo com conta não verificado)

## Acerto motor e pneus + remix (14/11, 05:20)
- [x] Cortes de giro de 10.000 rpm, conferir velocidades por relação original sem impor teto em km/h
- [x] Esclarecimento: preservar potência original; faixas aproximadas de referência cinemática, velocidade alcançada pelo equilíbrio de forças sem corte forçado
- [x] Mandrakin 40/100; largura estimada, peso e temperaturas de superfície/interna conectados à física
- [x] 82 testes selecionados e comparação antes/depois, sem alterar asfalto nem apagar dados; relatório auditoria/acerto-motor-pneus-2026-11-14.md
- [x] Conferir temperaturas durante corrida na tela — sessão indisponível para conta do solicitante; precisa entrar na prévia
- [x] Atualizar PYTHON_WORKER_TOKEN pelo formulário seguro
- [x] Conferir migrações do remix; conjunto já vazio, banco preservado

## Pneu Pirelli 50/100 + remix (14/11)
- [x] Pneu original 50/100, piloto dosa aos 2,5 s, patinagem 4–5 s a 40 psi, murchar ajuda largada e amarra em alta
- [x] 5 testes antigos de largada esperam o comportamento anterior (piloto mais pesado, troca rápida, roda aderida aos 6 s, giro suave, pneu cheio) — aguardando autorização para atualizar
- [x] Remix: atualizar PYTHON_WORKER_TOKEN (formulário seguro)
- [x] Remix: migrações copiadas limpas, conjunto vazio

## Remix (13/11, 4º pedido)
- [x] Atualizar PYTHON_WORKER_TOKEN (formulário seguro)
- [x] Migrações: conjunto vazio; banco desta cópia já tem a estrutura da Administração

## Remix (13/11, 3º pedido)
- [x] Atualizar PYTHON_WORKER_TOKEN (formulário seguro)
- [x] Migrações: só existem as 2 criadas neste projeto (Central de Administração), nada copiado a limpar

## Central de Administração (13/11)
- [x] Banco: equipe, punições, acessos/IP, filtro do chat, denúncias, bugs, investigações, notificações, auditoria, configurações
- [x] Servidor: chat moderado, denúncia, bug, minha situação, funções da equipe
- [x] Tela /administracao com 18 seções
- [x] Jogo: Denunciar jogador, Suporte (bug, meus reports, minhas denúncias, notificações), bloqueio de conta
- [x] Testes das regras
- [x] Você assumir o cargo de Superadministrador (botão em /administracao, só no ambiente de teste)

## Remix (13/11, 2º pedido)
- [x] Atualizar PYTHON_WORKER_TOKEN de novo (formulário seguro)
- [x] Migrações: conjunto já vazio, nada a limpar

## Nexus — reconstrução Top-Down dos dados pendentes (13/11)
- [x] Carburador: lenta e plena carga reconstruídas por inversão (CG 150 e Bolinha)
- [x] Carburador: meia abertura e progressão não fecham — falta modelo dos furos de progressão e perfil da agulha por posição (ou medidas reais)
- [x] Verificação automática de completude (oficial / equivalente / calculado / estimado / sem dado)
- [x] Chassi (caster, trail, entre-eixos, curso de suspensão, freios) sem dado — não afeta motor

## Remix (13/11)
- [x] PYTHON_WORKER_TOKEN atualizado pelo usuário (worker precisa do mesmo valor)
- [x] Migrações copiadas limpas: conjunto vazio pronto para o banco novo

## Dinamômetro AGR + relação (13/11)
- [x] Kit relação abre em pinhão e coroa soltos; original volta ao Fuçar
- [x] Controles + e − nos módulos, menus por categoria, scroll
- [x] Bateria AGR automática em todas as pistas + relatório
- [x] Mapas salvos (abrir, usar, duplicar, renomear, excluir) e comparação

## Afinando motor — pedido atual
- [x] Verificação inicial sem lista de arquivos
- [x] Gerar token sem e-mail/senha, entrada automática e expiração em 24 horas (entrada e bloqueio conferidos)
- [x] Curva de sobregiro por arquitetura e auditoria das quatro motos; parâmetros estimados documentados

## Migração para este projeto (2ª migração, 12/11)
- [x] Código, 93 imagens/músicas, banco reconstruído, login e mecânico IA conferidos neste projeto
- [x] 2 testes de balanceamento já falhavam no código original (Fácil mais rápido em toda pista; preparador 170 km/h) — aguardando decisão do usuário
- [x] Código, imagens, músicas, banco e login trazidos e conferidos
- [x] Importar dados antigos (jogadores, saves, amizades, ranking) — aguardando exportação do usuário
- [x] Importar contas antigas (e-mail, id original, papéis) — aguardando exportação do usuário
- [x] PYTHON_WORKER_TOKEN salvo; worker conectou e consultou a fila no projeto novo
- [x] Publicar e apontar o worker Python para o novo endereço — aguardando o usuário

## Token, preload e salas online
- [x] Anticheat detecta versão nova do servidor e atualiza sozinho pelo preload (fora da corrida)
- [x] Gerar token direto na tela de entrada, sem e-mail ou senha; validade de 24 horas
- [x] RealGear Anticheat: 4 s só na primeira carga da sessão
- [x] Preload mostra somente verificação do sistema; corrida carrega poses das 4 motos internamente
- [x] Sala por partida online: largada 5 s após os dois confirmarem

## Beta (atual)
- [x] Liderança abaixo de Recordes no HUD, mesmo visual
- [x] Online: corrida só vale com os dois carregados; falha cancela e mostra o nome
- [x] Calibração do matchmaking escondida
- [x] Card do Jogador (sem peso/altura, moto ativa, carreira, abas Card/Social/Entregas/Áudio)
- [x] Oficina em tela cheia por categorias
- [x] Polimento visual dos menus: moldura única (Auto Peças tela cheia, Oficina, Banco, Card, Posto, Correr, Online, trabalhos, Fuçar)
- [x] Conferir os menus no navegador: precisa de uma conta de teste do jogo

## Concluído (StressCheck + Zayma + remix)
- [x] Remix: PYTHON_WORKER_TOKEN atualizado; migrações copiadas já estavam vazias
- [x] StressChecker: monitor em tempo real (corrida, dino, diagnóstico), verificações cruzadas, anomalias com diagnóstico, painel e histórico salvo
- [x] Pistão 70 mm pino 15 = Zayma (não forjado, 12:1, 174 g, folga 0,04) com descrição completa
- [x] Pistões e bielas mostram o Ø do pino e as peças compatíveis

## Auto Peças
- [x] Cenário fixo único na Auto Peças
- [x] Foto de cada moto no menu de peças originais dela

## Pedido grande pendente
- [x] Sistema de carburadores (catálogo, física de venturi, regulagem na oficina, Scanner) — próxima etapa
- [x] Scanner limpo nos motores originais (marchas Titan 160/Factor aguardam aprovação; CG 150 e CG 125 sem relações de câmbio de fábrica)

## Decisão do usuário
- [x] Velocidade por marcha do jogo está 12–18% acima das relações do manual (Titan 5ª 142 × 120,5 km/h): corrigir muda tempos e adversários — aguardando aprovação

## Concluído nesta rodada
- [x] Física da largada: torque real da 1ª marcha, embreagem patina até acoplar (volante desacelera), pneu destraciona/empina; Fácil 402 m recalibrado (embreagem de discos, 14x46, 28 psi); 535/535 testes
- [x] Oficina: chave (EquippedPanel) removida da tela; Preparação = só usinagem/torno (seções completas); Montagem = peças/kits detectados do estoque (inclui emb-esportivo); tutorial aponta para Montagem
- [x] Fuçar (garagem): aba Fuçar lista escape e módulo do estoque (sem originais, sem peças montadas); essas peças deixaram de ser "só oficina"
- [x] Cérebro do mecânico: prompt expandido (cérebro/IA do jogo, física da largada) + mais fatos reais (marchas, giro de largada, capacidade da embreagem, tração/empinada, estoque, dinheiro)
- [x] Remix: PYTHON_WORKER_TOKEN atualizado pelo formulário seguro; migrações Drizzle já estavam limpas e consistentes

## Concluído (preparador + remix)
- [x] Preparador: módulo Athlon com ponto calculado, puxada no dinamômetro antes da entrega, entrega "MOTOR AFINADO 100%"
- [x] Preparador: usar todos os serviços (cavas, curso, cabeçote...), pneus para não patinar e embreagens
- [x] Loja: remover "Kit 4MM completo" pronto; 4MM só peça por peça
- [x] Remix: atualizar PYTHON_WORKER_TOKEN e conferir/limpar migrações copiadas

## Conhecido / pendente
- [x] Verificação visual da Oficina/Fuçar no navegador (login de teste já funciona; mapa e missões conferidos na migração)
- [x] Lembrete: colocar a mesma chave nova no worker Python (PYTHON_WORKER_TOKEN)

- [x] Remix: PYTHON_WORKER_TOKEN salvo pelo formulário seguro (12/11)
- [x] Remix: migrações limpas conferidas; tabelas de MMR já estão no banco novo
- [x] MMR Elo por categoria, histórico sem duplicar partidas, 11 testes
- [x] MMR na tela do 1x1

## Rodada "Atualizar geral" (pedido de 11/11)
- [x] Logo RealGear discreta na landing
- [x] Loja: categorias Motor / Cabeçote / Alimentação / Escape / Elétrica / Transmissão
- [x] Preparação gravada na peça (todas as peças, como o curso do virabrequim); troca de biela não apaga serviços do virabrequim
- [x] Montagem estilo craft: receitas detectadas com o que falta
- [x] Menu Preparação em categorias (grade igual à loja)
- [x] Pinos/encaixes: montagem bloqueia conjunto desconhecido; Kit 4MM valida o conjunto inteiro
- [x] Padronização de nomes/marcas do catálogo
- [x] Multiplayer 1x1 com fila por MMR e corrida calculada no servidor
- [x] Decisão do usuário: kits 205/220 cc usam cilindrada fixa; pela geometria (Ø × curso) dariam outra potência — muda os rivais Médio/Difícil
- [x] Pendente: save do jogador ainda é gravado pelo próprio navegador; dinheiro e peças não têm autoridade do servidor (antitrapaça completa do prompt RealGear)
- [x] Pendente: Categoria e Força Livre no multiplayer
- [x] Corrida visual online 1x1 com preload nos dois jogadores
- [x] Largada sincronizada pelo relógio do servidor

## COMPLEGAME / STARTGAME
- [x] Registro de disponibilidade (Titan, Factor, Dore, Polimet, Servitec)
- [x] Oficina sem serviços/montagem no jogo oficial; tutorial aponta pro Fuçar
- [x] Servitec com limitador configurável em AJUSTES
- [x] Mecânico IA limitado ao catálogo oficial
- [x] Validação no servidor de compras/inventário — bloqueado: o save do jogo ainda é local no aparelho (precisa mover economia pro servidor)
- [x] Auditoria geral de física/multiplayer/economia (próximas etapas)

## Servidor autoritativo
- [x] Save do piloto gravado só pelo servidor, com checagem de saldo, motos e peças
- [x] Mover cada ação (compra, corrida, entrega, conserto) para cálculo 100% no servidor
- [x] CG 150 Titan ESD e CG 125 Bolinha no jogo oficial com motores próprios e 4 poses

- [x] Bololo offline (Pega de rua menu): 4 motos distintas, 4 milhas
- [x] Evento Bololo online (LINE) — aguardando definição

## Rodada sprites/faixas + remix (12/11)
- [x] Motos com o mesmo tamanho em todas as faixas; troca de faixa só desloca 6% no asfalto (teste race-lanes)
- [x] Remix: migrações Drizzle copiadas limpas e conjunto vazio conferido; banco novo com as tabelas do jogo
- [x] Save na nuvem resetava (relação de fábrica recusada pelo servidor)
- [x] Posto: motos não-flex só gasolina
- [x] Factor mais fraca no álcool (tanque misto em flex)
- [x] Texto de confirmação de e-mail
- [x] Loja: cenário novo, motos pelos sprites, sem ficha técnica
- [x] STARTGAME: liberar todas as relações (pinhão/coroa avulsos)
- [x] Scanner OEM: relações de marcha do jogo divergem ~11% da ficha (Titan 160, Factor) — corrigir muda tempos de corrida, aguarda aprovação
- [x] Scanner OEM: CG 150 ESD sem relações de câmbio/pneu cadastrados; CG 125 sem limite de mola próprio (usa 10.300 rpm genérico)

## Engenharia multimodelo (12/11)
- [x] Ficha técnica própria por moto (motor, alimentação, ignição, elétrica, chassi, suspensão, rodas, freios, câmbio) com origem dos dados
- [x] Matriz de compatibilidade por moto (OEM, direto, adaptação, incompatível, não comprovado) na Auto Peças
- [x] Scanner sem alertas de injeção em moto carburada
- [x] Nexus: relatório de acerto OEM por moto
- [x] Remix: conferir migrações do banco limpas e conjunto vazio (21 tabelas, histórico consistente)
- [x] Relações de câmbio de fábrica da CG 150 ESD e da Bolinha 4 marchas — aguardam manual
- [x] Câmbio do jogo da CG 160 (5ª +18%) e Factor (1ª +15%) diverge do manual — aguarda aprovação para mudar tempos
- [x] Cáster, trail, curso de suspensão e freios da CG 160 e Factor — aguardam ficha
- [x] Acerto real de motores: relação final de fábrica por moto (Factor 14/39, CG 150 16/43, Bolinha 15/38, CG 160 15/44)
- [x] Token de acesso: gerar no menu da conta, entrar com token, bloqueio após 5 erros (falta testar entrada com conta real)
- [x] Ordem de dificuldade em pistas longas mudou com a relação real (teste facil-track) — dificuldade fora do escopo desta operação
- [x] Preparador 170 km/h na CG 160 — falta decidir pinhão 18T / coroa 34T na loja

## NEXUS — rodada CAIM-3 + Parts Intelligence
- [x] CG 150: VE própria de cada moto pela energia; falha de pressão resolvida sem mexer em potência/critério
- [x] Varredura marcha lenta → corte no CAIM (torque da corrida × ficha, VE exigida)
- [x] Curva de potência da corrida abaixo do pico passa o torque de ficha nas 4 motos — corrigir muda tempos: aguardando aprovação do usuário
- [x] Base NEXUS Parts Intelligence (fabricantes, peças, medidas, aplicações, compatibilidades) + painel + mecânico da bancada lendo a base
- [x] Cadastrar peças reais com fonte — aguardando fontes/decisão do usuário (base criada vazia)

## Rodada calibração (12/11 noite)
- [x] Registro de calibração por sprite (eixos, solo, bounds) usado por jogador e adversários
- [x] Física real da calibragem: pressão recomendada por moto, rolagem com velocidade/histerese, aderência por pressão de contato, carcaça progressiva, calor da deformação
- [x] Remix: atualizar segredo PYTHON_WORKER_TOKEN
- [x] Remix: migrações limpas e conjunto vazio conferido no banco novo

## Rodada garagem (13/11)
- [x] Saldo inicial R$ 100.000
- [x] Garagem com até 5 motos, troca de moto e venda à concessionária por 80%
- [x] Largada da Bolinha sem limitador (giro segurando entre 8.900–8.950 rpm)

- [x] Degraus leves entre faixas (4% por faixa) mantendo motos alinhadas e mesmo tamanho
- [x] Largada 1x1: anticolisão e trava de largada ativas, folga entre eixos 3 m

- [x] Remover neon dos eixos na corrida
- [x] Abandonar corrida com confirmação (-10% do XP máximo, pode cair de nível)

## Reengenharia física + perfis (13/11)
- [x] Perfil novo = conta própria com token fixo sem expiração (falta testar criação real no jogo)
- [x] Cada moto só com o próprio pinhão/coroa montado; jogo novo sem relação solta no estoque
- [x] Curva de torque da ficha por moto (P = T·ω), sem piso de 35% em baixa
- [x] Massa equivalente com inércia das rodas e do virabrequim (fim do ×1,06 fixo); volante 0,05 → 0,009 kg·m² (valor antigo contrariava a própria fonte)
- [x] CG por moto com piloto e combustível (entre-eixos da ficha) na largada/empinada
- [x] Roda traseira patinando com velocidade própria (giro não despenca na largada)
- [x] Amaciamento sem ganho acima da ficha
- [x] Massa peça a peça (pistão, biela, virabrequim, molas), suspensão e freios na corrida — aguardam dados medidos
- [x] Capacidade da embreagem original (22 N·m, ESTIMADO): com o torque corrigido os kits 4MM/190/220 não passam dela — aguarda dado real ou decisão

## Rodada perfis/som/login (13/11)
- [x] Perfis não podem mais ser excluídos
- [x] Som sem estouro/distorção; escape original com timbre próprio por moto
- [x] Preload fica na tela durante login/token/troca de perfil (sem piscar a landing)

## Rodada chat/preços/Bololo (13/11)
- [x] Preços fixos, sem taxa de balcão (peças e combustível)
- [x] Resultado da corrida compacto; Bololo mostra classificação dos 4
- [x] Bololo: posições ao vivo trocando a cada ultrapassagem
- [x] Botão Chat em cima de Missões (garagem e mapa): servidor + mensagens privadas
- [x] Casual/Competitivo separados, Bololo '4 motos', Etanol→Álcool

## Rodada escala Bolinha (13/11)
- [x] Sprite da Bolinha 13% menor (BIKE_SCALE cg125 = 0,87), pneu continua na linha da faixa
- [x] Chat de volta acima de Missões, fundo mais escuro, conversa privada não some
- [x] Oficina: Scanner/Dinamômetro no rodapé, bancada menor, mecânico fala como mecânico
- [x] Menus: Pega de rua mesmo tamanho, Online sem descrição, Competição "Ranqueado"
- [x] Amaciamento: Motor novo/Amaciando/Amaciado, até +3% potência, zera ao refazer motor
- [x] Perfis em cards (ativo na frente), máximo 1 secundário
- [x] Recorte manual da foto de perfil
- [x] Cards Online (Fama por winrate) e Competição (Pontos por faixa), abandono conta como derrota
- [x] Remix: atualizar PYTHON_WORKER_TOKEN e conferir migrações do banco novo
- [x] Indicador de mensagens privadas não lidas no botão do Chat, igual ao de Missões
- [x] Card único da corrida (posições, rpm/marcha/km/h, pista, combustível, scanner, alertas, vácuo, abandonar)

- [x] Online/Competição: escolher categoria (200cc, 300cc, Força Livre) antes da pista; fila só junta a mesma categoria
- [x] Corrida: card próprio de giro/marcha/velocidade com medidor; tempo fora da lista de pilotos
- [x] Preload: tempo base de 5 s em toda tela, espera mais se faltar algo
- [x] Remix: atualizar PYTHON_WORKER_TOKEN
- [x] Remix: conferir migrações vazias no banco novo
- [x] Física: motos originais/afinadas param no pico de força (Titan ~135 deitado), velocidades por marcha da ficha do jogador
- [x] Corrida: alertas (pneu, embreagem...) sem card, embaixo do scanner
- [x] Calibrar pneu sem psi recomendado; todas as motos saem da loja com 40 psi
- [x] Preload base 2,5 s, verifica sistema (sprites, anticheat) sem bugs
- [x] Mecânico/NEXUS reconhece platinado, CDI e ECU; bolinha da mistura lê excesso por faixa
- [x] Regra: contas de teste nunca são apagadas (README)
- [x] Sprite da Factor 150 +10% (BIKE_SCALE factor150 1.1)
- [x] Calibração dos circuitos do carburador (CG 150/Bolinha) no laboratório CAIM — bloqueado: falta medida de fábrica do pulverizador, agulha e Cd
- [x] Auditoria dimensional peça a peça (144 peças) por moto — aguardando prioridade do jogador

## Garagem, loja, liderança e mecânico (13/11)
- [x] Relações de fábrica não duplicam ao comprar motos; loja bloqueia relação já no estoque
- [x] Fuçar e Moto Peças mostram só peças compatíveis com a moto montada (menus ficam, só vazios)
- [x] Liderança só online, sem mês na temporada; menu Recordes removido; Bololo = pista 4 milhas
- [x] Categorias 200/300/400cc/Força Livre dentro de Online e Competição; sem trava de nível
- [x] Filtro por categoria dentro da tabela de Liderança — partidas antigas não guardam a categoria
- [x] RPM na garagem/loja (exibição): Titan 160 9500, CG 150 9000, Factor 9500, Bolinha 9000
- [x] Mecânico chama pelo nome e só fala do jogo oficial
- [x] Auto Peças: velas D8ES-L + CPR8EA-9, giclês alta/lenta, juntas Keihin 125/150, mangueira e filtro etanol

## Pacote 14/11 (loja, corrida, menus)
- [x] CDI esportivo · Servitec + rpm; velas "NGK - Grau térmico 8"; estoque ilimitado; giclê/junta/mangueira/filtro linha única
- [x] Scanner da corrida: temperatura do motor no lugar do pneu
- [x] Categorias 200 (até 299), 300 (até 399), Força Livre; sem 400; "Competição"
- [x] Bololo: só "Bololo", descrição em metros; fora da Competição; no Líder abre 200/300/FL
- [x] Dificuldades sem moto; menus de corrida e rodapé online/competição sem descrição
- [x] Chave: medidas das peças; Motor na loja com Cabeçote/Cilindro/Pistão/Biela/Virabrequim
- [x] Suporte fixo sem scroll; chat e missões mais modernos
- [ ] Remix: chave PYTHON_WORKER_TOKEN (formulário recusado — aguardando usuário); migrações vazias ✔

## Mecânico de rua (lançamento)
- [x] Mecânico fala no chat da oficina a cada serviço
- [x] Dinamômetro registra a dica no chat sem flood
- [x] Sem fórmulas, sem NEXUS/auditoria; vocabulário de rua (gorda/magra, pega, bololo)
- [x] Botões da oficina sem PNG, estilo da garagem; dinamômetro em destaque
- [x] Scanner/monitor com textos para o jogador
- [x] Oficina: menus verticais no rodapé esquerdo, Montar vazio, dino embaixo; bancada mostra cc/taxa/cv/bomba

- [x] Montagem categorizada (Alimentação › Passar pro álcool) e escapes Dore/Polimet sem descrição
- [x] Comandos montados só na Oficina › Montagem (lista do estoque + Montar)
- [x] Giclês no Fuçar (Giclê alta / Giclê baixa só quando tiver), troca com a moto no álcool
- [x] Menus da Oficina sem faixa preta, sem texto, fora do rodapé; Preparação só Pistão e Cabeçote
- [x] Chave da Bolinha: Platinado, sem limitador (corte "Livre"); escapes sem descrição
- [x] Montar original / consertar e montar original liberam a usinagem de novo (taxa de fábrica de cada moto)
- [x] Medidas padronizadas (rebaixo, solda, cava, curso): 0,3 0,6 0,9 1,2 1,5 1,8 2,1 2,4 2,7 3,0 4,0 5,0 6,0 mm
- [x] Chave: medida do pistão (Ø) na linha do pistão
- [x] Titan 160/150/Factor corte 9.000 e biela original 9.500; Bolinha sem corte e biela 10.000
- [x] 12 comandos em 3 grupos (Baixa/MB/MA/Alta, levante 5,8–8,0) no lugar dos 4 antigos
- [x] 12 escapes de rua no lugar de Dore/Polimet (antigos só saíram da loja)
- [x] Giclê universal: troca no Fuçar sem álcool, gasta 1 kit de juntas; passar pro álcool na garagem sem mão de obra
- [ ] Bolinha sem corte: dinamômetro e entregas varrem até 13.000 rpm e quebram a biela (aguardando autorização)
- [x] Bielas originais: Titan 160/150 e Factor 10.000 rpm, Bolinha 11.000 rpm
- [x] Standard liberado no jogo oficial
- [x] Atualizar o segredo PYTHON_WORKER_TOKEN
- [ ] Fluidez dos menus (investigar travamento)

- [x] Pistões KMP 4MM, Biela Ferzza 11.200 rpm, limpar cilindro/virabrequim, STD só no Standard
- [x] Atualizar secret PYTHON_WORKER_TOKEN (remix)
- [x] Biela: limite = inércia no giro de referência (Bolinha orig 11.000, Titan/Factor 9.500, WW3/TXK 10.500, Ferzza 11.500)
- [x] Remover Scanner do Diagnóstico/STARTGAME; Diagnóstico = conserto + óleo/pneu

- [x] Fuçar: após equipar e análise do Anticheat, voltar ao menu principal sem submenus abertos

## Kits Preparado e Start Check (15/11, 21:15)
- [x] Menu Kits Preparado com a arte enviada; Kit 4mm › moto › Stage 1/2/3 escolhidos pela física, comprar = instalar na hora
- [x] Kit 3mm, Turbo e Competição aparecem desativados
- [x] Pistões 4MM com anéis RIK (menos risco de quebra de anel)
- [x] Mecânico responde simples com alerta (seguro/atenção/risco) e letra maior
- [x] Card principal 'Mecânicas do jogo' contendo Piloto/Vento/Moto/Pista
- [x] Update PYTHON_WORKER_TOKEN secret (user enters value)
