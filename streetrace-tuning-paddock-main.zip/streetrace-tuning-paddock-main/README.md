# Welcome to your Lovable project

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Open your project in the [Lovable editor](https://lovable.dev) and keep building.

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: connect the project to GitHub and every change made in Lovable is committed straight to your repository.
- **Full ownership**: this code is yours. Push to your repository and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Built with

- TanStack Start
- TypeScript
- React
- Tailwind CSS

## Worker Python RealGear (documentação mestre)

Consulte esta seção antes de qualquer remix ou manutenção. Não gere chave nova, não crie outro worker e não mude esta configuração se a tarefa não depender dele.

| Item | Valor |
| --- | --- |
| Nome | RealGear Python Worker |
| Identificador | `python/realgear/worker.py` · worker id padrão `py-investigator-1` |
| Finalidade | Auditoria cruzada (cinemática, materiais, investigador do Fix Center) dos jobs gerados pelo jogo; respostas só são registradas, nunca alteram Setup ou física |
| Endpoint | `POST /api/public/python-jobs` no app publicado |
| Chave de autenticação | `PYTHON_WORKER_TOKEN` — variável secreta configurada no ambiente (Secrets do app e ambiente do worker, mesmo valor) |
| Contrato | saída `realgear.bridge/1.0.0`, resposta `realgear.response/1.0.0`, unidades SI em `python/realgear/contract_v1.json` |
| Dados | tabelas `python_jobs`, `cross_audits`, `service_heartbeats` e afins; só o servidor escreve; runs idempotentes por run key |

**Inicialização:** `python -m realgear.worker <URL do app publicado> "$PYTHON_WORKER_TOKEN"` (dentro de `python/`; opções `--worker-id`, `--intervalo`, `--uma-vez`). O worker envia heartbeat e busca jobs na fila.

**Manutenção:** em remix, apenas reconfigure o valor de `PYTHON_WORKER_TOKEN` (se o remix pedir) e copie o mesmo valor para o worker. Nunca publique o valor real da chave em arquivos, logs ou no frontend. Atualize esta seção somente quando a configuração mudar de fato.

## PYTHON WORKER — CONFIGURAÇÃO DE AUTENTICAÇÃO

- Nome da variável: `PYTHON_WORKER_TOKEN`
- Serviço: `realgear-worker` (`python/realgear/worker.py`)
- Finalidade: autenticação entre a aplicação (`POST /api/public/python-jobs`) e o Worker Python.
- A chave permanece nos Secrets do ambiente de execução (app e worker, mesmo valor) e é lida só no backend.
- Não gerar outra chave durante remixes; não solicitar novamente uma chave já configurada.
- Não armazenar o valor no código-fonte, em logs ou no frontend; não criar variáveis com outro nome.
- Não apagar essa configuração durante atualizações.
- Se a variável estiver ausente, a API responde 503 com aviso técnico e nada mais do jogo é afetado; com token errado, 401.

## REGRA MUITO IMPORTANTE — contas nunca são apagadas

- Nenhuma conta (de jogador ou de teste) é apagada do banco: nem em lote, nem por janela de tempo, nem para "limpar testes".
- Toda conta de teste criada permanece e é reutilizada nos testes seguintes; nunca criar e apagar contas a cada teste.
- Proibido `delete from auth.users`, apagar `players`, `game_saves` ou progresso de qualquer conta. Isso já apagou pilotos reais com progresso.
- Se uma conta precisar sair, só o dono pede, e por id conhecido, nunca por filtro.
