# Auditoria de sobregiro

`auditAllTopSpeed()` usa a própria `physics.step()` em reta de 3 km, tanque cheio, DT fixo. Resultado desta rodada:

| Moto cadastrada | Velocidade (km/h) | Estado |
|---|---:|---|
| CG 160 Titan | 120,5 | APROVADO |
| Yamaha Factor 150 | 119,5 | APROVADO |
| CG 150 Titan ESD | 120,8 | APROVADO |
| CG 125 Bolinha | 105,4 | APROVADO |

Bolinha: 9.918 rpm no final, sem corte eletrônico ou trava por km/h. A velocidade resulta da força de roda menos arrasto e rolamento, com eficiência de transmissão já aplicada.

Até o pico, a expressão anterior permanece exatamente igual, inclusive o piso de baixa rotação; potência e torque cadastrados não foram alterados. Acima do pico não existe piso mínimo permanente. OHV usa queda contínua de fluxo e energia relativa da centelha do circuito de platinado já existente; OHC/SOHC usa queda pós-pico sem piso e perda suave acima da referência de flutuação. Todos os consumidores de desempenho passam moto/setup.

## Limites de validade

O documento chama a Yamaha de YBR 125, mas o jogo tem **Factor 150 BlueFlex com ECU**. Não foi convertida para CDI/carburador nem renomeada. Os cortes presentes são 9.000 rpm (Titan 160 e CG 150) e 8.800 rpm (Factor), não os números citados no documento.

A largura da queda OHV é hipótese fenomenológica, **não curva medida nem certificação de fidelidade estrita**. A resistência/indutância/dwell do platinado também são hipóteses existentes. Os parâmetros e incertezas estão no registry. FMEP não foi somado novamente à potência líquida de ficha para evitar dupla contagem; não se reivindica modelo completo de atrito em sobregiro.

Testes: faixa 100–106 km/h da Bolinha, ausência de corte por velocidade, aprovação das quatro motos, igualdade exata da curva anterior em 1.000 rpm → pico e desaparecimento do piso em rotação extrema.