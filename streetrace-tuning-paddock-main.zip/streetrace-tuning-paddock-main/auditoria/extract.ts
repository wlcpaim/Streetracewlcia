// Auditoria forense — extrator TypeScript (somente leitura). Roda o código real do jogo e grava JSON.
// Uso: bun auditoria/extract.ts > auditoria/saida/ts.json
import { TITAN_160, FACTOR_150, STOCK_SETUP, BSFC, ETA, engine, stats, ccOf, type BikeModel } from "../src/game/physics";
import { LHV_BY_FUEL, CONSTANTS } from "../src/game/physics-registry/constants";
import { ENGINE_CATALOG } from "../src/game/data/engine_catalog";
import { FICHA, runFunnel, stockProject } from "../src/game/realgear/funnel";
import { tireRadius, curve } from "../src/game/intel/powertrain";
import { buildOf } from "../src/game/mechlimits";
import { Ledger, verifyChain } from "../src/nexus/evidence";
import { decide } from "../src/nexus/approval";
import { decideAccess } from "../src/nexus/access";
import { indicators, overall } from "../src/nexus/availability";

const AT = "2026-11-09T20:20:00.000Z";
function bike(b: BikeModel) {
  const s = STOCK_SETUP, e = engine(b, s), st = stats(b, s), kb = buildOf(b, s), c = curve(b, s, 50);
  const pk = c.reduce((a, x) => (x.kwMotor > a.kwMotor ? x : a), c[0]!);
  return {
    id: b.id, nome: b.name, ccJogo: ccOf(b, s), ccDeclarada: b.cc, ficha: FICHA[b.id] ?? null, catalogo: ENGINE_CATALOG[b.id]?.p ?? null,
    compressao: s.compression, rpmLimit: e.rpmLimit, rpmPeak: e.rpmPeak, hp: e.hp, kg: st.kg, torqueFichaKgfm: b.torqueGas,
    pico: { rpm: pk.rpm, kwMotor: pk.kwMotor, nmMotor: pk.nmMotor, cvMotor: pk.cvMotor, cvRoda: pk.cvRoda },
    recKg: kb.recKg, rodLimitN: kb.rodLimitN, raioPneu: tireRadius(b.tires), gearTop: b.gearTop, front: s.front, rear: s.rear,
    bsfc: BSFC[s.fuel], eta: ETA, lhv: LHV_BY_FUEL[s.fuel], fuel: s.fuel,
  };
}
const funnel = (b: BikeModel, setup = STOCK_SETUP) => runFunnel({ ...stockProject(b), setup }, AT).camadas.map((x) => ({ n: x.n, nome: x.nome, conclusao: x.conclusao, motivo: x.motivo, ausentes: x.ausentes }));

// Cadeia de evidências: íntegra, adulterada, removida, reordenada
const chk = (id: string) => ({ testId: id, kind: "x", source: "local", target: "local", state: "APPROVED", real: true, input: { id }, output: { ok: 1 }, contract: "c", engineVersion: "v", errors: [], note: "" }) as never;
const L = new Ledger("AUD"); ["a", "b", "c"].forEach((x) => L.add(chk(x), AT));
const ok = verifyChain(L.items);
const tamper = verifyChain(L.items.map((e, i) => (i === 1 ? { ...e, note: "adulterado" } : e)));
const removed = verifyChain([L.items[0]!, L.items[2]!]);
const reorder = verifyChain([L.items[1]!, L.items[0]!, L.items[2]!]);

// Approval: evidência simulada marcada como real; sem evidência
const gates = [{ id: "g", label: "g", required: true, tests: ["t"] }];
const base = { auditId: "A", specId: "s", at: AT, codeVersion: "v", input: {}, synthetic: false, gates, integrationGates: ["g"], physicsGates: ["g"] };
const forgedEv = [{ ...L.items[0]!, testId: "t", exec: "SIMULATED" as const }];
const forged = decide({ ...base, evidence: forgedEv }).homologation;
const empty = decide({ ...base, evidence: [] }).homologation;
const syn = decide({ ...base, synthetic: true, evidence: [{ ...L.items[0]!, testId: "t", exec: "INTERNAL" as const }] }).homologation;

// Acesso e disponibilidade
const access = { anon: decideAccess(null, null), naoAdmin: decideAccess("u", false), admin: decideAccess("u", true) };
const ind = (db: boolean, core: boolean) => overall(indicators({ checkedAt: AT, service: { ok: true, detail: "" }, core: { ok: core, detail: "" }, db: { ok: db, detail: "" }, lastAudit: { at: AT, homologation: "APPROVED" } }));
const disp = { tudoOk: ind(true, true), bancoFora: ind(false, true), nucleoFalho: ind(true, false), soAuditoria: overall(indicators({ checkedAt: AT, service: null, core: null, db: null, lastAudit: { at: AT, homologation: "APPROVED" } })) };

// Casos-limite no funil (dados inválidos devem reprovar/bloquear)
const limite: Record<string, unknown> = {};
for (const [k, v] of Object.entries({ compressaoNaN: NaN, compressaoZero: 0, compressaoNegativa: -5, compressaoInfinita: Infinity, compressao1: 1, compressao30: 30 })) {
  try { const f = runFunnel({ ...stockProject(TITAN_160), setup: { ...STOCK_SETUP, compression: v } }, AT); limite[k] = { estado: f.estado, camada: f.atual }; }
  catch (e) { limite[k] = { excecao: String(e) }; }
}

console.log(JSON.stringify({ at: AT, constantes: CONSTANTS, motos: [bike(TITAN_160), bike(FACTOR_150)],
  funil: { titan160: funnel(TITAN_160), factor150: funnel(FACTOR_150) },
  evidencias: { ok, tamper, removed, reorder }, aprovacao: { forged, empty, syn }, access, disp, limite }, null, 1));
