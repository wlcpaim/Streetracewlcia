# Homologação dos motores originais — 2026-11-13

Resultado (src/nexus/homologacao.ts, teste src/test/homologacao.test.ts): as 4 motos retornam
**MOTOR ORIGINAL — CONDIÇÃO NORMAL DE FÁBRICA**, com 0 alertas na corrida de 402 m e na puxada no rolo, e todos os testes OEM aprovados.

## Alterações (antes → depois)
| Item | Antes | Depois | Justificativa / fonte |
|---|---|---|---|
| Peças removidas (retrovisor, rabeta, freio dianteiro) | sempre removidas (−kg) | moto completa | ordem: sem vantagem de peso; STOCK_SETUP e normalizeSetup |
| Taxa de compressão | 9,5 genérica para todas | por moto via catálogo: CG160 9,5 · Factor 9,6 · CG150 9,5 · CG125 9,0 | manuais/fichas no engine_catalog; potência de ficha medida na taxa da própria moto |
| Velocidade por marcha CG 160 | 42,5/68/92,5/113/140 | 39,6/65,1/84,9/103,6/120,5 | manual Honda 00X6B-KVSP-001 (primária × marcha × 44/15 × raio dinâmico) |
| Factor 150 | 41,5/65/88/110/136 | 38,5/58,5/79,3/100,1/119,5 | manual Yamaha 2RP-F8197-W2 |
| CG 150 ESD | 42,5/68/92,5/113/140 | 40,6/63,3/83,8/103,8/120,8 | relações OEM 2004–2008 |
| CG 125 Bolinha | 33/58/82,5/105 | 38,0/61,1/82,7/105,2 | relações OEM 4 marchas |
| Factor etanol / regimes | 12,0 cv @7.250, torque @6.000 | 12,4 cv @7.500, torque @5.500 | ficha Yamaha Factor 150 UBS (catálogo) |
| Alerta "temperatura congelada" | comparava só início e fim da janela | soma a variação de cada passo | falso positivo na CG160 (subiu e voltou ao mesmo valor) |
| Alerta trem de válvulas | ALTO na Bolinha original | NORMAL com molas/comando de fábrica dentro do limite homologado; continua ALTO com peças trocadas ou acima do limite | flutuação 10.300 rpm é ESTIMADA, não evidência |
| Saves | taxa 9,5 antiga persistia | cabeçote nunca usinado recebe a taxa da própria moto ao carregar | atualização sem resíduo antigo |

## Bolinha
Taxa 9,0:1 aplicada. Limite real resultante 9.900 rpm = energia do platinado 6 V (9.923 rpm, modelo ESTIMADO), abaixo da flutuação estimada (10.300). Sem corte eletrônico. Potência 11 cv @ 9.000 rpm (ficha). Resistência da biela: sem documento (comprimento, massa, material DESCONHECIDOS) — não declarada.

## Desconhecidos (não inventados)
Potência/torque oficiais da CG 160 no catálogo, biela da Factor/CG150/CG125, massas do pistão, diagrama de comando, folga de válvulas, curva de avanço de fábrica, pressão de óleo, limite mecânico comprovado (limiteRpm) de todas.

## Efeitos em motos preparadas (pendente de decisão)
Com as marchas reais, motos preparadas ficam mais lentas no final: Kit 4MM 143,7 km/h (teste esperava ≥150), preparador não alcança 170 km/h, e a ordem de tempos dos níveis offline mudou numa pista. Esses testes seguem falhando até decidir re-balancear adversários/metas.
