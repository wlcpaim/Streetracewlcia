# VEREDITO FINAL NEXUS

- Commit: `1d5ba315c1c257249b387cde7bbd11862985069a`
- Data: 2026-11-09T20:51:06Z
- **Veredito: REJECTED**
- Motivo: Existe falha crítica (C1: modelo de quebras com curso único) e a Factor 150 reprova na camada 4; a camada 5 bloqueia as demais por falta de dados físicos.

## Contagem (todas as verificações desta auditoria)
| PASS | FAIL | BLOCKED | NOT_RUN | NOT_APPLICABLE | NEEDS_PHYSICAL_TEST |
|---|---|---|---|---|---|
| 58 | 9 | 45 | 16 | 3 | 3 |

Percentual de aprovação não é usado como critério de homologação.

## Por componente
| Componente | Estado | Base |
|---|---|---|
| Segurança do banco | APPROVED_WITH_RESTRICTIONS | anon bloqueado nas 7 tabelas; B1 e B2 abertos |
| Cadeia de evidências | PASS | alteração, remoção e reordenação detectadas |
| Approval Engine | PASS | simulado-como-real → BLOCKED; sem evidência → NOT_EXECUTED; sintético → INCONCLUSIVE |
| Constantes físicas | APPROVED_WITH_RESTRICTIONS | registro central; PCI gasolina estimado |
| Honda CG 160 Titan | BLOCKED | camadas 1–4 PASS; camada 5 sem dados físicos |
| Yamaha Factor 150 | REJECTED | camada 4 FAIL (curso 63 × 57,9 mm) |
| Funil de 24 camadas | BLOCKED | nenhuma moto passa da camada 5 |
| Worker Python em nuvem | NOT_RUN | integração externa não exercitada |
| Lint | FAIL | 1 erro de hooks real + formatação |
