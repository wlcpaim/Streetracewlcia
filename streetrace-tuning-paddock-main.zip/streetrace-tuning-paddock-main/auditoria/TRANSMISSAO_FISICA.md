# Transmissão física — câmbio, pinhão, coroa e pneu (2026-11-13)

## O que mudou
- `physics.gearSpeeds()` deixou de escalar a tabela fixa `BikeModel.gearTop`. Agora sai de `physics.drivetrain()`:
  - relação total `i_k = primária × marcha_k × (coroa / pinhão)` (relações do manual em `engine_catalog`);
  - `n_roda = rpm / i_k`; `v = ω_roda × r_din`; `r_din = raio estático do pneu MONTADO × 0,97` (registry `tire.rolling_factor`);
  - `T_roda = T_motor × i_k × η`, `η = 0,88` agora registrado em `drivetrain.eta_total` com fonte e incerteza (±0,03).
- Novas funções: `drivetrain`, `gearRatioTotal`, `speedAtRpm`, `rpmAtSpeed`, `wheelTorqueNm`, `wheelForceN`, `shiftRpm`, `rearTireDynM`.
- `gearTop` ficou só como referência de validação (`oemGearTop()` recalcula e o teste exige igualdade).
- A corrida (`step()`) já usava a velocidade de corte para o acoplamento ω = v·i/r; agora essa velocidade é física e o raio da massa equivalente é o do pneu montado.
- Dinamômetro: a tabela mostra **velocidade teórica no corte** e **velocidade alcançada** separadas. Antes mostrava só a alcançada; com relação longa a 4ª e a 5ª apareciam iguais (~125–135 km/h) porque a moto fica limitada pelo arrasto, não pelo câmbio.
- A potência na roda do dinamômetro usa `ETA` (antes `0,88` literal).
- `enginephys.transmission()` usava primária 67/20 e marchas 37/12…25/24 **genéricas, iguais para todas as motos**, e pneu fixo 100/80-18. Removidas: usa a cadeia da corrida.
- Mesma cadeia em: auditoria de motor (TR-02), overhaul22, scanner (monitor/diagnose), NEXUS oem-auditor, RealGear (funnel, kinematics, exportador Python), engenharia de dados (audit, fórmulas), Auto Peças, ficha de peças, relatório de preload, mapa da moto, potência e transmissão.
- RealGear kinematics: dentes da primária e das marchas vêm do manual (Titan 160 e Factor). Titan 150 e Bolinha têm só a relação decimal documentada: dentes ficam PENDENTES (nada inventado). η por estágio segue PENDENTE (só existe o total).

## Câmbio original de cada moto (depois = antes; já estava alinhado ao manual)
| Moto | Final | Primária | Marchas | Relação total | km/h no corte |
|---|---|---|---|---|---|
| Honda CG 160 Titan | 15×44 | 3,136 | 2,785 / 1,695 / 1,300 / 1,066 / 0,916 | 25,62 / 15,59 / 11,96 / 9,81 / 8,43 | 39,6 / 65,1 / 84,9 / 103,6 / 120,5 |
| Yamaha Factor 150 | 14×39 | 3,409 | 2,714 / 1,789 / 1,318 / 1,045 / 0,875 | 25,77 / 16,99 / 12,52 / 9,92 / 8,31 | 38,5 / 58,5 / 79,3 / 100,1 / 119,5 |
| Honda CG 150 Titan ESD | 16×43 | 3,350 | 2,785 / 1,789 / 1,350 / 1,090 / 0,937 | 25,07 / 16,11 / 12,15 / 9,81 / 8,44 | 40,6 / 63,3 / 83,8 / 103,8 / 120,8 |
| Honda CG 125 Bolinha | 15×38 | 4,055 | 2,769 / 1,722 / 1,272 / 1,000 | 28,45 / 17,69 / 13,07 / 10,27 | 38,0 / 61,1 / 82,7 / 105,2 |

## Kits na CG 160 (corte teórico × velocidade alcançada em 1000 m)
| Relação | coroa/pinhão | km/h no corte (1ª…5ª) | máx alcançada | 1000 m |
|---|---|---|---|---|
| 15×44 original | 2,933 | 39,6 / 65,1 / 84,9 / 103,6 / 120,5 | 120,5 | 38,50 s |
| 16×44 | 2,750 | 42,3 / 69,5 / 90,6 / 110,5 / 128,6 | 124,7 | 38,33 s |
| 14×44 | 3,143 | 37,0 / 60,8 / 79,3 / 96,7 / 112,5 | 112,5 | 39,39 s |
| 15×46 | 3,067 | 37,9 / 62,3 / 81,2 / 99,1 / 115,3 | 115,3 | 39,00 s |
| 15×42 | 2,800 | 41,5 / 68,2 / 89,0 / 108,5 / 126,3 | 124,5 | 38,35 s |
| 14×48 arrancada | 3,429 | 33,9 / 55,7 / 72,7 / 88,6 / 103,1 | 103,1 | 41,16 s |
| 16×40 | 2,500 | 46,5 / 76,4 / 99,7 / 121,5 / 141,4 | 124,7 | 38,34 s |
| 17×38 | 2,235 | 52,0 / 85,5 / 111,5 / 135,9 / 158,2 | 125,1 | 38,45 s |

Relação longa: a 5ª teórica (158 km/h) não é alcançada; 14,4 cv contra o arrasto param em ~125 km/h. Não há trava de km/h.

## Pneu (antes ignorado na relação)
| Pneu traseiro | r_din (m) | km/h no corte, CG 160 15×44 |
|---|---|---|
| original 100/80-18 | 0,2993 | 39,6 / 65,1 / 84,9 / 103,6 / 120,5 |
| Levorin 2.75-18 | 0,2895 | 38,3 / 63,0 / 82,1 / 100,2 / 116,6 |
| Drag Radial 120/70-17 | 0,2909 | 38,5 / 63,3 / 82,5 / 100,7 / 117,1 |
| Slick 130/70-17 | 0,2977 | 39,4 / 64,8 / 84,5 / 103,0 / 119,9 |
Antes, todos davam 120,5 km/h na 5ª.

## Pendências (não inventadas)
- Dentes da primária e das marchas da CG 150 ESD e da CG 125 Bolinha (só relação decimal documentada).
- η por estágio (primária, câmbio, corrente) — só existe o total estimado 0,88 ± 0,03.
- Raio dinâmico medido (usa estático × 0,97, estimado).

## Testes
`src/test/transmissao-fisica.test.ts` (19 testes, os 15 pedidos): original, pinhão ±1, coroa ±2, curta, longa, 4ª→5ª, queda de rpm na simulação para as 4 motos, rpm = velocidade × relação em toda a corrida, torque na roda, velocidade teórica por marcha, velocidade real com arrasto, comparação das 4 motos, todos os kits do catálogo nas 4 motos, persistência.
Atualizados: kinematics, axles, crossaudit (primária agora documentada), physics-overhaul-001.
Suite completa: os mesmos 5 testes que já falhavam antes continuam falhando (catalog-naming, facil-track, kit4mm-pino, prelaunch, preparador) com os mesmos valores; nenhuma regressão.
