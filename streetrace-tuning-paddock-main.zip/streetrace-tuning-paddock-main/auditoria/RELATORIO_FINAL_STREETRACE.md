# RELATÓRIO FINAL — AUDITORIA FORENSE STREETRACE

**A. Projeto:** STREETRACE (Wikipedia StreetRace, RealGear, NEXUS, Python, Cloud, Fix Center)
**B. Data/ambiente:** 2026-11-09T20:51:06Z · Linux · Bun 1.4.4 · Vitest 4.1 · Python 3.13 · banco do projeto (somente leitura)
**C. Commit auditado:** `1d5ba315c1c257249b387cde7bbd11862985069a`
**W. Veredito:** **REJECTED** — Existe falha crítica (C1: modelo de quebras com curso único) e a Factor 150 reprova na camada 4; a camada 5 bloqueia as demais por falta de dados físicos.

Nenhum código de produção, fórmula, constante ou dado foi alterado. Scripts da auditoria ficam em `auditoria/`.

## Contagem geral
| PASS | FAIL | BLOCKED | NOT_RUN | NOT_APPLICABLE | NEEDS_PHYSICAL_TEST |
|---|---|---|---|---|---|
| 58 | 9 | 45 | 16 | 3 | 3 |

## D/E. Componentes e arquivos examinados
physics.ts, mechlimits.ts, physics-registry/constants.ts, data/engine_catalog.ts, realgear/funnel.ts, realgear/kinematics.ts, intel/powertrain.ts, nexus/evidence.ts, nexus/approval.ts, nexus/access.ts, nexus/availability.ts, python/realgear/*.py, políticas e privilégios das 8 tabelas do banco.

## F/G. Comandos
```
bunx vitest run
PYTHONPATH=python python3 -m unittest discover -s python/tests
bunx eslint src
bun auditoria/extract.ts > auditoria/saida/ts.json
python3 auditoria/relatorio.py
consultas: pg_tables.rowsecurity, pg_policies, has_table_privilege(anon|authenticated|service_role)
```

## H. Regressão
| Comando | Resultado | Status |
|---|---|---|
| bunx vitest run | 378/378 aprovados, 58 arquivos | PASS |
| bun test (executor nativo) | falha de ambiente: import.meta.glob e localStorage indisponíveis; o projeto é configurado para vitest | NOT_APPLICABLE |
| python -m unittest discover -s python/tests | 14/14 aprovados | PASS |
| bunx eslint src | 4826 problemas: 4801 formatação (prettier); 1 rules-of-hooks em src/game/ui/Missions.tsx:107; 1 no-dupe-else-if em src/game/screens/Race.tsx:119; 1 no-constant-condition; 2 no-unused-expressions | FAIL |
| build / typecheck | executado automaticamente pela plataforma; último registro sem erros | PASS |

## J. Matemática TS × Python
| Moto | Grandeza | TS | Python | Dif. rel. | Status |
|---|---|---|---|---|---|
| Honda CG 160 Titan | 1. Cilindrada | 162.7 | 162.457 | 1.493e-03 | PASS |
| Honda CG 160 Titan | 2. Volume total do cilindro | 181.841 | 181.57 | 1.493e-03 | PASS |
| Honda CG 160 Titan | 3. Curso (funil × catálogo) | 63 | 63.096 | 1.521e-03 | FAIL |
| Honda CG 160 Titan | 3b. Curso (modelo de quebras × ficha) | 63 | 63 | 0.000e+00 | PASS |
| Honda CG 160 Titan | 4. Diâmetro (recalculado da cilindrada) | 57.3 | 57.3428 | 7.456e-04 | PASS |
| Honda CG 160 Titan | 5. Taxa de compressão (volta) | 9.5 | 9.5 | 0.000e+00 | PASS |
| Honda CG 160 Titan | 6. Velocidade média do pistão | 18.9 | 18.9 | — | NOT_RUN |
| Honda CG 160 Titan | 7. Torque no pico | 12.6423 | 12.6423 | 0.000e+00 | PASS |
| Honda CG 160 Titan | 8. Potência | 10.5912 | 10.5912 | 0.000e+00 | PASS |
| Honda CG 160 Titan | 9. Força de inércia (PMS, 1ª ordem) | 5043.978095613098 | 5043.978095613098 | — | NOT_RUN |
| Honda CG 160 Titan | 10. Trabalho por volta | 79.4339 | 79.4339 | 0.000e+00 | PASS |
| Honda CG 160 Titan | 11. PCI do combustível | 3.95e+07 | 3.87238e+07 | 2.004e-02 | PASS |
| Honda CG 160 Titan | 12. Aceleração | — | — | — | NOT_RUN |
| Honda CG 160 Titan | 13. Velocidade | — | — | — | NOT_RUN |
| Honda CG 160 Titan | 14. Relação primária | PENDENTE | PENDENTE | — | BLOCKED |
| Honda CG 160 Titan | 15. Relações de câmbio | PENDENTE | PENDENTE | — | BLOCKED |
| Honda CG 160 Titan | 16. Relação final | 2.933333333333333 | 2.933333333333333 | — | NOT_APPLICABLE |
| Honda CG 160 Titan | 17. Rotação da roda na final | 1220.5661006183375 | 1220.5661006183375 | — | NOT_RUN |
| Honda CG 160 Titan | 18. Velocidade teórica | — | — | — | BLOCKED |
| Honda CG 160 Titan | 19. Consumo no pico | 0.0012356379 | 0.0012356379 | — | NOT_RUN |
| Honda CG 160 Titan | 20. Eficiência térmica efetiva | 0.21699819168173598 | 0.21699819168173598 | — | PASS |
| Honda CG 160 Titan | 21. Perdas na transmissão | 1.728 | 1.728 | 1.285e-16 | PASS |
| Honda CG 160 Titan | 22. Tensão estrutural da biela | — | — | — | NEEDS_PHYSICAL_TEST |
| Yamaha Factor 150 | 1. Cilindrada | 149.3 | 149.306 | 4.117e-05 | PASS |
| Yamaha Factor 150 | 2. Volume total do cilindro | 166.865 | 166.872 | 4.117e-05 | PASS |
| Yamaha Factor 150 | 3. Curso (funil × catálogo) | 57.9 | 57.9 | 0.000e+00 | PASS |
| Yamaha Factor 150 | 3b. Curso (modelo de quebras × ficha) | 63 | 57.9 | 8.808e-02 | FAIL |
| Yamaha Factor 150 | 4. Diâmetro (recalculado da cilindrada) | 57.3 | 57.2988 | 2.059e-05 | PASS |
| Yamaha Factor 150 | 5. Taxa de compressão (volta) | 9.5 | 9.5 | 0.000e+00 | PASS |
| Yamaha Factor 150 | 6. Velocidade média do pistão | 16.983999999999998 | 16.983999999999998 | — | NOT_RUN |
| Yamaha Factor 150 | 7. Torque no pico | 11.4313 | 11.4313 | 0.000e+00 | PASS |
| Yamaha Factor 150 | 8. Potência | 8.67889 | 8.67889 | 2.047e-16 | PASS |
| Yamaha Factor 150 | 9. Força de inércia (PMS, 1ª ordem) | 4066.9027401173335 | 4066.9027401173335 | — | NOT_RUN |
| Yamaha Factor 150 | 10. Trabalho por volta | 71.8253 | 71.8253 | 0.000e+00 | PASS |
| Yamaha Factor 150 | 11. PCI do combustível | 3.95e+07 | 3.87238e+07 | 2.004e-02 | PASS |
| Yamaha Factor 150 | 12. Aceleração | — | — | — | NOT_RUN |
| Yamaha Factor 150 | 13. Velocidade | — | — | — | NOT_RUN |
| Yamaha Factor 150 | 14. Relação primária | PENDENTE | PENDENTE | — | BLOCKED |
| Yamaha Factor 150 | 15. Relações de câmbio | PENDENTE | PENDENTE | — | BLOCKED |
| Yamaha Factor 150 | 16. Relação final | 2.933333333333333 | 2.933333333333333 | — | NOT_APPLICABLE |
| Yamaha Factor 150 | 17. Rotação da roda na final | 997.0821667023038 | 997.0821667023038 | — | NOT_RUN |
| Yamaha Factor 150 | 18. Velocidade teórica | — | — | — | BLOCKED |
| Yamaha Factor 150 | 19. Consumo no pico | 0.0010125366125 | 0.0010125366125 | — | NOT_RUN |
| Yamaha Factor 150 | 20. Eficiência térmica efetiva | 0.21699819168173598 | 0.21699819168173598 | — | PASS |
| Yamaha Factor 150 | 21. Perdas na transmissão | 1.416 | 1.416 | 3.136e-16 | PASS |
| Yamaha Factor 150 | 22. Tensão estrutural da biela | — | — | — | NEEDS_PHYSICAL_TEST |

Observação: "TS" é a saída real do jogo; "Python" é recálculo independente neste script. Grandezas sem saída TS exposta ficam NOT_RUN, não PASS.

## K. Divergências físicas
- Honda CG 160 Titan · 3. Curso (funil × catálogo): TS 63 × ref 63.096 (Duas fontes de curso no código devem coincidir (tol. 0,05%))
- Yamaha Factor 150 · 3b. Curso (modelo de quebras × ficha): TS 63 × ref 57.9 (Modelo de quebras usa 63 mm para todas as motos)
- PCI gasolina C: jogo 39,5 MJ/kg × 38,7 MJ/kg pela mistura mássica (dentro de ±1,1 declarado).
- PCI etanol: hidratado 24,8 (calculado) × anidro 26,8 (tabela) — rótulos agora distintos.

## L. Segurança
| Teste | Esperado | Obtido | Status |
|---|---|---|---|
| Leitura anônima das 7 tabelas de auditoria | BLOQUEADA | anon sem privilégio SELECT (has_table_privilege=false) + RLS ativo | PASS |
| Escrita anônima nas 7 tabelas | BLOQUEADA | anon sem INSERT/UPDATE/DELETE | PASS |
| Escrita por usuário autenticado nas 7 tabelas | BLOQUEADA | authenticated só SELECT; política exige has_role admin | PASS |
| Políticas permissivas antigas | INEXISTENTES | 8 políticas, todas SELECT restritas (admin ou próprio usuário) | PASS |
| Acesso de usuário a papéis de terceiros (user_roles) | BLOQUEADO | RLS auth.uid()=user_id | PASS |
| Privilégios de tabela em user_roles para anon/authenticated | MÍNIMOS | anon e authenticated têm SELECT/INSERT/UPDATE/DELETE concedidos; só a RLS impede | FAIL |
| Alteração de evidência pelo cliente | BLOQUEADA | sem privilégio de escrita + gatilho somente-inserção | PASS |
| Adulteração detectada pela cadeia SHA-256 | DETECTADA | alterado→False, removido→False, reordenado→False | PASS |
| Função NEXUS sem sessão | 401 | 401 | PASS |
| Função NEXUS sem papel admin | 403 | 403 | PASS |
| Acesso administrativo autorizado (ao vivo) | PERMITIDO | verificado em sessão anterior no navegador; não repetido nesta auditoria | NOT_RUN |
| Chave privilegiada no código do navegador | INEXISTENTE | nenhuma referência fora de *.server.ts | PASS |
| Arquivo .env versionado | NÃO VERSIONADO | .env está no Git (só chaves públicas: URL, project id, publishable key) | FAIL |
| Endpoint /api/public/python-jobs sem token | 401 | não chamado ao vivo | NOT_RUN |

## N. Funil de 24 camadas
| Camada | Nome | Titan | Factor |
|---|---|---|---|
| 1 | Recebimento e integridade do projeto | APROVADA | APROVADA |
| 2 | Identificação completa do motor | APROVADA | APROVADA |
| 3 | Compatibilidade entre componentes | APROVADA | APROVADA |
| 4 | Geometria e dimensões mecânicas | APROVADA | REPROVADA |
| 5 | Propriedades dos materiais | INCONCLUSIVA | BLOQUEADA |
| 6 | Condições iniciais e operacionais | BLOQUEADA | BLOQUEADA |
| 7 | Geometria volumétrica e cilindrada | BLOQUEADA | BLOQUEADA |
| 8 | Cinemática do conjunto alternativo | BLOQUEADA | BLOQUEADA |
| 9 | Dinâmica, forças e torque | BLOQUEADA | BLOQUEADA |
| 10 | Combustão, combustível e oxigênio | BLOQUEADA | BLOQUEADA |
| 11 | Termodinâmica e transferência de energia | BLOQUEADA | BLOQUEADA |
| 12 | Eficiência energética e perdas | BLOQUEADA | BLOQUEADA |
| 13 | Resistência dos materiais | BLOQUEADA | BLOQUEADA |
| 14 | Fadiga e vida mecânica | BLOQUEADA | BLOQUEADA |
| 15 | Lubrificação, atrito e desgaste | BLOQUEADA | BLOQUEADA |
| 16 | Arrefecimento e transferência de calor | BLOQUEADA | BLOQUEADA |
| 17 | Transmissão e relações mecânicas | BLOQUEADA | BLOQUEADA |
| 18 | Integridade estrutural e modos de falha | BLOQUEADA | BLOQUEADA |
| 19 | Partida e marcha lenta | BLOQUEADA | BLOQUEADA |
| 20 | Aceleração e variação de carga | BLOQUEADA | BLOQUEADA |
| 21 | Funcionamento em diferentes rotações | BLOQUEADA | BLOQUEADA |
| 22 | Resistência e funcionamento prolongado | BLOQUEADA | BLOQUEADA |
| 23 | Auditoria independente integral | BLOQUEADA | BLOQUEADA |
| 24 | Certificação final do projeto | BLOQUEADA | BLOQUEADA |

## Cenários de bloqueio
| Id | Cenário | Esperado | Status | Observado |
|---|---|---|---|---|
| A | Curso incorreto (Factor 150, 63 vs 57,9 mm) | FAIL na camada 4 | PASS | funil real: camada 4 REPROVADA |
| B | Material sem escoamento documentado | camada 5 não aprova | PASS | funil real: camada 5 INCONCLUSIVA |
| C | Combustível sem identificação | bloqueio | NOT_RUN | não exercitado nesta auditoria |
| D | Unidade incompatível | rejeição | PASS | test_unidade_incompativel (Python) aprovado |
| E | Divergência TS × Python | bloqueio | PASS | suíte crossaudit/nexus aprovada (vitest) |
| F | Fórmula modificada sem aprovação | bloqueio | PASS | bugfix: patch adulterado → REPROVADA NEXUS (vitest) |
| G | Evidência adulterada | detecção | PASS | conteúdo alterado: entryHash não confere |
| H | Python indisponível | sem aprovação | PASS | sem evidência → NOT_EXECUTED |
| I | Banco indisponível | não ONLINE | PASS | indicador → DEGRADED |
| J | Usuário sem autorização | 401/403 | PASS | decideAccess |
| K | Camada obrigatória sem dados | cascata bloqueada | PASS | camadas 6–24 BLOQUEADA |
| L | Fator de segurança abaixo do limite | reprovação | NOT_RUN | camada 13 nunca alcançada (bloqueio na 4/5) |
| X1 | Evidência simulada marcada como real | BLOCKED | PASS | → BLOCKED |
| X2 | Ficha sintética | nunca APPROVED | PASS | → INCONCLUSIVE |
| X3 | Só auditoria carregada, sem sondas | não ONLINE | PASS | → UNKNOWN |

## Casos-limite (taxa de compressão no funil)
| Entrada | Resultado | Status |
|---|---|---|
| compressaoNaN | {"estado": "DIVERGÊNCIA DETECTADA", "camada": 1} | PASS |
| compressaoZero | {"estado": "DADOS INCOMPLETOS", "camada": 5} | FAIL |
| compressaoNegativa | {"estado": "DADOS INCOMPLETOS", "camada": 5} | FAIL |
| compressaoInfinita | {"estado": "DIVERGÊNCIA DETECTADA", "camada": 1} | PASS |
| compressao1 | {"estado": "DADOS INCOMPLETOS", "camada": 5} | FAIL |
| compressao30 | {"estado": "DIVERGÊNCIA DETECTADA", "camada": 3} | PASS |
Esperado: rejeição explícita até a camada 3. Valores 0, negativo e 1 só param na camada 5 → FAIL (falha A1).

## O/P. Não executado e dependências externas
- Worker Python em nuvem e endpoint público: site não publicado nesta auditoria.
- Chamada HTTP ao vivo das funções NEXUS com/sem sessão: verificado apenas por teste de unidade.
- Desempenho, carga e concorrência: NOT_RUN (não autorizado em produção).
- Cenários C e L: NOT_RUN.

## Q. Ensaios físicos necessários
Escoamento e seção da biela, liga/tratamento do pistão, curva S-N (biela/virabrequim), viscosidade e pressão de óleo, raio dinâmico do pneu, BSFC medido em dinamômetro, dentes da primária e do câmbio.

## R–U. Falhas
Ver LISTA_DE_FALHAS_PRIORIZADAS.md (1 crítica, 4 altas, 4 médias, 4 baixas).

## V. Recomendações priorizadas
1. C1 — curso por moto no modelo de quebras (precisa aprovação: muda corridas).
2. A1 — rejeitar taxa de compressão inválida na camada 1.
3. A4 — corrigir hook condicional em Missões.
4. A2/Q — obter dados de material.
5. A3 — publicar e ligar o worker Python.
6. B1/B2 — revogar privilégios extras de user_roles; tirar .env do Git.
