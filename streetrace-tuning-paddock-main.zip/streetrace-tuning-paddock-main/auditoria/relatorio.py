"""Auditoria forense STREETRACE — gera os 8 entregáveis a partir de auditoria/saida/*.
Cálculos de referência independentes em Python puro (stdlib); não importa nada do jogo.
Uso: python3 auditoria/relatorio.py
"""
import csv, json, math, os, subprocess, hashlib
from collections import Counter

R = os.path.dirname(os.path.abspath(__file__))
S = os.path.join(R, "saida")
d = json.load(open(os.path.join(S, "ts.json"), encoding="utf-8"))
git = subprocess.check_output(["git", "rev-parse", "HEAD"]).decode().strip()
AT = subprocess.check_output(["date", "-u", "+%Y-%m-%dT%H:%M:%SZ"]).decode().strip()
CV_W, PI = 735.49875, math.pi  # definição exata do cv métrico

def row(moto, g, un, formula, entrada, ts, py, tol_rel, nota, status=None):
    if status is None:
        ref = py
        da = abs(ts - ref); dr = da / max(abs(ref), 1e-12)
        status = "PASS" if dr <= tol_rel else "FAIL"
        return dict(moto=moto, grandeza=g, unidade=un, formula=formula, entrada=entrada, ts=f"{ts:.6g}", python=f"{py:.6g}",
                    referencia=f"{ref:.6g}", dif_abs=f"{da:.3e}", dif_rel=f"{dr:.3e}", tolerancia=f"{tol_rel:g} rel", status=status, nota=nota)
    return dict(moto=moto, grandeza=g, unidade=un, formula=formula, entrada=entrada, ts=ts, python=py, referencia="—",
                dif_abs="—", dif_rel="—", tolerancia="—", status=status, nota=nota)

math_rows = []
for m in d["motos"]:
    n, f, cat = m["nome"], m["ficha"], m["catalogo"]
    D, Sf = f["boreMm"], f["strokeMm"]; Scat = cat["curso"]["valor"]
    Vd = PI / 4 * (D / 10) ** 2 * (Sf / 10)
    math_rows.append(row(n, "1. Cilindrada", "cm³", "π/4·D²·S", f"D={D} S={Sf} mm (FICHA do funil)", m["ccJogo"], Vd, 0.005, "Jogo usa cilindrada declarada; tolerância 0,5% = arredondamento de ficha"))
    CR = m["compressao"]; Vc = Vd / (CR - 1)
    math_rows.append(row(n, "2. Volume total do cilindro", "cm³", "Vd·CR/(CR−1)", f"CR={CR}", m["ccJogo"] * CR / (CR - 1), Vd + Vc, 0.005, "Derivado da cilindrada do jogo vs ficha"))
    math_rows.append(row(n, "3. Curso (funil × catálogo)", "mm", "fonte documental", f"funil={Sf} catálogo={Scat}", Sf, Scat, 0.0005, "Duas fontes de curso no código devem coincidir (tol. 0,05%)"))
    math_rows.append(row(n, "3b. Curso (modelo de quebras × ficha)", "mm", "mechlimits.STROKE_MM", "STROKE_MM=63 (src/game/mechlimits.ts:11)", 63.0, Sf, 0.0005, "Modelo de quebras usa 63 mm para todas as motos"))
    Dcalc = math.sqrt(4 * m["ccDeclarada"] * 1000 / (PI * Sf))
    math_rows.append(row(n, "4. Diâmetro (recalculado da cilindrada)", "mm", "√(4·Vd/(π·S))", f"Vd={m['ccDeclarada']} S={Sf}", D, Dcalc, 0.005, "Consistência D×S×cilindrada"))
    math_rows.append(row(n, "5. Taxa de compressão (volta)", ":1", "(Vd+Vc)/Vc", f"Vc={Vc:.3f} cm³", CR, (Vd + Vc) / Vc, 1e-9, "Identidade geométrica"))
    vm = 2 * (Sf / 1000) * m["rpmLimit"] / 60
    math_rows.append(row(n, "6. Velocidade média do pistão", "m/s", "2·S·n/60", f"n={m['rpmLimit']}", vm, vm, 0, "O jogo não expõe v_m fora do funil (camada 8 bloqueada)", status="NOT_RUN"))
    pk = m["pico"]; w = 2 * PI * pk["rpm"] / 60
    math_rows.append(row(n, "7. Torque no pico", "N·m", "T=P/ω", f"P={pk['kwMotor']} kW n={pk['rpm']}", pk["nmMotor"], pk["kwMotor"] * 1000 / w, 1e-9, "curve() do jogo vs Python"))
    math_rows.append(row(n, "8. Potência", "kW", "P=cv·735,49875 W", f"{pk['cvMotor']} cv", pk["kwMotor"], pk["cvMotor"] * CV_W / 1000, 1e-9, "Conversão cv→kW"))
    Fi = m["recKg"] * (Sf / 2000) * (2 * PI * m["rpmLimit"] / 60) ** 2
    math_rows.append(row(n, "9. Força de inércia (PMS, 1ª ordem)", "N", "m·r·ω²", f"m={m['recKg']:.4f} kg (ESTIMADO)", Fi, Fi, 0, "Massa alternativa é estimada; sem rota TS independente exposta", status="NOT_RUN"))
    math_rows.append(row(n, "10. Trabalho por volta", "J", "W=2π·T", f"T={pk['nmMotor']:.4f}", 2 * PI * pk["nmMotor"], 2 * PI * pk["kwMotor"] * 1000 / w, 1e-9, ""))
    math_rows.append(row(n, "11. PCI do combustível", "J/kg", "registry", m["fuel"], m["lhv"], 0.714 * 43.5e6 + 0.286 * 26.8e6, 0.03, "Python: mistura mássica E27 = 38,7 MJ/kg; jogo 39,5 (ESTIMADO ±1,1)"))
    math_rows.append(row(n, "12. Aceleração", "m/s²", "F/m", "—", "—", "—", 0, "Sem grandeza escalar exposta; coberta por testes de física do jogo", status="NOT_RUN"))
    math_rows.append(row(n, "13. Velocidade", "km/h", "—", "—", "—", "—", 0, "Idem", status="NOT_RUN"))
    math_rows.append(row(n, "14. Relação primária", "—", "Z2/Z1", "dentes não cadastrados", "PENDENTE", "PENDENTE", 0, "Sem ficha do fabricante", status="BLOCKED"))
    math_rows.append(row(n, "15. Relações de câmbio", "—", "Z2/Z1", "dentes não cadastrados", "PENDENTE", "PENDENTE", 0, "Sem ficha do fabricante", status="BLOCKED"))
    math_rows.append(row(n, "16. Relação final", "—", "coroa/pinhão", f"{m['rear']}/{m['front']}", m["rear"] / m["front"], m["rear"] / m["front"], 0, "Dado do jogo (STOCK_REAR/FRONT), não ficha", status="NOT_APPLICABLE"))
    rT = m["raioPneu"]; vt = m["gearTop"][-1] / 3.6; nr = vt / (2 * PI * rT) * 60
    math_rows.append(row(n, "17. Rotação da roda na final", "rpm", "v/(2πr)·60", f"v={m['gearTop'][-1]} km/h r={rT:.4f} m (ESTIMADO)", nr, nr, 0, "Raio estático estimado", status="NOT_RUN"))
    math_rows.append(row(n, "18. Velocidade teórica", "km/h", "ω·r/N", "—", "—", "—", 0, "Exige relações por marcha", status="BLOCKED"))
    mf = pk["kwMotor"] * m["bsfc"] / 3600
    math_rows.append(row(n, "19. Consumo no pico", "kg/s", "P·BSFC/3600", f"BSFC={m['bsfc']} kg/kWh", mf, mf, 0, "BSFC do jogo é ESTIMADO", status="NOT_RUN"))
    eta = 3.6e6 / (m["bsfc"] * m["lhv"]); otto = 1 - CR ** (-0.3)
    math_rows.append(row(n, "20. Eficiência térmica efetiva", "—", "3,6e6/(BSFC·PCI)", f"η={eta:.4f}; η_Otto(γ=1,3)={otto:.4f}", eta, eta, 0, "2ª lei: η < η_Otto", status="PASS" if 0 < eta < otto else "FAIL"))
    math_rows.append(row(n, "21. Perdas na transmissão", "cv", "P·(1−η)", f"η={m['eta']}", pk["cvMotor"] - pk["cvRoda"], pk["cvMotor"] * (1 - m["eta"]), 1e-9, "η agregado ESTIMADO"))
    math_rows.append(row(n, "22. Tensão estrutural da biela", "MPa", "F/A", "área e material desconhecidos", "—", "—", 0, "Exige ensaio/ficha metalúrgica", status="NEEDS_PHYSICAL_TEST"))

layers = []
PHYS = {5, 13, 14, 15, 19}
for t, fc in zip(d["funil"]["titan160"], d["funil"]["factor150"]):
    st = lambda c: {"APROVADA": "PASS", "REPROVADA": "FAIL", "BLOQUEADA": "BLOCKED", "INCONCLUSIVA": "NEEDS_PHYSICAL_TEST" if t["n"] in PHYS else "BLOCKED"}[c]
    layers.append(dict(camada=t["n"], nome=t["nome"], titan_conclusao=t["conclusao"], titan_status=st(t["conclusao"]), titan_motivo=t["motivo"],
                       factor_conclusao=fc["conclusao"], factor_status=st(fc["conclusao"]), factor_motivo=fc["motivo"],
                       exige_dado_experimental="SIM" if t["n"] in PHYS else "NÃO"))

ev, ap, ac, ds, lim = d["evidencias"], d["aprovacao"], d["access"], d["disp"], d["limite"]
sec = [
    ("Leitura anônima das 7 tabelas de auditoria", "BLOQUEADA", "anon sem privilégio SELECT (has_table_privilege=false) + RLS ativo", "PASS", "consulta ao catálogo do banco"),
    ("Escrita anônima nas 7 tabelas", "BLOQUEADA", "anon sem INSERT/UPDATE/DELETE", "PASS", "consulta ao catálogo do banco"),
    ("Escrita por usuário autenticado nas 7 tabelas", "BLOQUEADA", "authenticated só SELECT; política exige has_role admin", "PASS", "consulta ao catálogo do banco"),
    ("Políticas permissivas antigas", "INEXISTENTES", "8 políticas, todas SELECT restritas (admin ou próprio usuário)", "PASS", "pg_policies"),
    ("Acesso de usuário a papéis de terceiros (user_roles)", "BLOQUEADO", "RLS auth.uid()=user_id", "PASS", "pg_policies"),
    ("Privilégios de tabela em user_roles para anon/authenticated", "MÍNIMOS", "anon e authenticated têm SELECT/INSERT/UPDATE/DELETE concedidos; só a RLS impede", "FAIL", "defesa em profundidade ausente (severidade baixa)"),
    ("Alteração de evidência pelo cliente", "BLOQUEADA", "sem privilégio de escrita + gatilho somente-inserção", "PASS", "catálogo; gatilho não exercitado ao vivo"),
    ("Adulteração detectada pela cadeia SHA-256", "DETECTADA", f"alterado→{ev['tamper']['ok']}, removido→{ev['removed']['ok']}, reordenado→{ev['reorder']['ok']}", "PASS" if not (ev['tamper']['ok'] or ev['removed']['ok'] or ev['reorder']['ok']) and ev['ok']['ok'] else "FAIL", "verifyChain real"),
    ("Função NEXUS sem sessão", "401", str(ac["anon"].get("status")), "PASS" if ac["anon"].get("status") == 401 else "FAIL", "decideAccess (unidade); chamada HTTP ao vivo não executada"),
    ("Função NEXUS sem papel admin", "403", str(ac["naoAdmin"].get("status")), "PASS" if ac["naoAdmin"].get("status") == 403 else "FAIL", "decideAccess (unidade)"),
    ("Acesso administrativo autorizado (ao vivo)", "PERMITIDO", "verificado em sessão anterior no navegador; não repetido nesta auditoria", "NOT_RUN", "sem sessão admin nesta execução"),
    ("Chave privilegiada no código do navegador", "INEXISTENTE", "nenhuma referência fora de *.server.ts", "PASS", "busca no código"),
    ("Arquivo .env versionado", "NÃO VERSIONADO", ".env está no Git (só chaves públicas: URL, project id, publishable key)", "FAIL", "severidade baixa: não há segredo privado no arquivo"),
    ("Endpoint /api/public/python-jobs sem token", "401", "não chamado ao vivo", "NOT_RUN", "site não publicado nesta auditoria"),
]

scen = [
    ("A", "Curso incorreto (Factor 150, 63 vs 57,9 mm)", "FAIL na camada 4" , "PASS" if layers[3]["factor_status"] == "FAIL" else "FAIL", "funil real: camada 4 " + layers[3]["factor_conclusao"]),
    ("B", "Material sem escoamento documentado", "camada 5 não aprova", "PASS" if layers[4]["titan_conclusao"] != "APROVADA" else "FAIL", "funil real: camada 5 " + layers[4]["titan_conclusao"]),
    ("C", "Combustível sem identificação", "bloqueio", "NOT_RUN", "não exercitado nesta auditoria"),
    ("D", "Unidade incompatível", "rejeição", "PASS", "test_unidade_incompativel (Python) aprovado"),
    ("E", "Divergência TS × Python", "bloqueio", "PASS", "suíte crossaudit/nexus aprovada (vitest)"),
    ("F", "Fórmula modificada sem aprovação", "bloqueio", "PASS", "bugfix: patch adulterado → REPROVADA NEXUS (vitest)"),
    ("G", "Evidência adulterada", "detecção", "PASS" if not ev["tamper"]["ok"] else "FAIL", ev["tamper"]["reason"]),
    ("H", "Python indisponível", "sem aprovação", "PASS" if ap["empty"] != "APPROVED" else "FAIL", f"sem evidência → {ap['empty']}"),
    ("I", "Banco indisponível", "não ONLINE", "PASS" if ds["bancoFora"] != "ONLINE" else "FAIL", f"indicador → {ds['bancoFora']}"),
    ("J", "Usuário sem autorização", "401/403", "PASS" if not ac["anon"]["allowed"] and not ac["naoAdmin"]["allowed"] else "FAIL", "decideAccess"),
    ("K", "Camada obrigatória sem dados", "cascata bloqueada", "PASS" if all(l["titan_status"] == "BLOCKED" for l in layers[5:]) else "FAIL", "camadas 6–24 BLOQUEADA"),
    ("L", "Fator de segurança abaixo do limite", "reprovação", "NOT_RUN", "camada 13 nunca alcançada (bloqueio na 4/5)"),
    ("X1", "Evidência simulada marcada como real", "BLOCKED", "PASS" if ap["forged"] == "BLOCKED" else "FAIL", f"→ {ap['forged']}"),
    ("X2", "Ficha sintética", "nunca APPROVED", "PASS" if ap["syn"] != "APPROVED" else "FAIL", f"→ {ap['syn']}"),
    ("X3", "Só auditoria carregada, sem sondas", "não ONLINE", "PASS" if ds["soAuditoria"] != "ONLINE" else "FAIL", f"→ {ds['soAuditoria']}"),
]
edge = []
for k, v in lim.items():
    expected_reject = True
    rejected_early = v.get("camada", 99) <= 3 or "excecao" in v
    edge.append((k, json.dumps(v, ensure_ascii=False), "PASS" if rejected_early else "FAIL"))

vit = open(os.path.join(S, "vitest.log")).read(); py = open(os.path.join(S, "python.log")).read()
reg = [
    ("bunx vitest run", "378/378 aprovados, 58 arquivos", "PASS" if "378 passed" in vit else "FAIL"),
    ("bun test (executor nativo)", "falha de ambiente: import.meta.glob e localStorage indisponíveis; o projeto é configurado para vitest", "NOT_APPLICABLE"),
    ("python -m unittest discover -s python/tests", "14/14 aprovados", "PASS" if "OK" in py else "FAIL"),
    ("bunx eslint src", "4826 problemas: 4801 formatação (prettier); 1 rules-of-hooks em src/game/ui/Missions.tsx:107; 1 no-dupe-else-if em src/game/screens/Race.tsx:119; 1 no-constant-condition; 2 no-unused-expressions", "FAIL"),
    ("build / typecheck", "executado automaticamente pela plataforma; último registro sem erros", "PASS"),
]

# ---------- grava CSVs
def wcsv(name, rows, fields):
    with open(os.path.join(R, name), "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=fields); w.writeheader(); w.writerows(rows)
wcsv("COMPARACAO_TYPESCRIPT_PYTHON.csv", math_rows, list(math_rows[0].keys()))
wcsv("MATRIZ_DAS_24_CAMADAS.csv", layers, list(layers[0].keys()))
wcsv("MATRIZ_DE_SEGURANCA.csv", [dict(teste=a, esperado=b, obtido=c, status=s, metodo=m) for a, b, c, s, m in sec], ["teste", "esperado", "obtido", "status", "metodo"])

allst = ([r["status"] for r in math_rows] + [l["titan_status"] for l in layers] + [l["factor_status"] for l in layers]
         + [s[3] for s in sec] + [s[3] for s in scen] + [e[2] for e in edge] + [r[2] for r in reg])
C = Counter(allst)
counts = {k: C.get(k, 0) for k in ["PASS", "FAIL", "BLOCKED", "NOT_RUN", "NOT_APPLICABLE", "NEEDS_PHYSICAL_TEST"]}
mf = [r for r in math_rows if r["status"] == "FAIL"]

failures = {
    "CRITICA": [
        ("C1", "Modelo de quebras usa curso 63 mm para todas as motos", "src/game/mechlimits.ts:11 (STROKE_MM = 63)", "Factor 150 (ficha 57,9 mm) reprova na camada 4; tensões de biela/inércia da Factor calculadas com geometria errada", "Ler o curso por moto do catálogo; muda resultado de corrida — exige aprovação e recalibração"),
    ],
    "ALTA": [
        ("A1", "Taxa de compressão fisicamente inválida não é rejeitada", "src/game/realgear/funnel.ts camadas 1 e 3", "CR = 0, −5 e 1 passam as camadas 1–4 e param só na 5 como 'dados incompletos' (CR=1 gera divisão por zero em Vc)", "Rejeitar CR ≤ 1 e não finita na camada 1"),
        ("A2", "Camada 5 sem propriedades de material", "funnel.ts camada 5", "Bloqueia 6–24 para todas as motos", "Ficha metalúrgica ou ensaio (escoamento, seção, liga)"),
        ("A3", "Worker Python em nuvem não exercitado", "/api/public/python-jobs + python/realgear/worker.py", "Integração externa real não comprovada", "Publicar, configurar token e rodar o worker"),
        ("A4", "Hook React chamado condicionalmente", "src/game/ui/Missions.tsx:107", "Pode quebrar a tela de missões em certos estados", "Mover useState para antes de qualquer return"),
    ],
    "MEDIA": [
        ("M1", "Duas fontes de curso da Titan", "funnel.ts FICHA (63,0) × engine_catalog.ts (63,096)", "Diferença de 0,15% entre fontes internas", "Unificar a ficha em um único catálogo"),
        ("M2", "PCI da gasolina C no limite da faixa", "physics-registry/constants.ts", "39,5 vs 38,7 MJ/kg calculado (dentro da incerteza ±1,1 declarada)", "Obter valor medido/ANP"),
        ("M3", "Ramo inalcançável e condição constante", "src/game/screens/Race.tsx:119 e no-constant-condition", "Lógica morta", "Revisar"),
        ("M4", "Relações primária e de marchas sem dentes", "realgear/kinematics.ts", "Grandezas 14, 15, 18 bloqueadas", "Cadastrar ficha do fabricante"),
    ],
    "BAIXA": [
        ("B1", "Privilégios amplos de tabela em user_roles", "banco: user_roles", "Só a RLS protege; sem defesa em profundidade", "Revogar INSERT/UPDATE/DELETE de anon/authenticated"),
        ("B2", ".env versionado", ".env", "Só chaves públicas; risco se um segredo for adicionado", "Adicionar ao .gitignore"),
        ("B3", "4801 avisos de formatação", "eslint/prettier", "Nenhum impacto funcional", "Rodar formatação"),
        ("B4", "bun test incompatível", "src/test", "Projeto depende de vitest", "Documentar o executor"),
    ],
}
verdict = "REJECTED"
why = "Existe falha crítica (C1: modelo de quebras com curso único) e a Factor 150 reprova na camada 4; a camada 5 bloqueia as demais por falta de dados físicos."

# ---------- Markdown
def tbl(head, rows):
    return "| " + " | ".join(head) + " |\n|" + "---|" * len(head) + "\n" + "\n".join("| " + " | ".join(str(c).replace("|", "/") for c in r) + " |" for r in rows)

fl = "\n".join(f"\n## {sev}\n" + "\n".join(f"- **{i} — {t}**\n  - Local: `{loc}`\n  - Impacto: {imp}\n  - Recomendação: {rec}" for i, t, loc, imp, rec in items) for sev, items in failures.items())
open(os.path.join(R, "LISTA_DE_FALHAS_PRIORIZADAS.md"), "w", encoding="utf-8").write(f"# LISTA DE FALHAS PRIORIZADAS\n\nCommit `{git}` · {AT}\n{fl}\n")

open(os.path.join(R, "VEREDITO_FINAL_NEXUS.md"), "w", encoding="utf-8").write(f"""# VEREDITO FINAL NEXUS

- Commit: `{git}`
- Data: {AT}
- **Veredito: {verdict}**
- Motivo: {why}

## Contagem (todas as verificações desta auditoria)
{tbl(list(counts.keys()), [list(counts.values())])}

Percentual de aprovação não é usado como critério de homologação.

## Por componente
{tbl(["Componente", "Estado", "Base"], [
 ("Segurança do banco", "APPROVED_WITH_RESTRICTIONS", "anon bloqueado nas 7 tabelas; B1 e B2 abertos"),
 ("Cadeia de evidências", "PASS", "alteração, remoção e reordenação detectadas"),
 ("Approval Engine", "PASS", "simulado-como-real → BLOCKED; sem evidência → NOT_EXECUTED; sintético → INCONCLUSIVE"),
 ("Constantes físicas", "APPROVED_WITH_RESTRICTIONS", "registro central; PCI gasolina estimado"),
 ("Honda CG 160 Titan", "BLOCKED", "camadas 1–4 PASS; camada 5 sem dados físicos"),
 ("Yamaha Factor 150", "REJECTED", "camada 4 FAIL (curso 63 × 57,9 mm)"),
 ("Funil de 24 camadas", "BLOCKED", "nenhuma moto passa da camada 5"),
 ("Worker Python em nuvem", "NOT_RUN", "integração externa não exercitada"),
 ("Lint", "FAIL", "1 erro de hooks real + formatação"),
])}
""")

open(os.path.join(R, "RELATORIO_FINAL_STREETRACE.md"), "w", encoding="utf-8").write(f"""# RELATÓRIO FINAL — AUDITORIA FORENSE STREETRACE

**A. Projeto:** STREETRACE (Wikipedia StreetRace, RealGear, NEXUS, Python, Cloud, Fix Center)
**B. Data/ambiente:** {AT} · Linux · Bun 1.4.4 · Vitest 4.1 · Python 3.13 · banco do projeto (somente leitura)
**C. Commit auditado:** `{git}`
**W. Veredito:** **{verdict}** — {why}

Nenhum código de produção, fórmula, constante ou dado foi alterado. Scripts da auditoria ficam em `auditoria/`.

## Contagem geral
{tbl(list(counts.keys()), [list(counts.values())])}

## D/E. Componentes e arquivos examinados
physics.ts, mechlimits.ts, physics-registry/constants.ts, data/engine_catalog.ts, realgear/funnel.ts, realgear/kinematics.ts, intel/powertrain.ts, nexus/evidence.ts, nexus/approval.ts, nexus/access.ts, nexus/availability.ts, python/realgear/*.py, políticas e privilégios das 8 tabelas do banco.

## F/G. Comandos
```
bunx vitest run
PYTHONPATH=python python3 -m unittest discover -s python/tests
bunx eslint src
bun auditoria/extract.ts > auditoria/saida/ts.json
python3 auditoria/relatorio.py
consultas: pg_tables.rowsecurity, pg_policies, has_table_privilege(anon|authenticated|service_role)
```

## H. Regressão
{tbl(["Comando", "Resultado", "Status"], reg)}

## J. Matemática TS × Python
{tbl(["Moto", "Grandeza", "TS", "Python", "Dif. rel.", "Status"], [(r["moto"], r["grandeza"], r["ts"], r["python"], r["dif_rel"], r["status"]) for r in math_rows])}

Observação: "TS" é a saída real do jogo; "Python" é recálculo independente neste script. Grandezas sem saída TS exposta ficam NOT_RUN, não PASS.

## K. Divergências físicas
{chr(10).join(f"- {r['moto']} · {r['grandeza']}: TS {r['ts']} × ref {r['python']} ({r['nota']})" for r in mf) or "- nenhuma"}
- PCI gasolina C: jogo 39,5 MJ/kg × 38,7 MJ/kg pela mistura mássica (dentro de ±1,1 declarado).
- PCI etanol: hidratado 24,8 (calculado) × anidro 26,8 (tabela) — rótulos agora distintos.

## L. Segurança
{tbl(["Teste", "Esperado", "Obtido", "Status"], [s[:4] for s in sec])}

## N. Funil de 24 camadas
{tbl(["Camada", "Nome", "Titan", "Factor"], [(l["camada"], l["nome"], l["titan_conclusao"], l["factor_conclusao"]) for l in layers])}

## Cenários de bloqueio
{tbl(["Id", "Cenário", "Esperado", "Status", "Observado"], scen)}

## Casos-limite (taxa de compressão no funil)
{tbl(["Entrada", "Resultado", "Status"], edge)}
Esperado: rejeição explícita até a camada 3. Valores 0, negativo e 1 só param na camada 5 → FAIL (falha A1).

## O/P. Não executado e dependências externas
- Worker Python em nuvem e endpoint público: site não publicado nesta auditoria.
- Chamada HTTP ao vivo das funções NEXUS com/sem sessão: verificado apenas por teste de unidade.
- Desempenho, carga e concorrência: NOT_RUN (não autorizado em produção).
- Cenários C e L: NOT_RUN.

## Q. Ensaios físicos necessários
Escoamento e seção da biela, liga/tratamento do pistão, curva S-N (biela/virabrequim), viscosidade e pressão de óleo, raio dinâmico do pneu, BSFC medido em dinamômetro, dentes da primária e do câmbio.

## R–U. Falhas
Ver LISTA_DE_FALHAS_PRIORIZADAS.md (1 crítica, 4 altas, 4 médias, 4 baixas).

## V. Recomendações priorizadas
1. C1 — curso por moto no modelo de quebras (precisa aprovação: muda corridas).
2. A1 — rejeitar taxa de compressão inválida na camada 1.
3. A4 — corrigir hook condicional em Missões.
4. A2/Q — obter dados de material.
5. A3 — publicar e ligar o worker Python.
6. B1/B2 — revogar privilégios extras de user_roles; tirar .env do Git.
""")

json.dump(dict(projeto="STREETRACE", data=AT, commit=git, veredito=verdict, motivo=why, contagem=counts,
               matematica=math_rows, camadas=layers, seguranca=[dict(zip(["teste", "esperado", "obtido", "status", "metodo"], s)) for s in sec],
               cenarios=[dict(zip(["id", "cenario", "esperado", "status", "observado"], s)) for s in scen],
               casos_limite=[dict(zip(["entrada", "resultado", "status"], e)) for e in edge], regressao=[dict(zip(["comando", "resultado", "status"], r)) for r in reg],
               falhas={k: [dict(zip(["id", "titulo", "local", "impacto", "recomendacao"], x)) for x in v] for k, v in failures.items()}),
          open(os.path.join(R, "RELATORIO_FINAL_STREETRACE.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# evidências
E = os.path.join(R, "EVIDENCIAS_DE_TESTES"); os.makedirs(E, exist_ok=True)
for f in ["ts.json", "vitest.log", "python.log", "lint.log"]:
    open(os.path.join(E, f), "wb").write(open(os.path.join(S, f), "rb").read())
with open(os.path.join(E, "SHA256SUMS.txt"), "w") as fh:
    for f in sorted(os.listdir(E)):
        if f != "SHA256SUMS.txt": fh.write(hashlib.sha256(open(os.path.join(E, f), "rb").read()).hexdigest() + "  " + f + "\n")
print(verdict, counts)
