# LISTA DE FALHAS PRIORIZADAS

Commit `1d5ba315c1c257249b387cde7bbd11862985069a` · 2026-11-09T20:51:06Z

## CRITICA
- **C1 — Modelo de quebras usa curso 63 mm para todas as motos**
  - Local: `src/game/mechlimits.ts:11 (STROKE_MM = 63)`
  - Impacto: Factor 150 (ficha 57,9 mm) reprova na camada 4; tensões de biela/inércia da Factor calculadas com geometria errada
  - Recomendação: Ler o curso por moto do catálogo; muda resultado de corrida — exige aprovação e recalibração

## ALTA
- **A1 — Taxa de compressão fisicamente inválida não é rejeitada**
  - Local: `src/game/realgear/funnel.ts camadas 1 e 3`
  - Impacto: CR = 0, −5 e 1 passam as camadas 1–4 e param só na 5 como 'dados incompletos' (CR=1 gera divisão por zero em Vc)
  - Recomendação: Rejeitar CR ≤ 1 e não finita na camada 1
- **A2 — Camada 5 sem propriedades de material**
  - Local: `funnel.ts camada 5`
  - Impacto: Bloqueia 6–24 para todas as motos
  - Recomendação: Ficha metalúrgica ou ensaio (escoamento, seção, liga)
- **A3 — Worker Python em nuvem não exercitado**
  - Local: `/api/public/python-jobs + python/realgear/worker.py`
  - Impacto: Integração externa real não comprovada
  - Recomendação: Publicar, configurar token e rodar o worker
- **A4 — Hook React chamado condicionalmente**
  - Local: `src/game/ui/Missions.tsx:107`
  - Impacto: Pode quebrar a tela de missões em certos estados
  - Recomendação: Mover useState para antes de qualquer return

## MEDIA
- **M1 — Duas fontes de curso da Titan**
  - Local: `funnel.ts FICHA (63,0) × engine_catalog.ts (63,096)`
  - Impacto: Diferença de 0,15% entre fontes internas
  - Recomendação: Unificar a ficha em um único catálogo
- **M2 — PCI da gasolina C no limite da faixa**
  - Local: `physics-registry/constants.ts`
  - Impacto: 39,5 vs 38,7 MJ/kg calculado (dentro da incerteza ±1,1 declarada)
  - Recomendação: Obter valor medido/ANP
- **M3 — Ramo inalcançável e condição constante**
  - Local: `src/game/screens/Race.tsx:119 e no-constant-condition`
  - Impacto: Lógica morta
  - Recomendação: Revisar
- **M4 — Relações primária e de marchas sem dentes**
  - Local: `realgear/kinematics.ts`
  - Impacto: Grandezas 14, 15, 18 bloqueadas
  - Recomendação: Cadastrar ficha do fabricante

## BAIXA
- **B1 — Privilégios amplos de tabela em user_roles**
  - Local: `banco: user_roles`
  - Impacto: Só a RLS protege; sem defesa em profundidade
  - Recomendação: Revogar INSERT/UPDATE/DELETE de anon/authenticated
- **B2 — .env versionado**
  - Local: `.env`
  - Impacto: Só chaves públicas; risco se um segredo for adicionado
  - Recomendação: Adicionar ao .gitignore
- **B3 — 4801 avisos de formatação**
  - Local: `eslint/prettier`
  - Impacto: Nenhum impacto funcional
  - Recomendação: Rodar formatação
- **B4 — bun test incompatível**
  - Local: `src/test`
  - Impacto: Projeto depende de vitest
  - Recomendação: Documentar o executor
