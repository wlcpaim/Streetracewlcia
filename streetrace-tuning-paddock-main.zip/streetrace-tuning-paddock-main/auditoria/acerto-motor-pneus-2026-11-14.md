# Acerto motor e pneus — 14/11/2026

Nenhuma operação de banco, exclusão, reset ou limpeza foi executada. Migrações locais já vazias; token atualizado via formulário seguro. Asfalto permanece 1,8. Potência, torque, relações primária/câmbio/final OEM e Bolinha preservados.

## Antes/depois (180 s, tanque cheio, gasolina, piloto padrão, sem vento/vácuo)

| Moto | Potência cv | Corte anterior → atual | Teórico atual | Topo anterior → atual | RPM final | Superfície / interno |
|---|---|---|---|---|---|---|
| titan160 | 14.4 | 9000 → 10000 | 133.9 km/h | 120.5 → 127.9 km/h | 9547 | 44.9 / 56.5 °C |
| factor150 | 11.8 | 8800 → 10000 | 135.8 km/h | 119.5 → 119.6 km/h | 8806 | 44.4 / 54.7 °C |
| titan150 | 14.2 | 9000 → 10000 | 134.2 km/h | 120.8 → 127.7 km/h | 9515 | 44.5 / 55.8 °C |
| cg125 | 11 | 9900 → 9900 | 105.2 km/h | 102.4 → 102.4 km/h | 9641 | 40.1 / 46.5 °C |

Bolinha não possui corte eletrônico: o valor de rpmLimit é referência física de centelha/molas. As três outras estabilizam abaixo de 10.000 rpm por equilíbrio de forças, sem ganho fictício de potência. Factor teórico 135,8 km/h é ligeiramente acima dos 128–133 pedidos; não foi falseada relação documentada para atingir faixa. Bolinha preservada resulta em 102,4 km/h; não foram criados ganhos para prometer 105–110.

## Pneus

Mandrakin 40/100; massas e durabilidade anteriores mantidas. Larguras relativas estimadas escolhidas: Mandrakin 0,8; Semi-slick sport 1,2; Slick racing 1,4; Slick pro 1,6. Não são medidas OEM. Largura modifica área aerodinâmica exposta e rolamento; massa já entra no peso da moto. Não foi adicionada nova inércia girante por falta de repartição de massa dianteiro/traseiro.

Superfície recebe calor de deslizamento; carcaça recebe histerese, troca calor com superfície e ambiente; vento aumenta resfriamento superficial. Sem temperaturas travadas nem piso 50 °C. Teste de rodagem sustentada a 35 m/s e 650 W verifica equilíbrio 50–60 / 70–80 °C; em corridas curtas ou menor carga a temperatura pode ser menor. Mandrakin na Titan a 180 s: 130,9 km/h e 52,1 / 78,9 °C; original 127,9 km/h e 44,9 / 56,5 °C.

## Validação

82/82 testes selecionados (motor, ignição, transmissão, pneus, largada, ficha). Teste antigo ground que exige piloto esperar 5 s já falhava antes e permanece intacto. Bateria completa não terminou dentro do limite de execução; não homologada integralmente. Atualização sem erros de compilação. Verificação visual de corrida pendente: conta do solicitante indisponível para sessão de teste; página pública verificada.
