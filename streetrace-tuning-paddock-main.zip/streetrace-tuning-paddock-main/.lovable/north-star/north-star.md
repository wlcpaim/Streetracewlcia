<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Estrela-guia

Jogadores montam uma moto própria mais rápida e vencem rachas de rua.

## Métrica

Corridas concluídas por dia
