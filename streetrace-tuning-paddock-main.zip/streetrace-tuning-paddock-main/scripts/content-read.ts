// Executa a Leitura de Conteúdo sobre o repositório e grava em src/game/realgear/content/.
// Uso: bun scripts/content-read.ts   — preserva a leitura anterior em history/ antes de gravar.
import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync, statSync, rmSync, copyFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { readContent } from "../src/game/realgear/content-reader/reader";
import { buildFiles } from "../src/game/realgear/content-reader/writer";

const ROOT = process.cwd(); const OUT = join(ROOT, "src/game/realgear/content");
function walk(dir: string, acc: string[] = []) { for (const n of readdirSync(dir)) { const p = join(dir, n); if (statSync(p).isDirectory()) walk(p, acc); else if (/\.(ts|tsx|json)$/.test(n)) acc.push(p); } return acc; }
const src: Record<string, string> = {};
for (const f of walk(join(ROOT, "src"))) { const rel = f.slice(ROOT.length + 1); if (!rel.startsWith("src/game/realgear/content/")) src[rel] = readFileSync(f, "utf8"); }
const L = readContent(src, new Date().toISOString());
const files = buildFiles(L);

const manPath = join(OUT, "manifest.json");
const histPath = join(OUT, "history/historico.json");
const hist: unknown[] = existsSync(histPath) ? JSON.parse(readFileSync(histPath, "utf8")) : [];
if (existsSync(manPath)) {
  const old = JSON.parse(readFileSync(manPath, "utf8"));
  const dir = join(OUT, "history", `${String(old.data).replace(/[:.]/g, "-")}_${String(old.codigo_hash).slice(0, 8)}`);
  mkdirSync(dir, { recursive: true });
  copyFileSync(manPath, join(dir, "manifest.json"));
  for (const f of ["audits/leitura-atual.json", "audits/pendencias.json", "audits/relatorio.md"]) if (existsSync(join(OUT, f))) copyFileSync(join(OUT, f), join(dir, f.replace("audits/", "")));
  for (const g of old.arquivos_gerados ?? []) if (!(g.caminho in files) && existsSync(join(OUT, g.caminho))) rmSync(join(OUT, g.caminho));
}
for (const [rel, text] of Object.entries(files)) { const p = join(OUT, rel); mkdirSync(dirname(p), { recursive: true }); writeFileSync(p, text); }
hist.push({ data: L.data, codigo_hash: L.codigo_hash, versao_leitor: L.versao_leitor, totais: L.totais });
mkdirSync(dirname(histPath), { recursive: true }); writeFileSync(histPath, JSON.stringify(hist, null, 2) + "\n");
console.log(JSON.stringify({ data: L.data, codigo_hash: L.codigo_hash, totais: L.totais, gerados: Object.keys(files).length }, null, 2));
