// Demo da ponte: exporta a Honda CG 160 Titan ORIGINAL (STOCK_SETUP) para JSON de engenharia.
// Uso: bun scripts/realgear-export.ts [saida.json]
import { writeFileSync } from "node:fs";
import { TITAN_160 } from "../src/game/physics";
import { stockProject } from "../src/game/realgear/funnel";
import { exportProject } from "../src/game/realgear/bridge/exporter";

const out = process.argv[2] ?? "python/realgear/examples/cg160-original.v1.json";
const r = exportProject(stockProject(TITAN_160), "2026-11-09T00:00:00.000Z");
if (!r.ok) { console.error(r.errors.join("\n")); process.exit(1); }
writeFileSync(out, JSON.stringify(r.pkg, null, 2) + "\n");
console.log(`exportado ${out} · hash ${r.pkg.integrity.hash} · ${r.pkg.missing_data.length} dados ausentes`);
