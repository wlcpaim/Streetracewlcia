// Regenerates src/lib/admin-combos.json (best full-catalog setup per track). Run: bun scripts/admin-combos.ts <distance>
import { writeFileSync, readFileSync, existsSync } from "node:fs";
import { bestSetup } from "../src/game/acerto";
import { PARTS_CATALOG, SLOTS, slotPart } from "../src/game/parts";
import { STOCK_SETUP, TITAN_160, simulate } from "../src/game/physics";
const out = "src/lib/admin-combos.json";
const d = Number(process.argv[2]);
const s = bestSetup({ setup: STOCK_SETUP, parts: PARTS_CATALOG.map((p) => p.id) } as never, d);
const r = simulate(TITAN_160, s, d, TITAN_160.tank);
const items: [string, string][] = [
  ["Relação", `${s.front} x ${s.rear}`],
  ["Desmontagem", s.removed.mirrors && s.removed.rabeta && s.removed.frontBrake ? "Desmontada" : "Original"],
  ["Filtro de ar", s.airFilter === "sem" ? "Sem filtro" : "Original"],
  ["Calibragem", `${s.psi} psi`],
  ...SLOTS.filter((sl) => sl !== "oleo").map((sl) => { const p = slotPart(s.slots[sl], sl); return [sl, `${p.brand ? p.brand + " · " : ""}${p.name}`] as [string, string]; }),
];
const all = existsSync(out) ? JSON.parse(readFileSync(out, "utf8")) : {};
all[d] = { distance: d, time: r.finishT, vmax: Math.round(r.top), items };
writeFileSync(out, JSON.stringify(all, null, 1));
console.log("ok", d);
