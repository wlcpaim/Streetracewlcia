<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

- StreetRace game lives in src/game: one client-only `Game` scene machine on `/` (no routes per screen) so transitions feel like a game; all screen changes go through `go()` which shows a preload loading screen.
- Race outcome is purely computed by src/game/physics.ts (fixed-step sim, power from setup, weight affects acceleration only); stock vs stock must tie, so keep sims deterministic.
- Save data is localStorage (`streetrace-save-v1`) until a backend is requested.
- Fuel is physical: tank liters add weight via FUEL_DENSITY in physics.stats(); each sim step burns fuel from delivered power (BSFC), so more power = more consumption and a dry tank stalls the bike; the opponent always runs a full stock tank. Never show predicted race consumption in the UI.
- Final drive (pinhão x coroa) scales gearTop via gearSpeeds(); wheel force uses gear-equivalent speed so short gearing launches harder and long gearing raises top speed.
- Moto Peças catalog lives in src/game/parts.ts; owned part ids are Player.parts and Fuçar categories double as the inventory (no separate inventory menu).
- Fuçar equips parts; Oficina runs paid machining services (taxar cabeçote, comando).
- Swappable components use `Setup.slots` (ids from parts.ts; `<slot>-original` is factory, always equippable, never sold); physics.engine() derives hp/rpmPeak/rpmLimit from slots, compression, cam, km break-in and oil wear so every change reaches the race. Why: one place crosses all preparation.
- Oficina services modify the installed head/cam in place (one service per piece); spare heads/cams live in Player.headStock/camStock and swap in Fuçar. Why: mirrors real machining that consumes the original part.
- Oficina machining services live in src/game/data/workshop_services.json (Setup.services); physics.stress() turns every part/service/ECU choice into break risk rolled per race and per dyno pull. Why: one data source keeps services and failure crossed with the engine model.
- /admin is an open client-side lab (src/game/admin-lab.ts) that runs the real physics step() over a scenario matrix and exports JSON/ZIP with engine logs. Why: tests must use the same deterministic sim as races.
- Athlon map (Setup.ecu: band trims incl. over-rev, band timing tLow/tHigh, closed loop, lean protection, soft cut, per-gear shift rpm and qsGear, 2-step, idle; new fields optional and neutral when unset) is applied only when the módulo is `prog`; physics.mixtureAt()/mixFactor() make mixture rpm-dependent so the dyno AFR curve and race use the same model.
- Engine failure rolls use physics.breakPoint()/rng() seeded from player+setup, never Math.random. Why: same inputs must reproduce the same result.
- Engine failure collateral damage lives in src/game/damage.ts, keyed by the stress() cause and seeded by odometer; repairPrice() adds its parts bill. Why: the laudo and the repair cost must always agree.
- Cartão de crédito logic lives in src/game/credit.ts: all player income goes through earn() (settles the bill once cash covers it) and engine repair through chargeRepair(). Why: one place keeps bill payoff and limit growth consistent.
- Offline race opponent replays the sim of its level build (offline.oppSetup: Fácil = full 4MM kit with per-track gearing and psi) on a full tank. Why: winning Fácil requires the full kit plus the right gearing and psi for each track.
- Trampo runs in the background via src/game/jobrun.ts (Player.shifts, Player.activeJobs delivery list capped by MAX_RUNS and run back-to-back, stacked offers) rendered by ui/Caller JobLayer; go() blocks race/dino while any run is listed. Why: player keeps navigating menus during a run.
- Map hub is src/game/screens/Mapa.tsx with percent hotspots over the map art; workplace menus are instant modals, not scenes.
- Slipstream (physics.draftMul) opens only when the follower front axle A is within DRAFT_GAP of the leader rear axle B (axle offsets in physics); catching it latches SimState.tucked (half drag, tucked sprite) until the finish. Why: vácuo and tuck must stay one deterministic rule.
- Street use (delivery km/L, tire wear per km, delivery time by hp) lives in src/game/usage.ts and derives from physics.engine(); worn tread enters races via Setup.tireWear. Why: every km and part choice must have a real, connected cost.
- Bank statement is recorded automatically in store.setPlayer from money/creditDebt diffs, labeled by current scene or ledgerTag(). Why: no spend path can bypass the extrato.
- Prices pass through src/game/economy.ts priceNow()/fuelUsdMul() from the live USD/BRL quote (catalog price = price at BASE_USD); keep physics independent of the rate. Why: live economy without breaking deterministic races.
- Mechanic advice, failure forensics and post-repair warnings live in src/game/mechanic.ts and read physics.engine()/stress(); tips point a direction, never the exact part or value. Why: player must reason like a tuner.
- EngineSound takes the full Setup (exhaust, displacement, cam, compression, intake, qs) and shift() cuts for the QS time. Why: every engine change must be audible.
- Scene image manifests live in scene-assets.ts; image-preload.ts deduplicates and decodes with bounded retries, and only the latest go() request reveals a committed screen. Why: prevent stale navigation and incomplete imagery.
- Component replacements use component-swap.ts to remove machining of replaced components. Why: preparation cannot transfer to a different physical piece.
- Dyno, automatic tuning and mechanic advice use the active bike model. Why: Factor preparation must match its race physics.
- Fuel blends live in src/game/fuelmix.ts (Setup.blend fractions, Player.cans in liters); physics.engine() applies blendFx() relative to the base fuel so a pure base tank stays neutral. Why: mixing must be deterministic and stock vs stock must tie.
- Broken-engine repair paths, Player.scrap (Scrap.state danificada = fixable, sucata = metal kg kept for future use, never sold; mechanic keeps nothing) live in src/game/scrap.ts. Why: repair cost, stock and scrap must stay in one place.
- Cloud audit tables (cloud_runs, python_jobs, cross_audits, cloud_failures, pipeline_events, service_heartbeats, nexus_evidence) are readable only by admins (RLS has_role admin; anon has no grant); all writes go through server code with the service role, and the external Python worker only reaches them via /api/public/python-jobs. Why: NEXUS C2 requires anonymous writes to be blocked.
- NEXUS server functions (src/nexus/nexus.functions.ts) require requireSupabaseAuth plus has_role(admin) from public.user_roles; NEXUS availability comes only from live probes in availability.ts, never from a loaded audit. Why: privileged audits must not run anonymously and old audits cannot prove current availability.

- Users carried over from an earlier project sit in public.legacy_users (service-role only); the auth.users trigger link_legacy_user grants their roles only after the email is confirmed and matches exactly one row. Why: access must follow verified email ownership, never client input.

- Physical constants live only in src/game/physics-registry/constants.ts and engine geometry in src/game/data/engine_catalog.ts (value, unit, source, origin); physics-constants.test.ts fails on duplicated literals. Why: Enginephys and RealGear had diverging fuel heating values.

- Exhaust sound tuning (sound/ExhaustEqTab + engine-sound EQ_BANDS/readEqs) stores per-exhaust EQ and profile overrides in localStorage and EngineSound applies them in races and dyno; it never touches physics. Why: sound is player-tunable, power stays physical.

- Nitromethane Lab (src/game/nitro/lab.ts + NitroLabTab, RG-CHEM-NM-001) is read-only science: eight calculation engines, illustrative LHV and hypothesis parameters labeled, never feeds race/fuelmix and never declares Nexus approval. Why: race changes need separate approval and Nexus audits independently.
- Factory components (`<slot>-original`) are never stored in Player.parts (Peças › Standard is derived from the setup); kit loose pieces and the factory pinhão/coroa are owned parts, hidden while mounted. Why: the Peças menu lists only real loose pieces, and swapped-out kit pieces must not vanish.
- Part lists in the garage never show per-part cv gains; only total power (garage, dyno, race) is displayed. Why: parts help the engine through the physics, the player measures the result.

- NEXUS UPDATE (src/game/nexus-update/registry.ts) stores edits in localStorage and mutates the live game objects (parts, services, bikes, map, jobs, dyno) in place on load and save; defaults are snapshotted first so reset is exact. Why: one edit must reach every screen without forking data.
- Ranked MMR (src/game/mmr/): Elo per category in player_mmr, append-only mmr_history unique by match_id, written only server-side via apply.server.ts; never uses money, parts or bike power. Why: fair, idempotent, tamper-resistant ranking.

- Accounts own up to 5 players (public.players, unique case-insensitive name and tag); the game save is per player (game_saves kind `player:<uuid>`), other saves stay per account; create/rename/switch only via security-definer RPCs. Why: one account, independent player identities, no client-chosen ownership.
- Friendships link player ids (unique unordered pair, no self), presence comes from the heartbeat RPC with server time and expires after ONLINE_WINDOW_S. Why: never show a player falsely online.
- Players are readable only by their owner or a friendship-linked player; discovery goes through the search_players RPC (id, name, tag only). Why: no signed-in user can list every account's players.
- CloudGate shows the landing only after cloud-store.authResolved (INITIAL_SESSION checked and, when signed in, the active player loaded). Why: signed-in players must never flash the landing.
- PYTHON_WORKER_TOKEN is read only from server env in /api/public/python-jobs and documented in README; agents must check `test -n "$PYTHON_WORKER_TOKEN"` and reuse it instead of asking again. Why: remixes must not re-request an existing credential.

- user_id columns: no FK to auth.users; link_legacy_user re-owns imported rows. anon: no grants. Why: safe import.
- AEIC (src/nexus/aeic.ts) is an index over existing data (engine_catalog, platforms, parts kinds) plus 'file#symbol' formula refs verified by aeic.test.ts; never a second catalog. Why: audit must point to real code, not duplicate it.
- CAIM (src/nexus/caim.ts) only composes existing physics/enginephys/mechlimits/ignition/topdown/AEIC calls into per-bike certificates; any unknown critical datum yields PENDENTE, never approval. Why: certification must audit the real sim, not a parallel model.
- NEXUS Encyclopedia lives in DB tables nexus_kb_sources (tier A–E), nexus_kb_entries (versioned by trigger into nexus_kb_versions) and nexus_kb_facts (one row per datum with source/method; VALIDADO facts cannot be overwritten or deleted, conflicts are new rows); entries admin-only, sources/facts admin or active-player read; admin write. Generic SI formulas with uncertainty are src/nexus/encyclopedia/formulas.ts and never feed race, shop or catalog. Why: knowledge must persist with provenance without becoming game data.
- NEXUS Dyno Engineering: dyno_* tables (admin read and write, update/delete logged to dyno_history; raw and processed curves are separate rows); math lives only in src/nexus/dyno/analysis.ts and never feeds race/shop. Why: experimental data validates trends, never replaces physics.
- Access tokens (src/game/auth/): only the SHA-256 hash is stored (access_tokens, service-role only), one active token per account, login goes through loginWithToken which rate-limits failures per hashed IP (token_attempts) and opens the session via a one-time magic-link hash. Why: a leaked database row or brute force must never grant a session.
- NEXUS Parts Intelligence (nexus_parts_*): admin or active-player read, admin write, sources in nexus_kb_sources, DB checks block unsourced verified data; /api/mecanico reads it with the player's token; never feeds shop/race. Why: knowledge stays apart from game data.
- Gateway model calls (e.g. /api/mecanico) use @lovable.dev/ai-gateway with the model's supported surface (Gemini → streamChatCompletion) and re-stream plain text to the client. Why: the gateway Responses surface serves OpenAI models only.
- Never delete accounts; reuse test accounts (README rule). Why: lost real progress.
