"""Worker externo do Python Investigator.

Reserva jobs na Cloud Central e executa o motor Python certo para cada tipo:
  - axles       → realgear.axles.compute (recálculo independente em SI)
  - investigate → realgear.investigator.investigate (lê o código-fonte real do repositório)
Nunca recebe o resultado do TypeScript: só a ficha/condição ou o evento de falha.
"""
import argparse, json, sys, time, urllib.request, urllib.error
from pathlib import Path
from .axles import compute
from .investigator import investigate, SCHEMA as FIX_SCHEMA

SCHEMA = "realgear.axles/1.0.0"
REPO = str(Path(__file__).resolve().parents[2])


def post(base, token, body):
    req = urllib.request.Request(
        f"{base.rstrip('/')}/api/public/python-jobs",
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {token}"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode("utf-8"))
        except Exception:
            return e.code, {"error": f"HTTP {e.code}"}
    except (urllib.error.URLError, TimeoutError) as e:
        return 0, {"error": f"sem conexão: {e}"}


def handle(job, repo=REPO):
    """Executa um job e devolve a resposta no contrato do tipo. Erros viram resposta explícita, nunca sucesso."""
    kind = job.get("kind", "axles")
    p = job["payload"]
    if kind == "investigate":
        ev = p.get("event") or {}
        if ev.get("schema") != FIX_SCHEMA or ev.get("kind") != "FailureEvent":
            return {"schema": FIX_SCHEMA, "erro": "evento inválido", "investigacao": None}
        return {"schema": FIX_SCHEMA, "erro": None, "investigacao": investigate(ev, repo)}
    spec, cond = p["spec"], p["cond"]
    try:
        return {"schema": SCHEMA, "erro": None, "resultado": compute(spec, cond["marcha"], cond["rpm"], cond["torque"], cond["v"], cond["a"])}
    except (TypeError, ZeroDivisionError, KeyError) as e:
        return {"schema": SCHEMA, "erro": f"dado PENDENTE ou inválido: {e}", "resultado": None}


def run_job(base, token, worker, job, repo=REPO):
    try:
        resp = handle(job, repo)
    except Exception as e:  # falha inesperada: devolve o job à fila (máx. 3 tentativas no servidor)
        st, body = post(base, token, {"action": "fail", "worker": worker, "jobId": job["jobId"], "error": f"{type(e).__name__}: {e}"})
        print(f"[worker] job {job['jobId']} falhou → HTTP {st}", file=sys.stderr)
        return False
    st, body = post(base, token, {"action": "result", "worker": worker, "jobId": job["jobId"], "response": resp})
    print(f"[worker] job {job['jobId']} ({job.get('kind', 'axles')}) → HTTP {st} · {body.get('status', body.get('error'))}", file=sys.stderr)
    return st == 200


def main(argv=None):
    ap = argparse.ArgumentParser(prog="realgear.worker")
    ap.add_argument("base"); ap.add_argument("token")
    ap.add_argument("--worker-id", default="py-investigator-1")
    ap.add_argument("--intervalo", type=float, default=5.0)
    ap.add_argument("--repo", default=REPO, help="raiz do repositório para o investigador ler o código")
    ap.add_argument("--uma-vez", action="store_true", help="processa a fila atual e sai")
    a = ap.parse_args(argv)
    post(a.base, a.token, {"action": "heartbeat", "worker": a.worker_id})
    while True:
        st, body = post(a.base, a.token, {"action": "claim", "worker": a.worker_id})
        if st != 200:
            print(f"[worker] claim falhou: HTTP {st} · {body.get('error')}", file=sys.stderr)
            if a.uma_vez: return 2
            time.sleep(a.intervalo); continue
        job = body.get("job")
        if not job:
            if a.uma_vez:
                print("[worker] fila vazia", file=sys.stderr); return 0
            time.sleep(a.intervalo); continue
        run_job(a.base, a.token, a.worker_id, job, a.repo)


if __name__ == "__main__":
    sys.exit(main())
