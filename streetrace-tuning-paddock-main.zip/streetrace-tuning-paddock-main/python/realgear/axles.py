"""Rota Python independente dos três eixos (stdlib). Uso: python -m realgear.axles spec.json --marcha 2 --rpm 6000 --torque 12 --v 15 --a 2
Recalcula a partir do JSON (MotoSpec do TS) sem importar nada do TypeScript.
"""
import argparse, json, math, sys

G0 = 9.80665


def val(d):
    return None if d is None or d.get("valor") is None else float(d["valor"])


def inertia(c):
    m, g, d = val(c["massa"]), c["geometria"], c["dims"]
    if g == "NAO_ROTATIVO":
        return 0.0
    if m is None:
        return None
    if g == "ANEL_FINO":
        r = val(d.get("r"));  return None if r is None else m * r * r
    if g in ("DISCO_SOLIDO", "CILINDRO_MACICO"):
        r = val(d.get("r"));  return None if r is None else 0.5 * m * r * r
    a, b = val(d.get("rInt")), val(d.get("rExt"))
    return None if a is None or b is None else 0.5 * m * (a * a + b * b)


def compute(s, marcha, rpm, torque, vx, acel):
    k = s["kin"]; g = k["marchas"][marcha - 1]
    i_p = val(k["primaria"]["conduzida"]) / val(k["primaria"]["motora"])
    i_g = val(g["conduzida"]) / val(g["motora"])
    i_f = val(k["coroa"]) / val(k["pinhao"])
    eta = val(k["eta"]["primaria"]) * val(k["eta"]["cambio"]) * val(k["eta"]["corrente"])
    i_t = i_p * i_g * i_f
    n_roda = rpm / i_t
    n_pinhao = rpm / (i_p * i_g)
    p = val(s["corrente"]["passo"])
    veh = s["veiculo"]; m = val(veh["massaMoto"]) + val(veh["massaPiloto"])
    h, L, b = val(veh["alturaCG"]), val(veh["entreEixos"]), val(veh["cgAteEixoTraseiro"])
    FzA = (m * G0 * b - m * acel * h) / L
    FzB = (m * G0 * (L - b) + m * acel * h) / L
    rB = val(s["rodaB"]["raioDinamico"])
    w_roda = 2 * math.pi * n_roda / 60.0
    return {
        "i_total": i_t, "rpm_roda": n_roda, "torque_roda": torque * i_t * eta,
        "potencia_roda": torque * i_t * eta * w_roda, "potencia_entrada": torque * 2 * math.pi * rpm / 60.0,
        "v_corrente_media": val(k["pinhao"]) * p * n_pinhao / 60.0,
        "v_periferica_B": w_roda * rB, "slip_B": (w_roda * rB - vx) / max(abs(w_roda * rB), abs(vx), 1e-12),
        "I_A": sum(inertia(c) for c in s["rodaA"]["componentes"]), "I_B": sum(inertia(c) for c in s["rodaB"]["componentes"]),
        "FzA": FzA, "FzB": FzB,
    }


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("spec"); ap.add_argument("--marcha", type=int, default=2)
    ap.add_argument("--rpm", type=float, default=6000); ap.add_argument("--torque", type=float, default=12)
    ap.add_argument("--v", type=float, default=15); ap.add_argument("--a", type=float, default=0)
    a = ap.parse_args(argv)
    s = json.load(open(a.spec, encoding="utf-8"))
    try:
        out = {"schema": "realgear.axles/1.0.0", "erro": None, "resultado": compute(s, a.marcha, a.rpm, a.torque, a.v, a.a)}
    except (TypeError, ZeroDivisionError) as e:
        out = {"schema": "realgear.axles/1.0.0", "erro": f"dado PENDENTE ou inválido: {e}", "resultado": None}
    json.dump(out, sys.stdout)


if __name__ == "__main__":
    main()
