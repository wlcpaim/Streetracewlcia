"""Uso: python -m realgear receive <pacote.json> [--out resposta.json] [--ledger ledger.jsonl]"""
import argparse, json, sys
from pathlib import Path
from .bridge import Ledger, receive

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="realgear")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("receive", help="recebe um pacote exportado pelo StreetRace")
    r.add_argument("package"); r.add_argument("--out"); r.add_argument("--ledger", default="realgear-ledger.jsonl")
    a = ap.parse_args(argv)
    resp = receive(Path(a.package).read_text(encoding="utf-8"), Ledger(a.ledger))
    txt = json.dumps(resp, ensure_ascii=False, indent=2)
    if a.out: Path(a.out).write_text(txt + "\n", encoding="utf-8")
    print(resp["report"], file=sys.stderr)
    print(f"status: {resp['status']} · execução {resp['execution_id']}", file=sys.stderr)
    return 0 if resp["status"] in ("RECEBIDO", "DUPLICADO") else 2

if __name__ == "__main__":
    sys.exit(main())
