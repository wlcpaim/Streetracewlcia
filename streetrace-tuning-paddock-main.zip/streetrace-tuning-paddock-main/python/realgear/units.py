"""Conversões explícitas SI ↔ unidades de oficina (só para relatório; o contrato trafega em SI)."""
import math
RAD_S_TO_RPM = 60 / (2 * math.pi)
M_TO_MM = 1e3
M3_TO_CC = 1e6
W_TO_CV = 1 / 735.49875
RAD_TO_DEG = 180 / math.pi
TO_DISPLAY = {"m": ("mm", M_TO_MM), "m^3": ("cm³", M3_TO_CC), "rad/s": ("rpm", RAD_S_TO_RPM), "W": ("cv", W_TO_CV), "rad": ("°", RAD_TO_DEG)}

def display(q: dict) -> str:
    v, u = q.get("value"), q.get("unit")
    if v is None:
        return f"DESCONHECIDO [{u}]"
    if u in TO_DISPLAY:
        du, k = TO_DISPLAY[u]
        return f"{v:.6g} {u} (= {v * k:.4g} {du}) [{q.get('origin')}]"
    return f"{v:.6g} {u} [{q.get('origin')}]"
