"""Motor 3 (Python, stdlib): recalcula a cadeia cinemática e confere unidades.

Uso: python -m realgear.kinematics spec.json [--marcha 1 --rpm 6000 --torque 10]
Saída: JSON com i_total, rpm/torque/potência na roda e verificação de unidades.
"""
import argparse, json, math, sys

UNITS = {"dentes", "m", "1", "N·m"}


def check_units(spec):
    errs = []
    def walk(name, d):
        if not isinstance(d, dict) or "unidade" not in d:
            return
        if d["unidade"] not in UNITS:
            errs.append(f"{name}: unidade {d['unidade']!r} fora do SI aceito")
        if d.get("valor") is None:
            errs.append(f"{name}: PENDENTE")
    for k in ("pinhao", "coroa", "passoCorrente", "raioPneu", "embreagemNm"):
        walk(k, spec[k])
    for k in ("motora", "conduzida"):
        walk(f"primaria.{k}", spec["primaria"][k])
    for i, g in enumerate(spec["marchas"]):
        for k in ("motora", "conduzida"):
            walk(f"marcha{i+1}.{k}", g[k])
    for k, d in spec["eta"].items():
        walk(f"eta.{k}", d)
    if spec["passoCorrente"].get("unidade") == "m" and (spec["passoCorrente"].get("valor") or 0) > 0.1:
        errs.append("passoCorrente: valor parece mm lido como m")
    return errs


def compute(spec, marcha, rpm, torque):
    v = lambda d: float(d["valor"])
    g = spec["marchas"][marcha - 1]
    i_p = v(spec["primaria"]["conduzida"]) / v(spec["primaria"]["motora"])
    i_g = v(g["conduzida"]) / v(g["motora"])
    i_f = v(spec["coroa"]) / v(spec["pinhao"])
    i_t = i_p * i_g * i_f
    eta = v(spec["eta"]["primaria"]) * v(spec["eta"]["cambio"]) * v(spec["eta"]["corrente"])
    omega = rpm * 2 * math.pi / 60.0  # rad/s
    n_roda = rpm / i_t
    w_roda = omega / i_t
    t_roda = torque * i_t * eta
    return {"i_total": i_t, "rpm_roda": n_roda, "torque_roda": t_roda, "potencia_roda": t_roda * w_roda,
            "v_periferica": w_roda * v(spec["raioPneu"])}


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("spec")
    ap.add_argument("--marcha", type=int, default=1)
    ap.add_argument("--rpm", type=float, default=6000)
    ap.add_argument("--torque", type=float, default=10)
    a = ap.parse_args(argv)
    spec = json.load(open(a.spec, encoding="utf-8"))
    errs = check_units(spec)
    out = {"schema": "realgear.kinematics/1.0.0", "erros_unidade": errs,
           "resultado": None if errs else compute(spec, a.marcha, a.rpm, a.torque)}
    json.dump(out, sys.stdout)


if __name__ == "__main__":
    main()
