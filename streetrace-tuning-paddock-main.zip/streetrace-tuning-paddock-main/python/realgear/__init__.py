"""Engrenagem Real — lado Python da ponte com a Wikipedia StreetRace (somente biblioteca padrão)."""
from .contract import SPEC, validate_package, validate_response, package_hash, canonical
from .bridge import receive, Ledger
__all__ = ["SPEC", "validate_package", "validate_response", "package_hash", "canonical", "receive", "Ledger"]
