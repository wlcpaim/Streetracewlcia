"""Contrato v1: leitura do arquivo único contract_v1.json, validação e hash canônico (igual ao TypeScript)."""
from __future__ import annotations
import json, math
from datetime import datetime
from pathlib import Path

SPEC = json.loads((Path(__file__).with_name("contract_v1.json")).read_text(encoding="utf-8"))

def _num(n) -> str:
    if isinstance(n, int):
        return str(n)
    if not math.isfinite(n):
        raise ValueError("número não finito")
    if n.is_integer():
        return str(int(n))
    m, e = f"{n:.11e}".split("e")
    return f"{m}e{int(e)}"

def canonical(x) -> str:
    if x is None:
        return "null"
    if isinstance(x, bool):
        return "true" if x else "false"
    if isinstance(x, (int, float)):
        return _num(x)
    if isinstance(x, str):
        return json.dumps(x, ensure_ascii=False)
    if isinstance(x, list):
        return "[" + ",".join(canonical(v) for v in x) + "]"
    if isinstance(x, dict):
        return "{" + ",".join(f"{json.dumps(k, ensure_ascii=False)}:{canonical(x[k])}" for k in sorted(x)) + "}"
    raise TypeError(f"tipo não suportado: {type(x).__name__}")

def fnv1a32(s: str) -> str:
    h = 0x811C9DC5
    for b in s.encode("utf-8"):
        h ^= b
        h = (h * 0x01000193) & 0xFFFFFFFF
    return f"{h:08x}"

def package_hash(p: dict) -> str:
    keys = ("schema_version", "identification", "configuration", "missing_data", "audit")
    return fnv1a32(canonical({k: p.get(k) for k in keys}))

def _is_num(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)

def check_q(path: str, q, errs: list[str]) -> None:
    if not isinstance(q, dict):
        errs.append(f"{path}: grandeza deve ser objeto {{value, unit, origin, source}}"); return
    if q.get("origin") not in SPEC["origins"]:
        errs.append(f"{path}: origem inválida '{q.get('origin')}'")
    if not isinstance(q.get("source"), str) or not q["source"]:
        errs.append(f"{path}: source obrigatório")
    if not isinstance(q.get("unit"), str):
        errs.append(f"{path}: unidade obrigatória")
    v = q.get("value")
    if v is None:
        if q.get("origin") != "DESCONHECIDO":
            errs.append(f"{path}: valor nulo exige origem DESCONHECIDO")
    elif not _is_num(v):
        errs.append(f"{path}: valor deve ser número finito ou null")
    elif q.get("origin") == "DESCONHECIDO":
        errs.append(f"{path}: DESCONHECIDO não pode ter valor")
    want = SPEC["units"].get(path)
    if want and q.get("unit") != want:
        errs.append(f"{path}: unidade incompatível '{q.get('unit')}' (esperado {want})")

def validate_package(x) -> list[str]:
    errs: list[str] = []
    if not isinstance(x, dict):
        return ["pacote não é objeto JSON"]
    if x.get("schema_version") != SPEC["schema_version"]:
        errs.append(f"schema_version '{x.get('schema_version')}' não suportado (esperado {SPEC['schema_version']})")
    ide = x.get("identification")
    if not isinstance(ide, dict):
        errs.append("identification ausente")
    else:
        for k in ("project_id", "bike_id", "engine_id", "created_at", "source_system"):
            if not isinstance(ide.get(k), str) or not ide[k]:
                errs.append(f"identification.{k} obrigatório")
        pv = ide.get("project_version")
        if not isinstance(pv, int) or isinstance(pv, bool) or pv < 1:
            errs.append("identification.project_version deve ser inteiro ≥ 1")
        if ide.get("approval_status") != "MECANICO_APROVADO":
            errs.append("identification.approval_status deve ser MECANICO_APROVADO")
        if isinstance(ide.get("created_at"), str):
            try: datetime.fromisoformat(ide["created_at"].replace("Z", "+00:00"))
            except ValueError: errs.append("identification.created_at não é data ISO")
    cfg = x.get("configuration")
    if not isinstance(cfg, dict):
        errs.append("configuration ausente")
    else:
        for g in SPEC["config_groups"]:
            if not isinstance(cfg.get(g), dict):
                errs.append(f"configuration.{g} obrigatório")
        for path in SPEC["units"]:
            g, k = path.split(".")
            grp = cfg.get(g)
            if isinstance(grp, dict):
                if k not in grp: errs.append(f"configuration.{path} obrigatório")
                else: check_q(path, grp[k], errs)
    md = x.get("missing_data")
    if not isinstance(md, list) or any(not isinstance(m, str) for m in md):
        errs.append("missing_data deve ser lista de textos")
    au = x.get("audit")
    if not isinstance(au, list):
        errs.append("audit deve ser lista")
    else:
        for i, a in enumerate(au):
            if not isinstance(a, dict): errs.append(f"audit[{i}] não é objeto"); continue
            for k in ("layer_id", "audit_id", "execution_id", "test_status"):
                if not isinstance(a.get(k), str) or not a[k]: errs.append(f"audit[{i}].{k} obrigatório")
            for k in ("inputs", "expected_results", "actual_results"):
                if not isinstance(a.get(k), dict): errs.append(f"audit[{i}].{k} obrigatório")
            for k in ("evidence", "findings"):
                if not isinstance(a.get(k), list): errs.append(f"audit[{i}].{k} deve ser lista")
    ig = x.get("integrity")
    if not isinstance(ig, dict) or ig.get("algorithm") != SPEC["hash_algorithm"] or not isinstance(ig.get("hash"), str):
        errs.append("integrity {algorithm, hash} obrigatório")
    elif not errs and package_hash(x) != ig["hash"]:
        errs.append("integrity.hash não confere: conteúdo alterado")
    return errs

def validate_response(x) -> list[str]:
    errs: list[str] = []
    if not isinstance(x, dict):
        return ["resposta não é objeto JSON"]
    if x.get("schema_version") != SPEC["response_schema"]:
        errs.append(f"schema_version '{x.get('schema_version')}' não suportado")
    for k in ("project_id", "project_hash", "audit_id", "execution_id", "layer_id", "report", "next_action", "created_at"):
        if not isinstance(x.get(k), str) or not x[k]: errs.append(f"{k} obrigatório")
    if not isinstance(x.get("project_version"), int): errs.append("project_version deve ser inteiro")
    if x.get("status") not in SPEC["response_status"]: errs.append(f"status inválido '{x.get('status')}'")
    for k in ("calculations", "findings", "missing_data", "evidence"):
        if not isinstance(x.get(k), list): errs.append(f"{k} deve ser lista")
    for i, c in enumerate(x.get("calculations") or []):
        if not isinstance(c, dict) or not c.get("name") or not c.get("equation"): errs.append(f"calculations[{i}] incompleto")
        else: check_q(f"calculations[{i}]", c.get("result"), errs)
    bad = [k for k in SPEC["response_forbidden_keys"] if k in x]
    if bad: errs.append(f"resposta externa não pode carregar alterações de motor/física ({', '.join(bad)})")
    if x.get("status") in ("APROVADO", "REPROVADO") and (not x.get("evidence") or not x.get("calculations")):
        errs.append(f"{x.get('status')} sem evidência e cálculos não é aceito")
    return errs
