"""Importador da Engrenagem Real: recebe o JSON do StreetRace, valida, registra (append-only) e devolve confirmação.
Recebimento NÃO é aprovação física: nesta etapa o status máximo devolvido é RECEBIDO."""
from __future__ import annotations
import json
from datetime import datetime, timezone
from pathlib import Path
from .contract import SPEC, validate_package, validate_response
from .units import display

class Ledger:
    """Histórico append-only em JSON Lines. Nunca reescreve linhas anteriores."""
    def __init__(self, path: str | Path):
        self.path = Path(path)
    def read(self) -> list[dict]:
        if not self.path.exists(): return []
        return [json.loads(l) for l in self.path.read_text(encoding="utf-8").splitlines() if l.strip()]
    def append(self, ev: dict) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(ev, ensure_ascii=False) + "\n")

def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"

def _report(pkg: dict) -> str:
    ide, cfg = pkg["identification"], pkg["configuration"]
    L = ["ENGRENAGEM REAL — CONFIRMAÇÃO DE RECEBIMENTO (não é aprovação física)",
         f"Projeto {ide['project_id']} v{ide['project_version']} · moto {ide['bike_id']} · motor {ide['engine_id']}",
         f"Origem {ide['source_system']} · criado {ide['created_at']} · hash {pkg['integrity']['hash']}", ""]
    for path in SPEC["units"]:
        g, k = path.split(".")
        L.append(f"  {path:42s} {display(cfg[g][k])}")
    L += ["", f"Dados ausentes ({len(pkg['missing_data'])}):", *[f"  - {m}" for m in pkg["missing_data"]],
          "", f"Auditoria da Wikipedia anexada: {len(pkg['audit'])} registro(s)",
          *[f"  [{a['test_status']}] {a['layer_id']}/{a['audit_id']}" for a in pkg["audit"]]]
    return "\n".join(L)

def receive(raw: str, ledger: Ledger) -> dict:
    """Recebe texto JSON e devolve a resposta do contrato realgear.response/1.0.0."""
    errs: list[str] = []
    try:
        pkg = json.loads(raw)
    except json.JSONDecodeError as e:
        pkg, errs = None, [f"JSON malformado: {e}"]
    if pkg is not None:
        errs = validate_package(pkg)
    ide = pkg.get("identification", {}) if isinstance(pkg, dict) else {}
    pid, ver = ide.get("project_id") or "?", ide.get("project_version") if isinstance(ide.get("project_version"), int) else -1
    h = (pkg.get("integrity") or {}).get("hash", "?") if isinstance(pkg, dict) else "?"
    status = "REJEITADO"
    if not errs:
        prev = [e for e in ledger.read() if e.get("kind") == "RECEIPT" and e.get("status") == "RECEBIDO" and e.get("project_id") == pid]
        same = next((e for e in prev if e["project_version"] == ver), None)
        if same and same["hash"] == h:
            status = "DUPLICADO"
        elif same:
            errs.append(f"versão {ver} já recebida com outro conteúdo (hash {same['hash']}): crie nova versão")
        elif prev and ver < max(e["project_version"] for e in prev):
            errs.append(f"versão {ver} é mais antiga que a última recebida ({max(e['project_version'] for e in prev)})")
        else:
            status = "RECEBIDO"
    n = len(ledger.read()) + 1
    exec_id = f"rg-{pid}-v{ver}-{n:06d}"
    ledger.append({"kind": "RECEIPT", "at": _now(), "project_id": pid, "project_version": ver, "hash": h, "status": status, "errors": errs, "execution_id": exec_id})
    resp = {
        "schema_version": SPEC["response_schema"], "project_id": pid, "project_version": ver, "project_hash": h,
        "audit_id": "BRIDGE-RECEIPT", "execution_id": exec_id, "layer_id": "BRIDGE-00", "status": status,
        "calculations": [], "findings": errs if errs else ([] if status == "RECEBIDO" else ["pacote idêntico já recebido: execução não repetida"]),
        "missing_data": pkg.get("missing_data", []) if isinstance(pkg, dict) and not errs else [],
        "evidence": [f"validate_package: {len(errs)} erro(s)", f"hash {h} conferido" if not errs else "hash não conferido"],
        "report": _report(pkg) if not errs else "Pacote rejeitado:\n" + "\n".join(f"  - {e}" for e in errs),
        "next_action": "Aguardar validação matemática independente do motor original (próxima etapa)" if status == "RECEBIDO" else ("Nenhuma: já recebido" if status == "DUPLICADO" else "Corrigir o pacote e exportar novamente"),
        "created_at": _now(),
    }
    assert not validate_response(resp), validate_response(resp)
    return resp
