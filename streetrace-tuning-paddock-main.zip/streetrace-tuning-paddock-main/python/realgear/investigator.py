"""Investigador do código (Python, só biblioteca padrão).

Lê o código-fonte REAL do repositório e investiga um FailureEvent (realgear.fix/1.0.0).
Mesmas regras do espelho TS (src/game/realgear/fix/investigator.ts). Sem regra demonstrável → determinado=False.

Uso: python -m realgear.investigator evento.json --repo /caminho/do/projeto
"""
import argparse, hashlib, json, math, re, sys
from pathlib import Path

SCHEMA = "realgear.fix/1.0.0"
MECH = "src/game/mechlimits.ts"
FUNNEL = "src/game/realgear/funnel.ts"


def r4(n):
    v = round(n * 1e4) / 1e4
    return int(v) if v == int(v) else v


def fmt(n):
    return str(r4(n))


def find_line(src, pattern):
    rx = re.compile(pattern)
    for i, line in enumerate(src.split("\n")):
        m = rx.search(line)
        if m:
            return i + 1, line, m
    return None


def occurrences(arquivo, src, pattern):
    rx = re.compile(pattern)
    return [{"arquivo": arquivo, "linha": i + 1, "trecho": l.strip()} for i, l in enumerate(src.split("\n")) if rx.search(l)]


def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def investigate(ev, repo):
    src = {k: (Path(repo) / k).read_text(encoding="utf-8") for k in (MECH, FUNNEL) if (Path(repo) / k).exists()}
    base = {"schema": SCHEMA, "kind": "PythonInvestigation", "failureId": ev["failureId"], "investigador": "python"}

    def done(**x):
        x.setdefault("faltando", [])
        x["investigationId"] = "INV-PY-" + hashlib.sha256(canonical({"f": ev["failureId"], "x": x}).encode()).hexdigest()[:12]
        return {**base, **x}

    tf = ev.get("testesFalhos", [])
    if ev["camada"]["n"] == 4 and any(t["nome"].startswith("Curso do modelo de quebras") for t in tf):
        s = find_line(src.get(MECH, ""), r"^const STROKE_MM = ([\d.]+);")
        f = find_line(src.get(FUNNEL, ""), r"^\s*" + re.escape(ev["bikeId"]) + r": \{ boreMm: ([\d.]+), strokeMm: ([\d.]+)")
        if not s and f:
            # sem constante fixa: a simulação usa o curso do catálogo (= ficha); a linha é a leitura no funil
            fl = find_line(src.get(FUNNEL, ""), r"const MECH_STROKE_MM = ov\.mechStrokeMm")
            if fl: s = (fl[0], fl[1], re.match(r"(.*)", f[2].group(2)))
        if not s or not f:
            falt = ([f'linha "const STROKE_MM" em {MECH}'] if not s else []) + ([f"ficha de fábrica (diâmetro × curso) de {ev['bikeId']} em {FUNNEL}"] if not f else [])
            return done(determinado=False, arquivo=None, funcao=None, linha=None, trecho=None, comportamentoAtual=ev["teste"]["observado"], comportamentoEsperado=ev["teste"]["esperado"], causa="Não determinada: fonte do dado ausente.", equacao="Vd = π/4 · D² · S", demonstracao=[], unidade="mm", dependencias=[], correcao=None, testesNecessarios=[], faltando=falt)
        src_val = float(s[2].group(1)); D = float(f[2].group(1)); S = float(f[2].group(2))
        run_val = float(ev.get("overrides", {}).get("mechStrokeMm", src_val))
        vd = lambda st: fmt(math.pi / 4 * D * D * st / 1000)
        deps = occurrences(MECH, src[MECH], r"\bSTROKE_MM\b") + [{"arquivo": FUNNEL, "linha": f[0], "trecho": f[1].strip()}]
        demo = [f"D = {fmt(D)} mm, S(ficha) = {fmt(S)} mm, S(código) = {fmt(src_val)} mm, S(execução) = {fmt(run_val)} mm",
                f"Vd(ficha) = π/4 · {fmt(D)}² · {fmt(S)} / 1000 = {vd(S)} cm³ (declarada {fmt(ev['ccDeclared'])} cm³)",
                f"Vd(execução) = π/4 · {fmt(D)}² · {fmt(run_val)} / 1000 = {vd(run_val)} cm³",
                f"Diferença de curso = {fmt(run_val - S)} mm ({fmt(100 * (run_val - S) / S)}%)"]
        testes = ["Camada 4: Curso do modelo de quebras = curso da ficha", "Camada 4: Vd(ficha) ≈ cilindrada declarada", "Regressão: camadas aprovadas de todos os projetos continuam aprovadas", "Corrida: engine()/stats() inalterados"]
        corr = {"key": "mechStrokeMm", "value": r4(S), "fonte": f"FICHA.{ev['bikeId']} em {FUNNEL}:{f[0]}"}
        if abs(run_val - S) < 0.05:
            return done(determinado=False, arquivo=MECH, funcao=None, linha=s[0], trecho=s[1], comportamentoAtual=ev["teste"]["observado"], comportamentoEsperado=ev["teste"]["esperado"], causa="Não determinada: curso em execução coincide com a ficha; a falha não vem do curso.", equacao="S_modelo = S_ficha", demonstracao=demo, unidade="mm", dependencias=deps, correcao=None, testesNecessarios=[], faltando=["evidência adicional da camada 4"])
        if run_val != src_val:
            fl = find_line(src.get(FUNNEL, ""), r"const MECH_STROKE_MM = ov\.mechStrokeMm")
            ratio = r4(src_val / run_val)
            unit = abs(ratio - 10) < 1e-6 or abs(ratio - 0.1) < 1e-6
            return done(determinado=True, arquivo=FUNNEL, funcao="runFunnel", linha=fl[0] if fl else None, trecho=fl[1].strip() if fl else None,
                        comportamentoAtual=f"curso em execução {fmt(run_val)} mm", comportamentoEsperado=f"curso {fmt(S)} mm (ficha)",
                        causa=f"Valor em execução ({fmt(run_val)} mm) difere do código-fonte ({fmt(src_val)} mm), razão {ratio}: " + ("erro de conversão de unidade (cm tratado como mm)." if unit else "valor alterado em execução."),
                        equacao="Vd = π/4 · D² · S", demonstracao=demo, unidade="mm", dependencias=deps, correcao=corr, testesNecessarios=testes)
        return done(determinado=True, arquivo=MECH, funcao="módulo mechlimits (constante lida por buildOf, telemetria e laudo)", linha=s[0], trecho=s[1],
                    comportamentoAtual=f"STROKE_MM = {fmt(src_val)} mm para todas as motos", comportamentoEsperado=f"curso por moto; {ev['bikeId']} = {fmt(S)} mm (ficha)",
                    causa=f"Constante universal STROKE_MM = {fmt(src_val)} mm aplicada a todas as motos; a ficha de {ev['bikeId']} tem curso {fmt(S)} mm.",
                    equacao="Vd = π/4 · D² · S ; λ = (S/2)/L", demonstracao=demo, unidade="mm", dependencias=deps, correcao=corr, testesNecessarios=testes)
    nome = ev["teste"]["nome"]
    loc = find_line(src.get(FUNNEL, ""), r'T\("' + re.escape(nome[:18]))
    return done(determinado=False, arquivo=FUNNEL if loc else None, funcao="runFunnel" if loc else None, linha=loc[0] if loc else None, trecho=loc[1].strip() if loc else None,
                comportamentoAtual=ev["teste"]["observado"], comportamentoEsperado=ev["teste"]["esperado"], causa="Não determinada: não há regra que demonstre a causa no código.",
                equacao=" ; ".join(f["eq"] for f in ev.get("formula", [])) or "—", demonstracao=[], unidade="—", dependencias=[], correcao=None, testesNecessarios=[],
                faltando=ev.get("ausentes") or [f'regra de investigação para o teste "{nome}" (camada {ev["camada"]["n"]})'])


def main(argv=None):
    ap = argparse.ArgumentParser(description="Investigador do código da Engrenagem Real")
    ap.add_argument("evento"); ap.add_argument("--repo", default=".")
    a = ap.parse_args(argv)
    ev = json.loads(Path(a.evento).read_text(encoding="utf-8"))
    if ev.get("schema") != SCHEMA or ev.get("kind") != "FailureEvent":
        print(json.dumps({"erro": "evento inválido"}), file=sys.stderr); return 2
    print(json.dumps(investigate(ev, a.repo), ensure_ascii=False, indent=2)); return 0


if __name__ == "__main__":
    sys.exit(main())
