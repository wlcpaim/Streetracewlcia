"""Testes da ponte (unittest, biblioteca padrão). Rodar: cd python && python3 -m unittest discover -s tests -v"""
import copy, json, tempfile, unittest
from pathlib import Path
from realgear import Ledger, receive, validate_package, validate_response, package_hash
from realgear.contract import canonical

EX = Path(__file__).resolve().parents[1] / "realgear" / "examples" / "cg160-original.v1.json"

def pkg():
    return json.loads(EX.read_text(encoding="utf-8"))

def rehash(p):
    p["integrity"]["hash"] = package_hash(p); return p

class Bridge(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.led = Ledger(Path(self.tmp.name) / "l.jsonl")
    def tearDown(self):
        self.tmp.cleanup()

    def test_exemplo_real_valido_e_hash_igual_ao_typescript(self):
        p = pkg(); self.assertEqual(validate_package(p), []); self.assertEqual(package_hash(p), p["integrity"]["hash"])
    def test_recebe_sem_aprovar(self):
        r = receive(EX.read_text(encoding="utf-8"), self.led)
        self.assertEqual(r["status"], "RECEBIDO"); self.assertEqual(r["project_id"], "stock-titan160"); self.assertEqual(r["project_version"], 1)
        self.assertEqual(r["calculations"], []); self.assertNotIn(r["status"], ("APROVADO",)); self.assertEqual(validate_response(r), [])
    def test_campo_obrigatorio_ausente(self):
        p = pkg(); del p["configuration"]["geometry"]["bore"]
        self.assertIn("configuration.geometry.bore obrigatório", validate_package(p))
    def test_unidade_incompativel(self):
        p = pkg(); p["configuration"]["geometry"]["bore"]["unit"] = "mm"
        self.assertTrue(any("unidade incompatível" in e for e in validate_package(p)))
    def test_valor_inventado_em_desconhecido(self):
        p = pkg(); p["configuration"]["geometry"]["rod_length"]["value"] = 0.1
        self.assertTrue(any("DESCONHECIDO não pode ter valor" in e for e in validate_package(p)))
    def test_conteudo_alterado_quebra_hash(self):
        p = pkg(); p["configuration"]["geometry"]["compression_ratio"]["value"] = 12.0
        self.assertIn("integrity.hash não confere: conteúdo alterado", validate_package(p))
    def test_duplicado_nao_reexecuta(self):
        raw = EX.read_text(encoding="utf-8"); receive(raw, self.led)
        self.assertEqual(receive(raw, self.led)["status"], "DUPLICADO")
    def test_mesma_versao_conteudo_diferente_rejeita(self):
        receive(EX.read_text(encoding="utf-8"), self.led)
        p = pkg(); p["configuration"]["geometry"]["compression_ratio"]["value"] = 10.0; rehash(p)
        self.assertEqual(receive(json.dumps(p), self.led)["status"], "REJEITADO")
    def test_versao_antiga_rejeitada(self):
        p2 = pkg(); p2["identification"]["project_version"] = 2; rehash(p2); receive(json.dumps(p2), self.led)
        r = receive(EX.read_text(encoding="utf-8"), self.led)
        self.assertEqual(r["status"], "REJEITADO"); self.assertTrue(any("mais antiga" in f for f in r["findings"]))
    def test_json_malformado(self):
        r = receive("{ isso não é json", self.led)
        self.assertEqual(r["status"], "REJEITADO"); self.assertTrue(r["findings"][0].startswith("JSON malformado"))
    def test_ledger_append_only(self):
        raw = EX.read_text(encoding="utf-8"); receive(raw, self.led); first = self.led.path.read_text(encoding="utf-8")
        receive(raw, self.led); self.assertTrue(self.led.path.read_text(encoding="utf-8").startswith(first))
    def test_resposta_aprovada_sem_evidencia_invalida(self):
        r = receive(EX.read_text(encoding="utf-8"), self.led); r = copy.deepcopy(r); r["status"] = "APROVADO"; r["evidence"] = []
        self.assertTrue(any("sem evidência" in e for e in validate_response(r)))
    def test_resposta_nao_carrega_setup(self):
        r = receive(EX.read_text(encoding="utf-8"), self.led); r["setup"] = {"compression": 14}
        self.assertTrue(any("não pode carregar" in e for e in validate_response(r)))
    def test_canonico_numeros(self):
        self.assertEqual(canonical({"b": 0.0001627, "a": 22.0, "c": 9.5}), '{"a":22,"b":1.62700000000e-4,"c":9.50000000000e0}')

if __name__ == "__main__":
    unittest.main()
