# Engrenagem Real — Python

Lado Python da ponte com a Wikipedia StreetRace. Só biblioteca padrão (Python 3.10+), nada para instalar.

## Contrato
`realgear/contract_v1.json` é o contrato único: versões de esquema, grupos obrigatórios, unidade SI exigida por grandeza,
origens aceitas (MEDIDO, FICHA, JOGO, CALCULADO, ESTIMADO, DESCONHECIDO) e status de resposta.
Cada grandeza é `{ "value": número|null, "unit": "SI", "origin": "...", "source": "..." }`; `null` só com `DESCONHECIDO`.
O hash `fnv1a32-canon-v1` (JSON canônico, chaves ordenadas, números em notação fixa) é idêntico no TypeScript e no Python.

## Uso
1. No jogo: `/realgear` → aba **Ponte Python** → **EXPORTAR JSON** (ou `bun scripts/realgear-export.ts`).
2. Receber no Python:
   ```
   cd python
   python3 -m realgear receive realgear/examples/cg160-original.v1.json --out resposta.json --ledger realgear-ledger.jsonl
   ```
3. No jogo: **Carregar resposta do Python** com o `resposta.json`.

Status de recebimento: RECEBIDO, DUPLICADO ou REJEITADO. Receber **não** é aprovação física.

## Testes
```
cd python && python3 -m unittest discover -s tests -v
```
